# ApplyCaptain Brand System
*Navigate Your Career with Confidence*

## Brand Overview
ApplyCaptain is an AI-powered job application assistant that uses nautical metaphors to guide users through their career journey. The brand positions itself as a trusted captain navigating the sometimes turbulent waters of job searching.

## Color Palette

### Primary Colors (Nautical Navy)
- **Navy**: `hsl(210, 100%, 8%)` - Deep ocean depths, primary backgrounds
- **Deep Blue**: `hsl(215, 84%, 15%)` - Secondary navy, cards and sections
- **Ocean**: `hsl(220, 76%, 25%)` - Interactive elements, hover states

### Accent Colors (Captain's Gold)
- **Anchor Gold**: `hsl(45, 100%, 55%)` - Primary accent, CTAs, highlights
- **Compass**: `hsl(45, 95%, 60%)` - Hover states, active elements
- **Lighthouse**: `hsl(45, 90%, 45%)` - Subtle accents, icons

### Neutral Colors (Ship Elements)
- **Deck**: `hsl(210, 25%, 98%)` - Light backgrounds, cards in light mode
- **Sail**: `hsl(0, 0%, 100%)` - Pure white, text on dark backgrounds
- **Mist**: `hsl(210, 25%, 95%)` - Subtle backgrounds
- **Seafoam**: `hsl(180, 25%, 85%)` - Light blue-green, inactive states
- **Wave**: `hsl(210, 15%, 75%)` - Medium gray, secondary text
- **Storm**: `hsl(210, 10%, 45%)` - Dark gray, body text
- **Anchor**: `hsl(210, 15%, 15%)` - Near black, headings

## Typography

### Headings
- **Font**: Inter (primary), Playfair Display (serif fallback)
- **Weight**: 700 (bold)
- **Letter Spacing**: -0.02em (tight)
- **Class**: `.captain-heading`

### Body Text
- **Font**: Inter, system-ui, sans-serif
- **Weight**: 400 (regular)
- **Line Height**: 1.6
- **Class**: `.captain-body`

## Logo System

### Icon Design
- **Shape**: Rotated anchor (-12 degrees) in golden gradient container
- **Container**: Rounded rectangle with gradient from yellow-400 to yellow-600
- **Sizes**: sm (32px), md (48px), lg (64px), xl (80px)

### Wordmark
- **Primary**: "ApplyCaptain" in captain-heading font
- **Tagline**: "Navigate Your Career" in smaller captain-body font
- **Color Variants**: Light (white), Dark (slate-900), Color (slate-900)

### Usage
```jsx
<CaptainLogo size="lg" variant="light" showText={true} />
```

## Dark/Light Compatibility

### Dark Mode (Default)
- Background: Navy gradient
- Text: White/light variants
- Accents: Gold gradients
- Glass morphism effects with white transparency

### Light Mode
- Background: Deck/Sail colors
- Text: Anchor/Storm colors
- Accents: Maintained gold system
- Subtle shadows and borders

## Nautical Metaphors & Messaging

### Core Concepts
- **Captain**: AI assistant guiding the journey
- **Navigation**: Job search strategy and direction
- **Voyage**: Job search process
- **Fleet**: Collection of job opportunities
- **Harbor**: Secure data storage
- **Chart/Compass**: Resume optimization and career planning
- **Anchor**: Stability and trust
- **Set Sail**: Begin job search process

### Voice & Tone
- **Confident**: Authoritative but approachable
- **Nautical**: Consistent maritime terminology
- **Professional**: Serious about career advancement
- **Supportive**: Guiding users through challenges

### Key Messages
- "Chart Your Course to Success"
- "Navigate Your Career with Confidence"
- "Let Your Captain Handle the Navigation"
- "Set Sail Toward Your Dream Career"

## UI Components

### Gradients
```css
.bg-captain-gradient {
  background: linear-gradient(135deg, var(--brand-navy) 0%, var(--brand-deep-blue) 40%, var(--brand-ocean) 100%);
}

.text-captain-gold {
  background: linear-gradient(135deg, var(--brand-anchor-gold) 0%, var(--brand-compass) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
```

### Glass Morphism
- Background: `rgba(255, 255, 255, 0.1)`
- Backdrop blur: 20px
- Border: `rgba(255, 255, 255, 0.15)`

### Buttons
- **Primary**: Gold gradient with navy text
- **Secondary**: Glass morphism with white text
- **Hover**: Enhanced gold brightness

## Icon Usage

### Primary Icons
- **Compass**: Navigation, direction-finding
- **Anchor**: Stability, core features
- **Navigation/Helm**: Control, automation
- **Shield**: Security, privacy
- **BarChart3**: Analytics, progress tracking

### Implementation
All icons should use consistent sizing and the established color system. Maritime icons are preferred when available.

## Brand Applications

### Landing Page
- Navy gradient background with gold accents
- Nautical terminology throughout
- Captain's bridge metaphor for dashboard sections

### Dashboard
- Captain's log for analytics
- Fleet operations for job management
- Navigation charts for resume optimization

### Mobile
- Condensed logo without tagline
- Maintained color relationships
- Touch-friendly gold CTAs

## Usage Guidelines

### Do's
- Use nautical terminology consistently
- Maintain color hierarchy (navy → gold)
- Apply captain-heading to all major headings
- Use glass morphism for floating elements

### Don'ts
- Mix non-nautical metaphors
- Use colors outside the established palette
- Override typography classes
- Break the captain/navigator relationship

## File References
- Logo Component: `/components/ui/captain-logo.tsx`
- CSS Variables: `/index.css` (lines 27-45)
- Brand Classes: `/index.css` (lines 113-135)