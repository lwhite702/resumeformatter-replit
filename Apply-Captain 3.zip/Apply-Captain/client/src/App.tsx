import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SignedIn, SignedOut } from "@clerk/clerk-react";
import ErrorBoundary from "@/components/ui/error-boundary";
import NotFound from "@/pages/not-found";
import LandingUnified from "@/pages/landing-unified";
import Blog from "@/pages/blog";
import Legal from "@/pages/legal-wordpress";
import Admin from "@/pages/admin";
import AdminDocs from "@/pages/admin-docs";
import AdminSettings from "@/pages/admin-settings";
import Dashboard from "@/pages/dashboard";
import DailyQueue from "@/pages/daily-queue";
import ApplyJobs from "@/pages/apply-jobs";
import ApplicationHistory from "@/pages/application-history";
import RulesEngine from "@/pages/rules-engine";
import ResumeLibrary from "@/pages/resume-library";
import Settings from "@/pages/settings";
import AIAssistant from "@/pages/ai-assistant";
import KnowledgeBase from "@/pages/knowledge-base";
import OnboardingTestPage from "@/pages/onboarding-test-page";
import LandingAds from "@/pages/landing-ads";
import LandingSocial from "@/pages/landing-social";
import LandingReferral from "@/pages/landing-referral";
import ModernSidebar from "@/components/ui/modern-sidebar";
import Header from "@/components/header";
import { ToastNotifications } from "@/components/toast-notifications";
import { LoadingModal } from "@/components/loading-modal";
import { FloatingHelpWidget } from "@/components/ui/floating-help-widget";

function Router() {
  return (
    <>
      <SignedOut>
        <Switch>
          <Route path="/" component={LandingUnified} />
          <Route path="/ads" component={LandingAds} />
          <Route path="/social" component={LandingSocial} />
          <Route path="/ref" component={LandingReferral} />
          <Route path="/blog" component={Blog} />
          <Route path="/blog/:slug" component={Blog} />
          <Route path="/legal" component={Legal} />
          <Route path="/legal/:section" component={Legal} />
          <Route component={NotFound} />
        </Switch>
      </SignedOut>

      <SignedIn>
        <div className="flex min-h-screen bg-gradient-to-br from-slate-50 to-white">
          <ModernSidebar />

          <div className="ml-72 flex-1 flex flex-col min-h-screen">
            <Header />

            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/daily-queue" component={DailyQueue} />
              <Route path="/apply" component={ApplyJobs} />
              <Route path="/history" component={ApplicationHistory} />
              <Route path="/rules" component={RulesEngine} />
              <Route path="/resumes" component={ResumeLibrary} />
              <Route path="/settings" component={Settings} />
              <Route path="/ai-assistant" component={AIAssistant} />
              <Route path="/knowledge-base" component={KnowledgeBase} />
              <Route path="/test-onboarding" component={OnboardingTestPage} />
              <Route path="/blog" component={Blog} />
              <Route path="/blog/:slug" component={Blog} />
              <Route path="/legal" component={Legal} />
              <Route path="/legal/:section" component={Legal} />
              <Route path="/admin" component={Admin} />
              <Route path="/admin/settings" component={AdminSettings} />
              <Route path="/admin/docs" component={AdminDocs} />
              <Route path="/admin/docs/:section" component={AdminDocs} />
              <Route component={NotFound} />
            </Switch>
          </div>

          <ToastNotifications />
          <LoadingModal />
          <FloatingHelpWidget />
        </div>
      </SignedIn>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <a href="#main-content" className="skip-to-main">
          Skip to main content
        </a>
        <ErrorBoundary>
          <Router />
        </ErrorBoundary>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;