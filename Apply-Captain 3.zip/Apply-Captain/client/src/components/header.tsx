import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const [quickApplyEnabled, setQuickApplyEnabled] = useState(true);
  const { toast } = useToast();

  const toggleQuickApply = () => {
    setQuickApplyEnabled(!quickApplyEnabled);
    toast({
      title: quickApplyEnabled ? "Quick Apply disabled" : "Quick Apply enabled",
      description: quickApplyEnabled 
        ? "You can still apply manually to jobs" 
        : "Jobs will be applied to automatically when conditions are met",
    });
  };

  return (
    <header className="bg-white border-b brand-border px-8 py-5 shadow-soft">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold brand-text-primary text-display">Dashboard</h2>
          <p className="text-sm brand-text-secondary mt-1">Welcome back to your job application command center</p>
        </div>
        <div className="flex items-center space-x-6">
          {/* Quick Apply Toggle */}
          <div className="flex items-center space-x-3 p-3 rounded-xl bg-brand-surface">
            <span className="text-sm font-medium brand-text-primary">Auto-Apply</span>
            <button 
              onClick={toggleQuickApply}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2 ${
                quickApplyEnabled ? "bg-brand-accent" : "bg-gray-300"
              }`}
            >
              <span 
                className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform duration-200 ${
                  quickApplyEnabled ? "translate-x-6" : "translate-x-1"
                }`} 
              />
            </button>
            <span className={`text-xs font-medium ${quickApplyEnabled ? "brand-accent" : "brand-text-secondary"}`}>
              {quickApplyEnabled ? "ON" : "OFF"}
            </span>
          </div>
          
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative p-3 rounded-xl hover:bg-brand-surface transition-colors">
            <i className="fas fa-bell text-lg brand-text-secondary"></i>
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center font-medium shadow-sm">
              3
            </span>
          </Button>
        </div>
      </div>
    </header>
  );
}
