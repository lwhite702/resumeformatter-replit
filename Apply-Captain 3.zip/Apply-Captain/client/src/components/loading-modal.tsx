import { create } from "zustand";

interface LoadingState {
  isOpen: boolean;
  title: string;
  message: string;
  show: (title: string, message: string) => void;
  hide: () => void;
}

export const useLoadingModal = create<LoadingState>((set) => ({
  isOpen: false,
  title: "",
  message: "",
  show: (title: string, message: string) => set({ isOpen: true, title, message }),
  hide: () => set({ isOpen: false, title: "", message: "" }),
}));

export function LoadingModal() {
  const { isOpen, title, message } = useLoadingModal();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-gray-900 bg-opacity-50"></div>
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="bg-white rounded-lg p-6 flex items-center space-x-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-wrelik-blue"></div>
          <div>
            <p className="font-medium text-gray-900">{title}</p>
            <p className="text-sm text-gray-600">{message}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
