import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function Sidebar() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const navigationItems = [
    { href: "/", icon: "fas fa-home", label: "Dashboard" },
    { href: "/daily-queue", icon: "fas fa-clock", label: "Daily Queue" },
    { href: "/apply", icon: "fas fa-paper-plane", label: "Apply to Jobs" },
    { href: "/history", icon: "fas fa-history", label: "Application History" },
    { href: "/rules", icon: "fas fa-cog", label: "Auto-Apply Rules" },
    { href: "/resumes", icon: "fas fa-file-alt", label: "Resume Library" },
    { href: "/settings", icon: "fas fa-user-cog", label: "Settings" },
  ];

  const isActive = (href: string) => {
    return location === href || (href !== "/" && location.startsWith(href));
  };

  return (
    <div className="fixed inset-y-0 left-0 w-72 bg-white border-r brand-border shadow-soft z-40">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center px-6 py-6 border-b brand-border bg-gradient-to-r from-white to-brand-surface">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-brand-primary rounded-xl flex items-center justify-center shadow-brand">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-white">
                <path d="M12 2L2 7v10c0 5.55 3.84 9.95 9 11 5.16-1.05 9-5.45 9-11V7l-10-5z" fill="currentColor"/>
                <path d="M8 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
              </svg>
            </div>
            <div className="ml-4">
              <h1 className="text-xl font-bold brand-text-primary text-display">AutoApply</h1>
              <p className="text-sm brand-accent font-medium">by Wrelik</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navigationItems.map((item) => (
            <button
              key={item.href}
              onClick={() => setLocation(item.href)}
              className={`group w-full flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 ${
                isActive(item.href)
                  ? "bg-brand-accent text-white shadow-brand"
                  : "brand-text-secondary hover:bg-brand-surface hover:brand-text-primary"
              }`}
            >
              <i className={`${item.icon} mr-4 text-base ${
                isActive(item.href) ? "text-white" : "brand-text-secondary group-hover:brand-accent"
              }`}></i>
              <span className="text-body">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="px-4 py-6 border-t brand-border bg-gradient-to-r from-brand-surface to-white">
          <div className="flex items-center p-3 rounded-xl bg-white shadow-soft">
            <div className="w-10 h-10 bg-gradient-to-br from-brand-accent to-brand-accent-light rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-sm">
                {(user as any)?.firstName?.charAt(0) || "U"}
              </span>
            </div>
            <div className="ml-3 flex-1">
              <p className="text-sm font-semibold brand-text-primary">
                {(user as any)?.firstName && (user as any)?.lastName 
                  ? `${(user as any).firstName} ${(user as any).lastName}` 
                  : (user as any)?.email || "User"}
              </p>
              <p className="text-xs brand-accent font-medium">Pro Plan</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
