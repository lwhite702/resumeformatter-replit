
import * as React from "react";
import { cn } from "@/lib/utils";

interface AccessibleCardProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: keyof JSX.IntrinsicElements;
  focusable?: boolean;
  role?: string;
}

const AccessibleCard = React.forwardRef<HTMLDivElement, AccessibleCardProps>(
  ({ className, as: Component = "div", focusable = false, role, children, ...props }, ref) => {
    const cardProps = {
      ref,
      className: cn(
        "rounded-xl border bg-card text-card-foreground shadow",
        focusable && "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500",
        className
      ),
      ...(focusable && { tabIndex: 0 }),
      ...(role && { role }),
      ...props
    };

    return React.createElement(Component, cardProps, children);
  }
);

AccessibleCard.displayName = "AccessibleCard";

const AccessibleCardHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("flex flex-col space-y-1.5 p-6", className)}
    {...props}
  />
));
AccessibleCardHeader.displayName = "AccessibleCardHeader";

const AccessibleCardTitle = React.forwardRef<
  HTMLHeadingElement,
  React.HTMLAttributes<HTMLHeadingElement> & { level?: 1 | 2 | 3 | 4 | 5 | 6 }
>(({ className, level = 3, ...props }, ref) => {
  const Heading = `h${level}` as keyof JSX.IntrinsicElements;
  
  return React.createElement(Heading, {
    ref,
    className: cn("font-semibold leading-none tracking-tight", className),
    ...props
  });
});
AccessibleCardTitle.displayName = "AccessibleCardTitle";

const AccessibleCardDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
AccessibleCardDescription.displayName = "AccessibleCardDescription";

const AccessibleCardContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
));
AccessibleCardContent.displayName = "AccessibleCardContent";

const AccessibleCardFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("flex items-center p-6 pt-0", className)}
    {...props}
  />
));
AccessibleCardFooter.displayName = "AccessibleCardFooter";

export {
  AccessibleCard,
  AccessibleCardHeader,
  AccessibleCardFooter,
  AccessibleCardTitle,
  AccessibleCardDescription,
  AccessibleCardContent,
};
