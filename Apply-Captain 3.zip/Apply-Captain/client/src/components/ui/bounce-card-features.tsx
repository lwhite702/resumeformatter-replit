import React from "react";
import { motion } from "framer-motion";

export const BouncyCardsFeatures = () => {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 text-gray-900">
      <div className="mb-12 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end md:px-8">
        <h2 className="max-w-lg text-4xl font-bold md:text-5xl text-display">
          Revolutionize your job search with
          <span className="text-brand-accent"> intelligent automation</span>
        </h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => window.location.href = "/daily-queue"}
          className="whitespace-nowrap rounded-xl bg-gradient-to-r from-brand-primary to-brand-secondary px-6 py-3 font-semibold text-white shadow-xl transition-colors hover:from-brand-secondary hover:to-brand-primary"
        >
          View Demo
        </motion.button>
      </div>
      <div className="mb-4 grid grid-cols-12 gap-4">
        <BounceCard className="col-span-12 md:col-span-4">
          <CardTitle>AI Job Matching</CardTitle>
          <div className="absolute bottom-0 left-4 right-4 top-32 translate-y-8 rounded-t-2xl bg-gradient-to-br from-blue-500 to-brand-primary p-6 transition-transform duration-[250ms] group-hover:translate-y-4 group-hover:rotate-[2deg]">
            <div className="text-white space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Match Score</span>
                <span className="text-lg font-bold">92%</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div className="bg-white h-2 rounded-full w-[92%]"></div>
              </div>
              <div className="text-xs opacity-90">
                Senior Developer • Remote • $120k-160k
              </div>
            </div>
          </div>
        </BounceCard>
        <BounceCard className="col-span-12 md:col-span-8">
          <CardTitle>Daily Queue Automation</CardTitle>
          <div className="absolute bottom-0 left-4 right-4 top-32 translate-y-8 rounded-t-2xl bg-gradient-to-br from-brand-accent to-teal-500 p-6 transition-transform duration-[250ms] group-hover:translate-y-4 group-hover:rotate-[2deg]">
            <div className="text-white space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-lg font-bold">5</div>
                  <div className="text-xs opacity-90">Queued</div>
                </div>
                <div>
                  <div className="text-lg font-bold">12</div>
                  <div className="text-xs opacity-90">Applied</div>
                </div>
                <div>
                  <div className="text-lg font-bold">3</div>
                  <div className="text-xs opacity-90">Interviews</div>
                </div>
              </div>
              <div className="text-center text-sm font-medium">
                Next batch: 9:00 AM
              </div>
            </div>
          </div>
        </BounceCard>
      </div>
      <div className="grid grid-cols-12 gap-4">
        <BounceCard className="col-span-12 md:col-span-8">
          <CardTitle>Smart Resume Optimization</CardTitle>
          <div className="absolute bottom-0 left-4 right-4 top-32 translate-y-8 rounded-t-2xl bg-gradient-to-br from-emerald-500 to-green-600 p-6 transition-transform duration-[250ms] group-hover:translate-y-4 group-hover:rotate-[2deg]">
            <div className="text-white space-y-3">
              <div className="flex items-center space-x-2">
                <i className="fas fa-file-alt text-lg"></i>
                <span className="font-medium">ResumeFormatter.io</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Frontend Resume</span>
                  <span className="text-green-200">✓ Optimized</span>
                </div>
                <div className="flex justify-between">
                  <span>Backend Resume</span>
                  <span className="text-green-200">✓ Optimized</span>
                </div>
                <div className="flex justify-between">
                  <span>Full-Stack Resume</span>
                  <span className="text-green-200">✓ Optimized</span>
                </div>
              </div>
            </div>
          </div>
        </BounceCard>
        <BounceCard className="col-span-12 md:col-span-4">
          <CardTitle>Email Parsing</CardTitle>
          <div className="absolute bottom-0 left-4 right-4 top-32 translate-y-8 rounded-t-2xl bg-gradient-to-br from-purple-500 to-pink-500 p-6 transition-transform duration-[250ms] group-hover:translate-y-4 group-hover:rotate-[2deg]">
            <div className="text-white space-y-3">
              <div className="flex items-center space-x-2">
                <i className="fas fa-envelope text-lg"></i>
                <span className="text-sm font-medium">Job Alerts</span>
              </div>
              <div className="space-y-2">
                <div className="bg-white/20 rounded p-2 text-xs">
                  <div className="font-medium">MetaCorp</div>
                  <div className="opacity-90">Frontend Dev</div>
                  <div className="text-purple-200">92% confidence</div>
                </div>
                <div className="text-center text-xs">
                  Auto-parsed from Gmail
                </div>
              </div>
            </div>
          </div>
        </BounceCard>
      </div>
    </section>
  );
};

const BounceCard = ({ className, children }: { className?: string; children: React.ReactNode }) => {
  return (
    <motion.div
      whileHover={{ scale: 0.95, rotate: "-1deg" }}
      className={`group relative min-h-[300px] cursor-pointer overflow-hidden rounded-2xl bg-white border border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300 p-8 ${className}`}
    >
      {children}
    </motion.div>
  );
};

const CardTitle = ({ children }: { children: React.ReactNode }) => {
  return (
    <h3 className="mx-auto text-center text-2xl font-bold text-gray-900 mb-4">{children}</h3>
  );
};