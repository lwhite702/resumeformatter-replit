import { Anchor } from "lucide-react";

interface CaptainLogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "light" | "dark" | "color";
  showText?: boolean;
  className?: string;
}

export function CaptainLogo({ 
  size = "md", 
  variant = "light", 
  showText = true, 
  className = "" 
}: CaptainLogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12", 
    lg: "w-16 h-16",
    xl: "w-20 h-20"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-3xl", 
    xl: "text-4xl"
  };

  const iconColorClasses = {
    light: "text-white",
    dark: "text-slate-900",
    color: "text-captain-gold"
  };

  const textColorClasses = {
    light: "text-white",
    dark: "text-slate-900", 
    color: "text-slate-900"
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Captain's Anchor Icon */}
      <div className={`${sizeClasses[size]} bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-xl flex items-center justify-center shadow-lg transform -rotate-12`}>
        <Anchor className={`${size === 'sm' ? 'w-4 h-4' : size === 'md' ? 'w-6 h-6' : size === 'lg' ? 'w-8 h-8' : 'w-10 h-10'} text-white`} />
      </div>

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col">
          <h1 className={`${textSizeClasses[size]} font-bold captain-heading ${textColorClasses[variant]} leading-tight`}>
            ApplyCaptain
          </h1>
          {size !== 'sm' && (
            <p className={`text-xs ${variant === 'light' ? 'text-white/70' : variant === 'dark' ? 'text-slate-600' : 'text-slate-600'} captain-body tracking-wide`}>
              Navigate Your Career
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export function CaptainFavicon() {
  return (
    <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-lg flex items-center justify-center">
      <Anchor className="w-4 h-4 text-white transform -rotate-12" />
    </div>
  );
}