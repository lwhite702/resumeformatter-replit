import { motion } from "framer-motion";

interface CaptainsWheelProps {
  progress: number; // 0-100
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function CaptainsWheel({ progress, size = "md", className = "" }: CaptainsWheelProps) {
  const sizeClasses = {
    sm: "w-16 h-16",
    md: "w-24 h-24", 
    lg: "w-32 h-32"
  };

  const wheelRotation = (progress / 100) * 360;

  return (
    <div className={`relative ${sizeClasses[size]} ${className}`}>
      {/* Outer Ring */}
      <div className="absolute inset-0 rounded-full border-4 border-white/20"></div>
      
      {/* Progress Ring */}
      <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
        <circle
          cx="50"
          cy="50"
          r="46"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={`${progress * 2.89} 289`}
          className="text-yellow-400 transition-all duration-500 ease-out"
        />
      </svg>

      {/* Captain's Wheel */}
      <motion.div
        className="absolute inset-2 flex items-center justify-center"
        animate={{ rotate: wheelRotation }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full text-white">
          {/* Center Hub */}
          <circle cx="50" cy="50" r="8" fill="currentColor" />
          
          {/* Spokes */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, index) => (
            <line
              key={index}
              x1="50"
              y1="50"
              x2={50 + 35 * Math.cos((angle * Math.PI) / 180)}
              y2={50 + 35 * Math.sin((angle * Math.PI) / 180)}
              stroke="currentColor"
              strokeWidth="2"
            />
          ))}
          
          {/* Handles */}
          {[0, 90, 180, 270].map((angle, index) => (
            <circle
              key={index}
              cx={50 + 35 * Math.cos((angle * Math.PI) / 180)}
              cy={50 + 35 * Math.sin((angle * Math.PI) / 180)}
              r="3"
              fill="currentColor"
            />
          ))}
        </svg>
      </motion.div>

      {/* Progress Text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-white font-bold text-sm">{Math.round(progress)}%</span>
      </div>
    </div>
  );
}