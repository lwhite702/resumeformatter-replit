import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  HelpCircle, 
  ChevronRight, 
  Clock, 
  CheckCircle,
  AlertCircle,
  Info,
  Lightbulb,
  Target,
  Zap
} from "lucide-react";

interface ContextualTip {
  id: string;
  title: string;
  description: string;
  type: "tip" | "warning" | "info" | "success";
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ContextualHelpProps {
  page: "daily-queue" | "resume-library" | "rules-engine" | "settings" | "application-history";
  tips: ContextualTip[];
  onboardingStep?: number;
}

export function ContextualHelp({ page, tips, onboardingStep }: ContextualHelpProps) {
  const [showDialog, setShowDialog] = useState(false);

  const getPageTitle = (page: string) => {
    switch (page) {
      case "daily-queue": return "Daily Queue Help";
      case "resume-library": return "Resume Library Help";
      case "rules-engine": return "Auto-Apply Rules Help";
      case "settings": return "Settings Help";
      case "application-history": return "Application History Help";
      default: return "Help";
    }
  };

  const getPageDescription = (page: string) => {
    switch (page) {
      case "daily-queue": return "Navigate your daily job opportunities effectively";
      case "resume-library": return "Manage and optimize your resumes";
      case "rules-engine": return "Set up intelligent automation rules";
      case "settings": return "Configure your job search preferences";
      case "application-history": return "Track and analyze your applications";
      default: return "Get help with this feature";
    }
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case "tip": return <Lightbulb className="h-4 w-4 text-yellow-600" />;
      case "warning": return <AlertCircle className="h-4 w-4 text-orange-600" />;
      case "info": return <Info className="h-4 w-4 text-blue-600" />;
      case "success": return <CheckCircle className="h-4 w-4 text-green-600" />;
      default: return <Info className="h-4 w-4 text-gray-600" />;
    }
  };

  const getCardStyle = (type: string) => {
    switch (type) {
      case "tip": return "border-yellow-200 bg-yellow-50";
      case "warning": return "border-orange-200 bg-orange-50";
      case "info": return "border-blue-200 bg-blue-50";
      case "success": return "border-green-200 bg-green-50";
      default: return "border-gray-200 bg-gray-50";
    }
  };

  return (
    <div className="space-y-4">
      {/* Inline Tips */}
      {tips.slice(0, 2).map((tip) => (
        <Card key={tip.id} className={`border ${getCardStyle(tip.type)}`}>
          <CardContent className="pt-4">
            <div className="flex items-start space-x-3">
              {getIconForType(tip.type)}
              <div className="flex-1">
                <h4 className="font-medium text-sm">{tip.title}</h4>
                <p className="text-sm text-gray-600 mt-1">{tip.description}</p>
                {tip.action && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2"
                    onClick={tip.action.onClick}
                  >
                    {tip.action.label}
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {/* More Help Dialog */}
      {tips.length > 2 && (
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="w-full">
              <HelpCircle className="h-4 w-4 mr-2" />
              More Help for {getPageTitle(page).replace(" Help", "")}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{getPageTitle(page)}</DialogTitle>
              <DialogDescription>
                {getPageDescription(page)}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 mt-4">
              {tips.map((tip) => (
                <Card key={tip.id} className={`border ${getCardStyle(tip.type)}`}>
                  <CardContent className="pt-4">
                    <div className="flex items-start space-x-3">
                      {getIconForType(tip.type)}
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{tip.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{tip.description}</p>
                        {tip.action && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="mt-2"
                            onClick={() => {
                              tip.action!.onClick();
                              setShowDialog(false);
                            }}
                          >
                            {tip.action.label}
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Onboarding Progress */}
      {onboardingStep && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="pt-4">
            <div className="flex items-center space-x-3">
              <Target className="h-4 w-4 text-blue-600" />
              <div className="flex-1">
                <h4 className="font-medium text-sm">Onboarding Progress</h4>
                <p className="text-sm text-gray-600 mt-1">
                  Step {onboardingStep} of 5 - You're doing great!
                </p>
                <div className="mt-2 bg-white rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(onboardingStep / 5) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export function QuickTip({ 
  title, 
  children, 
  type = "info",
  action
}: { 
  title: string;
  children: React.ReactNode;
  type?: "tip" | "warning" | "info" | "success";
  action?: {
    label: string;
    onClick: () => void;
  };
}) {
  const getIconForType = (type: string) => {
    switch (type) {
      case "tip": return <Lightbulb className="h-4 w-4 text-yellow-600" />;
      case "warning": return <AlertCircle className="h-4 w-4 text-orange-600" />;
      case "info": return <Info className="h-4 w-4 text-blue-600" />;
      case "success": return <CheckCircle className="h-4 w-4 text-green-600" />;
      default: return <Info className="h-4 w-4 text-gray-600" />;
    }
  };

  const getCardStyle = (type: string) => {
    switch (type) {
      case "tip": return "border-yellow-200 bg-yellow-50";
      case "warning": return "border-orange-200 bg-orange-50";
      case "info": return "border-blue-200 bg-blue-50";
      case "success": return "border-green-200 bg-green-50";
      default: return "border-gray-200 bg-gray-50";
    }
  };

  return (
    <Card className={`border ${getCardStyle(type)} mb-4`}>
      <CardContent className="pt-4">
        <div className="flex items-start space-x-3">
          {getIconForType(type)}
          <div className="flex-1">
            <h4 className="font-medium text-sm mb-2">{title}</h4>
            <div className="text-sm text-gray-600">{children}</div>
            {action && (
              <Button
                size="sm"
                variant="outline"
                className="mt-3"
                onClick={action.onClick}
              >
                {action.label}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function ProgressIndicator({ 
  current, 
  total, 
  label 
}: { 
  current: number; 
  total: number; 
  label: string; 
}) {
  const percentage = (current / total) * 100;

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardContent className="pt-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">{label}</span>
          <span className="text-sm text-gray-600">{current}/{total}</span>
        </div>
        <div className="bg-white rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${percentage}%` }}
          />
        </div>
        <p className="text-xs text-gray-600 mt-2">
          {percentage.toFixed(0)}% complete
        </p>
      </CardContent>
    </Card>
  );
}