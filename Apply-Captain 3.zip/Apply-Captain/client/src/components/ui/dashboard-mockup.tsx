import { BarChart3, Clock, Target, CheckCircle } from "lucide-react";

export function DashboardMockup() {
  return (
    <div className="bg-slate-900 rounded-xl p-6 text-white max-w-sm mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold">AutoApply Dashboard</h3>
          <p className="text-slate-400 text-sm">Live Statistics</p>
        </div>
        <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-brand-accent" />
            <span className="text-xs text-slate-400">Applied</span>
          </div>
          <div className="text-2xl font-bold">247</div>
        </div>
        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-xs text-slate-400">Responses</span>
          </div>
          <div className="text-2xl font-bold">23</div>
        </div>
      </div>

      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-slate-400">Success Rate</span>
          <span className="text-sm font-semibold">9.3%</span>
        </div>
        <div className="w-full bg-slate-800 rounded-full h-2">
          <div className="bg-brand-accent h-2 rounded-full" style={{ width: '93%' }}></div>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>Last updated: 2 min ago</span>
        <Clock className="w-4 h-4" />
      </div>
    </div>
  );
}