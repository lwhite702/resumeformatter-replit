import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  HelpCircle, 
  X, 
  MessageCircle, 
  Book, 
  Video, 
  ExternalLink,
  Upload,
  Settings,
  Target,
  Compass,
  BarChart3
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface QuickAction {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  description: string;
  action: string;
  badge?: string;
}

export function FloatingHelpWidget() {
  const [isExpanded, setIsExpanded] = useState(false);

  const quickActions: QuickAction[] = [
    { 
      icon: Target, 
      label: "View Daily Queue", 
      description: "Check today's AI-matched opportunities",
      action: "/daily-queue",
      badge: "1 min"
    },
    { 
      icon: Upload, 
      label: "Upload Resume", 
      description: "Add or update your resume for better matching",
      action: "/resume-library",
      badge: "2 min"
    },
    { 
      icon: Compass, 
      label: "Create Auto-Apply Rule", 
      description: "Set up intelligent job application automation",
      action: "/rules-engine",
      badge: "3 min"
    },
    { 
      icon: Settings, 
      label: "Configure Preferences", 
      description: "Set location, salary, and job preferences",
      action: "/settings",
      badge: "2 min"
    },
    { 
      icon: BarChart3, 
      label: "View Analytics", 
      description: "Track your job search performance",
      action: "/application-history",
      badge: "1 min"
    },
    { 
      icon: Book, 
      label: "Knowledge Base", 
      description: "Access guides and documentation",
      action: "/knowledge-base",
      badge: "Browse"
    }
  ];

  const supportOptions = [
    {
      icon: MessageCircle,
      title: "Live Chat Support",
      description: "Get instant help from our team",
      action: () => window.open("mailto:help@applycaptain.com", "_blank")
    },
    {
      icon: Video,
      title: "Video Tutorials",
      description: "Watch step-by-step guides",
      action: () => window.open("/knowledge-base", "_blank")
    },
    {
      icon: Book,
      title: "Documentation",
      description: "Browse complete user guides",
      action: () => window.open("/knowledge-base", "_blank")
    }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="mb-4"
          >
            <Card className="w-80 max-h-96 shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Quick Help</CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsExpanded(false)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4 max-h-64 overflow-y-auto">
                {/* Quick Actions */}
                <div>
                  <h4 className="font-medium text-sm mb-3">Quick Actions</h4>
                  <div className="space-y-2">
                    {quickActions.map((action, index) => {
                      const Icon = action.icon;
                      return (
                        <button
                          key={index}
                          onClick={() => window.location.href = action.action}
                          className="w-full p-3 text-left border rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-start space-x-3">
                            <Icon className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <p className="font-medium text-sm">{action.label}</p>
                                {action.badge && (
                                  <Badge variant="secondary" className="text-xs">
                                    {action.badge}
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                {action.description}
                              </p>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Support Options */}
                <div className="border-t pt-4">
                  <h4 className="font-medium text-sm mb-3">Get Support</h4>
                  <div className="space-y-2">
                    {supportOptions.map((option, index) => {
                      const Icon = option.icon;
                      return (
                        <button
                          key={index}
                          onClick={option.action}
                          className="w-full p-2 text-left border rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center space-x-3">
                            <Icon className="h-4 w-4 text-green-600" />
                            <div>
                              <p className="font-medium text-sm">{option.title}</p>
                              <p className="text-xs text-gray-500">{option.description}</p>
                            </div>
                            <ExternalLink className="h-3 w-3 text-gray-400 ml-auto" />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg flex items-center justify-center transition-colors"
      >
        {isExpanded ? (
          <X className="h-6 w-6" />
        ) : (
          <HelpCircle className="h-6 w-6" />
        )}
      </motion.button>
    </div>
  );
}

export function InlineHelpTooltip({ 
  children, 
  content, 
  title,
  position = "top"
}: { 
  children: React.ReactNode; 
  content: string;
  title?: string;
  position?: "top" | "bottom" | "left" | "right";
}) {
  const [isVisible, setIsVisible] = useState(false);

  const getPositionClasses = () => {
    switch (position) {
      case "bottom":
        return "top-full left-1/2 transform -translate-x-1/2 mt-2";
      case "left":
        return "right-full top-1/2 transform -translate-y-1/2 mr-2";
      case "right":
        return "left-full top-1/2 transform -translate-y-1/2 ml-2";
      default: // top
        return "bottom-full left-1/2 transform -translate-x-1/2 mb-2";
    }
  };

  const getArrowClasses = () => {
    switch (position) {
      case "bottom":
        return "bottom-full left-1/2 transform -translate-x-1/2 -mb-1 border-4 border-transparent border-b-gray-900";
      case "left":
        return "left-full top-1/2 transform -translate-y-1/2 -ml-1 border-4 border-transparent border-l-gray-900";
      case "right":
        return "right-full top-1/2 transform -translate-y-1/2 -mr-1 border-4 border-transparent border-r-gray-900";
      default: // top
        return "top-full left-1/2 transform -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900";
    }
  };

  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className={`absolute ${getPositionClasses()} z-50 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg pointer-events-none whitespace-nowrap max-w-xs`}
          >
            {title && <div className="font-medium mb-1">{title}</div>}
            <div>{content}</div>
            <div className={`absolute ${getArrowClasses()}`}></div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}