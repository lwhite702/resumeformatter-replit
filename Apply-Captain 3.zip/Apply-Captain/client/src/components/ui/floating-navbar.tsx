
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, User, Settings, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useIsMobile } from "@/hooks/use-mobile";
import logoWhite from "@assets/White logo - no background_1750184669735.png";

const FloatingNavbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { user } = useAuth();
  const isMobile = useIsMobile();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Features', href: '#features' },
    { name: 'How it Works', href: '#how-it-works' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Blog', href: '/blog' },
  ];

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 ${
          scrolled 
            ? 'bg-white/20 backdrop-blur-xl border border-white/30' 
            : 'bg-white/10 backdrop-blur-lg border border-white/20'
        } rounded-2xl px-4 sm:px-6 py-3 shadow-2xl max-w-6xl w-[95%] sm:w-auto`}
      >
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img src={logoWhite} alt="AutoApply" className="h-8 w-auto" />
            <span className="text-white font-bold text-lg hidden sm:block">AutoApply</span>
          </div>

          {/* Desktop Navigation */}
          {!isMobile && (
            <div className="hidden lg:flex items-center space-x-8">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-white/90 hover:text-brand-accent transition-colors font-medium"
                >
                  {item.name}
                </a>
              ))}
            </div>
          )}

          {/* Auth Section */}
          <div className="flex items-center space-x-3">
            {!user ? (
              <>
                <button
                  onClick={handleLogin}
                  className="hidden sm:block bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900 px-4 py-2 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                >
                  Get Started
                </button>
                
                {/* Mobile menu button */}
                {isMobile && (
                  <button
                    onClick={toggleMenu}
                    className="text-white p-2 rounded-lg hover:bg-white/20 transition-colors touch-target"
                    aria-label="Toggle menu"
                  >
                    {isOpen ? <X size={24} /> : <Menu size={24} />}
                  </button>
                )}
              </>
            ) : (
              <div className="flex items-center space-x-3">
                <div className="hidden sm:flex items-center space-x-2 text-white">
                  <User size={20} />
                  <span className="font-medium">{user.firstName}</span>
                </div>
                
                {isMobile && (
                  <button
                    onClick={toggleMenu}
                    className="text-white p-2 rounded-lg hover:bg-white/20 transition-colors touch-target"
                    aria-label="Toggle menu"
                  >
                    {isOpen ? <X size={24} /> : <Menu size={24} />}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && isMobile && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={toggleMenu}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            />
            
            {/* Menu Panel */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-white/20 backdrop-blur-xl border border-white/30 rounded-2xl shadow-2xl w-[90%] max-w-sm"
            >
              <div className="p-6 space-y-6">
                {/* Navigation Links */}
                <div className="space-y-4">
                  {navItems.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      onClick={toggleMenu}
                      className="block text-white font-medium py-3 px-4 rounded-lg hover:bg-white/20 transition-colors touch-target"
                    >
                      {item.name}
                    </a>
                  ))}
                </div>

                {/* Auth Actions */}
                <div className="border-t border-white/20 pt-6 space-y-3">
                  {!user ? (
                    <button
                      onClick={() => {
                        handleLogin();
                        toggleMenu();
                      }}
                      className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900 py-3 rounded-lg font-semibold touch-target"
                    >
                      Get Started Free
                    </button>
                  ) : (
                    <>
                      <a
                        href="/dashboard"
                        onClick={toggleMenu}
                        className="flex items-center space-x-3 text-white py-3 px-4 rounded-lg hover:bg-white/20 transition-colors touch-target"
                      >
                        <User size={20} />
                        <span>Dashboard</span>
                      </a>
                      <a
                        href="/settings"
                        onClick={toggleMenu}
                        className="flex items-center space-x-3 text-white py-3 px-4 rounded-lg hover:bg-white/20 transition-colors touch-target"
                      >
                        <Settings size={20} />
                        <span>Settings</span>
                      </a>
                      <button
                        onClick={() => {
                          // Add logout logic here
                          toggleMenu();
                        }}
                        className="flex items-center space-x-3 text-white py-3 px-4 rounded-lg hover:bg-white/20 transition-colors w-full text-left touch-target"
                      >
                        <LogOut size={20} />
                        <span>Sign Out</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default FloatingNavbar;
