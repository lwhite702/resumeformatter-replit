import logoWhite from "@assets/White logo - no background_1750184669735.png";

interface MenuItem {
  title: string;
  links: {
    text: string;
    url: string;
  }[];
}

interface FooterProps {
  logo?: {
    url: string;
    src: string;
    alt: string;
    title: string;
  };
  tagline?: string;
  menuItems?: MenuItem[];
  copyright?: string;
  bottomLinks?: {
    text: string;
    url: string;
  }[];
}

const Footer = ({
  logo = {
    src: logoWhite,
    alt: "AutoApply by Wrelik",
    title: "AutoApply",
    url: "/",
  },
  tagline = "Intelligent job application automation powered by AI.",
  menuItems = [
    {
      title: "Product",
      links: [
        { text: "Daily Queue", url: "/daily-queue" },
        { text: "Resume Library", url: "/resume-library" },
        { text: "Application History", url: "/application-history" },
        { text: "Rules Engine", url: "/rules-engine" },
        { text: "Analytics", url: "/dashboard" },
      ],
    },
    {
      title: "Features",
      links: [
        { text: "AI Job Matching", url: "/daily-queue" },
        { text: "Smart Automation", url: "/rules-engine" },
        { text: "Email Parsing", url: "/daily-queue" },
        { text: "Resume Optimization", url: "/resume-library" },
        { text: "Cover Letter AI", url: "/daily-queue" },
      ],
    },
    {
      title: "Integrations",
      links: [
        { text: "ResumeFormatter.io", url: "#" },
        { text: "PrepPair.me", url: "#" },
        { text: "LinkedIn", url: "#" },
        { text: "Indeed", url: "#" },
        { text: "Glassdoor", url: "#" },
      ],
    },
    {
      title: "Company",
      links: [
        { text: "About Wrelik", url: "#" },
        { text: "Blog", url: "#" },
        { text: "Careers", url: "#" },
        { text: "Contact", url: "#" },
        { text: "Support", url: "#" },
      ],
    },
  ],
  copyright = "© 2024 Wrelik. All rights reserved.",
  bottomLinks = [
    { text: "Terms of Service", url: "/legal/terms-of-service" },
    { text: "Privacy Policy", url: "/legal/privacy-policy" },
    { text: "Cookie Policy", url: "/legal/cookie-policy" },
    { text: "Legal", url: "/legal" },
  ],
}: FooterProps) => {
  return (
    <section className="bg-gradient-to-r from-brand-primary to-brand-secondary py-20 text-white">
      <div className="container mx-auto px-6">
        <footer>
          <div className="grid grid-cols-2 gap-8 lg:grid-cols-6">
            <div className="col-span-2 mb-8 lg:mb-0">
              <div className="flex items-center gap-3 lg:justify-start">
                <a href={logo.url}>
                  <img
                    src={logo.src}
                    alt={logo.alt}
                    title={logo.title}
                    className="h-12 w-auto"
                  />
                </a>
                <p className="text-2xl font-bold text-white">{logo.title}</p>
              </div>
              <p className="mt-4 text-lg font-medium text-white/90 max-w-sm">{tagline}</p>
            </div>
            {menuItems.map((section, sectionIdx) => (
              <div key={sectionIdx}>
                <h3 className="mb-6 font-bold text-white text-lg">{section.title}</h3>
                <ul className="space-y-3 text-white/80">
                  {section.links.map((link, linkIdx) => (
                    <li
                      key={linkIdx}
                      className="font-medium hover:text-brand-accent transition-colors cursor-pointer"
                    >
                      <a href={link.url}>{link.text}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-16 flex flex-col justify-between gap-4 border-t border-white/20 pt-8 text-sm font-medium text-white/70 md:flex-row md:items-center">
            <p>{copyright}</p>
            <ul className="flex gap-6">
              {bottomLinks.map((link, linkIdx) => (
                <li key={linkIdx} className="hover:text-brand-accent transition-colors">
                  <a href={link.url}>{link.text}</a>
                </li>
              ))}
            </ul>
          </div>
        </footer>
      </div>
    </section>
  );
};

export { Footer };