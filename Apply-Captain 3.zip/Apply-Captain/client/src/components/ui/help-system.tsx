import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  HelpCircle, 
  BookOpen, 
  Video, 
  MessageCircle, 
  ChevronRight, 
  Clock, 
  Target,
  Compass,
  Anchor,
  Navigation,
  Search,
  ExternalLink
} from "lucide-react";

interface HelpSystemProps {
  context?: "dashboard" | "daily-queue" | "resume-library" | "settings" | "rules-engine" | "general";
  trigger?: React.ReactNode;
}

export function HelpSystem({ context = "general", trigger }: HelpSystemProps) {
  const [activeTab, setActiveTab] = useState("quick-start");

  const contextualHelp = {
    dashboard: {
      title: "Dashboard Help",
      description: "Master your job search command center",
      quickTips: [
        "Your application stats show real-time progress",
        "Daily queue preview shows today's opportunities",
        "Click any metric to dive deeper into details"
      ]
    },
    "daily-queue": {
      title: "Daily Queue Help", 
      description: "Navigate your daily job opportunities",
      quickTips: [
        "Jobs are auto-ranked by AI matching your profile",
        "Green badges show high-match opportunities",
        "Use filters to focus on specific job types"
      ]
    },
    "resume-library": {
      title: "Resume Library Help",
      description: "Manage and optimize your resumes",
      quickTips: [
        "Create targeted resumes for different roles",
        "AI analyzes each resume for optimization tips",
        "Tag resumes by industry or role type"
      ]
    },
    settings: {
      title: "Settings Help",
      description: "Configure your job search preferences", 
      quickTips: [
        "Set your location and salary preferences",
        "Configure notification settings",
        "Update your skills and experience"
      ]
    },
    "rules-engine": {
      title: "Auto-Apply Rules Help",
      description: "Set intelligent automation rules",
      quickTips: [
        "Create rules to auto-apply to matching jobs",
        "Set filters by company size, location, salary",
        "Review auto-applications in your history"
      ]
    },
    general: {
      title: "ApplyCaptain Help",
      description: "Your complete job search assistant",
      quickTips: [
        "Navigate with the sidebar for quick access",
        "Use the search to find specific features",
        "Check notifications for important updates"
      ]
    }
  };

  const currentContext = contextualHelp[context];

  const quickStartGuides = [
    {
      title: "Set Up Your Profile",
      duration: "2 min",
      steps: [
        "Upload your primary resume",
        "Set location and salary preferences", 
        "Add your key skills and experience",
        "Configure notification settings"
      ],
      icon: Target
    },
    {
      title: "Create Auto-Apply Rules",
      duration: "3 min", 
      steps: [
        "Navigate to Rules Engine",
        "Set job criteria (title, location, salary)",
        "Choose which resume to use",
        "Enable the rule and start automation"
      ],
      icon: Compass
    },
    {
      title: "Review Daily Opportunities",
      duration: "1 min",
      steps: [
        "Check your Daily Queue each morning",
        "Review AI-matched job recommendations",
        "Apply to high-priority opportunities",
        "Track applications in your history"
      ],
      icon: Anchor
    }
  ];

  const faqData = [
    {
      question: "How does the AI job matching work?",
      answer: "Our AI analyzes your resume, skills, and preferences to score job opportunities. It considers factors like skill match, location, salary range, and company culture fit to rank positions from 1-100."
    },
    {
      question: "What happens when I enable auto-apply?",
      answer: "Auto-apply rules automatically submit applications to jobs matching your criteria. You'll receive notifications for each application sent, and can review all submissions in your application history."
    },
    {
      question: "How do I optimize my resume for better matches?",
      answer: "Upload multiple targeted resumes for different roles. Use our AI resume analyzer to get optimization suggestions. Include relevant keywords and skills that match your target positions."
    },
    {
      question: "Can I pause or modify auto-apply rules?",
      answer: "Yes! You can pause, edit, or delete any auto-apply rule at any time from the Rules Engine. Changes take effect immediately for new job opportunities."
    },
    {
      question: "How often are new jobs added to my queue?",
      answer: "New jobs are added to your Daily Queue every 24 hours. We scan thousands of job boards and company websites to find fresh opportunities that match your profile."
    },
    {
      question: "What if I want to apply manually to some jobs?",
      answer: "You have full control! You can apply manually to any job in your queue, disable auto-apply for specific positions, or create rules with manual review requirements."
    }
  ];

  const videoTutorials = [
    {
      title: "Getting Started with ApplyCaptain",
      duration: "4:32",
      thumbnail: "🚀",
      description: "Complete walkthrough of setting up your account and first auto-apply rule"
    },
    {
      title: "Advanced Resume Optimization",
      duration: "6:15", 
      thumbnail: "📄",
      description: "Expert tips for creating targeted resumes that get noticed"
    },
    {
      title: "Mastering the Rules Engine",
      duration: "5:41",
      thumbnail: "⚙️",
      description: "Create sophisticated automation rules for different job types"
    }
  ];

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="gap-2">
            <HelpCircle className="h-4 w-4" />
            Help
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5" />
            {currentContext.title}
          </DialogTitle>
          <DialogDescription>
            {currentContext.description}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="quick-start">Quick Start</TabsTrigger>
            <TabsTrigger value="contextual">Context Help</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[500px] mt-4">
            <TabsContent value="quick-start" className="space-y-4">
              <div className="grid gap-4">
                {quickStartGuides.map((guide, index) => {
                  const Icon = guide.icon;
                  return (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Icon className="h-5 w-5 text-blue-600" />
                            <CardTitle className="text-base">{guide.title}</CardTitle>
                          </div>
                          <Badge variant="secondary" className="gap-1">
                            <Clock className="h-3 w-3" />
                            {guide.duration}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <ol className="space-y-2">
                          {guide.steps.map((step, stepIndex) => (
                            <li key={stepIndex} className="flex items-start gap-3">
                              <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                                {stepIndex + 1}
                              </span>
                              <span className="text-sm text-gray-600">{step}</span>
                            </li>
                          ))}
                        </ol>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="contextual" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Tips for {currentContext.title.replace(" Help", "")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {currentContext.quickTips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <ChevronRight className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Related Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2">
                    <Button variant="outline" size="sm" className="justify-start">
                      <BookOpen className="h-4 w-4 mr-2" />
                      View Documentation
                    </Button>
                    <Button variant="outline" size="sm" className="justify-start">
                      <Video className="h-4 w-4 mr-2" />
                      Watch Tutorial
                    </Button>
                    <Button variant="outline" size="sm" className="justify-start">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Contact Support
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="faq" className="space-y-4">
              {faqData.map((faq, index) => (
                <Card key={index}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">{faq.question}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 leading-relaxed">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="resources" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Video Tutorials</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {videoTutorials.map((video, index) => (
                      <div key={index} className="flex items-center gap-4 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-lg">
                          {video.thumbnail}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{video.title}</h4>
                          <p className="text-xs text-gray-500 mt-1">{video.description}</p>
                          <Badge variant="outline" className="mt-2 text-xs">
                            {video.duration}
                          </Badge>
                        </div>
                        <ExternalLink className="h-4 w-4 text-gray-400" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Additional Resources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2">
                    <Button variant="outline" size="sm" className="justify-start">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Complete Documentation
                    </Button>
                    <Button variant="outline" size="sm" className="justify-start">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Community Forum
                    </Button>
                    <Button variant="outline" size="sm" className="justify-start">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Contact Support
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export function QuickHelpTooltip({ children, content, title }: { 
  children: React.ReactNode; 
  content: string;
  title?: string;
}) {
  return (
    <div className="group relative">
      {children}
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-50 whitespace-nowrap max-w-xs">
        {title && <div className="font-medium mb-1">{title}</div>}
        <div>{content}</div>
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900"></div>
      </div>
    </div>
  );
}