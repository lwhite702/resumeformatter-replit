export default function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-brand-primary via-brand-secondary to-slate-900 py-16 sm:py-20 lg:py-28 relative overflow-hidden min-h-screen flex items-center">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-transparent to-transparent"></div>
      <div className="absolute top-10 right-10 sm:top-20 sm:right-20 w-48 h-48 sm:w-96 sm:h-96 bg-brand-accent/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 left-10 sm:bottom-20 sm:left-20 w-32 h-32 sm:w-80 sm:h-80 bg-white/5 rounded-full blur-3xl"></div>
      
      {/* Enhanced decorative elements */}
      <div className="absolute top-16 right-16 sm:top-20 sm:right-20 w-2 h-2 sm:w-4 sm:h-4 bg-brand-accent rounded-full animate-pulse"></div>
      <div className="absolute top-24 right-24 sm:top-32 sm:right-32 w-1.5 h-1.5 sm:w-3 sm:h-3 bg-white/30 rounded-sm transform rotate-45 animate-pulse delay-300"></div>
      <div className="absolute top-32 right-12 sm:top-40 sm:right-16 w-0.5 h-4 sm:w-2 sm:h-8 bg-brand-accent animate-pulse delay-700"></div>
      <div className="absolute top-40 right-20 sm:top-48 sm:right-24 w-3 h-0.5 sm:w-6 sm:h-2 bg-white/40 animate-pulse delay-500"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight mb-6 text-display">
              Job Applications,
              <br className="block" />
              <span className="text-brand-accent block bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">Automated</span>
            </h1>

            <p className="text-base sm:text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium">
              The first AI-powered platform that finds, analyzes, and applies to jobs on your behalf using intelligent matching and personalized cover letters.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <button 
                onClick={() => window.location.href = "/api/login"}
                className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-slate-900 px-8 py-4 rounded-xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 transform shadow-xl min-h-[48px] touch-target"
                aria-label="Start applying to jobs now"
              >
                🚀 Start Applying Now
              </button>
              <button 
                onClick={() => window.location.href = "/daily-queue"}
                className="glass-morphism text-white border border-white/30 hover:bg-white/20 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:scale-105 transform min-h-[48px] touch-target"
                aria-label="View application demo"
              >
                👀 View Demo
              </button>
            </div>
            
            <div className="text-center lg:text-left">
              <p className="text-white/70 text-xs sm:text-sm font-medium">
                ✅ Free trial • ✅ No credit card • ✅ Setup in 2 minutes
              </p>
            </div>
          </div>

          <div className="relative mt-8 lg:mt-0">
            {/* AI Dashboard Card */}
            <div className="relative glass-morphism rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-2xl transform rotate-2 sm:rotate-6 hover:rotate-0 transition-all duration-500 max-w-sm mx-auto lg:max-w-none hover:shadow-3xl border border-white/30">
              <div className="text-white mb-3 sm:mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <div className="text-xs sm:text-sm text-brand-accent font-bold">AutoApply Live</div>
                </div>
                <div className="text-xs text-white/70 font-medium">AI Job Matching Dashboard</div>
              </div>

              {/* Queue visualization */}
              <div className="grid grid-cols-6 sm:grid-cols-8 gap-0.5 sm:gap-1 mb-3 sm:mb-4">
                {Array.from({ length: 48 }, (_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 sm:w-3 sm:h-3 rounded-sm ${
                      Math.random() > 0.7
                        ? Math.random() > 0.5
                          ? "bg-brand-accent"
                          : Math.random() > 0.5
                            ? "bg-green-400"
                            : "bg-blue-400"
                        : "bg-white/20"
                    }`}
                  />
                ))}
              </div>

              <div className="flex justify-between items-center text-white text-xs sm:text-sm">
                <div className="space-y-1">
                  <div className="font-bold text-green-400">AI Score: 92%</div>
                  <div className="text-white/70 text-xs flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
                    Processing
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <div className="font-bold text-blue-400">Queue: 5 Jobs</div>
                  <div className="text-white/70 text-xs">Applied: 12 today</div>
                </div>
              </div>
            </div>

            {/* Floating decorative elements */}
            <div className="absolute -top-2 -left-2 sm:-top-4 sm:-left-4 w-6 h-6 sm:w-8 sm:h-8 bg-brand-accent/80 rounded-lg transform rotate-45"></div>
            <div className="absolute -bottom-2 -right-2 sm:-bottom-4 sm:-right-4 w-4 h-4 sm:w-6 sm:h-6 bg-white/60 rounded-full"></div>
            <div className="hidden sm:block absolute top-1/2 -right-8 w-4 h-12 bg-brand-accent/60"></div>

            {/* Scattered pixels */}
            <div className="hidden sm:block absolute top-8 right-8 w-2 h-2 bg-white/40"></div>
            <div className="hidden sm:block absolute bottom-12 left-8 w-3 h-3 bg-brand-accent/60 rounded-full"></div>
            <div className="hidden sm:block absolute top-16 left-12 w-2 h-6 bg-white/40"></div>
          </div>
        </div>

        {/* Integration indicators */}
        <div className="mt-16 sm:mt-20 pt-8 border-t border-white/20">
          <div className="text-center mb-8">
            <p className="text-white/70 text-sm font-semibold">🤝 Trusted integrations with</p>
          </div>
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center justify-center gap-4 sm:gap-6 lg:gap-8">
            {[
              { name: "ResumeFormatter.io", icon: "fas fa-file-alt", color: "text-blue-400" },
              { name: "PrepPair.me", icon: "fas fa-chart-line", color: "text-green-400" },
              { name: "LinkedIn", icon: "fab fa-linkedin", color: "text-blue-500" },
              { name: "Indeed", icon: "fas fa-briefcase", color: "text-purple-400" },
              { name: "OpenAI", icon: "fas fa-brain", color: "text-yellow-400" }
            ].map((integration, index) => (
              <div key={index} className="flex items-center justify-center sm:justify-start space-x-2 glass-morphism px-3 py-2 rounded-lg hover:scale-105 transition-transform duration-200">
                <i className={`${integration.icon} ${integration.color} text-sm sm:text-lg`}></i>
                <span className="text-white/80 font-medium text-xs sm:text-sm">{integration.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}