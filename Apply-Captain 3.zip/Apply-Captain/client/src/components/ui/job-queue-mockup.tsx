import { Clock, MapPin, DollarSign, Building } from "lucide-react";

export function JobQueueMockup() {
  const jobs = [
    {
      title: "Senior Software Engineer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: "$120k - $160k",
      posted: "2h ago",
      match: 95
    },
    {
      title: "Full Stack Developer",
      company: "StartupXYZ",
      location: "Remote",
      salary: "$90k - $130k",
      posted: "4h ago",
      match: 88
    },
    {
      title: "React Developer",
      company: "Innovation Labs",
      location: "New York, NY",
      salary: "$100k - $140k",
      posted: "6h ago",
      match: 92
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 max-w-md mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">Today's Queue</h3>
        <span className="bg-brand-accent text-white px-3 py-1 rounded-full text-sm font-semibold">
          {jobs.length} Jobs
        </span>
      </div>

      <div className="space-y-4">
        {jobs.map((job, index) => (
          <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-brand-accent transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold text-gray-900 text-sm">{job.title}</h4>
                <div className="flex items-center gap-1 text-gray-600 text-xs mt-1">
                  <Building className="w-3 h-3" />
                  {job.company}
                </div>
              </div>
              <div className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-semibold">
                {job.match}% match
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-gray-500">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {job.location}
                </div>
                <div className="flex items-center gap-1">
                  <DollarSign className="w-3 h-3" />
                  {job.salary}
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {job.posted}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-3 bg-brand-accent/10 rounded-lg">
        <p className="text-sm text-gray-700 font-medium">Auto-applying in progress...</p>
        <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
          <div className="bg-brand-accent h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
        </div>
      </div>
    </div>
  );
}