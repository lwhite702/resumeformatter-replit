import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Search, 
  Book, 
  Settings, 
  Target, 
  Upload, 
  Compass, 
  BarChart3,
  ChevronRight,
  Clock,
  Users,
  MessageCircle,
  ExternalLink,
  X
} from "lucide-react";

interface KnowledgeArticle {
  id: string;
  title: string;
  category: string;
  content: string;
  tags: string[];
  readTime: string;
  difficulty: "beginner" | "intermediate" | "advanced";
}

const knowledgeArticles: KnowledgeArticle[] = [
  {
    id: "getting-started",
    title: "Getting Started with ApplyCaptain",
    category: "Setup",
    content: `
      <h3>Welcome to ApplyCaptain!</h3>
      <p>ApplyCaptain is your intelligent job search assistant that automates applications and matches you with opportunities. Here's how to get started:</p>
      
      <h4>1. Upload Your Resume</h4>
      <p>Start by uploading your primary resume. Our AI will analyze it to understand your skills, experience, and career focus.</p>
      
      <h4>2. Set Your Preferences</h4>
      <p>Configure your job search preferences including location, salary range, job types, and industries you're interested in.</p>
      
      <h4>3. Create Auto-Apply Rules</h4>
      <p>Set up intelligent rules that automatically apply to jobs matching your criteria. You can create multiple rules for different job types.</p>
      
      <h4>4. Review Your Daily Queue</h4>
      <p>Check your Daily Queue each morning to see new job opportunities that match your profile. The AI scores each job based on fit.</p>
    `,
    tags: ["setup", "beginner", "onboarding"],
    readTime: "3 min",
    difficulty: "beginner"
  },
  {
    id: "resume-optimization",
    title: "Optimizing Your Resume for Better Matches",
    category: "Resume",
    content: `
      <h3>Resume Optimization Best Practices</h3>
      <p>Your resume is the foundation of successful job matching. Here's how to optimize it:</p>
      
      <h4>Create Multiple Targeted Resumes</h4>
      <p>Upload different versions of your resume for different job types. For example, create separate resumes for:</p>
      <ul>
        <li>Frontend Development positions</li>
        <li>Full-stack Development roles</li>
        <li>Technical Leadership positions</li>
      </ul>
      
      <h4>Include Relevant Keywords</h4>
      <p>Our AI looks for keywords that match job descriptions. Include:</p>
      <ul>
        <li>Technical skills and programming languages</li>
        <li>Industry-specific terminology</li>
        <li>Soft skills mentioned in job postings</li>
      </ul>
      
      <h4>Quantify Your Achievements</h4>
      <p>Use numbers and metrics wherever possible. Instead of "Improved website performance," write "Improved website performance by 40%, reducing load time from 3s to 1.8s."</p>
    `,
    tags: ["resume", "optimization", "matching"],
    readTime: "5 min",
    difficulty: "intermediate"
  },
  {
    id: "auto-apply-rules",
    title: "Creating Effective Auto-Apply Rules",
    category: "Automation",
    content: `
      <h3>Mastering Auto-Apply Rules</h3>
      <p>Auto-apply rules are the heart of ApplyCaptain's automation. Here's how to create effective rules:</p>
      
      <h4>Start Conservative</h4>
      <p>Begin with strict criteria and gradually expand. It's easier to add more opportunities than to manage too many applications.</p>
      
      <h4>Rule Components</h4>
      <ul>
        <li><strong>Job Title Keywords:</strong> Specific roles you want (e.g., "Software Engineer", "Developer")</li>
        <li><strong>Location:</strong> Geographic preferences and remote work options</li>
        <li><strong>Salary Range:</strong> Minimum and maximum compensation</li>
        <li><strong>Company Size:</strong> Startup, mid-size, or enterprise preferences</li>
        <li><strong>Experience Level:</strong> Junior, mid-level, or senior positions</li>
      </ul>
      
      <h4>Advanced Filtering</h4>
      <p>Use exclude keywords to avoid unwanted positions. Common exclusions:</p>
      <ul>
        <li>Internship, Contract, Temporary</li>
        <li>Technologies you don't work with</li>
        <li>Industries you want to avoid</li>
      </ul>
    `,
    tags: ["automation", "rules", "filtering"],
    readTime: "4 min",
    difficulty: "intermediate"
  },
  {
    id: "daily-queue-guide",
    title: "Understanding Your Daily Queue",
    category: "Features",
    content: `
      <h3>Making the Most of Your Daily Queue</h3>
      <p>Your Daily Queue is refreshed every 24 hours with new opportunities. Here's how to use it effectively:</p>
      
      <h4>AI Scoring System</h4>
      <p>Each job receives a match score from 1-100 based on:</p>
      <ul>
        <li>Skills alignment with your resume</li>
        <li>Experience level match</li>
        <li>Location and salary preferences</li>
        <li>Company culture fit</li>
      </ul>
      
      <h4>Queue Management</h4>
      <p>Prioritize your time by focusing on:</p>
      <ul>
        <li><strong>90-100 score:</strong> Excellent matches - review immediately</li>
        <li><strong>75-89 score:</strong> Good matches - review when time permits</li>
        <li><strong>Below 75:</strong> Consider for future or ignore</li>
      </ul>
      
      <h4>Taking Action</h4>
      <p>For each opportunity you can:</p>
      <ul>
        <li>Apply immediately</li>
        <li>Save for later review</li>
        <li>Add to auto-apply rules</li>
        <li>Remove from queue</li>
      </ul>
    `,
    tags: ["daily-queue", "scoring", "management"],
    readTime: "3 min",
    difficulty: "beginner"
  },
  {
    id: "application-tracking",
    title: "Tracking Your Applications",
    category: "Analytics",
    content: `
      <h3>Monitor Your Job Search Progress</h3>
      <p>Track your applications and analyze your job search performance:</p>
      
      <h4>Application Status Types</h4>
      <ul>
        <li><strong>Applied:</strong> Application submitted successfully</li>
        <li><strong>Viewed:</strong> Employer has viewed your application</li>
        <li><strong>Interview:</strong> You've been invited to interview</li>
        <li><strong>Rejected:</strong> Application was declined</li>
        <li><strong>Offer:</strong> You received a job offer</li>
      </ul>
      
      <h4>Performance Metrics</h4>
      <p>Key metrics to monitor:</p>
      <ul>
        <li><strong>Application Rate:</strong> Applications per day/week</li>
        <li><strong>Response Rate:</strong> Percentage of applications that get responses</li>
        <li><strong>Interview Rate:</strong> Percentage leading to interviews</li>
        <li><strong>Success Rate:</strong> Offers received vs applications sent</li>
      </ul>
      
      <h4>Optimization Tips</h4>
      <p>Use analytics to improve your strategy:</p>
      <ul>
        <li>Low response rate? Optimize your resume</li>
        <li>High rejections? Adjust your auto-apply criteria</li>
        <li>Good interviews but no offers? Practice your interview skills</li>
      </ul>
    `,
    tags: ["tracking", "analytics", "performance"],
    readTime: "4 min",
    difficulty: "intermediate"
  },
  {
    id: "troubleshooting",
    title: "Troubleshooting Common Issues",
    category: "Support",
    content: `
      <h3>Solving Common Problems</h3>
      
      <h4>No Jobs in Daily Queue</h4>
      <p>If your queue is empty:</p>
      <ul>
        <li>Check if your location settings are too restrictive</li>
        <li>Expand your salary range temporarily</li>
        <li>Add more job title keywords</li>
        <li>Consider remote work options</li>
      </ul>
      
      <h4>Auto-Apply Not Working</h4>
      <p>Ensure your rules are properly configured:</p>
      <ul>
        <li>Verify the rule is enabled</li>
        <li>Check if criteria are too restrictive</li>
        <li>Make sure you have a resume selected</li>
        <li>Review excluded keywords</li>
      </ul>
      
      <h4>Low Match Scores</h4>
      <p>Improve your match scores by:</p>
      <ul>
        <li>Updating your resume with relevant keywords</li>
        <li>Adding more skills to your profile</li>
        <li>Expanding your experience descriptions</li>
        <li>Creating role-specific resumes</li>
      </ul>
      
      <h4>Application Errors</h4>
      <p>If applications fail:</p>
      <ul>
        <li>Check your internet connection</li>
        <li>Verify your resume format (PDF recommended)</li>
        <li>Try applying manually first</li>
        <li>Contact support if issues persist</li>
      </ul>
    `,
    tags: ["troubleshooting", "issues", "support"],
    readTime: "5 min",
    difficulty: "beginner"
  }
];

export function KnowledgeBase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [filteredArticles, setFilteredArticles] = useState(knowledgeArticles);

  useEffect(() => {
    let filtered = knowledgeArticles;

    if (selectedCategory !== "all") {
      filtered = filtered.filter(article => 
        article.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (searchTerm) {
      filtered = filtered.filter(article =>
        article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    setFilteredArticles(filtered);
  }, [searchTerm, selectedCategory]);

  const categories = ["all", "setup", "resume", "automation", "features", "analytics", "support"];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Knowledge Base</h1>
        <p className="text-gray-600">Everything you need to know about using ApplyCaptain effectively</p>
      </div>

      {/* Search and Filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search articles, guides, and documentation..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="capitalize"
            >
              {category === "all" ? "All Categories" : category}
            </Button>
          ))}
        </div>
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <Upload className="h-8 w-8 text-blue-600" />
              <div>
                <h3 className="font-medium">Quick Start Guide</h3>
                <p className="text-sm text-gray-500">Get set up in 5 minutes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <MessageCircle className="h-8 w-8 text-green-600" />
              <div>
                <h3 className="font-medium">Contact Support</h3>
                <p className="text-sm text-gray-500">Get help from our team</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <ExternalLink className="h-8 w-8 text-purple-600" />
              <div>
                <h3 className="font-medium">Video Tutorials</h3>
                <p className="text-sm text-gray-500">Watch step-by-step guides</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredArticles.map((article) => (
          <Card key={article.id} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{article.title}</CardTitle>
                  <CardDescription className="mt-2">{article.category}</CardDescription>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
              
              <div className="flex items-center space-x-2 mt-3">
                <Badge className={getDifficultyColor(article.difficulty)}>
                  {article.difficulty}
                </Badge>
                <Badge variant="outline" className="gap-1">
                  <Clock className="h-3 w-3" />
                  {article.readTime}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="flex flex-wrap gap-1 mb-3">
                {article.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              <div 
                className="text-sm text-gray-600 line-clamp-3"
                dangerouslySetInnerHTML={{ 
                  __html: article.content.substring(0, 150) + "..." 
                }}
              />
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredArticles.length === 0 && (
        <div className="text-center py-12">
          <Book className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
          <p className="text-gray-500">Try adjusting your search terms or category filter</p>
        </div>
      )}
    </div>
  );
}

export function QuickHelpWidget() {
  const [isExpanded, setIsExpanded] = useState(false);

  const quickActions = [
    { icon: Upload, label: "Upload Resume", action: "/resume-library" },
    { icon: Settings, label: "Set Preferences", action: "/settings" },
    { icon: Compass, label: "Create Rules", action: "/rules-engine" },
    { icon: Target, label: "View Queue", action: "/daily-queue" },
    { icon: BarChart3, label: "View Analytics", action: "/application-history" },
    { icon: MessageCircle, label: "Get Help", action: "/knowledge-base" }
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isExpanded && (
        <Card className="mb-4 w-64">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => window.location.href = action.action}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {action.label}
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <Button
        onClick={() => setIsExpanded(!isExpanded)}
        className="rounded-full w-12 h-12 shadow-lg"
        size="sm"
      >
        {isExpanded ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
      </Button>
    </div>
  );
}