import React, { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  Users, 
  MousePointer, 
  Target,
  BarChart3,
  Globe,
  Smartphone,
  Monitor
} from "lucide-react";

interface MarketingAnalyticsProps {
  landingPage: "ads" | "social" | "referral";
}

export function MarketingAnalytics({ landingPage }: MarketingAnalyticsProps) {
  const [analytics, setAnalytics] = useState({
    pageViews: 0,
    uniqueVisitors: 0,
    conversionRate: 0,
    bounceRate: 0,
    avgSessionDuration: 0,
    topSources: [],
    deviceBreakdown: { desktop: 0, mobile: 0, tablet: 0 }
  });

  useEffect(() => {
    // Track page performance metrics
    const trackPageMetrics = () => {
      // Core Web Vitals tracking
      if ('web-vital' in window) {
        // Track Largest Contentful Paint (LCP)
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          const lastEntry = entries[entries.length - 1];
          
          if (typeof (window as any).gtag !== 'undefined') {
            (window as any).gtag('event', 'LCP', {
              event_category: 'Web Vitals',
              value: Math.round(lastEntry.startTime),
              custom_parameter_1: landingPage
            });
          }
        }).observe({ type: 'largest-contentful-paint', buffered: true });

        // Track First Input Delay (FID)
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          entries.forEach((entry) => {
            if (typeof (window as any).gtag !== 'undefined') {
              (window as any).gtag('event', 'FID', {
                event_category: 'Web Vitals',
                value: Math.round(entry.processingStart - entry.startTime),
                custom_parameter_1: landingPage
              });
            }
          });
        }).observe({ type: 'first-input', buffered: true });

        // Track Cumulative Layout Shift (CLS)
        let clsValue = 0;
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          entries.forEach((entry) => {
            if (!(entry as any).hadRecentInput) {
              clsValue += (entry as any).value;
            }
          });
          
          if (typeof (window as any).gtag !== 'undefined') {
            (window as any).gtag('event', 'CLS', {
              event_category: 'Web Vitals',
              value: Math.round(clsValue * 1000),
              custom_parameter_1: landingPage
            });
          }
        }).observe({ type: 'layout-shift', buffered: true });
      }

      // Track scroll depth
      let maxScroll = 0;
      const trackScrollDepth = () => {
        const scrollPercent = Math.round(
          (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100
        );
        
        if (scrollPercent > maxScroll) {
          maxScroll = scrollPercent;
          
          // Track milestone scroll depths
          if ([25, 50, 75, 90].includes(scrollPercent)) {
            if (typeof (window as any).gtag !== 'undefined') {
              (window as any).gtag('event', 'scroll', {
                event_category: 'Engagement',
                event_label: `${scrollPercent}%`,
                custom_parameter_1: landingPage
              });
            }
          }
        }
      };

      window.addEventListener('scroll', trackScrollDepth, { passive: true });
      
      // Track time on page
      const startTime = Date.now();
      const trackTimeOnPage = () => {
        const timeSpent = Math.round((Date.now() - startTime) / 1000);
        
        if (typeof (window as any).gtag !== 'undefined') {
          (window as any).gtag('event', 'time_on_page', {
            event_category: 'Engagement',
            value: timeSpent,
            custom_parameter_1: landingPage
          });
        }
      };

      window.addEventListener('beforeunload', trackTimeOnPage);
      
      return () => {
        window.removeEventListener('scroll', trackScrollDepth);
        window.removeEventListener('beforeunload', trackTimeOnPage);
      };
    };

    trackPageMetrics();

    // Simulate analytics data (replace with real API calls)
    const mockAnalytics = {
      ads: {
        pageViews: 12547,
        uniqueVisitors: 8932,
        conversionRate: 12.4,
        bounceRate: 34.2,
        avgSessionDuration: 245,
        topSources: [
          { source: 'Google Ads', visitors: 4521, conversion: 14.2 },
          { source: 'Facebook Ads', visitors: 3211, conversion: 11.8 },
          { source: 'LinkedIn Ads', visitors: 1200, conversion: 9.7 }
        ],
        deviceBreakdown: { desktop: 45, mobile: 48, tablet: 7 }
      },
      social: {
        pageViews: 28934,
        uniqueVisitors: 19876,
        conversionRate: 8.7,
        bounceRate: 42.1,
        avgSessionDuration: 198,
        topSources: [
          { source: 'TikTok', visitors: 9234, conversion: 9.8 },
          { source: 'Instagram', visitors: 7821, conversion: 8.2 },
          { source: 'Twitter', visitors: 2821, conversion: 7.1 }
        ],
        deviceBreakdown: { desktop: 25, mobile: 68, tablet: 7 }
      },
      referral: {
        pageViews: 5632,
        uniqueVisitors: 4891,
        conversionRate: 24.8,
        bounceRate: 18.3,
        avgSessionDuration: 312,
        topSources: [
          { source: 'ResumeFormatter.io', visitors: 2934, conversion: 28.1 },
          { source: 'PrepPair', visitors: 1957, conversion: 21.2 }
        ],
        deviceBreakdown: { desktop: 62, mobile: 32, tablet: 6 }
      }
    };

    setAnalytics(mockAnalytics[landingPage]);
  }, [landingPage]);

  const getPerformanceColor = (value: number, type: 'conversion' | 'bounce') => {
    if (type === 'conversion') {
      return value > 15 ? 'text-green-600' : value > 10 ? 'text-yellow-600' : 'text-red-600';
    } else {
      return value < 30 ? 'text-green-600' : value < 50 ? 'text-yellow-600' : 'text-red-600';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Key Metrics */}
      <Card>
        <CardHeader className="pb-2">
          <CardDescription>Page Views</CardDescription>
          <CardTitle className="text-2xl">{analytics.pageViews.toLocaleString()}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <TrendingUp className="h-4 w-4" />
            <span>+12% from last month</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardDescription>Unique Visitors</CardDescription>
          <CardTitle className="text-2xl">{analytics.uniqueVisitors.toLocaleString()}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>+8% from last month</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardDescription>Conversion Rate</CardDescription>
          <CardTitle className={`text-2xl ${getPerformanceColor(analytics.conversionRate, 'conversion')}`}>
            {analytics.conversionRate}%
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Target className="h-4 w-4" />
            <span>+2.1% from last month</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardDescription>Bounce Rate</CardDescription>
          <CardTitle className={`text-2xl ${getPerformanceColor(analytics.bounceRate, 'bounce')}`}>
            {analytics.bounceRate}%
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <MousePointer className="h-4 w-4" />
            <span>-3.2% from last month</span>
          </div>
        </CardContent>
      </Card>

      {/* Traffic Sources */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Top Traffic Sources</CardTitle>
          <CardDescription>Conversion performance by source</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics.topSources.map((source: any, index: number) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="font-medium">{source.source}</span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-muted-foreground">
                    {source.visitors.toLocaleString()} visitors
                  </span>
                  <Badge variant={source.conversion > 12 ? "default" : "secondary"}>
                    {source.conversion}% CVR
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Device Breakdown */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Device Breakdown</CardTitle>
          <CardDescription>Traffic distribution by device type</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Monitor className="h-4 w-4" />
                <span>Desktop</span>
              </div>
              <div className="flex items-center space-x-3">
                <Progress value={analytics.deviceBreakdown.desktop} className="w-20" />
                <span className="text-sm font-medium">{analytics.deviceBreakdown.desktop}%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Smartphone className="h-4 w-4" />
                <span>Mobile</span>
              </div>
              <div className="flex items-center space-x-3">
                <Progress value={analytics.deviceBreakdown.mobile} className="w-20" />
                <span className="text-sm font-medium">{analytics.deviceBreakdown.mobile}%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Globe className="h-4 w-4" />
                <span>Tablet</span>
              </div>
              <div className="flex items-center space-x-3">
                <Progress value={analytics.deviceBreakdown.tablet} className="w-20" />
                <span className="text-sm font-medium">{analytics.deviceBreakdown.tablet}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function SEOOptimizer({ page }: { page: string }) {
  useEffect(() => {
    // Implement advanced SEO optimizations
    const optimizePage = () => {
      // Add canonical URL
      let canonicalLink = document.querySelector('link[rel="canonical"]');
      if (!canonicalLink) {
        canonicalLink = document.createElement('link');
        canonicalLink.setAttribute('rel', 'canonical');
        document.head.appendChild(canonicalLink);
      }
      canonicalLink.setAttribute('href', window.location.href);

      // Add hreflang for international SEO
      const hreflangLinks = [
        { lang: 'en', href: window.location.href },
        { lang: 'x-default', href: window.location.href }
      ];

      hreflangLinks.forEach(({ lang, href }) => {
        let hreflangLink = document.querySelector(`link[hreflang="${lang}"]`);
        if (!hreflangLink) {
          hreflangLink = document.createElement('link');
          hreflangLink.setAttribute('rel', 'alternate');
          hreflangLink.setAttribute('hreflang', lang);
          document.head.appendChild(hreflangLink);
        }
        hreflangLink.setAttribute('href', href);
      });

      // Add robots meta tag
      let robotsTag = document.querySelector('meta[name="robots"]');
      if (!robotsTag) {
        robotsTag = document.createElement('meta');
        robotsTag.setAttribute('name', 'robots');
        document.head.appendChild(robotsTag);
      }
      robotsTag.setAttribute('content', 'index, follow, max-image-preview:large');

      // Add theme color for mobile browsers
      let themeColorTag = document.querySelector('meta[name="theme-color"]');
      if (!themeColorTag) {
        themeColorTag = document.createElement('meta');
        themeColorTag.setAttribute('name', 'theme-color');
        document.head.appendChild(themeColorTag);
      }
      themeColorTag.setAttribute('content', '#4F46E5');

      // Add viewport optimization
      let viewportTag = document.querySelector('meta[name="viewport"]');
      if (!viewportTag) {
        viewportTag = document.createElement('meta');
        viewportTag.setAttribute('name', 'viewport');
        document.head.appendChild(viewportTag);
      }
      viewportTag.setAttribute('content', 'width=device-width, initial-scale=1, viewport-fit=cover');

      // Add preconnect for external resources
      const preconnectUrls = [
        'https://fonts.googleapis.com',
        'https://fonts.gstatic.com',
        'https://www.google-analytics.com',
        'https://connect.facebook.net'
      ];

      preconnectUrls.forEach(url => {
        let preconnectLink = document.querySelector(`link[href="${url}"]`);
        if (!preconnectLink) {
          preconnectLink = document.createElement('link');
          preconnectLink.setAttribute('rel', 'preconnect');
          preconnectLink.setAttribute('href', url);
          if (url.includes('gstatic')) {
            preconnectLink.setAttribute('crossorigin', '');
          }
          document.head.appendChild(preconnectLink);
        }
      });
    };

    optimizePage();
  }, [page]);

  return null;
}