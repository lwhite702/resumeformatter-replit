import { Button } from "@/components/ui/button";
import logoWhite from "@assets/White logo - no background_1750184669735.png";

export default function ModernHero() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <section className="bg-brand-gradient py-12 sm:py-16 lg:py-24 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="hidden sm:block absolute top-20 right-20 w-3 h-3 sm:w-4 sm:h-4 bg-brand-accent rounded-full"></div>
      <div className="hidden sm:block absolute top-32 right-32 w-2 h-2 sm:w-3 sm:h-3 bg-brand-accent/80 rounded-sm transform rotate-45"></div>
      <div className="hidden sm:block absolute top-40 right-16 w-1 h-6 sm:w-2 sm:h-8 bg-brand-accent"></div>
      <div className="hidden sm:block absolute top-48 right-24 w-4 h-1 sm:w-6 sm:h-2 bg-brand-accent/60"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="text-center lg:text-left">
            {/* Logo */}
            <div className="flex items-center justify-center lg:justify-start gap-3 mb-6">
              <img src={logoWhite} alt="AutoApply" className="h-12 w-auto" />
              <h1 className="text-2xl font-bold text-white">AutoApply</h1>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-4 sm:mb-6">
              Stop Applying to Jobs.
              <br className="hidden sm:block" />
              <span className="block sm:inline text-brand-gradient"> Start Getting Offers.</span>
            </h1>

            <p className="text-base sm:text-lg text-white/90 mb-6 sm:mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Our AI-powered platform automatically finds, applies to, and tracks job opportunities that match your skills. 
              Land your dream job while you focus on what matters most.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start items-center mb-8">
              <Button 
                onClick={handleLogin}
                className="bg-brand-accent hover:bg-brand-accent-light text-white px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-xl"
              >
                Start Auto-Applying Now
              </Button>
              <Button 
                variant="outline"
                className="glass-morphism text-white border-white/30 hover:bg-white/10 px-8 py-4 text-lg font-semibold rounded-xl"
              >
                Watch Demo
              </Button>
            </div>

            <p className="text-white/70 text-sm">
              Free trial • No credit card required • Setup in 2 minutes
            </p>
          </div>

          <div className="relative mt-8 lg:mt-0">
            {/* AI Dashboard Card */}
            <div className="relative glass-morphism rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-2xl transform rotate-6 sm:rotate-12 hover:rotate-0 transition-transform duration-300 max-w-sm mx-auto lg:max-w-none">
              <div className="text-white mb-3 sm:mb-4">
                <div className="text-xs sm:text-sm text-white/70 mb-1 sm:mb-2">AutoApply Live</div>
                <div className="text-xs text-white/60">AI Job Dashboard</div>
              </div>

              {/* Job application grid */}
              <div className="grid grid-cols-6 sm:grid-cols-8 gap-0.5 sm:gap-1 mb-3 sm:mb-4">
                {Array.from({ length: 48 }, (_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 sm:w-3 sm:h-3 rounded-sm ${
                      Math.random() > 0.7
                        ? Math.random() > 0.5
                          ? "bg-brand-accent"
                          : Math.random() > 0.5
                            ? "bg-brand-accent/70"
                            : "bg-blue-400"
                        : "bg-white/10"
                    }`}
                  />
                ))}
              </div>

              <div className="flex justify-between items-center text-white text-xs sm:text-sm">
                <div>
                  <div className="mb-1">AI Model: Active</div>
                  <div className="text-white/60 text-xs">Status: Applying</div>
                </div>
                <div className="text-right">
                  <div className="mb-1">Success: 94.2%</div>
                  <div className="text-white/60 text-xs">Queue: 15 jobs</div>
                </div>
              </div>
            </div>

            {/* Floating decorative elements */}
            <div className="absolute -top-2 -left-2 sm:-top-4 sm:-left-4 w-6 h-6 sm:w-8 sm:h-8 bg-brand-accent/60 rounded-lg transform rotate-45"></div>
            <div className="absolute -bottom-2 -right-2 sm:-bottom-4 sm:-right-4 w-4 h-4 sm:w-6 sm:h-6 bg-brand-accent rounded-full"></div>
            <div className="hidden sm:block absolute top-1/2 -right-8 w-4 h-12 bg-brand-accent/80"></div>

            {/* Scattered pixels */}
            <div className="hidden sm:block absolute top-8 right-8 w-2 h-2 bg-brand-accent/70"></div>
            <div className="hidden sm:block absolute bottom-12 left-8 w-3 h-3 bg-brand-accent rounded-full"></div>
            <div className="hidden sm:block absolute top-16 left-12 w-2 h-6 bg-blue-400"></div>
          </div>
        </div>

        {/* Trust indicators */}
        <div className="mt-12 sm:mt-16 pt-6 sm:pt-8 border-t border-white/20">
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 lg:gap-12 opacity-70">
            {["LinkedIn", "Indeed", "Glassdoor", "AngelList", "RemoteOK"].map((platform, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-4 h-4 sm:w-6 sm:h-6 bg-white/20 rounded"></div>
                <span className="text-white/80 font-medium text-sm sm:text-base">{platform}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}