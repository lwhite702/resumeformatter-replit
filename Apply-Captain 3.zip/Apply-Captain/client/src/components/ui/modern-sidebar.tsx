import React, { useState } from 'react';
import { 
  Menu, 
  X, 
  LayoutDashboard, 
  User, 
  Settings, 
  LogOut,
  ChevronLeft,
  Clock,
  Send,
  History,
  Cog,
  FileText,
  Bot
} from 'lucide-react';
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

const ModernSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [location] = useLocation();
  const { user } = useAuth();
  const isMobile = useIsMobile();

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, href: '/', ariaLabel: 'Navigate to Dashboard' },
    { name: 'Daily Queue', icon: Clock, href: '/daily-queue', ariaLabel: 'View Daily Job Queue' },
    { name: 'Apply to Jobs', icon: Send, href: '/apply', ariaLabel: 'Apply to New Jobs' },
    { name: 'Application History', icon: History, href: '/history', ariaLabel: 'View Application History' },
    { name: 'AI Assistant', icon: Bot, href: '/ai-assistant', ariaLabel: 'Open AI Assistant' },
    { name: 'Auto-Apply Rules', icon: Cog, href: '/rules', ariaLabel: 'Configure Auto-Apply Rules' },
    { name: 'Resume Library', icon: FileText, href: '/resumes', ariaLabel: 'Manage Resume Library' },
    { name: 'Settings', icon: Settings, href: '/settings', ariaLabel: 'Open Settings' },
  ];

  const toggleSidebar = () => setIsOpen(!isOpen);
  const toggleCollapse = () => setIsCollapsed(!isCollapsed);

  const isActive = (href: string) => {
    return location === href || (href !== "/" && location.startsWith(href));
  };

  // Close sidebar when clicking outside on mobile
  const handleBackdropClick = () => {
    if (isMobile && isOpen) {
      setIsOpen(false);
    }
  };

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };
    
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Handle keyboard navigation
  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Escape' && isOpen) {
      setIsOpen(false);
    }
  };

  return (
    <div className="relative">
      {/* Mobile Backdrop */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={handleBackdropClick}
          aria-hidden="true"
        />
      )}

      {/* Mobile Hamburger Button */}
      <button
        onClick={toggleSidebar}
        aria-label={isOpen ? "Close navigation menu" : "Open navigation menu"}
        aria-expanded={isOpen}
        className="lg:hidden fixed top-4 left-4 z-50 p-3 rounded-lg bg-gradient-to-r from-brand-primary to-brand-secondary text-white hover:from-brand-secondary hover:to-brand-primary transition-all duration-200 shadow-lg touch-manipulation min-h-[48px] min-w-[48px] flex items-center justify-center"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full bg-gradient-to-b from-brand-primary via-brand-secondary to-slate-900 border-r border-brand-primary/20 transition-all duration-300 ease-in-out z-40 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 ${
          isCollapsed ? 'lg:w-20' : 'lg:w-72'
        } w-72 shadow-2xl backdrop-blur-sm`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-brand-primary">
                <path d="M12 2L2 7v10c0 5.55 3.84 9.95 9 11 5.16-1.05 9-5.45 9-11V7l-10-5z" fill="currentColor"/>
                <path d="M8 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
              </svg>
            </div>
            {!isCollapsed && (
              <div>
                <h1 className="text-xl font-bold text-white tracking-wide text-display">
                  AutoApply
                </h1>
                <span className="text-xs text-brand-accent font-medium">by Wrelik</span>
              </div>
            )}
          </div>
          
          {/* Desktop Collapse Button */}
          <button
            onClick={toggleCollapse}
            className="hidden lg:block p-1.5 rounded-lg hover:bg-white/10 text-white/60 hover:text-white transition-colors duration-200"
          >
            <ChevronLeft 
              size={20} 
              className={`transition-transform duration-300 ${
                isCollapsed ? 'rotate-180' : ''
              }`}
            />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            
            return (
              <Link key={item.name} href={item.href}>
                <button
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                    active
                      ? 'bg-white/20 backdrop-blur-sm text-white shadow-lg border border-white/20'
                      : 'text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon 
                    size={20} 
                    className={`transition-colors duration-200 ${
                      active ? 'text-brand-accent' : 'text-white/60 group-hover:text-white'
                    }`}
                  />
                  {!isCollapsed && (
                    <span className="font-medium transition-colors duration-200">
                      {item.name}
                    </span>
                  )}
                  
                  {/* Active indicator */}
                  {active && !isCollapsed && (
                    <div className="ml-auto w-2 h-2 bg-brand-accent rounded-full shadow-lg" />
                  )}
                </button>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        {!isCollapsed && (
          <div className="p-4 border-t border-white/10">
            <div className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/5">
              <div className="w-8 h-8 bg-gradient-to-r from-brand-accent to-teal-400 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {user?.firstName?.[0] || user?.email?.[0] || 'U'}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user?.email || 'User'
                  }
                </p>
                <p className="text-xs text-white/60 truncate">
                  {user?.email || 'user@example.com'}
                </p>
              </div>
            </div>
            
            {/* Logout Button */}
            <button
              onClick={() => window.location.href = '/api/logout'}
              className="w-full mt-3 flex items-center space-x-3 px-4 py-2 rounded-xl text-white/70 hover:bg-red-500/20 hover:text-red-300 transition-all duration-200 group"
            >
              <LogOut size={18} className="text-white/60 group-hover:text-red-300" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ModernSidebar;