import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Upload, 
  Settings, 
  Compass, 
  Target,
  CheckCircle,
  Play,
  Clock
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  target: string;
  position: "top" | "bottom" | "left" | "right";
  action?: {
    type: "navigate" | "click" | "input";
    path?: string;
    element?: string;
  };
  icon: React.ComponentType<{ className?: string }>;
  estimatedTime: string;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: "welcome",
    title: "Welcome to ApplyCaptain!",
    description: "Let's get you set up for successful job hunting. This tour takes 3-4 minutes.",
    target: "dashboard",
    position: "bottom",
    icon: Play,
    estimatedTime: "30s"
  },
  {
    id: "upload-resume",
    title: "Upload Your Resume",
    description: "Add your primary resume to get started with AI-powered job matching.",
    target: "resume-library",
    position: "right",
    action: {
      type: "navigate",
      path: "/resume-library"
    },
    icon: Upload,
    estimatedTime: "1m"
  },
  {
    id: "set-preferences",
    title: "Configure Your Preferences",
    description: "Set your location, salary range, and job preferences for better matches.",
    target: "settings",
    position: "right",
    action: {
      type: "navigate",
      path: "/settings"
    },
    icon: Settings,
    estimatedTime: "1m"
  },
  {
    id: "create-rules",
    title: "Set Up Auto-Apply Rules",
    description: "Create intelligent rules to automatically apply to matching jobs.",
    target: "rules-engine",
    position: "right",
    action: {
      type: "navigate",
      path: "/rules-engine"
    },
    icon: Compass,
    estimatedTime: "1m"
  },
  {
    id: "daily-queue",
    title: "Check Your Daily Queue",
    description: "Review AI-matched job opportunities added fresh every day.",
    target: "daily-queue",
    position: "right",
    action: {
      type: "navigate",
      path: "/daily-queue"
    },
    icon: Target,
    estimatedTime: "30s"
  },
  {
    id: "complete",
    title: "You're All Set!",
    description: "Your job search automation is now active. Check back daily for new opportunities.",
    target: "dashboard",
    position: "bottom",
    icon: CheckCircle,
    estimatedTime: "Complete"
  }
];

interface OnboardingTourProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export function OnboardingTour({ isOpen, onClose, onComplete }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
    }
  }, [isOpen]);

  const currentStepData = onboardingSteps[currentStep];
  const progress = ((currentStep + 1) / onboardingSteps.length) * 100;

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      if (currentStepData.action) {
        if (currentStepData.action.type === "navigate" && currentStepData.action.path) {
          window.location.href = currentStepData.action.path;
        }
      }
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    localStorage.setItem('applycaptain_onboarding_completed', 'true');
    onComplete();
    onClose();
  };

  const handleSkip = () => {
    setIsVisible(false);
    onClose();
  };

  if (!isVisible) return null;

  const Icon = currentStepData.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Icon className="h-5 w-5 text-blue-600" />
              {currentStepData.title}
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={handleSkip}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <DialogDescription>
            Step {currentStep + 1} of {onboardingSteps.length}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Progress value={progress} className="w-full" />
          
          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>Progress: {Math.round(progress)}%</span>
            <Badge variant="outline" className="gap-1">
              <Clock className="h-3 w-3" />
              {currentStepData.estimatedTime}
            </Badge>
          </div>

          <Card>
            <CardContent className="pt-6">
              <p className="text-sm leading-relaxed">
                {currentStepData.description}
              </p>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className="gap-2"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>

            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkip}
              >
                Skip Tour
              </Button>
              
              <Button
                onClick={handleNext}
                size="sm"
                className="gap-2"
              >
                {currentStep === onboardingSteps.length - 1 ? "Complete" : "Next"}
                {currentStep !== onboardingSteps.length - 1 && <ChevronRight className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {/* Quick tips for current step */}
          {currentStep === 1 && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-4">
                <p className="text-xs text-blue-700">
                  💡 Tip: Upload multiple resumes for different job types to improve match accuracy
                </p>
              </CardContent>
            </Card>
          )}

          {currentStep === 2 && (
            <Card className="bg-green-50 border-green-200">
              <CardContent className="pt-4">
                <p className="text-xs text-green-700">
                  💡 Tip: Be specific with location and salary to get the most relevant matches
                </p>
              </CardContent>
            </Card>
          )}

          {currentStep === 3 && (
            <Card className="bg-orange-50 border-orange-200">
              <CardContent className="pt-4">
                <p className="text-xs text-orange-700">
                  💡 Tip: Start conservative with auto-apply rules - you can always expand them later
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function OnboardingChecklisst() {
  const [completedItems, setCompletedItems] = useState<string[]>([]);

  useEffect(() => {
    const completed = localStorage.getItem('applycaptain_checklist') 
      ? JSON.parse(localStorage.getItem('applycaptain_checklist') || '[]')
      : [];
    setCompletedItems(completed);
  }, []);

  const checklistItems = [
    {
      id: "resume",
      title: "Upload your primary resume",
      description: "Add at least one resume to enable job matching",
      required: true
    },
    {
      id: "preferences",
      title: "Set job preferences",
      description: "Configure location, salary, and role preferences",
      required: true
    },
    {
      id: "rules",
      title: "Create an auto-apply rule",
      description: "Set up automation for your job search",
      required: false
    },
    {
      id: "profile",
      title: "Complete your profile",
      description: "Add skills, experience, and career goals",
      required: false
    }
  ];

  const toggleItem = (itemId: string) => {
    const updated = completedItems.includes(itemId)
      ? completedItems.filter(id => id !== itemId)
      : [...completedItems, itemId];
    
    setCompletedItems(updated);
    localStorage.setItem('applycaptain_checklist', JSON.stringify(updated));
  };

  const completionRate = (completedItems.length / checklistItems.length) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Getting Started Checklist</CardTitle>
        <CardDescription>
          Complete these steps to optimize your job search
        </CardDescription>
        <Progress value={completionRate} className="w-full" />
        <p className="text-sm text-gray-500">{completedItems.length} of {checklistItems.length} completed</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {checklistItems.map((item) => (
            <div
              key={item.id}
              className={`flex items-start space-x-3 p-3 rounded-lg border transition-colors ${
                completedItems.includes(item.id)
                  ? 'bg-green-50 border-green-200'
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <button
                onClick={() => toggleItem(item.id)}
                className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                  completedItems.includes(item.id)
                    ? 'bg-green-600 border-green-600 text-white'
                    : 'border-gray-300 hover:border-green-400'
                }`}
              >
                {completedItems.includes(item.id) && <CheckCircle className="w-3 h-3" />}
              </button>
              
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <h4 className={`font-medium text-sm ${
                    completedItems.includes(item.id) ? 'line-through text-gray-500' : ''
                  }`}>
                    {item.title}
                  </h4>
                  {item.required && (
                    <Badge variant="outline" className="text-xs">Required</Badge>
                  )}
                </div>
                <p className="text-xs text-gray-600 mt-1">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Hook to check if user needs onboarding
export function useOnboardingStatus() {
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  useEffect(() => {
    const completed = localStorage.getItem('applycaptain_onboarding_completed');
    setNeedsOnboarding(!completed);
  }, []);

  const markOnboardingComplete = () => {
    localStorage.setItem('applycaptain_onboarding_completed', 'true');
    setNeedsOnboarding(false);
  };

  return { needsOnboarding, markOnboardingComplete };
}