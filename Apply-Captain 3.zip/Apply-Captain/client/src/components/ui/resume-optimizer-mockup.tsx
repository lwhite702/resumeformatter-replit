import { FileText, CheckCircle, AlertCircle, TrendingUp } from "lucide-react";

export function ResumeOptimizerMockup() {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 max-w-sm mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">Resume Analysis</h3>
        <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
          Score: 92
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-900 text-sm">ATS Optimized</p>
            <p className="text-gray-600 text-xs">Resume passes ATS screening</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-900 text-sm">Keywords Matched</p>
            <p className="text-gray-600 text-xs">18/20 relevant keywords found</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-900 text-sm">Skills Section</p>
            <p className="text-gray-600 text-xs">Add 2 more technical skills</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <TrendingUp className="w-5 h-5 text-blue-500 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-900 text-sm">Format Score</p>
            <p className="text-gray-600 text-xs">Excellent formatting detected</p>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Match Rate</span>
          <span className="text-sm font-bold text-gray-900">92%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-brand-accent h-2 rounded-full" style={{ width: '92%' }}></div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between text-xs text-gray-500">
        <span>Last optimized: Just now</span>
        <FileText className="w-4 h-4" />
      </div>
    </div>
  );
}