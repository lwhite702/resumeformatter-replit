import { useState, useEffect } from "react";
import { useAuth } from "./useAuth";

export function useOnboarding() {
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      // Check if user has completed onboarding
      const completed = localStorage.getItem(`applycaptain_onboarding_${user.id || 'guest'}`);
      const hasCompletedOnboarding = completed === 'true';
      
      setIsOnboardingComplete(hasCompletedOnboarding);
      
      // Show onboarding for new users
      if (!hasCompletedOnboarding) {
        // Small delay to ensure app is mounted
        const timer = setTimeout(() => {
          setShowOnboarding(true);
        }, 1000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [user]);

  const completeOnboarding = () => {
    if (user) {
      localStorage.setItem(`applycaptain_onboarding_${user.id || 'guest'}`, 'true');
    }
    setIsOnboardingComplete(true);
    setShowOnboarding(false);
  };

  const skipOnboarding = () => {
    if (user) {
      localStorage.setItem(`applycaptain_onboarding_${user.id || 'guest'}`, 'true');
    }
    setIsOnboardingComplete(true);
    setShowOnboarding(false);
  };

  const resetOnboarding = () => {
    if (user) {
      localStorage.removeItem(`applycaptain_onboarding_${user.id || 'guest'}`);
    }
    setIsOnboardingComplete(false);
    setShowOnboarding(true);
  };

  return {
    isOnboardingComplete,
    showOnboarding,
    completeOnboarding,
    skipOnboarding,
    resetOnboarding
  };
}