import { useState, useEffect } from 'react';
import { useUser } from '@clerk/clerk-react';
import { useRoute } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { 
  FileText, 
  Shield, 
  Code, 
  Settings, 
  Database, 
  Users, 
  CreditCard,
  Globe,
  Anchor,
  Lock
} from 'lucide-react';

interface DocSection {
  id: string;
  title: string;
  icon: any;
  content: string;
  subsections?: DocSection[];
}

const knowledgeBase: DocSection[] = [
  {
    id: 'overview',
    title: 'ApplyCaptain Overview',
    icon: Anchor,
    content: `
      <h2>ApplyCaptain - AI-Powered Job Application Platform</h2>
      <p>ApplyCaptain is a comprehensive job application automation platform that leverages AI to streamline the job search process through intelligent matching, automated applications, and career management tools.</p>
      
      <h3>Core Mission</h3>
      <p>Transform job searching into an engaging maritime adventure while providing powerful automation tools to help users land their dream jobs efficiently.</p>
      
      <h3>Target Audience</h3>
      <ul>
        <li>Job seekers looking to automate their application process</li>
        <li>Professionals seeking career advancement opportunities</li>
        <li>Users who want intelligent job matching and recommendations</li>
        <li>Individuals needing help with resume optimization and cover letters</li>
      </ul>
      
      <h3>Key Differentiators</h3>
      <ul>
        <li>Nautical-themed UI that makes job searching engaging</li>
        <li>AI-powered job matching and application automation</li>
        <li>Integration with Wrelik Brands ecosystem</li>
        <li>Comprehensive career management tools</li>
        <li>Real-time application tracking and analytics</li>
      </ul>
    `
  },
  {
    id: 'features',
    title: 'Feature Documentation',
    icon: Settings,
    content: `
      <h2>Core Features</h2>
      
      <h3>1. Onboarding & Setup</h3>
      <ul>
        <li><strong>Maritime Onboarding Tour:</strong> 5-step guided setup with captain's wheel progress indicator</li>
        <li><strong>Profile Creation:</strong> Comprehensive career profile setup</li>
        <li><strong>Resume Upload:</strong> Support for multiple resume formats and versions</li>
        <li><strong>Preferences Configuration:</strong> Job search criteria and automation rules</li>
      </ul>
      
      <h3>2. Job Discovery & Matching</h3>
      <ul>
        <li><strong>AI Job Matching:</strong> Intelligent algorithm matches users with relevant opportunities</li>
        <li><strong>Daily Job Queue:</strong> Curated daily list of recommended jobs</li>
        <li><strong>Job Board Integration:</strong> Connections with major job boards and company APIs</li>
        <li><strong>Custom Filters:</strong> Advanced filtering by location, salary, company, etc.</li>
      </ul>
      
      <h3>3. Application Automation</h3>
      <ul>
        <li><strong>Auto-Apply Rules:</strong> User-defined criteria for automatic applications</li>
        <li><strong>Cover Letter Generation:</strong> AI-powered personalized cover letters</li>
        <li><strong>Application Tracking:</strong> Real-time status updates and response tracking</li>
        <li><strong>Follow-up Management:</strong> Automated follow-up scheduling and reminders</li>
      </ul>
      
      <h3>4. Career Management</h3>
      <ul>
        <li><strong>Resume Library:</strong> Multiple resume versions for different job types</li>
        <li><strong>Application History:</strong> Comprehensive tracking of all applications</li>
        <li><strong>Analytics Dashboard:</strong> Success rates, response rates, and performance metrics</li>
        <li><strong>Interview Preparation:</strong> Integration with PrepPair.me for interview practice</li>
      </ul>
      
      <h3>5. Ecosystem Integration</h3>
      <ul>
        <li><strong>ResumeFormatter.io:</strong> Professional resume formatting and optimization</li>
        <li><strong>PrepPair.me:</strong> AI-powered interview preparation and practice</li>
        <li><strong>WrelikBrands Blog:</strong> Career advice and industry insights</li>
        <li><strong>Cross-Platform Sync:</strong> Seamless data sharing between Wrelik apps</li>
      </ul>
    `,
    subsections: [
      {
        id: 'onboarding-details',
        title: 'Onboarding System Details',
        icon: Users,
        content: `
          <h3>Onboarding Flow Breakdown</h3>
          
          <h4>Step 1: Welcome Aboard</h4>
          <p>Introduction to ApplyCaptain with maritime theme explanation and value proposition.</p>
          
          <h4>Step 2: Set Your Course</h4>
          <p>Career goals and job search preferences configuration including location, salary range, and industry preferences.</p>
          
          <h4>Step 3: Prepare Your Vessel</h4>
          <p>Resume upload and profile completion with skills assessment and experience mapping.</p>
          
          <h4>Step 4: Chart Navigation Rules</h4>
          <p>Auto-apply rules configuration including application frequency, job criteria, and communication preferences.</p>
          
          <h4>Step 5: Begin Your Voyage</h4>
          <p>Final setup confirmation and first job queue generation with tutorial completion celebration.</p>
          
          <h3>Technical Implementation</h3>
          <ul>
            <li>React component with useOnboarding hook for state management</li>
            <li>localStorage persistence for progress tracking</li>
            <li>Animated captain's wheel progress indicator</li>
            <li>Mobile-responsive design with touch-friendly interactions</li>
          </ul>
        `
      }
    ]
  },
  {
    id: 'pricing',
    title: 'Pricing & Plans',
    icon: CreditCard,
    content: `
      <h2>Subscription Plans</h2>
      
      <h3>Free Plan - "Dinghy"</h3>
      <ul>
        <li><strong>Price:</strong> $0/month</li>
        <li><strong>Features:</strong></li>
        <ul>
          <li>5 manual applications per month</li>
          <li>Basic job matching</li>
          <li>1 resume version</li>
          <li>Standard support</li>
          <li>Basic analytics</li>
        </ul>
        <li><strong>Target:</strong> Job seekers just getting started</li>
      </ul>
      
      <h3>Professional Plan - "Yacht"</h3>
      <ul>
        <li><strong>Price:</strong> $29/month</li>
        <li><strong>Features:</strong></li>
        <ul>
          <li>Unlimited applications</li>
          <li>AI-powered auto-apply</li>
          <li>Advanced job matching</li>
          <li>Unlimited resume versions</li>
          <li>Custom cover letters</li>
          <li>Advanced analytics</li>
          <li>Priority support</li>
          <li>API integrations</li>
        </ul>
        <li><strong>Target:</strong> Active job seekers and career changers</li>
      </ul>
      
      <h3>Enterprise Plan - "Fleet Command"</h3>
      <ul>
        <li><strong>Price:</strong> $99/month</li>
        <li><strong>Features:</strong></li>
        <ul>
          <li>Everything in Professional</li>
          <li>White-label options</li>
          <li>Custom integrations</li>
          <li>Dedicated account manager</li>
          <li>Team management features</li>
          <li>Advanced reporting</li>
          <li>SLA guarantees</li>
        </ul>
        <li><strong>Target:</strong> Recruiting agencies and enterprise users</li>
      </ul>
      
      <h3>Wrelik Ecosystem Discounts</h3>
      <ul>
        <li>Professional users get 50% off ResumeFormatter.io</li>
        <li>Professional users get 50% off PrepPair.me</li>
        <li>Enterprise users get full access to all Wrelik products</li>
      </ul>
    `
  },
  {
    id: 'api',
    title: 'API Documentation',
    icon: Code,
    content: `
      <h2>ApplyCaptain API Reference</h2>
      
      <h3>Authentication</h3>
      <p>All API endpoints use Clerk authentication with JWT tokens. Include the authorization header:</p>
      <pre><code>Authorization: Bearer {jwt_token}</code></pre>
      
      <h3>Core Endpoints</h3>
      
      <h4>User Management</h4>
      <ul>
        <li><code>GET /api/auth/user</code> - Get current user profile</li>
        <li><code>GET /api/dashboard/stats</code> - Get user dashboard statistics</li>
        <li><code>GET /api/settings</code> - Get user settings</li>
        <li><code>POST /api/settings</code> - Update user settings</li>
      </ul>
      
      <h4>Job Management</h4>
      <ul>
        <li><code>GET /api/jobs</code> - Get user's jobs with pagination</li>
        <li><code>POST /api/jobs</code> - Create new job entry</li>
        <li><code>GET /api/jobs/:id</code> - Get specific job details</li>
        <li><code>PUT /api/jobs/:id</code> - Update job information</li>
        <li><code>DELETE /api/jobs/:id</code> - Delete job entry</li>
        <li><code>GET /api/jobs/suggestions</code> - Get AI-powered job suggestions</li>
      </ul>
      
      <h4>Application Management</h4>
      <ul>
        <li><code>GET /api/applications</code> - Get application history</li>
        <li><code>POST /api/applications</code> - Submit new application</li>
        <li><code>PUT /api/applications/:id</code> - Update application status</li>
        <li><code>GET /api/applications/stats</code> - Get application statistics</li>
      </ul>
      
      <h4>Resume Management</h4>
      <ul>
        <li><code>GET /api/resumes</code> - Get user's resume library</li>
        <li><code>POST /api/resumes</code> - Upload new resume</li>
        <li><code>PUT /api/resumes/:id</code> - Update resume</li>
        <li><code>DELETE /api/resumes/:id</code> - Delete resume</li>
        <li><code>POST /api/resumes/sync</code> - Sync with ResumeFormatter.io</li>
      </ul>
      
      <h4>Auto-Apply Rules</h4>
      <ul>
        <li><code>GET /api/rules</code> - Get auto-apply rules</li>
        <li><code>POST /api/rules</code> - Create/update auto-apply rules</li>
      </ul>
      
      <h4>Daily Queue</h4>
      <ul>
        <li><code>GET /api/daily-queue</code> - Get daily job queue</li>
        <li><code>POST /api/daily-queue/generate</code> - Generate new daily queue</li>
      </ul>
      
      <h4>Blog Integration</h4>
      <ul>
        <li><code>GET /api/blog/posts</code> - Get blog posts with pagination</li>
        <li><code>GET /api/blog/posts/:slug</code> - Get specific blog post</li>
        <li><code>GET /api/blog/recent</code> - Get recent blog posts</li>
      </ul>
      
      <h3>Error Handling</h3>
      <p>All endpoints return standardized error responses:</p>
      <pre><code>{
  "error": "Error message",
  "code": "ERROR_CODE",
  "timestamp": "2025-06-18T12:00:00Z"
}</code></pre>
      
      <h3>Rate Limiting</h3>
      <ul>
        <li>Free users: 100 requests per hour</li>
        <li>Professional users: 1000 requests per hour</li>
        <li>Enterprise users: 10000 requests per hour</li>
      </ul>
    `
  },
  {
    id: 'database',
    title: 'Database Schema',
    icon: Database,
    content: `
      <h2>Database Schema Documentation</h2>
      
      <h3>Core Tables</h3>
      
      <h4>users</h4>
      <ul>
        <li><code>id</code> - Primary key (string)</li>
        <li><code>email</code> - User email address</li>
        <li><code>name</code> - Full name</li>
        <li><code>avatar_url</code> - Profile picture URL</li>
        <li><code>created_at</code> - Account creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>jobs</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>title</code> - Job title</li>
        <li><code>company</code> - Company name</li>
        <li><code>location</code> - Job location</li>
        <li><code>salary_min</code> - Minimum salary</li>
        <li><code>salary_max</code> - Maximum salary</li>
        <li><code>description</code> - Job description</li>
        <li><code>requirements</code> - Job requirements (JSON)</li>
        <li><code>url</code> - Original job posting URL</li>
        <li><code>status</code> - Job status (discovered, reviewed, applied, etc.)</li>
        <li><code>match_score</code> - AI matching score (0-100)</li>
        <li><code>source</code> - Job board source</li>
        <li><code>posted_at</code> - Job posting date</li>
        <li><code>created_at</code> - Discovery timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>applications</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>job_id</code> - Foreign key to jobs</li>
        <li><code>resume_id</code> - Foreign key to resumes</li>
        <li><code>cover_letter</code> - Generated cover letter</li>
        <li><code>status</code> - Application status</li>
        <li><code>applied_at</code> - Application submission timestamp</li>
        <li><code>response_at</code> - Employer response timestamp</li>
        <li><code>notes</code> - User notes</li>
        <li><code>created_at</code> - Record creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>resumes</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>name</code> - Resume name/version</li>
        <li><code>file_name</code> - Original filename</li>
        <li><code>skills</code> - Extracted skills (JSON)</li>
        <li><code>experience</code> - Work experience summary</li>
        <li><code>focus</code> - Career focus area</li>
        <li><code>match_history</code> - Job matching history (JSON)</li>
        <li><code>times_used</code> - Usage count</li>
        <li><code>is_active</code> - Active status</li>
        <li><code>external_id</code> - ResumeFormatter.io integration ID</li>
        <li><code>last_synced_at</code> - Last sync timestamp</li>
        <li><code>created_at</code> - Creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>auto_apply_rules</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>is_enabled</code> - Rule active status</li>
        <li><code>max_applications_per_day</code> - Daily application limit</li>
        <li><code>min_match_score</code> - Minimum matching score threshold</li>
        <li><code>preferred_locations</code> - Location preferences (JSON)</li>
        <li><code>salary_range</code> - Salary requirements (JSON)</li>
        <li><code>excluded_companies</code> - Companies to avoid (JSON)</li>
        <li><code>required_keywords</code> - Must-have keywords (JSON)</li>
        <li><code>excluded_keywords</code> - Keywords to avoid (JSON)</li>
        <li><code>created_at</code> - Creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>daily_queue</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>job_id</code> - Foreign key to jobs</li>
        <li><code>queue_date</code> - Date for this queue</li>
        <li><code>priority_score</code> - Priority ranking</li>
        <li><code>status</code> - Queue item status</li>
        <li><code>created_at</code> - Creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>user_settings</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>user_id</code> - Foreign key to users</li>
        <li><code>email_notifications</code> - Email notification preferences (JSON)</li>
        <li><code>privacy_settings</code> - Privacy configuration (JSON)</li>
        <li><code>theme_preferences</code> - UI theme settings (JSON)</li>
        <li><code>api_integrations</code> - Third-party integrations (JSON)</li>
        <li><code>created_at</code> - Creation timestamp</li>
        <li><code>updated_at</code> - Last update timestamp</li>
      </ul>
      
      <h4>cached_posts (Blog Integration)</h4>
      <ul>
        <li><code>id</code> - Primary key (serial)</li>
        <li><code>wp_id</code> - WordPress post ID</li>
        <li><code>title</code> - Post title</li>
        <li><code>slug</code> - URL slug</li>
        <li><code>excerpt</code> - Post excerpt</li>
        <li><code>content</code> - Full post content</li>
        <li><code>published_at</code> - Original publication date</li>
        <li><code>created_at</code> - Cache creation timestamp</li>
        <li><code>updated_at</code> - Last cache update</li>
      </ul>
    `
  },
  {
    id: 'setup',
    title: 'Setup & Configuration',
    icon: Settings,
    content: `
      <h2>Development Setup</h2>
      
      <h3>Prerequisites</h3>
      <ul>
        <li>Node.js 18+ and npm</li>
        <li>PostgreSQL database</li>
        <li>Clerk authentication account</li>
        <li>OpenAI API key</li>
      </ul>
      
      <h3>Environment Variables</h3>
      <pre><code># Authentication
CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/applycaptain

# AI Services
OPENAI_API_KEY=sk-...

# Optional Integrations
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...</code></pre>
      
      <h3>Installation Steps</h3>
      <ol>
        <li>Clone the repository</li>
        <li>Install dependencies: <code>npm install</code></li>
        <li>Set up environment variables</li>
        <li>Initialize database: <code>npm run db:push</code></li>
        <li>Start development server: <code>npm run dev</code></li>
      </ol>
      
      <h3>Production Deployment</h3>
      <ul>
        <li>Set production environment variables</li>
        <li>Build the application: <code>npm run build</code></li>
        <li>Configure reverse proxy (nginx recommended)</li>
        <li>Set up SSL certificates</li>
        <li>Configure database backups</li>
        <li>Set up monitoring and logging</li>
      </ul>
      
      <h3>Key Configuration Files</h3>
      <ul>
        <li><code>drizzle.config.ts</code> - Database configuration</li>
        <li><code>tailwind.config.ts</code> - Styling configuration</li>
        <li><code>vite.config.ts</code> - Build configuration</li>
        <li><code>package.json</code> - Dependencies and scripts</li>
      </ul>
    `
  }
];

function AdminDocs() {
  const { user } = useUser();
  const [, params] = useRoute('/admin/docs/:section?');
  const [selectedSection, setSelectedSection] = useState<string>('overview');

  // Check admin permissions
  const isAdmin = user?.publicMetadata?.role === 'admin' || 
                  user?.emailAddresses[0]?.emailAddress?.includes('admin') ||
                  user?.emailAddresses[0]?.emailAddress?.includes('wrelik');

  useEffect(() => {
    if (params?.section) {
      setSelectedSection(params.section);
    }
  }, [params]);

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900 dark:to-red-800 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center text-red-600 dark:text-red-400">
              <Lock className="h-5 w-5 mr-2" />
              Restricted Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-300">
              This documentation is restricted to administrators only. Please contact your system administrator for access.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentSection = knowledgeBase.find(section => section.id === selectedSection) || knowledgeBase[0];

  return (
    <>
      {/* NoIndex meta tag for SEO */}
      <head>
        <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
      </head>
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
                <FileText className="h-8 w-8 mr-3 text-blue-600 dark:text-blue-400" />
                ApplyCaptain Knowledge Base
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mt-2">
                Administrative Documentation & System Reference
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="destructive">Admin Only</Badge>
              <Badge variant="secondary">No Index</Badge>
            </div>
          </div>

          {/* Documentation Content */}
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar Navigation */}
            <div className="lg:col-span-1">
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle className="text-lg">Documentation Sections</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <nav className="space-y-1">
                    {knowledgeBase.map((section) => {
                      const IconComponent = section.icon;
                      return (
                        <button
                          key={section.id}
                          onClick={() => setSelectedSection(section.id)}
                          className={`w-full text-left px-4 py-3 flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ${
                            selectedSection === section.id 
                              ? 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 border-r-2 border-blue-600' 
                              : 'text-gray-700 dark:text-gray-300'
                          }`}
                        >
                          <IconComponent className="h-4 w-4" />
                          <span className="text-sm font-medium">{section.title}</span>
                        </button>
                      );
                    })}
                  </nav>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                      <currentSection.icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <CardTitle className="text-2xl">{currentSection.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div 
                    className="prose prose-lg dark:prose-invert max-w-none blog-content"
                    dangerouslySetInnerHTML={{ __html: currentSection.content }}
                  />
                  
                  {/* Subsections */}
                  {currentSection.subsections && currentSection.subsections.length > 0 && (
                    <div className="mt-8">
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                        Additional Information
                      </h3>
                      <Accordion type="single" collapsible className="w-full">
                        {currentSection.subsections.map((subsection) => {
                          const SubIconComponent = subsection.icon;
                          return (
                            <AccordionItem key={subsection.id} value={subsection.id}>
                              <AccordionTrigger className="text-left">
                                <div className="flex items-center space-x-3">
                                  <SubIconComponent className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                                  <span>{subsection.title}</span>
                                </div>
                              </AccordionTrigger>
                              <AccordionContent>
                                <div 
                                  className="prose dark:prose-invert max-w-none blog-content pl-7"
                                  dangerouslySetInnerHTML={{ __html: subsection.content }}
                                />
                              </AccordionContent>
                            </AccordionItem>
                          );
                        })}
                      </Accordion>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AdminDocs;