import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Settings, Flag, CreditCard, Plus, Edit, Trash2, Save, RefreshCw, Shield, Scale, Cookie, Database, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Schemas for form validation
const featureFlagSchema = z.object({
  app: z.string().min(1, "App is required"),
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
  enabled: z.boolean(),
  planRequired: z.string().optional(),
});

const billingPlanSchema = z.object({
  app: z.string().min(1, "App is required"),
  planKey: z.string().min(1, "Plan key is required"),
  stripePriceId: z.string().optional(),
  displayName: z.string().min(1, "Display name is required"),
  price: z.string().optional(),
  currency: z.string().default("USD"),
  interval: z.string().optional(),
  features: z.string(),
  isActive: z.boolean(),
});

type FeatureFlag = {
  id: number;
  app: string;
  name: string;
  description?: string;
  enabled: boolean;
  planRequired?: string;
  createdAt: string;
  updatedAt: string;
};

type BillingPlan = {
  id: number;
  app: string;
  planKey: string;
  stripePriceId?: string;
  displayName: string;
  price?: string;
  currency: string;
  interval?: string;
  features: string[];
  isActive: boolean;
  metadata: any;
  createdAt: string;
  updatedAt: string;
};

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState<"flags" | "plans" | "legal">("flags");
  const [editingFlag, setEditingFlag] = useState<FeatureFlag | null>(null);
  const [editingPlan, setEditingPlan] = useState<BillingPlan | null>(null);
  const [flagDialogOpen, setFlagDialogOpen] = useState(false);
  const [planDialogOpen, setPlanDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch feature flags
  const { data: featureFlags = [], isLoading: flagsLoading } = useQuery<FeatureFlag[]>({
    queryKey: ["/api/admin/feature-flags"],
  });

  // Fetch billing plans
  const { data: billingPlans = [], isLoading: plansLoading } = useQuery<BillingPlan[]>({
    queryKey: ["/api/admin/billing-plans"],
  });

  // Feature flag mutations
  const createFlagMutation = useMutation({
    mutationFn: (data: any) => 
      fetch("/api/admin/feature-flags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      setFlagDialogOpen(false);
      toast({ title: "Feature flag created successfully" });
    },
  });

  const updateFlagMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      fetch(`/api/admin/feature-flags/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      setEditingFlag(null);
      toast({ title: "Feature flag updated successfully" });
    },
  });

  const deleteFlagMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/admin/feature-flags/${id}`, { method: "DELETE" }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      toast({ title: "Feature flag deleted successfully" });
    },
  });

  // Billing plan mutations
  const createPlanMutation = useMutation({
    mutationFn: (data: any) => 
      fetch("/api/admin/billing-plans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/billing-plans"] });
      setPlanDialogOpen(false);
      toast({ title: "Billing plan created successfully" });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      fetch(`/api/admin/billing-plans/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/billing-plans"] });
      setEditingPlan(null);
      toast({ title: "Billing plan updated successfully" });
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/admin/billing-plans/${id}`, { method: "DELETE" }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/billing-plans"] });
      toast({ title: "Billing plan deleted successfully" });
    },
  });

  // Form handlers
  const flagForm = useForm({
    resolver: zodResolver(featureFlagSchema),
    defaultValues: {
      app: "ApplyCaptain",
      name: "",
      description: "",
      enabled: false,
      planRequired: "",
    },
  });

  const planForm = useForm({
    resolver: zodResolver(billingPlanSchema),
    defaultValues: {
      app: "ApplyCaptain",
      planKey: "",
      stripePriceId: "",
      displayName: "",
      price: "",
      currency: "USD",
      interval: "",
      features: "",
      isActive: true,
    },
  });

  const onFlagSubmit = (data: any) => {
    if (editingFlag) {
      updateFlagMutation.mutate({ id: editingFlag.id, data });
    } else {
      createFlagMutation.mutate(data);
    }
  };

  const onPlanSubmit = (data: any) => {
    const planData = {
      ...data,
      features: data.features.split(",").map((f: string) => f.trim()).filter(Boolean),
      price: data.price ? parseFloat(data.price) : null,
    };

    if (editingPlan) {
      updatePlanMutation.mutate({ id: editingPlan.id, data: planData });
    } else {
      createPlanMutation.mutate(planData);
    }
  };

  const openFlagDialog = (flag?: FeatureFlag) => {
    if (flag) {
      setEditingFlag(flag);
      flagForm.reset({
        app: flag.app,
        name: flag.name,
        description: flag.description || "",
        enabled: flag.enabled,
        planRequired: flag.planRequired || "",
      });
    } else {
      setEditingFlag(null);
      flagForm.reset();
    }
    setFlagDialogOpen(true);
  };

  const openPlanDialog = (plan?: BillingPlan) => {
    if (plan) {
      setEditingPlan(plan);
      planForm.reset({
        app: plan.app,
        planKey: plan.planKey,
        stripePriceId: plan.stripePriceId || "",
        displayName: plan.displayName,
        price: plan.price?.toString() || "",
        currency: plan.currency,
        interval: plan.interval || "",
        features: Array.isArray(plan.features) ? plan.features.join(", ") : "",
        isActive: plan.isActive,
      });
    } else {
      setEditingPlan(null);
      planForm.reset();
    }
    setPlanDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Settings className="h-6 w-6 text-blue-600" />
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                Admin Settings
              </h1>
            </div>
            <Badge variant="outline" className="text-xs">
              Production Environment
            </Badge>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-8 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab("flags")}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "flags"
                ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm"
                : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            }`}
          >
            <Flag className="h-4 w-4" />
            <span>Feature Flags</span>
          </button>
          <button
            onClick={() => setActiveTab("plans")}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "plans"
                ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm"
                : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            }`}
          >
            <CreditCard className="h-4 w-4" />
            <span>Billing Plans</span>
          </button>
          <button
            onClick={() => setActiveTab("legal")}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "legal"
                ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm"
                : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            }`}
          >
            <Settings className="h-4 w-4" />
            <span>Legal Content</span>
          </button>
        </div>

        {/* Feature Flags Tab */}
        {activeTab === "flags" && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <Flag className="h-5 w-5" />
                    <span>Feature Flags</span>
                  </CardTitle>
                  <CardDescription>
                    Control app features across the Wrelik Brands ecosystem
                  </CardDescription>
                </div>
                <Button onClick={() => openFlagDialog()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Flag
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {flagsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>App</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Plan Required</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {featureFlags.map((flag: FeatureFlag) => (
                      <TableRow key={flag.id}>
                        <TableCell>
                          <Badge variant="outline">{flag.app}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{flag.name}</TableCell>
                        <TableCell className="text-sm text-gray-600 dark:text-gray-300">
                          {flag.description || "—"}
                        </TableCell>
                        <TableCell>
                          <Badge variant={flag.enabled ? "default" : "secondary"}>
                            {flag.enabled ? "Enabled" : "Disabled"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {flag.planRequired ? (
                            <Badge variant="outline">{flag.planRequired}</Badge>
                          ) : (
                            "Free"
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openFlagDialog(flag)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteFlagMutation.mutate(flag.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        )}

        {/* Legal Content Tab */}
        {activeTab === "legal" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>WordPress Legal Content Integration</span>
                </CardTitle>
                <CardDescription>
                  Manage legal content sourced from WrelikBrands.com with dynamic variable substitution
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* WordPress Connection Status */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Connection Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">WordPress API</span>
                          <Badge variant="default">Connected</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Endpoint</span>
                          <span className="text-xs text-gray-500">wrelikbrands.com/wp-json</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Cache Status</span>
                          <Badge variant="outline">Active (1 hour TTL)</Badge>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="w-full"
                          onClick={() => {
                            fetch('/api/legal/clear-cache', { method: 'POST' })
                              .then(() => toast({ title: "Cache cleared successfully" }));
                          }}
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Clear Cache
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Variable Substitution Preview */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Variable Substitution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3 text-sm">
                        <div className="grid grid-cols-2 gap-2">
                          <span className="font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {'{{App Name}}'}
                          </span>
                          <span className="text-gray-600 dark:text-gray-300">ApplyCaptain</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <span className="font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {'{{Support Email}}'}
                          </span>
                          <span className="text-gray-600 dark:text-gray-300">help@applycaptain.com</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <span className="font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {'{{App Features}}'}
                          </span>
                          <span className="text-gray-600 dark:text-gray-300">Bulleted list</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <span className="font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                            {'{Brand Name}'}
                          </span>
                          <span className="text-gray-600 dark:text-gray-300">ApplyCaptain</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Legal Pages Status */}
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4">Legal Pages Status</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { slug: 'privacy-policy', title: 'Privacy Policy', icon: Shield },
                      { slug: 'terms-of-service', title: 'Terms of Service', icon: Scale },
                      { slug: 'cookie-policy', title: 'Cookie Policy', icon: Cookie },
                      { slug: 'data-retention', title: 'Data Retention', icon: Database }
                    ].map((page) => {
                      const Icon = page.icon;
                      return (
                        <Card key={page.slug}>
                          <CardContent className="pt-4">
                            <div className="flex items-center space-x-3">
                              <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                              <div className="flex-1">
                                <div className="font-medium text-sm">{page.title}</div>
                                <div className="text-xs text-gray-500">/{page.slug}</div>
                              </div>
                            </div>
                            <div className="mt-3 flex items-center justify-between">
                              <Badge variant="default" className="text-xs">Active</Badge>
                              <Button 
                                size="sm" 
                                variant="ghost"
                                onClick={() => window.open(`/legal/${page.slug}`, '_blank')}
                              >
                                <ExternalLink className="h-3 w-3" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>

                {/* WordPress Content Preview */}
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4">Content Preview</h3>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">Sample Privacy Policy Content</span>
                          <Badge variant="outline">Variable Substitution Applied</Badge>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-sm">
                          <p className="mb-2">
                            <strong>ApplyCaptain Privacy Policy</strong>
                          </p>
                          <p className="text-gray-600 dark:text-gray-300 mb-2">
                            This Privacy Policy outlines how ApplyCaptain, a product of Wrelik Brands, LLC, 
                            collects, uses, and protects your personal information.
                          </p>
                          <p className="text-gray-600 dark:text-gray-300">
                            Questions? Contact us at help@applycaptain.com or visit our knowledge base.
                          </p>
                        </div>
                        <div className="text-xs text-gray-500">
                          Content dynamically pulled from wrelikbrands.com and processed with brand-specific variables
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Billing Plans Tab */}
        {activeTab === "plans" && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <CreditCard className="h-5 w-5" />
                    <span>Billing Plans</span>
                  </CardTitle>
                  <CardDescription>
                    Manage subscription plans and pricing across all apps
                  </CardDescription>
                </div>
                <Button onClick={() => openPlanDialog()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {plansLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>App</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Display Name</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Features</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {billingPlans.map((plan: BillingPlan) => (
                      <TableRow key={plan.id}>
                        <TableCell>
                          <Badge variant="outline">{plan.app}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{plan.planKey}</TableCell>
                        <TableCell>{plan.displayName}</TableCell>
                        <TableCell>
                          {plan.price ? `$${plan.price}/${plan.interval}` : "Free"}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {Array.isArray(plan.features) && plan.features.slice(0, 2).map((feature, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                            {Array.isArray(plan.features) && plan.features.length > 2 && (
                              <Badge variant="secondary" className="text-xs">
                                +{plan.features.length - 2} more
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={plan.isActive ? "default" : "secondary"}>
                            {plan.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openPlanDialog(plan)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deletePlanMutation.mutate(plan.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Feature Flag Dialog */}
      <Dialog open={flagDialogOpen} onOpenChange={setFlagDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingFlag ? "Edit Feature Flag" : "Create Feature Flag"}
            </DialogTitle>
            <DialogDescription>
              Configure feature availability across applications
            </DialogDescription>
          </DialogHeader>
          <Form {...flagForm}>
            <form onSubmit={flagForm.handleSubmit(onFlagSubmit)} className="space-y-4">
              <FormField
                control={flagForm.control}
                name="app"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Application</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select app" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="ApplyCaptain">ApplyCaptain</SelectItem>
                        <SelectItem value="ResumeFormatter.io">ResumeFormatter.io</SelectItem>
                        <SelectItem value="PrepPair.me">PrepPair.me</SelectItem>
                        <SelectItem value="NameDrop.cv">NameDrop.cv</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={flagForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="ai_resume_matching" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={flagForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Feature description..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={flagForm.control}
                name="enabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Enabled</FormLabel>
                      <FormDescription>
                        Whether this feature is currently active
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={flagForm.control}
                name="planRequired"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plan Required</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select plan (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">Free (no restriction)</SelectItem>
                        <SelectItem value="pro_monthly">Pro Monthly</SelectItem>
                        <SelectItem value="pro_quarterly">Pro Quarterly</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" disabled={createFlagMutation.isPending || updateFlagMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {editingFlag ? "Update" : "Create"} Flag
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Billing Plan Dialog */}
      <Dialog open={planDialogOpen} onOpenChange={setPlanDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>
              {editingPlan ? "Edit Billing Plan" : "Create Billing Plan"}
            </DialogTitle>
            <DialogDescription>
              Configure subscription plans and pricing
            </DialogDescription>
          </DialogHeader>
          <Form {...planForm}>
            <form onSubmit={planForm.handleSubmit(onPlanSubmit)} className="space-y-4">
              <FormField
                control={planForm.control}
                name="app"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Application</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select app" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="ApplyCaptain">ApplyCaptain</SelectItem>
                        <SelectItem value="ResumeFormatter.io">ResumeFormatter.io</SelectItem>
                        <SelectItem value="PrepPair.me">PrepPair.me</SelectItem>
                        <SelectItem value="NameDrop.cv">NameDrop.cv</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={planForm.control}
                  name="planKey"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Plan Key</FormLabel>
                      <FormControl>
                        <Input placeholder="pro_monthly" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={planForm.control}
                  name="displayName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Pro Monthly" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={planForm.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price</FormLabel>
                      <FormControl>
                        <Input placeholder="29.99" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={planForm.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <FormControl>
                        <Input placeholder="USD" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={planForm.control}
                  name="interval"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Interval</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="month">Month</SelectItem>
                          <SelectItem value="year">Year</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={planForm.control}
                name="stripePriceId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stripe Price ID</FormLabel>
                    <FormControl>
                      <Input placeholder="price_1234567890" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={planForm.control}
                name="features"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Features</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="AI Resume Matching, Unlimited Applications, Priority Support"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Separate features with commas
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={planForm.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Active</FormLabel>
                      <FormDescription>
                        Whether this plan is available for subscription
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" disabled={createPlanMutation.isPending || updatePlanMutation.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  {editingPlan ? "Update" : "Create"} Plan
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}