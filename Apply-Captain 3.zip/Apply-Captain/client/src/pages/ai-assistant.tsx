import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, Send, Search, HelpCircle, BookOpen, MessageSquare, AlertCircle } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface KnowledgeArticle {
  id: number;
  title: string;
  summary: string;
  category: string;
  viewCount: number;
  helpfulCount: number;
}

interface SupportTicket {
  id: number;
  subject: string;
  category: string;
  status: string;
  priority: string;
  createdAt: string;
}

export default function AIAssistant() {
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "assistant",
      content: "Welcome to ApplyCaptain AI Assistant! I'm here to help you navigate your job search journey. How can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock knowledge base articles for demonstration
  const mockArticles = searchQuery.length > 2 ? [
    {
      id: 1,
      title: "Getting Started with AI Job Matching",
      summary: "Learn how to configure ApplyCaptain's AI to find the best job matches for your skills and preferences.",
      category: "getting-started",
      viewCount: 1250,
      helpfulCount: 98
    },
    {
      id: 2,
      title: "Optimizing Your Application Success Rate", 
      summary: "Best practices for improving your job application response rates using ApplyCaptain's analytics.",
      category: "features",
      viewCount: 890,
      helpfulCount: 76
    },
    {
      id: 3,
      title: "Troubleshooting AI Recommendations",
      summary: "Common issues with AI job recommendations and how to resolve them for better results.",
      category: "troubleshooting", 
      viewCount: 456,
      helpfulCount: 42
    }
  ].filter(article => 
    article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.summary.toLowerCase().includes(searchQuery.toLowerCase())
  ) : [];

  // Mock support tickets
  const mockSupportTickets = [
    {
      id: 1,
      subject: "AI not finding relevant jobs",
      category: "ai-assistance",
      status: "open",
      priority: "medium",
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 2,
      subject: "Application automation setup help",
      category: "technical",
      status: "resolved", 
      priority: "low",
      createdAt: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString()
    }
  ];

  // AI chat mutation
  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      // Mock AI response for demonstration
      await new Promise(resolve => setTimeout(resolve, 1000));
      return {
        message: `I understand you're asking about "${message}". As your ApplyCaptain AI assistant, I can help you navigate job applications, optimize your search strategy, and troubleshoot any platform features. What specific area would you like assistance with?`
      };
    },
    onSuccess: (response) => {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString(),
        role: "assistant",
        content: response.message,
        timestamp: new Date()
      };
      setChatMessages(prev => [...prev, assistantMessage]);
    },
    onError: () => {
      toast({
        title: "Chat Error",
        description: "Failed to get AI response. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Create support ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: any) => {
      // Mock ticket creation for demonstration
      await new Promise(resolve => setTimeout(resolve, 500));
      return { id: Date.now(), ...ticketData };
    },
    onSuccess: () => {
      toast({
        title: "Support Ticket Created",
        description: "Your support ticket has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/support/tickets'] });
    }
  });

  const handleSendMessage = () => {
    if (!currentMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: currentMessage,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(currentMessage);
    setCurrentMessage("");
  };

  const handleCreateTicket = (category: string, subject: string) => {
    createTicketMutation.mutate({
      brand: "applycaptain",
      category,
      subject,
      description: `Request for assistance with ${category}`,
      priority: "medium"
    });
  };

  return (
    <div className="min-h-screen bg-captain-gradient p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="heading-large text-white mb-4 captain-heading">
            AI Assistant Command Center
          </h1>
          <p className="text-large text-white/80 max-w-2xl mx-auto">
            Your intelligent navigation companion for job search success. Get instant help, search knowledge, and access support.
          </p>
        </div>

        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full grid-cols-4 glass-morphism border-white/20">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              AI Chat
            </TabsTrigger>
            <TabsTrigger value="knowledge" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Knowledge Base
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4" />
              Support
            </TabsTrigger>
            <TabsTrigger value="tickets" className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              My Tickets
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="mt-6">
            <Card className="glass-card border-white/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Bot className="w-6 h-6 text-cyan-400" />
                  Captain's AI Assistant
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                  {chatMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-4 rounded-2xl ${
                          message.role === 'user'
                            ? 'bg-ocean-wave text-white'
                            : 'bg-white/10 text-white border border-white/20'
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className="text-xs opacity-70 mt-2">
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Input
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    placeholder="Ask me about job searching, applications, or ApplyCaptain features..."
                    className="glass-morphism border-white/30 text-white placeholder:text-white/50"
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={chatMutation.isPending || !currentMessage.trim()}
                    className="bg-ocean-wave hover:bg-cyan-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="knowledge" className="mt-6">
            <Card className="glass-card border-white/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Search className="w-6 h-6 text-cyan-400" />
                  Knowledge Base Search
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search for help articles, guides, and FAQs..."
                    className="glass-morphism border-white/30 text-white placeholder:text-white/50"
                  />
                </div>

                {searchLoading && (
                  <p className="text-white/70 text-center py-8">Searching knowledge base...</p>
                )}

                {articles.length > 0 && (
                  <div className="grid gap-4">
                    {articles.map((article: KnowledgeArticle) => (
                      <div key={article.id} className="glass-morphism p-4 rounded-xl border border-white/20">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-white">{article.title}</h3>
                          <Badge variant="outline" className="text-white border-white/30">
                            {article.category}
                          </Badge>
                        </div>
                        <p className="text-white/80 text-sm mb-3">{article.summary}</p>
                        <div className="flex items-center gap-4 text-xs text-white/60">
                          <span>{article.viewCount} views</span>
                          <span>{article.helpfulCount} helpful</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {searchQuery.length > 2 && articles.length === 0 && !searchLoading && (
                  <p className="text-white/70 text-center py-8">
                    No articles found. Try different keywords or create a support ticket for personalized help.
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="glass-card border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Quick Support</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { category: "technical", label: "Technical Issues", description: "App bugs, login problems, sync issues" },
                    { category: "ai-assistance", label: "AI Assistance", description: "Job matching, application optimization" },
                    { category: "job-search", label: "Job Search Help", description: "Strategy, resume tips, interview prep" },
                    { category: "billing", label: "Billing & Account", description: "Subscription, payments, account management" }
                  ].map((item) => (
                    <Button
                      key={item.category}
                      variant="outline"
                      className="w-full justify-start text-left glass-morphism border-white/30 text-white hover:bg-white/10"
                      onClick={() => handleCreateTicket(item.category, `Help with ${item.label}`)}
                    >
                      <div>
                        <div className="font-semibold">{item.label}</div>
                        <div className="text-xs text-white/70">{item.description}</div>
                      </div>
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card className="glass-card border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Popular Help Topics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    "How to optimize AI job matching",
                    "Setting up automated applications",
                    "Understanding success analytics", 
                    "Connecting external job boards",
                    "Resume optimization best practices"
                  ].map((topic, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      className="w-full justify-start text-white/80 hover:text-white hover:bg-white/5"
                      onClick={() => setSearchQuery(topic)}
                    >
                      {topic}
                    </Button>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tickets" className="mt-6">
            <Card className="glass-card border-white/20">
              <CardHeader>
                <CardTitle className="text-white">My Support Tickets</CardTitle>
              </CardHeader>
              <CardContent>
                {supportTickets.length === 0 ? (
                  <p className="text-white/70 text-center py-8">
                    No support tickets yet. Create one if you need assistance!
                  </p>
                ) : (
                  <div className="space-y-4">
                    {supportTickets.map((ticket: SupportTicket) => (
                      <div key={ticket.id} className="glass-morphism p-4 rounded-xl border border-white/20">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-white">{ticket.subject}</h3>
                          <div className="flex gap-2">
                            <Badge 
                              variant={ticket.status === 'open' ? 'destructive' : 'default'}
                              className="text-xs"
                            >
                              {ticket.status}
                            </Badge>
                            <Badge variant="outline" className="text-xs text-white border-white/30">
                              {ticket.priority}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-white/60">
                          <span>Category: {ticket.category}</span>
                          <span>Created: {new Date(ticket.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}