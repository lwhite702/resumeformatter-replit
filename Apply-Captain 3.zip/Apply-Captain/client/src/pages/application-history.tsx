import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function ApplicationHistory() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("30");
  const { toast } = useToast();

  const { data: applications, isLoading } = useQuery({
    queryKey: ["/api/applications"],
    retry: false,
  });

  const deleteApplicationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/applications/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Application deleted",
        description: "The application has been removed from your history",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to delete",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "interview_scheduled":
        return "bg-green-100 text-green-800";
      case "under_review":
        return "bg-yellow-100 text-yellow-800";
      case "sent":
        return "bg-blue-100 text-blue-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "offer":
        return "bg-emerald-100 text-emerald-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatStatus = (status: string) => {
    switch (status) {
      case "interview_scheduled":
        return "Interview Scheduled";
      case "under_review":
        return "Under Review";
      case "sent":
        return "Application Sent";
      case "rejected":
        return "Not Selected";
      case "offer":
        return "Offer Received";
      default:
        return status;
    }
  };

  const getCompanyInitial = (company: string) => {
    return company.charAt(0).toUpperCase();
  };

  const filteredApplications = applications?.filter((app: any) => {
    if (statusFilter !== "all" && app.status !== statusFilter) {
      return false;
    }
    
    const daysAgo = parseInt(dateFilter);
    if (daysAgo > 0) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
      if (new Date(app.appliedAt) < cutoffDate) {
        return false;
      }
    }
    
    return true;
  }) || [];

  const handleExportCSV = () => {
    if (!applications || applications.length === 0) {
      toast({
        title: "No data to export",
        description: "You don't have any applications to export",
        variant: "destructive",
      });
      return;
    }

    const headers = ["Job Title", "Company", "Status", "Applied Date", "Source"];
    const csvContent = [
      headers.join(","),
      ...filteredApplications.map((app: any) => [
        `"${app.jobTitle}"`,
        `"${app.company}"`,
        `"${formatStatus(app.status)}"`,
        `"${new Date(app.appliedAt).toLocaleDateString()}"`,
        `"${app.source || 'Manual'}"`
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "application-history.csv";
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export successful",
      description: "Your application history has been downloaded",
    });
  };

  if (isLoading) {
    return (
      <main className="p-6">
        <div className="mb-6">
          <h3 className="text-2xl font-semibold text-gray-900 mb-2">Application History</h3>
          <p className="text-gray-600">Track all your job applications and their current status</p>
        </div>
        <div className="animate-pulse">
          <div className="h-32 bg-gray-200 rounded-lg mb-6"></div>
          <div className="h-96 bg-gray-200 rounded-lg"></div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-6">
      <div className="mb-6">
        <h3 className="text-2xl font-semibold text-gray-900 mb-2">Application History</h3>
        <p className="text-gray-600">Track all your job applications and their current status</p>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="sent">Application Sent</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                  <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                  <SelectItem value="rejected">Not Selected</SelectItem>
                  <SelectItem value="offer">Offer Received</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date Range</label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 3 months</SelectItem>
                  <SelectItem value="180">Last 6 months</SelectItem>
                  <SelectItem value="0">All time</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1"></div>
            <Button onClick={handleExportCSV} className="bg-wrelik-green hover:bg-green-600">
              <i className="fas fa-download mr-2"></i>
              Export CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Applications Table */}
      {filteredApplications.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <i className="fas fa-inbox text-gray-400 text-4xl mb-4"></i>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No applications found</h3>
            <p className="text-gray-600 mb-6">
              {applications?.length === 0 
                ? "You haven't submitted any applications yet." 
                : "No applications match your current filters."}
            </p>
            <Button 
              onClick={() => window.location.href = "/apply"}
              className="bg-wrelik-green hover:bg-green-600"
            >
              <i className="fas fa-plus mr-2"></i>
              Submit Your First Application
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Job Details</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Applied Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredApplications.map((application: any) => (
                    <TableRow key={application.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div>
                          <div className="font-medium text-gray-900">{application.jobTitle}</div>
                          <div className="text-sm text-gray-500">Application #{application.id}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                            <span className="text-xs font-medium text-blue-800">
                              {getCompanyInitial(application.company)}
                            </span>
                          </div>
                          <div className="font-medium text-gray-900">{application.company}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-500">
                        {new Date(application.appliedAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(application.status)}>
                          {formatStatus(application.status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-500 capitalize">
                        {application.source || "Manual"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-wrelik-blue hover:text-blue-700">
                            View
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-gray-400 hover:text-red-600"
                            onClick={() => deleteApplicationMutation.mutate(application.id)}
                            disabled={deleteApplicationMutation.isPending}
                          >
                            Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="bg-white px-4 py-3 border-t border-gray-200 sm:px-6">
              <div className="flex items-center justify-between">
                <div className="flex-1 flex justify-between sm:hidden">
                  <Button variant="outline" disabled>Previous</Button>
                  <Button variant="outline" disabled>Next</Button>
                </div>
                <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm text-gray-700">
                      Showing <span className="font-medium">1</span> to{" "}
                      <span className="font-medium">{Math.min(filteredApplications.length, 10)}</span> of{" "}
                      <span className="font-medium">{filteredApplications.length}</span> results
                    </p>
                  </div>
                  <div>
                    <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                      <Button variant="outline" size="sm" disabled>
                        <i className="fas fa-chevron-left"></i>
                      </Button>
                      <Button variant="outline" size="sm" className="bg-wrelik-blue text-white">
                        1
                      </Button>
                      <Button variant="outline" size="sm" disabled>
                        <i className="fas fa-chevron-right"></i>
                      </Button>
                    </nav>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
