import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLoadingModal } from "@/components/loading-modal";

export default function ApplyJobs() {
  const [jobUrl, setJobUrl] = useState("");
  const [analyzedJob, setAnalyzedJob] = useState<any>(null);
  const [coverLetter, setCoverLetter] = useState("");
  const [selectedResume, setSelectedResume] = useState<any>(null);
  const { toast } = useToast();
  const { show: showLoading, hide: hideLoading } = useLoadingModal();

  const analyzeJobMutation = useMutation({
    mutationFn: async (data: { url?: string; description?: string }) => {
      const response = await apiRequest("POST", "/api/jobs/analyze", data);
      return response.json();
    },
    onSuccess: (job) => {
      setAnalyzedJob(job);
      generateCoverLetter(job.id);
      toast({
        title: "Job analyzed successfully",
        description: `Found ${job.title} at ${job.company} with ${job.matchScore}% match`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const coverLetterMutation = useMutation({
    mutationFn: async (jobId: number) => {
      const response = await apiRequest("POST", `/api/jobs/${jobId}/cover-letter`, {});
      return response.json();
    },
    onSuccess: (data) => {
      setCoverLetter(data.coverLetter);
      setSelectedResume(data.resume);
      hideLoading();
    },
    onError: (error) => {
      hideLoading();
      toast({
        title: "Failed to generate cover letter",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const submitApplicationMutation = useMutation({
    mutationFn: async (data: { jobId: number; coverLetter: string; resumeUsed: string }) => {
      const response = await apiRequest("POST", `/api/jobs/${data.jobId}/apply`, data);
      return response.json();
    },
    onSuccess: () => {
      hideLoading();
      toast({
        title: "Application submitted successfully",
        description: "Your application has been sent and saved to your history",
      });
      // Reset form
      setJobUrl("");
      setAnalyzedJob(null);
      setCoverLetter("");
      setSelectedResume(null);
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
    },
    onError: (error) => {
      hideLoading();
      toast({
        title: "Submission failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAnalyzeJob = () => {
    if (!jobUrl.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter a job URL or description",
        variant: "destructive",
      });
      return;
    }

    showLoading("Analyzing Job", "Extracting job details and matching with your profile...");
    
    // Determine if it's a URL or description
    const isUrl = jobUrl.includes("http");
    analyzeJobMutation.mutate(
      isUrl ? { url: jobUrl } : { description: jobUrl }
    );
  };

  const generateCoverLetter = (jobId: number) => {
    showLoading("Generating Cover Letter", "Creating a personalized cover letter...");
    coverLetterMutation.mutate(jobId);
  };

  const handleSubmitApplication = () => {
    if (!analyzedJob || !coverLetter) {
      toast({
        title: "Incomplete application",
        description: "Please analyze a job and generate a cover letter first",
        variant: "destructive",
      });
      return;
    }

    showLoading("Submitting Application", "Sending your application...");
    submitApplicationMutation.mutate({
      jobId: analyzedJob.id,
      coverLetter,
      resumeUsed: selectedResume?.name || "Default Resume",
    });
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "bg-emerald-100 text-emerald-800";
    if (score >= 80) return "bg-green-100 text-green-800";
    if (score >= 70) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  return (
    <main className="p-6">
      <div className="max-w-4xl mx-auto">
        {/* Job URL Input */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Add Job to Apply</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              <div className="flex-1">
                <Label htmlFor="job-url">Job URL or Job Description</Label>
                <Input
                  id="job-url"
                  value={jobUrl}
                  onChange={(e) => setJobUrl(e.target.value)}
                  placeholder="Paste job URL from LinkedIn, Indeed, etc. or enter job description"
                  className="mt-2"
                />
              </div>
              <div className="flex items-end">
                <Button 
                  onClick={handleAnalyzeJob}
                  disabled={analyzeJobMutation.isPending}
                  className="bg-wrelik-green hover:bg-green-600"
                >
                  <i className="fas fa-search mr-2"></i>
                  {analyzeJobMutation.isPending ? "Analyzing..." : "Analyze Job"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Job Analysis Results */}
        {analyzedJob && (
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{analyzedJob.title}</h3>
                  <p className="text-gray-600">{analyzedJob.company} • {analyzedJob.location || "Location not specified"}</p>
                </div>
                <Badge className={getMatchScoreColor(analyzedJob.matchScore)}>
                  {analyzedJob.matchScore}% Match
                </Badge>
              </div>

              {/* Job Details */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Salary Range</h4>
                  <p className="text-gray-600">
                    {analyzedJob.salaryMin && analyzedJob.salaryMax
                      ? `$${analyzedJob.salaryMin.toLocaleString()} - $${analyzedJob.salaryMax.toLocaleString()}`
                      : "Not specified"}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Work Type</h4>
                  <p className="text-gray-600">{analyzedJob.workType || "Not specified"}</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Employment Type</h4>
                  <p className="text-gray-600">{analyzedJob.employmentType || "Not specified"}</p>
                </div>
              </div>

              {/* Key Requirements */}
              {analyzedJob.requirements && analyzedJob.requirements.length > 0 && (
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Key Requirements</h4>
                  <div className="flex flex-wrap gap-2">
                    {analyzedJob.requirements.map((req: string, index: number) => (
                      <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                        {req}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Resume Selection */}
              {selectedResume && (
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-3">Best Resume Match</h4>
                  <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <i className="fas fa-file-alt text-wrelik-blue mr-3"></i>
                        <div>
                          <p className="font-medium text-gray-900">{selectedResume.name}</p>
                          <p className="text-sm text-gray-600">
                            {selectedResume.focus} focus • Used {selectedResume.timesUsed} times
                          </p>
                        </div>
                      </div>
                      <Button variant="link" className="text-wrelik-blue">
                        View Resume
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Generated Cover Letter Preview */}
              {coverLetter && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">AI-Generated Cover Letter</h4>
                    <Button 
                      variant="link" 
                      onClick={() => generateCoverLetter(analyzedJob.id)}
                      disabled={coverLetterMutation.isPending}
                      className="text-wrelik-green"
                    >
                      <i className="fas fa-sync-alt mr-1"></i>
                      {coverLetterMutation.isPending ? "Regenerating..." : "Regenerate"}
                    </Button>
                  </div>
                  <Textarea
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    className="min-h-40 bg-gray-50"
                    placeholder="Cover letter will appear here..."
                  />
                </div>
              )}

              {/* Application Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="save-history" defaultChecked />
                    <Label htmlFor="save-history" className="text-sm text-gray-700">
                      Save to application history
                    </Label>
                  </div>
                </div>
                <div className="flex space-x-3">
                  <Button variant="outline">
                    Save for Later
                  </Button>
                  <Button 
                    onClick={handleSubmitApplication}
                    disabled={submitApplicationMutation.isPending || !coverLetter}
                    className="bg-wrelik-green hover:bg-green-600"
                  >
                    {submitApplicationMutation.isPending ? "Submitting..." : "Submit Application"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
}
