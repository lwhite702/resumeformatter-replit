import { useState, useEffect } from 'react';
import { Link, useRoute } from 'wouter';
import { ArrowLeft, Calendar, Clock, User, Share2, BookOpen, ExternalLink, Anchor } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface BlogPost {
  id: number;
  wpId: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  publishedAt: string;
}

interface BlogPostPreview {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  publishedAt: string;
}

// Table of Contents Component
function TableOfContents({ content }: { content: string }) {
  const headings = content.match(/<h[2-6][^>]*>.*?<\/h[2-6]>/gi) || [];
  
  if (headings.length === 0) return null;

  const tocItems = headings.map((heading, index) => {
    const level = parseInt(heading.match(/<h([2-6])/)?.[1] || '2');
    const text = heading.replace(/<[^>]*>/g, '');
    const id = `heading-${index}`;
    
    return { level, text, id, index };
  });

  return (
    <Card className="mb-8 bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center text-blue-900 dark:text-blue-100">
          <BookOpen className="h-5 w-5 mr-2" />
          Table of Contents
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <nav className="space-y-2">
          {tocItems.map((item) => (
            <div
              key={item.index}
              className={`${
                item.level === 2 ? 'ml-0' : 
                item.level === 3 ? 'ml-4' : 
                item.level === 4 ? 'ml-8' : 'ml-12'
              }`}
            >
              <a
                href={`#${item.id}`}
                className="text-sm text-blue-700 dark:text-blue-300 hover:text-blue-900 dark:hover:text-blue-100 hover:underline block py-1"
              >
                {item.text}
              </a>
            </div>
          ))}
        </nav>
      </CardContent>
    </Card>
  );
}

// Cross-brand promotion component
// SEO Head Component for Blog Posts
function BlogSEOHead({ post }: { post?: any }) {
  const title = post ? `${post.title} | AutoApply Blog` : 'Job Search Tips & Career Advice | AutoApply Blog';
  const description = post ? post.excerpt : 'Expert job search tips, career advice, and AI-powered application strategies. Learn how to optimize your job hunt with AutoApply by Wrelik.';
  
  return (
    <>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content={post ? "article" : "website"} />
      {post && (
        <>
          <meta property="article:published_time" content={post.publishedAt} />
          <meta property="article:author" content="Wrelik Brands" />
          <meta property="article:section" content="Career Advice" />
        </>
      )}
    </>
  );
}

function CrossBrandPromotion() {
  const promotions = [
    {
      brand: 'ResumeFormatter.io',
      title: 'Perfect Your Resume Format',
      description: 'Professional resume templates that get noticed by recruiters',
      cta: 'Format Resume',
      color: 'bg-green-500',
      url: 'https://resumeformatter.io'
    },
    {
      brand: 'PrepPair.me',
      title: 'Ace Your Interviews',
      description: 'AI-powered interview preparation with real-time feedback',
      cta: 'Start Practicing',
      color: 'bg-purple-500',
      url: 'https://preppair.me'
    },
    {
      brand: 'WrelikBrands',
      title: 'Explore Our Ecosystem',
      description: 'Discover more career-boosting tools and resources',
      cta: 'Learn More',
      color: 'bg-orange-500',
      url: 'https://wrelikbrands.com'
    }
  ];

  const [currentPromo, setCurrentPromo] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPromo((prev) => (prev + 1) % promotions.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const promo = promotions[currentPromo];

  return (
    <Card className={`${promo.color} text-white border-0 mb-8`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="font-bold text-lg mb-1">{promo.brand}</h3>
            <h4 className="font-semibold mb-2">{promo.title}</h4>
            <p className="text-sm opacity-90 mb-3">{promo.description}</p>
            <Button 
              variant="secondary" 
              size="sm" 
              className="bg-white text-gray-900 hover:bg-gray-100"
              asChild
            >
              <a href={promo.url} target="_blank" rel="noopener noreferrer">
                {promo.cta}
                <ExternalLink className="h-4 w-4 ml-2" />
              </a>
            </Button>
          </div>
          <div className="ml-4">
            <div className="flex space-x-1">
              {promotions.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full ${
                    index === currentPromo ? 'bg-white' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Related Articles Component
function RelatedArticles({ currentSlug, posts }: { currentSlug?: string; posts: BlogPostPreview[] }) {
  const relatedPosts = posts
    .filter(post => post.slug !== currentSlug)
    .slice(0, 3);

  if (relatedPosts.length === 0) return null;

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle className="text-lg">Related Articles</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {relatedPosts.map((post) => (
            <div key={post.id} className="border-l-4 border-blue-500 pl-4">
              <Link href={`/blog/${post.slug}`}>
                <h4 className="font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200 cursor-pointer line-clamp-2">
                  {post.title}
                </h4>
              </Link>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {new Date(post.publishedAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Blog List Component
function BlogList() {
  const [posts, setPosts] = useState<BlogPostPreview[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch('/api/blog/posts');
        if (response.ok) {
          const data = await response.json();
          setPosts(data.posts);
        }
      } catch (error) {
        console.error('Failed to fetch posts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(5)].map((_, i) => (
          <Card key={i} className="p-6">
            <div className="animate-pulse">
              <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-3"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <Card key={post.id} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
              <Calendar className="h-4 w-4 mr-2" />
              {new Date(post.publishedAt).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric'
              })}
            </div>
            <CardTitle className="text-xl hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              <Link href={`/blog/${post.slug}`}>
                {post.title}
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
              {post.excerpt.replace(/<[^>]*>/g, '')}
            </p>
            <Link href={`/blog/${post.slug}`}>
              <Button variant="outline" size="sm">
                Read Full Article
              </Button>
            </Link>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// Single Blog Post Component
function BlogPost({ slug }: { slug: string }) {
  const [post, setPost] = useState<BlogPost | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogPostPreview[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const [postResponse, relatedResponse] = await Promise.all([
          fetch(`/api/blog/posts/${slug}`),
          fetch('/api/blog/recent?limit=6')
        ]);

        if (postResponse.ok) {
          const postData = await postResponse.json();
          setPost(postData);
        }

        if (relatedResponse.ok) {
          const relatedData = await relatedResponse.json();
          setRelatedPosts(relatedData);
        }
      } catch (error) {
        console.error('Failed to fetch post:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded mb-6"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
          <div className="space-y-3">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Article Not Found
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          The article you're looking for doesn't exist or has been moved.
        </p>
        <Link href="/blog">
          <Button>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Blog
          </Button>
        </Link>
      </div>
    );
  }

  // Add IDs to headings for table of contents navigation
  const processContent = (content: string) => {
    return content.replace(/<h([2-6])([^>]*)>/gi, (match, level, attrs, offset) => {
      const headingIndex = (content.substring(0, offset).match(/<h[2-6]/gi) || []).length;
      return `<h${level}${attrs} id="heading-${headingIndex}">`;
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Breadcrumbs */}
      <nav className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
        <Link href="/" className="hover:text-blue-600 dark:hover:text-blue-400">
          ApplyCaptain
        </Link>
        <span>/</span>
        <Link href="/blog" className="hover:text-blue-600 dark:hover:text-blue-400">
          Blog
        </Link>
        <span>/</span>
        <span className="text-gray-900 dark:text-white">{post.title}</span>
      </nav>

      {/* Article Header */}
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
          {post.title}
        </h1>
        <div className="flex items-center space-x-4 text-gray-600 dark:text-gray-400">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            {new Date(post.publishedAt).toLocaleDateString('en-US', {
              month: 'long',
              day: 'numeric',
              year: 'numeric'
            })}
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            {Math.ceil(post.content.split(' ').length / 200)} min read
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            WrelikBrands Team
          </div>
        </div>
      </header>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-3">
          <TableOfContents content={post.content} />
          
          <article className="prose prose-lg dark:prose-invert max-w-none mb-12">
            <div 
              dangerouslySetInnerHTML={{ 
                __html: processContent(post.content) 
              }}
              className="blog-content"
            />
          </article>

          {/* Share & Navigation */}
          <div className="flex items-center justify-between border-t pt-6 mb-8">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-gray-900 dark:text-white">Share:</span>
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-2" />
                Share Article
              </Button>
            </div>
            <Link href="/blog">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Blog
              </Button>
            </Link>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-8 space-y-6">
            <CrossBrandPromotion />
            <RelatedArticles currentSlug={post.slug} posts={relatedPosts} />
            
            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Career Tips</Badge>
                  <Badge variant="secondary">Job Search</Badge>
                  <Badge variant="secondary">Professional Growth</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Main Blog Page Component
export default function Blog() {
  const [match, params] = useRoute('/blog/:slug');
  const [allPosts, setAllPosts] = useState<BlogPostPreview[]>([]);

  useEffect(() => {
    const fetchAllPosts = async () => {
      try {
        const response = await fetch('/api/blog/posts');
        if (response.ok) {
          const data = await response.json();
          setAllPosts(data.posts);
        }
      } catch (error) {
        console.error('Failed to fetch posts:', error);
      }
    };

    fetchAllPosts();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {match && params?.slug ? (
          <BlogPost slug={params.slug} />
        ) : (
          <>
            {/* Blog Header */}
            <div className="text-center mb-12">
              <div className="flex items-center justify-center mb-4">
                <Anchor className="h-8 w-8 text-blue-600 dark:text-blue-400 mr-3" />
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
                  ApplyCaptain Blog
                </h1>
              </div>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Navigate your career journey with expert insights, job search strategies, and professional growth tips
              </p>
            </div>

            <div className="grid lg:grid-cols-4 gap-8">
              {/* Blog Posts */}
              <div className="lg:col-span-3">
                <BlogList />
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-8 space-y-6">
                  <CrossBrandPromotion />
                  <RelatedArticles posts={allPosts} />
                  
                  {/* Categories */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Categories</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Career Tips</span>
                          <Badge variant="outline" className="text-xs">12</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Job Search</span>
                          <Badge variant="outline" className="text-xs">8</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Professional Growth</span>
                          <Badge variant="outline" className="text-xs">6</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Tags */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Popular Tags</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline" className="text-xs">resume</Badge>
                        <Badge variant="outline" className="text-xs">interview</Badge>
                        <Badge variant="outline" className="text-xs">networking</Badge>
                        <Badge variant="outline" className="text-xs">career-change</Badge>
                        <Badge variant="outline" className="text-xs">remote-work</Badge>
                        <Badge variant="outline" className="text-xs">salary</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}