import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function DailyQueueDemo() {
  const [queueDate, setQueueDate] = useState(new Date().toISOString().split('T')[0]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Demo data showcasing the intelligent auto-application engine
  const queueJobs = [
    {
      id: 1,
      position: 1,
      status: "pending",
      scheduledTime: "09:00",
      job: {
        id: 1,
        title: "Senior Full Stack Developer",
        company: "TechCorp Inc",
        location: "Remote",
        workType: "remote",
        employmentType: "full-time",
        salaryMin: 120000,
        salaryMax: 160000,
        url: "https://example.com/job1",
        source: "linkedin",
        matchScore: 92,
        aiMatchScore: 88,
        status: "discovered",
      },
    },
    {
      id: 2,
      position: 2,
      status: "pending",
      scheduledTime: "09:15",
      job: {
        id: 2,
        title: "React Developer",
        company: "StartupXYZ",
        location: "San Francisco, CA",
        workType: "hybrid",
        employmentType: "full-time",
        salaryMin: 100000,
        salaryMax: 140000,
        url: "https://example.com/job2",
        source: "indeed",
        matchScore: 85,
        aiMatchScore: 82,
        status: "discovered",
      },
    },
    {
      id: 3,
      position: 3,
      status: "completed",
      scheduledTime: "09:30",
      job: {
        id: 3,
        title: "Frontend Engineer",
        company: "InnovateLab",
        location: "New York, NY",
        workType: "onsite",
        employmentType: "full-time",
        salaryMin: 90000,
        salaryMax: 130000,
        url: "https://example.com/job3",
        source: "email",
        matchScore: 78,
        aiMatchScore: 75,
        status: "applied",
      },
    },
  ];

  const emailJobs = [
    {
      id: 1,
      subject: "Exciting Frontend Developer Opportunity at MetaCorp",
      sender: "recruiter@metacorp.com",
      company: "MetaCorp",
      title: "Frontend Developer",
      confidence: 92,
    },
    {
      id: 2,
      subject: "Join Our Engineering Team - Senior Full Stack Role",
      sender: "talent@techvision.io",
      company: "TechVision",
      title: "Senior Full Stack Engineer",
      confidence: 88,
    },
  ];

  const handleGenerateQueue = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      alert("Queue generated successfully! Added 3 jobs to your daily queue");
    }, 2000);
  };

  const handleProcessQueue = (mode: string) => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const action = mode === "auto" ? "automatically applied to" : "reviewed";
      alert(`Queue processed successfully! ${action} 2 jobs, 0 failed`);
    }, 3000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "skipped":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-600 font-bold";
    if (score >= 80) return "text-green-600 font-semibold";
    if (score >= 70) return "text-yellow-600 font-medium";
    return "text-red-600 font-medium";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl flex items-center justify-center shadow-lg mr-3">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-white">
                  <path d="M12 2L2 7v10c0 5.55 3.84 9.95 9 11 5.16-1.05 9-5.45 9-11V7l-10-5z" fill="currentColor"/>
                  <path d="M8 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AutoApply by Wrelik</h1>
                <p className="text-sm text-gray-600">Daily Queue Demo</p>
              </div>
            </div>
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              Demo Mode
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-8">
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Daily Queue</h3>
          <p className="text-gray-600">AI-curated jobs ready for automated application</p>
        </div>

        {/* Queue Controls */}
        <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg text-gray-900">Queue Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Queue Date</label>
                  <input
                    type="date"
                    value={queueDate}
                    onChange={(e) => setQueueDate(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="pt-6">
                  <Button 
                    onClick={handleGenerateQueue}
                    disabled={isProcessing}
                    className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white rounded-xl"
                  >
                    <i className="fas fa-magic mr-2"></i>
                    {isProcessing ? "Generating..." : "Generate Queue"}
                  </Button>
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={() => handleProcessQueue("review")}
                  disabled={isProcessing}
                  variant="outline"
                  className="rounded-xl"
                >
                  <i className="fas fa-eye mr-2"></i>
                  Review & Apply
                </Button>
                <Button 
                  onClick={() => handleProcessQueue("auto")}
                  disabled={isProcessing}
                  className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white rounded-xl"
                >
                  <i className="fas fa-bolt mr-2"></i>
                  Auto Apply All
                </Button>
              </div>
            </div>

            {/* Queue Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-gray-200">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{queueJobs.length}</div>
                <div className="text-sm text-gray-600">Total Jobs</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {queueJobs.filter(job => job.status === "pending").length}
                </div>
                <div className="text-sm text-gray-600">Pending</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {queueJobs.filter(job => job.status === "completed").length}
                </div>
                <div className="text-sm text-gray-600">Applied</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">0</div>
                <div className="text-sm text-gray-600">Failed</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email Job Suggestions */}
        <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-lg text-gray-900 flex items-center">
              <i className="fas fa-envelope text-blue-600 mr-2"></i>
              Email Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {emailJobs.map((emailJob) => (
                <div key={emailJob.id} className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{emailJob.title}</h4>
                    <p className="text-sm text-gray-600">{emailJob.company} • {emailJob.sender}</p>
                    <div className="flex items-center mt-2">
                      <Badge className="bg-blue-100 text-blue-800 mr-2">
                        {emailJob.confidence}% confidence
                      </Badge>
                      <span className="text-xs text-gray-600">{emailJob.subject}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="rounded-lg">
                      <i className="fas fa-times mr-1"></i>
                      Dismiss
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white rounded-lg"
                    >
                      <i className="fas fa-plus mr-1"></i>
                      Add to Queue
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Queue Jobs Table */}
        <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Position</TableHead>
                    <TableHead>Job Details</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Match Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {queueJobs.map((queueJob, index) => (
                    <TableRow key={queueJob.id} className="hover:bg-blue-50">
                      <TableCell>
                        <div className="flex items-center">
                          <span className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-semibold text-blue-600">
                            {index + 1}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-semibold text-gray-900">{queueJob.job.title}</div>
                          <div className="text-sm text-gray-600">{queueJob.job.location}</div>
                          <div className="text-xs text-gray-500 mt-1">
                            {queueJob.job.workType} • {queueJob.job.employmentType}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-gray-900">{queueJob.job.company}</div>
                        {queueJob.job.salaryMin && queueJob.job.salaryMax && (
                          <div className="text-sm text-gray-600">
                            ${queueJob.job.salaryMin.toLocaleString()} - ${queueJob.job.salaryMax.toLocaleString()}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className={`text-sm ${getMatchScoreColor(queueJob.job.aiMatchScore || 0)}`}>
                            AI: {queueJob.job.aiMatchScore || 0}%
                          </div>
                          {queueJob.job.matchScore && (
                            <div className="text-xs text-gray-500">
                              Rules: {queueJob.job.matchScore}%
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(queueJob.status)}>
                          {queueJob.status}
                        </Badge>
                        <div className="text-xs text-gray-500 mt-1">
                          {queueJob.scheduledTime}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {queueJob.status === "pending" && (
                            <>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="rounded-lg"
                              >
                                Skip
                              </Button>
                              <Button 
                                size="sm"
                                className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white rounded-lg"
                              >
                                Apply Now
                              </Button>
                            </>
                          )}
                          {queueJob.status === "failed" && (
                            <Button 
                              size="sm"
                              variant="outline"
                              className="rounded-lg"
                            >
                              <i className="fas fa-redo mr-1"></i>
                              Retry
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}