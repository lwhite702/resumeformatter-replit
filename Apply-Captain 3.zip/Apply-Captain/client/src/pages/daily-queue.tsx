import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ContextualHelp, QuickTip } from "@/components/ui/contextual-help";
import { InlineHelpTooltip } from "@/components/ui/floating-help-widget";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLoadingModal } from "@/components/loading-modal";

export default function DailyQueue() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const { show: showLoading, hide: hideLoading } = useLoadingModal();
  const [queueDate, setQueueDate] = useState(new Date().toISOString().split('T')[0]);

  // Demo data for Daily Queue
  const demoQueueJobs = [
    {
      id: 1,
      position: 1,
      status: "pending",
      scheduledTime: "09:00",
      job: {
        id: 1,
        title: "Senior Full Stack Developer",
        company: "TechCorp Inc",
        location: "Remote",
        workType: "remote",
        employmentType: "full-time",
        salaryMin: 120000,
        salaryMax: 160000,
        url: "https://example.com/job1",
        source: "linkedin",
        matchScore: 92,
        aiMatchScore: 88,
        status: "discovered",
      },
    },
    {
      id: 2,
      position: 2,
      status: "pending",
      scheduledTime: "09:15",
      job: {
        id: 2,
        title: "React Developer",
        company: "StartupXYZ",
        location: "San Francisco, CA",
        workType: "hybrid",
        employmentType: "full-time",
        salaryMin: 100000,
        salaryMax: 140000,
        url: "https://example.com/job2",
        source: "indeed",
        matchScore: 85,
        aiMatchScore: 82,
        status: "discovered",
      },
    },
    {
      id: 3,
      position: 3,
      status: "completed",
      scheduledTime: "09:30",
      job: {
        id: 3,
        title: "Frontend Engineer",
        company: "InnovateLab",
        location: "New York, NY",
        workType: "onsite",
        employmentType: "full-time",
        salaryMin: 90000,
        salaryMax: 130000,
        url: "https://example.com/job3",
        source: "email",
        matchScore: 78,
        aiMatchScore: 75,
        status: "applied",
      },
    },
  ];

  const demoEmailJobs = [
    {
      id: 1,
      subject: "Exciting Frontend Developer Opportunity at MetaCorp",
      sender: "recruiter@metacorp.com",
      company: "MetaCorp",
      title: "Frontend Developer",
      confidence: 92,
    },
    {
      id: 2,
      subject: "Join Our Engineering Team - Senior Full Stack Role",
      sender: "talent@techvision.io",
      company: "TechVision",
      title: "Senior Full Stack Engineer",
      confidence: 88,
    },
  ];

  const { data: queueJobs = demoQueueJobs, isLoading } = useQuery<any[]>({
    queryKey: ["/api/daily-queue", queueDate],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: rules } = useQuery({
    queryKey: ["/api/rules"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: emailJobs = demoEmailJobs } = useQuery<any[]>({
    queryKey: ["/api/email-jobs"],
    enabled: isAuthenticated,
    retry: false,
  });

  const generateQueueMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/daily-queue/generate", { date: queueDate });
      return response.json();
    },
    onSuccess: (data) => {
      hideLoading();
      queryClient.invalidateQueries({ queryKey: ["/api/daily-queue"] });
      toast({
        title: "Queue generated successfully",
        description: `Added ${data.count} jobs to your daily queue`,
      });
    },
    onError: (error) => {
      hideLoading();
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to generate queue",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const processQueueMutation = useMutation({
    mutationFn: async (mode: string) => {
      const response = await apiRequest("POST", "/api/daily-queue/process", { 
        date: queueDate, 
        mode 
      });
      return response.json();
    },
    onSuccess: (data) => {
      hideLoading();
      queryClient.invalidateQueries({ queryKey: ["/api/daily-queue"] });
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Queue processed successfully",
        description: `Applied to ${data.applied} jobs, ${data.failed} failed`,
      });
    },
    onError: (error) => {
      hideLoading();
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to process queue",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateJobStatusMutation = useMutation({
    mutationFn: async ({ jobId, status }: { jobId: number; status: string }) => {
      const response = await apiRequest("PATCH", `/api/daily-queue/${jobId}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-queue"] });
      toast({
        title: "Job status updated",
        description: "Queue has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update job",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerateQueue = () => {
    showLoading("Generating Queue", "AI is analyzing and selecting the best job matches...");
    generateQueueMutation.mutate();
  };

  const handleProcessQueue = (mode: string) => {
    const modeLabel = mode === "auto" ? "automatically applying" : "reviewing applications";
    showLoading("Processing Queue", `Starting ${modeLabel} to jobs in queue...`);
    processQueueMutation.mutate(mode);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "skipped":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-600 font-bold";
    if (score >= 80) return "text-green-600 font-semibold";
    if (score >= 70) return "text-yellow-600 font-medium";
    return "text-red-600 font-medium";
  };

  if (authLoading) {
    return (
      <main className="p-8">
        <div className="mb-8">
          <h3 className="text-2xl font-bold brand-text-primary text-display mb-2">Daily Queue</h3>
          <p className="brand-text-secondary">AI-curated jobs ready for automated application</p>
        </div>
        <div className="animate-pulse space-y-6">
          <div className="h-32 bg-gray-200 rounded-xl"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </main>
    );
  }

  if (isLoading) {
    return (
      <main className="p-8">
        <div className="mb-8">
          <h3 className="text-2xl font-bold brand-text-primary text-display mb-2">Daily Queue</h3>
          <p className="brand-text-secondary">AI-curated jobs ready for automated application</p>
        </div>
        <div className="animate-pulse space-y-6">
          <div className="h-32 bg-gray-200 rounded-xl"></div>
          <div className="h-96 bg-gray-200 rounded-xl"></div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-8">
      <div className="mb-8">
        <h3 className="text-2xl font-bold brand-text-primary text-display mb-2">Daily Queue</h3>
        <p className="brand-text-secondary">AI-curated jobs ready for automated application</p>
      </div>

      {/* Queue Controls */}
      <Card className="mb-8 shadow-soft border-0">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg brand-text-primary">Queue Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <label className="block text-sm font-medium brand-text-secondary mb-2">Queue Date</label>
                <input
                  type="date"
                  value={queueDate}
                  onChange={(e) => setQueueDate(e.target.value)}
                  className="px-3 py-2 border brand-border rounded-lg focus:ring-2 focus:ring-brand-accent focus:border-transparent"
                />
              </div>
              <div className="pt-6">
                <Button 
                  onClick={handleGenerateQueue}
                  disabled={generateQueueMutation.isPending}
                  className="bg-brand-accent hover:bg-brand-accent-light text-white rounded-xl"
                >
                  <i className="fas fa-magic mr-2"></i>
                  {generateQueueMutation.isPending ? "Generating..." : "Generate Queue"}
                </Button>
              </div>
            </div>

            {queueJobs?.length > 0 && (
              <div className="flex gap-3">
                <Button 
                  onClick={() => handleProcessQueue("review")}
                  disabled={processQueueMutation.isPending}
                  variant="outline"
                  className="rounded-xl"
                >
                  <i className="fas fa-eye mr-2"></i>
                  Review & Apply
                </Button>
                <Button 
                  onClick={() => handleProcessQueue("auto")}
                  disabled={processQueueMutation.isPending}
                  className="bg-brand-primary hover:bg-brand-secondary text-white rounded-xl"
                >
                  <i className="fas fa-bolt mr-2"></i>
                  Auto Apply All
                </Button>
              </div>
            )}
          </div>

          {/* Queue Stats */}
          {queueJobs?.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t brand-border">
              <div className="text-center">
                <div className="text-2xl font-bold brand-text-primary">{queueJobs.length}</div>
                <div className="text-sm brand-text-secondary">Total Jobs</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold brand-accent">
                  {queueJobs.filter((job: any) => job.status === "pending").length}
                </div>
                <div className="text-sm brand-text-secondary">Pending</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {queueJobs.filter((job: any) => job.status === "completed").length}
                </div>
                <div className="text-sm brand-text-secondary">Applied</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {queueJobs.filter((job: any) => job.status === "failed").length}
                </div>
                <div className="text-sm brand-text-secondary">Failed</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Email Job Suggestions */}
      {emailJobs?.length > 0 && (
        <Card className="mb-8 shadow-soft border-0">
          <CardHeader>
            <CardTitle className="text-lg brand-text-primary flex items-center">
              <i className="fas fa-envelope text-brand-accent mr-2"></i>
              Email Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {emailJobs.slice(0, 3).map((emailJob: any) => (
                <div key={emailJob.id} className="flex items-center justify-between p-4 bg-brand-surface rounded-xl">
                  <div className="flex-1">
                    <h4 className="font-semibold brand-text-primary">{emailJob.title}</h4>
                    <p className="text-sm brand-text-secondary">{emailJob.company} • {emailJob.sender}</p>
                    <div className="flex items-center mt-2">
                      <Badge className="bg-blue-100 text-blue-800 mr-2">
                        {emailJob.confidence}% confidence
                      </Badge>
                      <span className="text-xs brand-text-secondary">{emailJob.subject}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="rounded-lg">
                      <i className="fas fa-times mr-1"></i>
                      Dismiss
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-brand-accent hover:bg-brand-accent-light text-white rounded-lg"
                    >
                      <i className="fas fa-plus mr-1"></i>
                      Add to Queue
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Queue Jobs Table */}
      {queueJobs?.length === 0 ? (
        <Card className="shadow-soft border-0">
          <CardContent className="p-12 text-center">
            <i className="fas fa-clock text-4xl text-gray-400 mb-4"></i>
            <h3 className="text-lg font-semibold brand-text-primary mb-2">No jobs in queue</h3>
            <p className="brand-text-secondary mb-6">
              Generate your daily queue to see AI-curated job matches ready for application.
            </p>
            <Button 
              onClick={handleGenerateQueue}
              disabled={generateQueueMutation.isPending}
              className="bg-brand-accent hover:bg-brand-accent-light text-white rounded-xl"
            >
              <i className="fas fa-magic mr-2"></i>
              Generate Daily Queue
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="shadow-soft border-0">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Position</TableHead>
                    <TableHead>Job Details</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Match Score</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {queueJobs.map((queueJob: any, index: number) => (
                    <TableRow key={queueJob.id} className="hover:bg-brand-surface">
                      <TableCell>
                        <div className="flex items-center">
                          <span className="w-8 h-8 bg-brand-accent/10 rounded-full flex items-center justify-center text-sm font-semibold brand-accent">
                            {index + 1}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-semibold brand-text-primary">{queueJob.job.title}</div>
                          <div className="text-sm brand-text-secondary">{queueJob.job.location}</div>
                          <div className="text-xs brand-text-secondary mt-1">
                            {queueJob.job.workType} • {queueJob.job.employmentType}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium brand-text-primary">{queueJob.job.company}</div>
                        {queueJob.job.salaryMin && queueJob.job.salaryMax && (
                          <div className="text-sm brand-text-secondary">
                            ${queueJob.job.salaryMin.toLocaleString()} - ${queueJob.job.salaryMax.toLocaleString()}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className={`text-sm ${getMatchScoreColor(queueJob.job.aiMatchScore || 0)}`}>
                            AI: {queueJob.job.aiMatchScore || 0}%
                          </div>
                          {queueJob.job.matchScore && (
                            <div className="text-xs brand-text-secondary">
                              Rules: {queueJob.job.matchScore}%
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(queueJob.status)}>
                          {queueJob.status}
                        </Badge>
                        {queueJob.scheduledTime && (
                          <div className="text-xs brand-text-secondary mt-1">
                            {new Date(queueJob.scheduledTime).toLocaleTimeString()}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {queueJob.status === "pending" && (
                            <>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => updateJobStatusMutation.mutate({ jobId: queueJob.id, status: "skipped" })}
                                className="rounded-lg"
                              >
                                Skip
                              </Button>
                              <Button 
                                size="sm"
                                onClick={() => updateJobStatusMutation.mutate({ jobId: queueJob.id, status: "processing" })}
                                className="bg-brand-accent hover:bg-brand-accent-light text-white rounded-lg"
                              >
                                Apply Now
                              </Button>
                            </>
                          )}
                          {queueJob.status === "failed" && (
                            <Button 
                              size="sm"
                              variant="outline"
                              onClick={() => updateJobStatusMutation.mutate({ jobId: queueJob.id, status: "pending" })}
                              className="rounded-lg"
                            >
                              <i className="fas fa-redo mr-1"></i>
                              Retry
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  );
}