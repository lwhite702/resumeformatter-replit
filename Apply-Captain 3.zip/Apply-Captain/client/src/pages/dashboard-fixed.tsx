import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { OnboardingTour, OnboardingChecklisst, useOnboardingStatus } from "@/components/ui/onboarding-tour";
import { HelpSystem, QuickHelpTooltip } from "@/components/ui/help-system";
import { useOnboarding } from "@/hooks/useOnboarding";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useEffect } from "react";
import { HelpCircle, Play } from "lucide-react";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const { showOnboarding, completeOnboarding, skipOnboarding } = useOnboarding();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/dashboard/stats", {});
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("Unauthorized");
        }
        throw new Error("Failed to fetch stats");
      }
      return response.json();
    },
    enabled: isAuthenticated,
  });

  const { data: suggestions, isLoading: suggestionsLoading } = useQuery({
    queryKey: ["/api/jobs/suggestions"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: applications, isLoading: applicationsLoading } = useQuery({
    queryKey: ["/api/applications"],
    enabled: isAuthenticated,
    retry: false,
  });

  if (authLoading || !isAuthenticated) {
    return null;
  }

  const firstName = (user as any)?.firstName || "User";
  const recentApplications = (applications as any[] || []).slice(0, 4);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "interview_scheduled":
        return "bg-green-100 text-green-800";
      case "under_review":
        return "bg-yellow-100 text-yellow-800";
      case "sent":
        return "bg-blue-100 text-blue-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatStatus = (status: string) => {
    switch (status) {
      case "interview_scheduled":
        return "Interview Scheduled";
      case "under_review":
        return "Under Review";
      case "sent":
        return "Application Sent";
      case "rejected":
        return "Not Selected";
      default:
        return status;
    }
  };

  return (
    <>
      <main className="p-8">
        {/* Welcome Banner with Help Options */}
        <div className="bg-gradient-to-r from-brand-primary to-brand-secondary rounded-2xl p-8 mb-8 text-white shadow-brand relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-20 translate-x-20"></div>
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-3 text-display">Welcome back, {firstName}!</h3>
              <p className="text-white/80 mb-6 text-lg">
                {(suggestions as any[])?.length ? `You have ${(suggestions as any[]).length} new intelligent job matches waiting` : "Your AI job search assistant is ready to work"}
              </p>
              <Button 
                className="bg-brand-accent hover:bg-brand-accent-light text-white px-6 py-3 rounded-xl font-semibold shadow-lg transition-all duration-200"
                onClick={() => window.location.href = "/apply"}
              >
                <i className="fas fa-plus mr-2"></i>
                Analyze New Job
              </Button>
            </div>
            
            <div className="flex items-center space-x-3">
              <QuickHelpTooltip 
                content="Get instant help and guidance for any feature"
                title="Help System"
              >
                <HelpSystem context="dashboard" />
              </QuickHelpTooltip>
              
              <QuickHelpTooltip 
                content="Start the guided tour to learn ApplyCaptain in 3 minutes"
                title="Take Tour"
              >
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.location.reload()}
                  className="gap-2 bg-white/20 border-white/30 text-white hover:bg-white/30"
                >
                  <Play className="h-4 w-4" />
                  Tour
                </Button>
              </QuickHelpTooltip>
            </div>
          </div>
        </div>

        {/* Onboarding Checklist - appears for new users */}
        <div className="mb-8">
          <OnboardingChecklisst />
        </div>

        {/* Stats Cards with Help Tooltips */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <QuickHelpTooltip content="Total number of job applications you've submitted through ApplyCaptain" title="Applications Sent">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-paper-plane text-emerald-600"></i>
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Applications Sent</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.totalApplications || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </QuickHelpTooltip>

          <QuickHelpTooltip content="Number of companies that have viewed your profile or application" title="Profile Views">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-eye text-blue-600"></i>
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Profile Views</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.profileViews || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </QuickHelpTooltip>

          <QuickHelpTooltip content="Number of interview invitations you've received" title="Interviews">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-calendar text-purple-600"></i>
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Interviews</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {statsLoading ? "..." : stats?.interviews || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </QuickHelpTooltip>

          <QuickHelpTooltip content="Percentage of applications that result in positive responses" title="Success Rate">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center">
                      <i className="fas fa-trophy text-amber-600"></i>
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Success Rate</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {statsLoading ? "..." : `${stats?.successRate || 0}%`}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </QuickHelpTooltip>
        </div>

        {/* Recent Applications with Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent Applications</CardTitle>
              <QuickHelpTooltip content="View all your job applications and their current status" title="Application History">
                <Button variant="outline" size="sm" onClick={() => window.location.href = "/history"}>
                  View All
                </Button>
              </QuickHelpTooltip>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentApplications.length > 0 ? (
                  recentApplications.map((app: any, index: number) => (
                    <div key={index} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium">{app.jobTitle}</h4>
                        <p className="text-sm text-gray-600">{app.company}</p>
                      </div>
                      <Badge className={getStatusColor(app.status)}>
                        {formatStatus(app.status)}
                      </Badge>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>No applications yet. Start by exploring your daily queue!</p>
                    <Button className="mt-4" onClick={() => window.location.href = "/daily-queue"}>
                      View Daily Queue
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Quick Actions</CardTitle>
              <QuickHelpTooltip content="Common tasks to help you manage your job search effectively" title="Quick Actions">
                <HelpCircle className="h-4 w-4 text-gray-400" />
              </QuickHelpTooltip>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <QuickHelpTooltip content="Check today's AI-curated job opportunities" title="Daily Queue">
                  <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/daily-queue"}>
                    <i className="fas fa-list mr-2"></i>
                    View Daily Queue
                  </Button>
                </QuickHelpTooltip>
                
                <QuickHelpTooltip content="Upload and manage multiple versions of your resume" title="Resume Library">
                  <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/resumes"}>
                    <i className="fas fa-file-alt mr-2"></i>
                    Manage Resumes
                  </Button>
                </QuickHelpTooltip>
                
                <QuickHelpTooltip content="Set up automatic job applications based on your preferences" title="Auto-Apply Rules">
                  <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/rules"}>
                    <i className="fas fa-cog mr-2"></i>
                    Auto-Apply Rules
                  </Button>
                </QuickHelpTooltip>
                
                <QuickHelpTooltip content="Configure your job search preferences and account settings" title="Settings">
                  <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/settings"}>
                    <i className="fas fa-sliders-h mr-2"></i>
                    Settings
                  </Button>
                </QuickHelpTooltip>
                
                <QuickHelpTooltip content="Access comprehensive guides and documentation" title="Knowledge Base">
                  <Button variant="outline" className="w-full justify-start" onClick={() => window.location.href = "/knowledge-base"}>
                    <i className="fas fa-book mr-2"></i>
                    Knowledge Base
                  </Button>
                </QuickHelpTooltip>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Job Search Performance
              <QuickHelpTooltip content="Analytics to help you optimize your job search strategy" title="Performance Metrics">
                <HelpCircle className="h-4 w-4 text-gray-400" />
              </QuickHelpTooltip>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium text-gray-900">Response Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    {stats ? `${stats.responseRate || 0}%` : '0%'}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Applications with responses</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium text-gray-900">Interview Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">
                    {stats ? `${stats.interviewRate || 0}%` : '0%'}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Applications leading to interviews</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium text-gray-900">Offers Received</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">
                    {stats ? stats.offers || 0 : 0}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Job offers received</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium text-gray-900">Average Response Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">
                    {stats ? `${stats.avgResponseTime || 0} days` : '0 days'}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Time to first response</p>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Nautical Onboarding Tour */}
      <OnboardingTour
        isOpen={showOnboarding}
        onClose={skipOnboarding}
        onComplete={completeOnboarding}
      />
    </>
  );
}