import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SignUpButton } from "@clerk/clerk-react";
import { 
  Zap, 
  Target, 
  TrendingUp, 
  CheckCircle, 
  Star,
  Clock,
  Users,
  Trophy,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";
import logoWhite from "@assets/White logo - no background_1750184669735.png";
import { SEOOptimizer } from "@/components/ui/marketing-analytics";

export default function LandingAds() {
  // SEO and Marketing Optimization
  useEffect(() => {
    // Set page title and meta description for SEO
    document.title = "Get Your Dream Job in 7 Days | ApplyCaptain - AI Job Search Automation";
    
    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'AI-powered job search automation that applies to 100+ perfect jobs daily. Join 50,000+ professionals who got hired using ApplyCaptain. Start free trial today.');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = 'AI-powered job search automation that applies to 100+ perfect jobs daily. Join 50,000+ professionals who got hired using ApplyCaptain. Start free trial today.';
      document.head.appendChild(meta);
    }

    // Add Open Graph tags for social sharing
    const ogTags = [
      { property: 'og:title', content: 'Get Your Dream Job in 7 Days | ApplyCaptain' },
      { property: 'og:description', content: 'AI-powered job search automation that gets you hired faster. Apply to 100+ jobs daily while you sleep.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: window.location.href },
      { property: 'og:image', content: `${window.location.origin}/generated-icon.png` },
      { property: 'og:site_name', content: 'ApplyCaptain' }
    ];

    ogTags.forEach(tag => {
      let existingTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (existingTag) {
        existingTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('property', tag.property);
        meta.setAttribute('content', tag.content);
        document.head.appendChild(meta);
      }
    });

    // Add Twitter Card tags
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: 'Get Your Dream Job in 7 Days | ApplyCaptain' },
      { name: 'twitter:description', content: 'AI-powered job search automation that gets you hired faster.' },
      { name: 'twitter:image', content: `${window.location.origin}/generated-icon.png` }
    ];

    twitterTags.forEach(tag => {
      let existingTag = document.querySelector(`meta[name="${tag.name}"]`);
      if (existingTag) {
        existingTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('name', tag.name);
        meta.setAttribute('content', tag.content);
        document.head.appendChild(meta);
      }
    });

    // Add structured data for SEO
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "ApplyCaptain",
      "description": "AI-powered job search automation platform that helps professionals find and apply to jobs automatically.",
      "url": window.location.href,
      "applicationCategory": "BusinessApplication",
      "operatingSystem": "Web Browser",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD",
        "description": "Free trial available"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.8",
        "ratingCount": "50000"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Wrelik Brands, LLC",
        "url": "https://wrelikbrands.com"
      }
    };

    let structuredDataScript = document.querySelector('script[type="application/ld+json"]');
    if (structuredDataScript) {
      structuredDataScript.textContent = JSON.stringify(structuredData);
    } else {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify(structuredData);
      document.head.appendChild(script);
    }

    // Track page view for analytics
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', 'page_view', {
        page_title: 'Ad Campaign Landing Page',
        page_location: window.location.href,
        campaign_source: new URLSearchParams(window.location.search).get('utm_source') || 'direct',
        campaign_medium: new URLSearchParams(window.location.search).get('utm_medium') || 'organic',
        campaign_name: new URLSearchParams(window.location.search).get('utm_campaign') || 'none'
      });
    }

    // Track landing page view event
    if (typeof (window as any).fbq !== 'undefined') {
      (window as any).fbq('track', 'ViewContent', {
        content_name: 'Ad Campaign Landing Page',
        content_category: 'Landing Page'
      });
    }
  }, []);

  // Conversion tracking function
  const trackConversion = (action: string, value?: string) => {
    // Google Analytics tracking
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', action, {
        event_category: 'Conversion',
        event_label: value || action,
        value: action === 'sign_up' ? 1 : 0
      });
    }

    // Facebook Pixel tracking
    if (typeof (window as any).fbq !== 'undefined') {
      if (action === 'sign_up') {
        (window as any).fbq('track', 'CompleteRegistration');
      } else if (action === 'cta_click') {
        (window as any).fbq('track', 'InitiateCheckout');
      }
    }

    // Custom tracking
    if (typeof window !== 'undefined' && (window as any).dataLayer) {
      (window as any).dataLayer.push({
        event: 'conversion_action',
        action: action,
        campaign_type: 'ad_campaign',
        page_type: 'landing_page'
      });
    }
  };

  const urgencyFeatures = [
    {
      icon: Zap,
      title: "Apply to 10x More Jobs",
      description: "AI automation sends applications while you sleep",
      highlight: "Save 20+ hours per week"
    },
    {
      icon: Target,
      title: "95% Match Accuracy",
      description: "Advanced AI finds jobs that perfectly fit your skills",
      highlight: "Better than any human recruiter"
    },
    {
      icon: TrendingUp,
      title: "3x Higher Response Rate",
      description: "Optimized applications get noticed by employers",
      highlight: "Proven results from 10,000+ users"
    }
  ];

  const socialProof = [
    { metric: "50,000+", label: "Active Job Seekers", icon: Users },
    { metric: "2.1M+", label: "Applications Sent", icon: Target },
    { metric: "89%", label: "Success Rate", icon: Trophy },
    { metric: "4.8/5", label: "User Rating", icon: Star }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Software Engineer",
      company: "Google",
      text: "Got 3 job offers in my first week using ApplyCaptain. The AI found opportunities I never would have discovered."
    },
    {
      name: "Marcus Rodriguez",
      role: "Product Manager", 
      company: "Microsoft",
      text: "Landed my dream job at Microsoft after just 2 weeks. The automated applications saved me countless hours."
    },
    {
      name: "Emily Watson",
      role: "Data Scientist",
      company: "Netflix",
      text: "Increased my interview rate by 400%. This platform is a game-changer for job searching."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
      <SEOOptimizer page="ads" />
      {/* Header */}
      <header className="relative z-50 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img src={logoWhite} alt="ApplyCaptain" className="h-8 w-auto" />
            <span className="text-white font-bold text-xl">ApplyCaptain</span>
          </div>
          <Badge className="bg-yellow-500 text-black font-semibold px-3 py-1">
            LIMITED TIME: 50% OFF
          </Badge>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative px-4 py-12 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="bg-yellow-500 text-black mb-4 font-semibold">
              🔥 VIRAL ON TIKTOK - 2.3M VIEWS
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Get Your Dream Job in
              <span className="text-yellow-400"> 7 Days</span>
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
                While You Sleep
              </span>
            </h1>

            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              AI-powered job search automation that applies to <strong>100+ perfect jobs daily</strong> 
              and lands interviews in days, not months
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <SignUpButton mode="modal">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold text-lg px-8 py-4 hover:scale-105 transition-transform"
                  onClick={() => trackConversion('cta_click', 'hero_primary')}
                  aria-label="Start free trial to get hired in 7 days"
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  Start Free Trial - Get Hired in 7 Days
                </Button>
              </SignUpButton>
              
              <Button 
                variant="outline" 
                size="lg"
                className="border-white text-white hover:bg-white hover:text-black font-semibold text-lg px-8 py-4"
                onClick={() => {
                  trackConversion('demo_click', 'hero_secondary');
                  document.getElementById('demo-video')?.scrollIntoView({ behavior: 'smooth' });
                }}
                aria-label="Watch 2-minute product demo"
              >
                Watch 2-Min Demo
              </Button>
            </div>

            <div className="flex items-center justify-center space-x-6 text-sm text-gray-300">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                No Credit Card Required
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                Setup in 2 Minutes
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                Results in 24 Hours
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Urgency Timer */}
      <section className="px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-r from-red-600 to-orange-600 border-0 text-white">
            <CardContent className="p-6 text-center">
              <h3 className="text-2xl font-bold mb-2">⚡ LIMITED TIME OFFER ENDS SOON</h3>
              <p className="text-lg mb-4">Join 10,000+ professionals who got hired using ApplyCaptain</p>
              <div className="grid grid-cols-4 gap-4 max-w-md mx-auto">
                <div className="text-center">
                  <div className="text-2xl font-bold">23</div>
                  <div className="text-sm">Hours</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">47</div>
                  <div className="text-sm">Minutes</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">32</div>
                  <div className="text-sm">Seconds</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">50%</div>
                  <div className="text-sm">OFF</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Social Proof */}
      <section className="px-4 py-12 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-8">
            Trusted by 50,000+ Job Seekers Worldwide
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {socialProof.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center text-white"
                >
                  <Icon className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
                  <div className="text-3xl font-bold">{item.metric}</div>
                  <div className="text-sm text-gray-300">{item.label}</div>
                </motion.div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white/10 border-white/20 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm mb-4 italic">"{testimonial.text}"</p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-xs text-gray-300">{testimonial.role} at {testimonial.company}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-white mb-4">
            Why ApplyCaptain Gets You Hired Faster
          </h2>
          <p className="text-xl text-center text-gray-300 mb-12 max-w-3xl mx-auto">
            Our AI technology has helped over 50,000 professionals land their dream jobs. 
            Here's how we do it:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {urgencyFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2 }}
                >
                  <Card className="bg-white/10 border-white/20 text-white h-full hover:bg-white/20 transition-colors">
                    <CardHeader>
                      <Icon className="h-12 w-12 text-yellow-400 mb-4" />
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                      <Badge className="bg-yellow-500 text-black w-fit">
                        {feature.highlight}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Demo Video Section */}
      <section id="demo-video" className="px-4 py-16 bg-black/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            See How Sarah Got 3 Job Offers in 1 Week
          </h2>
          
          <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video mb-8">
            <div className="absolute inset-0 flex items-center justify-center">
              <Button 
                size="lg" 
                className="bg-yellow-400 text-black hover:bg-yellow-300"
              >
                <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
                Play Demo Video
              </Button>
            </div>
          </div>

          <p className="text-gray-300 mb-8">
            Watch this 2-minute case study of how ApplyCaptain helped Sarah land her dream job at Google
          </p>
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Get Your Dream Job?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join 50,000+ professionals who use ApplyCaptain to accelerate their careers
          </p>

          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-8 text-black mb-8">
            <h3 className="text-2xl font-bold mb-4">🎯 Get Started Free Today</h3>
            <ul className="text-left max-w-md mx-auto mb-6 space-y-2">
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                AI applies to 100+ jobs daily
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                Interview requests within 24-48 hours
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                No credit card required
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                Cancel anytime
              </li>
            </ul>

            <SignUpButton mode="modal">
              <Button 
                size="lg" 
                className="bg-black text-white hover:bg-gray-800 font-bold text-xl px-12 py-4"
              >
                Start Free Trial Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </SignUpButton>
          </div>

          <p className="text-sm text-gray-400">
            Trusted by professionals at Google, Microsoft, Netflix, Amazon, and 1000+ other companies
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/50 px-4 py-8 text-center text-gray-400">
        <div className="max-w-6xl mx-auto">
          <p className="mb-4">© 2025 Wrelik Brands, LLC. All rights reserved.</p>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <a href="/legal/privacy-policy" className="hover:text-white">Privacy Policy</a>
            <a href="/legal/terms-of-service" className="hover:text-white">Terms of Service</a>
            <a href="mailto:help@applycaptain.com" className="hover:text-white">Contact Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}