import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SignUpButton } from "@clerk/clerk-react";
import { 
  Zap, 
  Target, 
  CheckCircle, 
  Star,
  Users,
  Trophy,
  ArrowRight,
  Sparkles,
  Gift,
  Crown,
  Rocket,
  FileText,
  Briefcase
} from "lucide-react";
import { motion } from "framer-motion";
import logoWhite from "@assets/White logo - no background_1750184669735.png";
import prepPairLogo from "@assets/3_1750210014430.png";
import resumeFormatterLogo from "@assets/5_1750210014431.png";
import { SEOOptimizer } from "@/components/ui/marketing-analytics";

export default function LandingReferral() {
  useEffect(() => {
    // Detect referral source from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const referralSource = urlParams.get('ref') || urlParams.get('source') || 'ecosystem';
    const referringApp = urlParams.get('app') || 'unknown';
    
    // SEO Optimization for Referral Traffic
    document.title = `Complete Your Job Search Toolkit | ApplyCaptain + ${referringApp === 'prepair' ? 'PrepPair' : 'ResumeFormatter.io'}`;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    const description = `Complete your professional toolkit! You're already using ${referringApp === 'prepair' ? 'PrepPair for interview prep' : 'ResumeFormatter.io for resumes'} - now add ApplyCaptain for automated job applications. Exclusive 30% discount for existing users.`;
    
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = description;
      document.head.appendChild(meta);
    }

    // Referral-specific Open Graph tags
    const ogTags = [
      { property: 'og:title', content: `Complete Your Job Search Toolkit | ApplyCaptain + ${referringApp === 'prepair' ? 'PrepPair' : 'ResumeFormatter.io'}` },
      { property: 'og:description', content: 'Exclusive offer for existing Wrelik Brands users. Complete your job search toolkit with 30% off ApplyCaptain.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: window.location.href },
      { property: 'og:image', content: `${window.location.origin}/generated-icon.png` },
      { property: 'og:site_name', content: 'ApplyCaptain - Wrelik Brands Ecosystem' }
    ];

    ogTags.forEach(tag => {
      let existingTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (existingTag) {
        existingTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('property', tag.property);
        meta.setAttribute('content', tag.content);
        document.head.appendChild(meta);
      }
    });

    // Track referral source
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', 'page_view', {
        page_title: 'Ecosystem Referral Landing Page',
        page_location: window.location.href,
        campaign_source: referralSource,
        campaign_medium: 'referral',
        campaign_name: `${referringApp}_cross_sell`,
        custom_parameter_1: referringApp,
        custom_parameter_2: 'ecosystem_user'
      });
    }

    // Facebook Pixel for referral traffic
    if (typeof (window as any).fbq !== 'undefined') {
      (window as any).fbq('track', 'ViewContent', {
        content_name: 'Ecosystem Referral Landing Page',
        content_category: 'Cross-sell',
        source: 'ecosystem_referral',
        referring_app: referringApp
      });
    }

    // Set referral data in sessionStorage for tracking through conversion
    sessionStorage.setItem('referral_source', referralSource);
    sessionStorage.setItem('referring_app', referringApp);
  }, []);

  const trackReferralConversion = (action: string, value?: string) => {
    const referralSource = sessionStorage.getItem('referral_source') || 'unknown';
    const referringApp = sessionStorage.getItem('referring_app') || 'unknown';
    
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', action, {
        event_category: 'Referral_Conversion',
        event_label: value || action,
        custom_parameter_1: referringApp,
        custom_parameter_2: referralSource,
        value: action === 'sign_up' ? 30 : 0 // 30% discount value
      });
    }

    if (typeof (window as any).fbq !== 'undefined') {
      if (action === 'sign_up') {
        (window as any).fbq('track', 'CompleteRegistration', {
          source: 'ecosystem_referral',
          referring_app: referringApp,
          discount_applied: '30_percent'
        });
      }
    }
  };

  // Get referral source for personalization
  const urlParams = new URLSearchParams(window.location.search);
  const referringApp = urlParams.get('app') || 'ecosystem';
  
  const ecosystemApps = {
    prepair: {
      name: "PrepPair",
      logo: prepPairLogo,
      description: "Interview preparation and practice",
      userBenefit: "You're already acing interviews with PrepPair"
    },
    resumeformatter: {
      name: "ResumeFormatter.io", 
      logo: resumeFormatterLogo,
      description: "Professional resume formatting",
      userBenefit: "You already have a perfect resume with ResumeFormatter.io"
    }
  };

  const currentApp = ecosystemApps[referringApp as keyof typeof ecosystemApps] || {
    name: "Wrelik Brands",
    logo: logoWhite,
    description: "Professional career tools",
    userBenefit: "You're already part of the Wrelik Brands family"
  };

  const ecosystemBenefits = [
    {
      icon: FileText,
      title: "Perfect Resume",
      description: "ResumeFormatter.io creates ATS-optimized resumes",
      status: referringApp === 'resumeformatter' ? 'completed' : 'available'
    },
    {
      icon: Rocket,
      title: "Auto Job Applications", 
      description: "ApplyCaptain applies to 100+ jobs daily",
      status: 'current'
    },
    {
      icon: Briefcase,
      title: "Interview Success",
      description: "PrepPair helps you ace every interview",
      status: referringApp === 'prepair' ? 'completed' : 'available'
    }
  ];

  const exclusiveOffers = [
    {
      title: "30% Off First Month",
      description: "Exclusive discount for existing users",
      value: "$20 savings",
      highlight: true
    },
    {
      title: "Priority Support",
      description: "Fast-track customer service",
      value: "VIP treatment",
      highlight: false
    },
    {
      title: "Cross-Platform Sync",
      description: "Seamless integration with your current tools",
      value: "Enhanced workflow",
      highlight: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      <SEOOptimizer page="referral" />
      {/* Header with Ecosystem Branding */}
      <header className="relative z-50 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img src={currentApp.logo} alt={currentApp.name} className="h-8 w-auto" />
            <div className="text-white">
              <div className="text-xs text-gray-300">From the makers of {currentApp.name}</div>
              <div className="font-bold">Complete Your Toolkit</div>
            </div>
          </div>
          <Badge className="bg-yellow-500 text-black font-semibold px-3 py-1">
            <Gift className="h-3 w-3 mr-1" />
            30% OFF
          </Badge>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative px-4 py-12 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black mb-6 font-bold px-4 py-2">
              <Crown className="h-4 w-4 mr-2" />
              EXCLUSIVE FOR {currentApp.name.toUpperCase()} USERS
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              You've Got the{" "}
              <span className="text-yellow-400">
                {referringApp === 'prepair' ? 'Interview Skills' : 'Perfect Resume'}
              </span>
              <br />
              Now Get the{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-400">
                Job Offers
              </span>
            </h1>

            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              {currentApp.userBenefit} - now let AI automatically apply to 100+ perfect jobs 
              while you focus on what you do best.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <SignUpButton mode="modal">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold text-lg px-8 py-4 hover:scale-105 transition-transform"
                  onClick={() => trackReferralConversion('sign_up', 'hero_primary')}
                  aria-label="Claim exclusive 30% discount for ecosystem users"
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  Claim 30% Discount - Complete Your Toolkit
                </Button>
              </SignUpButton>
            </div>

            <div className="flex items-center justify-center space-x-6 text-sm text-gray-300">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                Exclusive User Discount
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                Instant Integration
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-400 mr-2" />
                Priority Setup
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Ecosystem Integration */}
      <section className="px-4 py-12 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-8">
            Complete Your Professional Toolkit
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {ecosystemBenefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2 }}
                >
                  <Card className={`h-full transition-all ${
                    benefit.status === 'current' 
                      ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-black border-0' 
                      : benefit.status === 'completed'
                      ? 'bg-green-600/20 border-green-400 text-white'
                      : 'bg-white/10 border-white/20 text-white'
                  }`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Icon className={`h-12 w-12 ${
                          benefit.status === 'current' ? 'text-black' : 'text-yellow-400'
                        }`} />
                        <Badge className={
                          benefit.status === 'current' 
                            ? 'bg-black text-white' 
                            : benefit.status === 'completed'
                            ? 'bg-green-600 text-white'
                            : 'bg-white/20 text-white'
                        }>
                          {benefit.status === 'current' ? 'ADD NOW' : 
                           benefit.status === 'completed' ? 'COMPLETED' : 'AVAILABLE'}
                        </Badge>
                      </div>
                      <CardTitle className={`text-xl ${
                        benefit.status === 'current' ? 'text-black' : 'text-white'
                      }`}>
                        {benefit.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className={`${
                        benefit.status === 'current' ? 'text-black/80' : 'text-gray-300'
                      }`}>
                        {benefit.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>

          <div className="text-center">
            <p className="text-gray-300 mb-4">
              Join 15,000+ professionals using the complete Wrelik Brands toolkit
            </p>
            <div className="flex justify-center space-x-8 items-center opacity-70">
              <img src={resumeFormatterLogo} alt="ResumeFormatter.io" className="h-8" />
              <span className="text-white text-2xl">+</span>
              <img src={logoWhite} alt="ApplyCaptain" className="h-8" />
              <span className="text-white text-2xl">+</span>
              <img src={prepPairLogo} alt="PrepPair" className="h-8" />
            </div>
          </div>
        </div>
      </section>

      {/* Exclusive Offers */}
      <section className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-white mb-4">
            Exclusive Ecosystem User Benefits
          </h2>
          <p className="text-xl text-center text-gray-300 mb-12">
            Because you're already part of the family, you get special treatment
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {exclusiveOffers.map((offer, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                <Card className={`h-full ${
                  offer.highlight 
                    ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-black border-0 transform scale-105' 
                    : 'bg-white/10 border-white/20 text-white'
                }`}>
                  <CardHeader>
                    {offer.highlight && (
                      <Badge className="bg-black text-white w-fit mb-2">
                        LIMITED TIME
                      </Badge>
                    )}
                    <CardTitle className="text-xl">{offer.title}</CardTitle>
                    <div className={`text-2xl font-bold ${
                      offer.highlight ? 'text-black' : 'text-yellow-400'
                    }`}>
                      {offer.value}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className={offer.highlight ? 'text-black/80' : 'text-gray-300'}>
                      {offer.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="px-4 py-12 bg-black/30">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Trusted by the Wrelik Brands Community
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            <div className="text-center text-white">
              <Users className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
              <div className="text-3xl font-bold">15,000+</div>
              <div className="text-sm text-gray-300">Ecosystem Users</div>
            </div>
            <div className="text-center text-white">
              <Target className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
              <div className="text-3xl font-bold">500K+</div>
              <div className="text-sm text-gray-300">Cross-Platform Applications</div>
            </div>
            <div className="text-center text-white">
              <Trophy className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
              <div className="text-3xl font-bold">94%</div>
              <div className="text-sm text-gray-300">Success Rate</div>
            </div>
            <div className="text-center text-white">
              <Star className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
              <div className="text-3xl font-bold">4.9/5</div>
              <div className="text-sm text-gray-300">User Rating</div>
            </div>
          </div>

          <blockquote className="text-lg text-gray-200 max-w-3xl mx-auto italic">
            "Using ResumeFormatter.io + ApplyCaptain + PrepPair together was like having 
            a personal career coach. Got my dream job at Microsoft in 3 weeks!"
          </blockquote>
          <div className="text-sm text-gray-400 mt-2">
            - Jennifer K., Software Engineer at Microsoft
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Complete Your Toolkit?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of {currentApp.name} users who upgraded their job search
          </p>

          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-8 text-black mb-8">
            <h3 className="text-2xl font-bold mb-4">
              <Gift className="inline h-6 w-6 mr-2" />
              Exclusive 30% Off for {currentApp.name} Users
            </h3>
            <ul className="text-left max-w-md mx-auto mb-6 space-y-2">
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                AI applies to 100+ jobs daily
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                Seamless integration with {currentApp.name}
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                Priority support and onboarding
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                30% discount (limited time)
              </li>
            </ul>

            <SignUpButton mode="modal">
              <Button 
                size="lg" 
                className="bg-black text-white hover:bg-gray-800 font-bold text-xl px-12 py-4"
                onClick={() => trackReferralConversion('sign_up', 'final_cta')}
              >
                Claim Your 30% Discount
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </SignUpButton>
          </div>

          <p className="text-sm text-gray-400">
            Trusted by professionals at Google, Microsoft, Netflix, Amazon, and 1000+ other companies
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/50 px-4 py-8 text-center text-gray-400">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-center space-x-6 mb-4">
            <img src={resumeFormatterLogo} alt="ResumeFormatter.io" className="h-6 opacity-60" />
            <img src={logoWhite} alt="ApplyCaptain" className="h-6" />
            <img src={prepPairLogo} alt="PrepPair" className="h-6 opacity-60" />
          </div>
          <p className="mb-4">© 2025 Wrelik Brands, LLC. All rights reserved.</p>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <a href="/legal/privacy-policy" className="hover:text-white">Privacy Policy</a>
            <a href="/legal/terms-of-service" className="hover:text-white">Terms of Service</a>
            <a href="mailto:help@applycaptain.com" className="hover:text-white">Contact Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}