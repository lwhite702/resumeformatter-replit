import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SignUpButton } from "@clerk/clerk-react";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  TrendingUp, 
  CheckCircle, 
  Star,
  Users,
  Trophy,
  ArrowRight,
  Sparkles,
  Play,
  Instagram,
  Twitter,
  Linkedin
} from "lucide-react";
import { motion } from "framer-motion";
import logoWhite from "@assets/White logo - no background_1750184669735.png";
import { SEOOptimizer } from "@/components/ui/marketing-analytics";

export default function LandingSocial() {
  useEffect(() => {
    // SEO Optimization for Social Media Traffic
    document.title = "🔥 This AI Tool Got Me 3 Job Offers in 1 Week | ApplyCaptain";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', '🚀 Viral job search hack! AI applies to 100+ jobs daily while you sleep. 50k+ people already got hired. Try free!');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = '🚀 Viral job search hack! AI applies to 100+ jobs daily while you sleep. 50k+ people already got hired. Try free!';
      document.head.appendChild(meta);
    }

    // Social Media Optimized Open Graph tags
    const ogTags = [
      { property: 'og:title', content: '🔥 This AI Tool Got Me 3 Job Offers in 1 Week' },
      { property: 'og:description', content: '🚀 Viral on TikTok! AI applies to jobs while you sleep. 50k+ already hired!' },
      { property: 'og:type', content: 'article' },
      { property: 'og:url', content: window.location.href },
      { property: 'og:image', content: `${window.location.origin}/generated-icon.png` },
      { property: 'og:image:width', content: '1200' },
      { property: 'og:image:height', content: '630' },
      { property: 'og:site_name', content: 'ApplyCaptain' },
      { property: 'article:author', content: 'ApplyCaptain' },
      { property: 'article:published_time', content: new Date().toISOString() }
    ];

    ogTags.forEach(tag => {
      let existingTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (existingTag) {
        existingTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('property', tag.property);
        meta.setAttribute('content', tag.content);
        document.head.appendChild(meta);
      }
    });

    // Twitter Card optimization for viral content
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: '🔥 This AI Tool Got Me 3 Job Offers in 1 Week' },
      { name: 'twitter:description', content: '🚀 Viral on TikTok! AI applies to jobs while you sleep. Try free!' },
      { name: 'twitter:image', content: `${window.location.origin}/generated-icon.png` },
      { name: 'twitter:creator', content: '@ApplyCaptain' }
    ];

    twitterTags.forEach(tag => {
      let existingTag = document.querySelector(`meta[name="${tag.name}"]`);
      if (existingTag) {
        existingTag.setAttribute('content', tag.content);
      } else {
        const meta = document.createElement('meta');
        meta.setAttribute('name', tag.name);
        meta.setAttribute('content', tag.content);
        document.head.appendChild(meta);
      }
    });

    // Track social media source
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', 'page_view', {
        page_title: 'Social Media Landing Page',
        page_location: window.location.href,
        campaign_source: new URLSearchParams(window.location.search).get('utm_source') || 'social',
        campaign_medium: 'social',
        campaign_name: new URLSearchParams(window.location.search).get('utm_campaign') || 'viral_content'
      });
    }

    // Facebook Pixel for social traffic
    if (typeof (window as any).fbq !== 'undefined') {
      (window as any).fbq('track', 'ViewContent', {
        content_name: 'Social Media Landing Page',
        content_category: 'Viral Content',
        source: 'social_media'
      });
    }
  }, []);

  const trackSocialConversion = (action: string, platform?: string) => {
    if (typeof (window as any).gtag !== 'undefined') {
      (window as any).gtag('event', action, {
        event_category: 'Social_Conversion',
        event_label: platform || action,
        custom_parameter_1: 'viral_content'
      });
    }

    if (typeof (window as any).fbq !== 'undefined') {
      if (action === 'sign_up') {
        (window as any).fbq('track', 'CompleteRegistration', {
          source: 'social_media',
          platform: platform
        });
      }
    }
  };

  const viralStats = [
    { number: "2.3M", label: "TikTok Views", icon: Heart },
    { number: "847K", label: "Shares", icon: Share2 },
    { number: "156K", label: "Comments", icon: MessageCircle },
    { number: "89%", label: "Success Rate", icon: Trophy }
  ];

  const socialTestimonials = [
    {
      name: "@techcareer_sarah",
      platform: "TikTok",
      followers: "127K",
      text: "Y'ALL!! This app literally got me hired at Google in 6 days 😭 I'm crying tears of joy",
      likes: "23.4K",
      verified: true
    },
    {
      name: "@jobhunter_mike",
      platform: "Instagram", 
      followers: "89K",
      text: "No cap, this AI thing is INSANE. Applied to 300+ jobs overnight and got 12 interviews 🤯",
      likes: "18.7K",
      verified: true
    },
    {
      name: "@linkedinqueen",
      platform: "LinkedIn",
      followers: "45K",
      text: "As someone who's been job searching for months, this is a GAME CHANGER. Got my dream role at Netflix!",
      likes: "31.2K",
      verified: true
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-700">
      <SEOOptimizer page="social" />
      {/* Mobile-First Header */}
      <header className="relative z-50 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src={logoWhite} alt="ApplyCaptain" className="h-6 w-auto" />
            <span className="text-white font-bold text-lg">ApplyCaptain</span>
          </div>
          <Badge className="bg-red-500 text-white font-bold text-xs px-2 py-1 animate-pulse">
            🔥 VIRAL
          </Badge>
        </div>
      </header>

      {/* Hero Section - Social Media Optimized */}
      <section className="px-4 py-8 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Badge className="bg-red-500 text-white mb-4 font-bold text-sm px-4 py-2">
              🔥 VIRAL ON TIKTOK - 2.3M VIEWS
            </Badge>
            
            <h1 className="text-3xl md:text-5xl font-black mb-4 leading-tight">
              POV: You Used AI to Get
              <br />
              <span className="text-yellow-300">3 Job Offers</span>
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-pink-400">
                in 1 Week 🤯
              </span>
            </h1>

            <p className="text-lg md:text-xl mb-6 max-w-2xl mx-auto font-medium">
              This AI literally applies to <span className="text-yellow-300 font-bold">100+ jobs daily</span> while you sleep. 
              50k+ people already got hired 💀
            </p>

            <div className="mb-6">
              <SignUpButton mode="modal">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-yellow-400 to-pink-500 text-black font-black text-lg px-8 py-4 rounded-full hover:scale-105 transition-transform w-full sm:w-auto"
                  onClick={() => trackSocialConversion('sign_up', 'viral_cta')}
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  Try Free (No 🧢)
                </Button>
              </SignUpButton>
            </div>

            <p className="text-sm text-gray-200 mb-8">
              💯 Free trial • ⚡ 2-min setup • 🎯 Results in 24hrs
            </p>

            {/* Social Proof Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {viralStats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="text-center"
                  >
                    <Icon className="h-6 w-6 mx-auto mb-1 text-yellow-300" />
                    <div className="text-2xl font-bold">{stat.number}</div>
                    <div className="text-xs text-gray-300">{stat.label}</div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Viral Testimonials */}
      <section className="px-4 py-12 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-8">
            The Internet is Going CRAZY 🤯
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {socialTestimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                <Card className="bg-white/10 border-white/20 text-white overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full"></div>
                        <div>
                          <div className="font-bold text-sm flex items-center">
                            {testimonial.name}
                            {testimonial.verified && (
                              <CheckCircle className="h-3 w-3 ml-1 text-blue-400" />
                            )}
                          </div>
                          <div className="text-xs text-gray-300">
                            {testimonial.followers} followers
                          </div>
                        </div>
                      </div>
                      <Badge className="text-xs" variant="outline">
                        {testimonial.platform}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-3 leading-relaxed">
                      {testimonial.text}
                    </p>
                    <div className="flex items-center text-xs text-gray-400">
                      <Heart className="h-3 w-3 mr-1 text-red-400" />
                      {testimonial.likes} likes
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works - TikTok Style */}
      <section className="px-4 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            How This Actually Works 👀
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-white/10 border-white/20 text-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-3">📄</div>
                <h3 className="font-bold mb-2">Upload Resume</h3>
                <p className="text-sm text-gray-300">Takes literally 30 seconds</p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20 text-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-3">🤖</div>
                <h3 className="font-bold mb-2">AI Goes Brrrr</h3>
                <p className="text-sm text-gray-300">Applies to 100+ jobs overnight</p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 border-white/20 text-white">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-3">💰</div>
                <h3 className="font-bold mb-2">Get Hired</h3>
                <p className="text-sm text-gray-300">Multiple offers in days</p>
              </CardContent>
            </Card>
          </div>

          <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl p-6 text-black">
            <h3 className="text-xl font-bold mb-2">Fr No 🧢</h3>
            <p className="text-sm mb-4">
              This isn't some get-rich-quick scheme. It's literally AI automation for job applications.
              The same AI tech that powers ChatGPT, but for getting you hired.
            </p>
            <div className="flex justify-center space-x-4 text-xs">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1" />
                100% Legit
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1" />
                Actually Works
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 mr-1" />
                50k+ Users
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA - Social Optimized */}
      <section className="px-4 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Blow Up Your Career? 🚀
          </h2>
          <p className="text-lg text-gray-200 mb-8">
            Join the 50k+ people who already used this to get hired
          </p>

          <div className="bg-gradient-to-r from-yellow-400 to-pink-500 rounded-2xl p-8 text-black mb-8">
            <h3 className="text-2xl font-bold mb-4">🎯 Start Your Glow Up</h3>
            
            <SignUpButton mode="modal">
              <Button 
                size="lg" 
                className="bg-black text-white hover:bg-gray-800 font-bold text-xl px-12 py-4 rounded-full mb-4"
                onClick={() => trackSocialConversion('sign_up', 'final_cta')}
              >
                Get Hired Now (Free)
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </SignUpButton>

            <p className="text-sm">
              ✨ Free trial • 🚫 No credit card • ⚡ Setup in 2 min
            </p>
          </div>

          <div className="flex justify-center space-x-6 text-white/60">
            <button 
              className="flex items-center space-x-2 text-sm hover:text-white"
              onClick={() => trackSocialConversion('share', 'instagram')}
            >
              <Instagram className="h-4 w-4" />
              <span>Share on IG</span>
            </button>
            <button 
              className="flex items-center space-x-2 text-sm hover:text-white"
              onClick={() => trackSocialConversion('share', 'twitter')}
            >
              <Twitter className="h-4 w-4" />
              <span>Tweet This</span>
            </button>
            <button 
              className="flex items-center space-x-2 text-sm hover:text-white"
              onClick={() => trackSocialConversion('share', 'linkedin')}
            >
              <Linkedin className="h-4 w-4" />
              <span>Post on LinkedIn</span>
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/50 px-4 py-6 text-center text-gray-400">
        <div className="max-w-6xl mx-auto">
          <p className="mb-2 text-sm">© 2025 Wrelik Brands, LLC. All rights reserved.</p>
          <div className="flex flex-wrap justify-center gap-4 text-xs">
            <a href="/legal/privacy-policy" className="hover:text-white">Privacy</a>
            <a href="/legal/terms-of-service" className="hover:text-white">Terms</a>
            <a href="mailto:help@applycaptain.com" className="hover:text-white">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}