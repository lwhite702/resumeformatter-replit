import { Button } from "@/components/ui/button";
import FloatingNavbar from "@/components/ui/floating-navbar";
import { Footer } from "@/components/ui/footer";
import { CaptainLogo } from "@/components/ui/captain-logo";
import { DashboardMockup } from "@/components/ui/dashboard-mockup";
import { JobQueueMockup } from "@/components/ui/job-queue-mockup";
import { ResumeOptimizerMockup } from "@/components/ui/resume-optimizer-mockup";
import { BlogSection } from "@/components/ui/blog-section";
import { SignInButton, SignUpButton } from "@clerk/clerk-react";
import { Clock, Brain, Target, Shield, BarChart3, Zap, Play, Check, Star, Compass, Anchor, Navigation } from "lucide-react";
import prepPairLogo from "@assets/3_1750210014430.png";
import resumeFormatterLogo from "@assets/5_1750210014431.png";

export default function LandingUnified() {

  const features = [
    {
      icon: Compass,
      title: "Smart Navigation",
      description: "Our AI captain charts the best course through job opportunities, matching your skills with perfect positions.",
      component: ResumeOptimizerMockup
    },
    {
      icon: Anchor,
      title: "Daily Fleet Operations",
      description: "Your personal job fleet is managed daily, with new opportunities automatically added to your voyage.",
      component: JobQueueMockup
    },
    {
      icon: Navigation,
      title: "Auto-Pilot Applications",
      description: "Set sail with automated applications while your captain handles the navigation and communications.",
      component: DashboardMockup
    },
    {
      icon: Shield,
      title: "Secure Harbor",
      description: "Your career data is protected in our secure harbor. We never share your information with unauthorized ports.",
      component: DashboardMockup
    },
    {
      icon: BarChart3,
      title: "Captain's Log",
      description: "Track your voyage progress, success rates, and chart your course to better opportunities.",
      component: DashboardMockup
    },
    {
      icon: Zap,
      title: "Quick Departure",
      description: "Set sail in minutes. Upload your credentials, set your destination, and let your captain take command.",
      component: ResumeOptimizerMockup
    }
  ];

  const plans = [
    {
      name: "First Mate",
      price: "$0",
      period: "month",
      description: "Begin your voyage with essential navigation tools",
      features: [
        "5 job expeditions per month",
        "Basic AI compass",
        "Harbor support via email",
        "Resume chart optimization"
      ],
      popular: false
    },
    {
      name: "Ship Captain", 
      price: "$29",
      period: "month",
      description: "Command your fleet with advanced navigation",
      features: [
        "Unlimited job expeditions",
        "Advanced AI navigation system",
        "Priority lighthouse support",
        "Custom cover letter crew",
        "Captain's analytics bridge",
        "50% off Wrelik fleet products"
      ],
      popular: true
    },
    {
      name: "Fleet Admiral",
      price: "$99",
      period: "month", 
      description: "Lead multiple fleets across career oceans",
      features: [
        "Everything in Ship Captain",
        "Multi-crew user accounts",
        "Custom port integrations",
        "Dedicated fleet commander",
        "White-label vessel options"
      ],
      popular: false
    }
  ];

  const stats = [
    { number: "10,000+", label: "Applications Sent" },
    { number: "2,400+", label: "Interviews Scheduled" },
    { number: "850+", label: "Job Offers Received" },
    { number: "94%", label: "User Satisfaction" }
  ];

  return (
    <div className="min-h-screen bg-captain-gradient relative overflow-hidden">
      {/* Floating Navigation */}
      <FloatingNavbar />

      {/* Nautical Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 right-20 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 left-20 w-80 h-80 bg-white/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-yellow-400/5 to-transparent rounded-full blur-3xl"></div>
      </div>

      {/* Hero Section */}
      <section className="relative py-20 sm:py-24 lg:py-32 pt-24 sm:pt-32">
        <div className="container-spacing">
          <div className="text-center max-w-5xl mx-auto">
            {/* ApplyCaptain Logo */}
            <div className="mb-8">
              <CaptainLogo size="xl" variant="light" />
            </div>

            {/* Main Headline */}
            <h1 className="heading-display text-white mb-6 captain-heading">
              Chart Your Course to Success.
              <br />
              <span className="text-captain-gold">Let Your Captain Navigate.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-large text-white/90 mb-10 max-w-3xl mx-auto captain-body">
              Your AI-powered career captain automatically discovers, applies to, and tracks the perfect job opportunities. 
              Set sail toward your dream career while we handle the navigation.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <SignUpButton mode="modal">
                <Button className="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-slate-900 px-8 py-4 text-lg font-bold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-xl captain-heading">
                  Set Sail Now
                </Button>
              </SignUpButton>
              <SignInButton mode="modal">
                <Button 
                  variant="outline"
                  className="glass-morphism text-white border-white/30 hover:bg-white/10 px-8 py-4 text-lg font-semibold rounded-xl flex items-center gap-2 captain-body"
                >
                  <Compass className="w-5 h-5" />
                  Sign In
                </Button>
              </SignInButton>
            </div>

            {/* Trust Indicators */}
            <p className="text-white/70 text-sm captain-body">
              Free voyage • No commitment required • Ready to sail in 2 minutes
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-16">
        <div className="container-spacing">
          <div className="glass-morphism rounded-3xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="heading-medium text-brand-gradient mb-2">{stat.number}</div>
                  <div className="text-body text-white/80">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Live Functionality Showcase */}
      <section className="section-padding">
        <div className="container-spacing">
          <div className="text-center mb-12">
            <h2 className="heading-large text-white mb-6 captain-heading">Captain's Bridge Overview</h2>
            <p className="text-large text-white/80 max-w-2xl mx-auto mb-8 captain-body">
              Navigate your career from the captain's bridge with live job discovery and automated application management.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="glass-card rounded-2xl p-6 border-l-4 border-cyan-400">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-ocean-wave p-2 rounded-lg">
                  <Anchor className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white captain-heading">Fleet Operations</h3>
              </div>
              <JobQueueMockup />
            </div>
            
            <div className="glass-card rounded-2xl p-6 border-l-4 border-purple-400">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-aurora-gradient p-2 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white captain-heading">Captain's Log</h3>
              </div>
              <DashboardMockup />
            </div>
            
            <div className="glass-card rounded-2xl p-6 border-l-4 border-orange-400">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-sunset-gradient p-2 rounded-lg">
                  <Navigation className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white captain-heading">Navigation Charts</h3>
              </div>
              <ResumeOptimizerMockup />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding" itemScope itemType="https://schema.org/Service">
        <div className="container-spacing">
          <div className="text-center mb-16">
            <h2 className="heading-large text-white mb-6" itemProp="name">
              Everything You Need to
              <span className="text-brand-gradient"> Automate Your Job Search</span>
            </h2>
            <p className="text-large text-white/80 max-w-3xl mx-auto" itemProp="description">
              Our comprehensive platform handles every aspect of your job search, from finding opportunities to tracking applications.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const gradients = [
                "bg-ocean-wave border-cyan-400",
                "bg-aurora-gradient border-purple-400", 
                "bg-sunset-gradient border-orange-400",
                "bg-gradient-to-br from-emerald-400 to-teal-600 border-emerald-400",
                "bg-gradient-to-br from-rose-400 to-pink-600 border-rose-400",
                "bg-gradient-to-br from-violet-400 to-purple-600 border-violet-400"
              ];
              const gradient = gradients[index % gradients.length];
              
              return (
                <div key={index} className={`glass-card rounded-2xl p-8 text-center border-l-4 ${gradient.split(' ')[1]} hover:scale-105 transition-all duration-300`}>
                  <div className="mb-6">
                    <div className="mb-4">
                      <feature.component />
                    </div>
                    <div className={`inline-flex items-center justify-center w-16 h-16 ${gradient.split(' ')[0]} rounded-2xl shadow-lg`}>
                      <feature.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <h3 className="heading-small text-white mb-4">{feature.title}</h3>
                  <p className="text-body text-white/80">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="section-padding" aria-labelledby="how-it-works-heading">
        <div className="container-spacing">
          <div className="text-center mb-16">
            <h2 id="how-it-works-heading" className="heading-large text-white mb-6">How It Works</h2>
            <p className="text-large text-white/80 max-w-2xl mx-auto mobile-text-large">
              Get started in three simple steps and let our AI handle the rest.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Upload & Setup",
                description: "Upload your resume and set your job preferences. Our AI learns your skills and career goals."
              },
              {
                step: "02", 
                title: "AI Finds Jobs",
                description: "Our system continuously scans job boards and finds opportunities that match your profile."
              },
              {
                step: "03",
                title: "Auto-Apply",
                description: "We automatically apply to jobs with personalized cover letters and optimized applications."
              }
            ].map((step, index) => {
              const stepGradients = [
                "bg-ocean-wave",
                "bg-aurora-gradient", 
                "bg-sunset-gradient"
              ];
              const stepGradient = stepGradients[index];
              
              return (
                <div key={index} className="text-center group hover:scale-105 transition-all duration-300">
                  <div className={`inline-flex items-center justify-center w-20 h-20 ${stepGradient} rounded-2xl mb-6 shadow-xl`}>
                    <span className="text-2xl font-bold text-white">{step.step}</span>
                  </div>
                  <h3 className="heading-small text-white mb-4 group-hover:text-ocean-gradient transition-colors">{step.title}</h3>
                  <p className="text-body text-white/80">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="section-padding">
        <div className="container-spacing">
          <div className="text-center mb-16">
            <h2 className="heading-large text-white mb-6">Choose Your Rank</h2>
            <p className="text-large text-white/80 max-w-2xl mx-auto">
              Begin as First Mate, advance to Ship Captain, or command as Fleet Admiral with full AI navigation power.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => {
              const pricingGradients = [
                "border-l-4 border-cyan-400",
                "border-l-4 border-purple-400 ring-2 ring-purple-400/30",
                "border-l-4 border-orange-400"
              ];
              const pricingGradient = pricingGradients[index];
              
              return (
                <div key={index} className={`glass-card rounded-3xl p-8 text-center relative ${pricingGradient} hover:scale-105 transition-all duration-300`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-slate-900 px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-1">
                      <Star className="w-4 h-4 fill-current" />
                      Captain's Choice
                    </div>
                  </div>
                )}
                
                <h3 className="heading-small text-white mb-2">{plan.name}</h3>
                <p className="text-white/70 mb-6">{plan.description}</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold text-brand-gradient">{plan.price}</span>
                  <span className="text-white/70">/{plan.period}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-white/80">
                      <Check className="w-5 h-5 text-brand-accent mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <SignUpButton mode="modal">
                  <Button 
                    className={`w-full py-3 rounded-xl font-semibold transition-all duration-200 ${
                      plan.popular 
                        ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-slate-900' 
                        : 'glass-morphism text-white border-white/30 hover:bg-white/10'
                    }`}
                  >
                    {plan.name === 'Free' ? 'Start Free' : 'Get Started'}
                  </Button>
                </SignUpButton>
              </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <BlogSection />

      {/* Wrelik Brand Integration Section */}
      <section className="section-padding">
        <div className="container-spacing">
          <div className="text-center mb-12">
            <h2 className="heading-large text-white mb-6">Powered by Wrelik Ecosystem</h2>
            <p className="text-large text-white/80 max-w-3xl mx-auto mb-8">
              AutoApply integrates seamlessly with our suite of professional tools. Pro users get 50% off all Wrelik products.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="glass-card rounded-2xl p-8 text-center">
              <img src={resumeFormatterLogo} alt="ResumeFormatter.io" className="h-16 mx-auto mb-6" />
              <h3 className="heading-small text-white mb-4">ResumeFormatter.io</h3>
              <p className="text-body text-white/80 mb-6">
                Professional resume formatting and optimization tools. Create ATS-friendly resumes that get noticed.
              </p>
              <a 
                href="https://resumeformatter.io" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block"
              >
                <Button className="bg-brand-accent hover:bg-brand-accent-light text-white px-6 py-3 rounded-xl">
                  Visit ResumeFormatter.io
                </Button>
              </a>
            </div>

            <div className="glass-card rounded-2xl p-8 text-center">
              <img src={prepPairLogo} alt="PrepPair.me" className="h-16 mx-auto mb-6" />
              <h3 className="heading-small text-white mb-4">PrepPair.me</h3>
              <p className="text-body text-white/80 mb-6">
                Interview preparation and career coaching platform. Practice with AI-powered mock interviews.
              </p>
              <a 
                href="https://preppair.me" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block"
              >
                <Button className="bg-brand-accent hover:bg-brand-accent-light text-white px-6 py-3 rounded-xl">
                  Visit PrepPair.me
                </Button>
              </a>
            </div>
          </div>

          <div className="text-center mt-12">
            <div className="glass-morphism rounded-2xl p-6 max-w-2xl mx-auto">
              <p className="text-white font-semibold mb-2">🎉 Pro User Exclusive</p>
              <p className="text-white/80">
                Upgrade to AutoApply Professional and get <span className="text-brand-gradient font-bold">50% off</span> all Wrelik products including ResumeFormatter.io and PrepPair.me subscriptions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="section-padding">
        <div className="container-spacing">
          <div className="glass-morphism rounded-3xl p-12 text-center">
            <h2 className="heading-large text-white mb-6">Ready to 10x Your Job Search?</h2>
            <p className="text-large text-white/80 mb-10 max-w-2xl mx-auto">
              Join thousands of professionals who've automated their way to better opportunities.
            </p>
            <SignUpButton mode="modal">
              <Button className="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-slate-900 px-12 py-4 text-xl font-bold rounded-xl transition-all duration-200 transform hover:scale-105 shadow-xl captain-heading">
                Start Your Free Trial
              </Button>
            </SignUpButton>
            <p className="text-white/60 mt-6">
              Free trial • No credit card required • Setup in 2 minutes
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}