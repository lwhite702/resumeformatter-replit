import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import HeroSection from "@/components/ui/hero-section";
import { BouncyCardsFeatures } from "@/components/ui/bounce-card-features";
import FloatingNavbar from "@/components/ui/floating-navbar";
import { Footer } from "@/components/ui/footer";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-primary via-brand-secondary to-slate-900 relative overflow-hidden text-white">
      {/* Floating Navigation */}
      <FloatingNavbar />
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-transparent to-transparent"></div>
      <div className="absolute top-20 right-20 w-96 h-96 bg-brand-accent/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-20 w-80 h-80 bg-white/5 rounded-full blur-3xl"></div>
      
      <div className="relative z-10">
        {/* Header */}
        <header className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-white/90 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-brand mr-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-brand-primary">
                  <path d="M12 2L2 7v10c0 5.55 3.84 9.95 9 11 5.16-1.05 9-5.45 9-11V7l-10-5z" fill="currentColor"/>
                  <path d="M8 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white text-display">AutoApply</h1>
                <span className="text-sm text-brand-accent font-medium">by Wrelik</span>
              </div>
            </div>
            <Button 
              onClick={handleLogin}
              className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white border border-white/20 px-8 py-3 rounded-xl font-semibold transition-all duration-200"
            >
              Get Started
            </Button>
          </div>
        </header>

        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-6xl lg:text-7xl font-bold text-white mb-8 text-display leading-tight">
              Job Applications,
              <br />
              <span className="text-brand-accent">Automated</span>
            </h1>
            <p className="text-xl lg:text-2xl text-white/80 max-w-3xl mx-auto mb-12 leading-relaxed">
              The first AI-powered platform that finds, analyzes, and applies to jobs on your behalf using intelligent matching and personalized cover letters.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16">
              <Button 
                onClick={handleLogin}
                className="bg-brand-accent hover:bg-brand-accent-light text-white px-12 py-4 text-lg font-semibold rounded-xl shadow-brand transition-all duration-200 transform hover:scale-105"
              >
                Start Auto-Applying
              </Button>
              <Button 
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-12 py-4 text-lg font-semibold rounded-xl backdrop-blur-sm transition-all duration-200"
              >
                Watch Demo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-2">10K+</div>
                <div className="text-white/60 text-sm">Applications Sent</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-2">95%</div>
                <div className="text-white/60 text-sm">Match Accuracy</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-2">2.5x</div>
                <div className="text-white/60 text-sm">Interview Rate</div>
              </div>
            </div>
          </div>
        </div>

      </div>
      
      {/* Bouncy Card Features Section */}
      <div className="bg-gray-50">
        <BouncyCardsFeatures />
      </div>

      <div className="relative z-10">
        {/* Social Proof */}
        <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20 text-center">
          <div className="glass rounded-2xl p-12">
            <h2 className="text-3xl font-bold text-white mb-8 text-display">"AutoApply transformed my job search"</h2>
            <p className="text-xl text-white/80 mb-8 leading-relaxed">
              "I went from spending 20 hours a week on applications to getting 3x more interviews with zero manual work. The AI-generated cover letters are incredibly personalized."
            </p>
            <div className="flex items-center justify-center">
              <div className="w-12 h-12 bg-brand-accent rounded-full flex items-center justify-center mr-4">
                <span className="text-white font-semibold">SL</span>
              </div>
              <div className="text-left">
                <div className="text-white font-semibold">Sarah Lopez</div>
                <div className="text-white/60 text-sm">Software Engineer at Meta</div>
              </div>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20 text-center">
          <h2 className="text-4xl font-bold text-white mb-6 text-display">Ready to 10x Your Job Search?</h2>
          <p className="text-xl text-white/80 mb-10">
            Join hundreds of professionals who've automated their way to better opportunities
          </p>
          <Button 
            onClick={handleLogin}
            className="bg-brand-accent hover:bg-brand-accent-light text-white px-16 py-5 text-xl font-bold rounded-xl shadow-brand transition-all duration-200 transform hover:scale-105"
          >
            Start Auto-Applying Now
          </Button>
          <p className="text-white/60 mt-6">
            Free trial • No credit card required • Setup in 2 minutes
          </p>
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}
