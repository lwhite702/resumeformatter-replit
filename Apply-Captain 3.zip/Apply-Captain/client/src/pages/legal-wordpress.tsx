import { useState, useEffect } from 'react';
import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Shield, Cookie, Database, FileText, Scale, RefreshCw, ExternalLink, AlertCircle } from 'lucide-react';

interface LegalPageData {
  slug: string;
  content: string;
  appName: string;
  lastUpdated: string;
}

interface LegalPagesData {
  pages: Record<string, string>;
  appName: string;
  lastUpdated: string;
}

const legalSections = [
  {
    id: 'privacy-policy',
    title: 'Privacy Policy',
    icon: Shield,
    description: 'How we collect, use, and protect your personal information'
  },
  {
    id: 'terms-of-service',
    title: 'Terms of Service',
    icon: Scale,
    description: 'Legal terms and conditions for using ApplyCaptain'
  },
  {
    id: 'cookie-policy',
    title: 'Cookie Policy',
    icon: Cookie,
    description: 'How we use cookies and similar technologies'
  },
  {
    id: 'data-retention',
    title: 'Data Retention Policy',
    icon: Database,
    description: 'How long we keep your data and deletion procedures'
  }
];

export default function LegalWordPress() {
  const [, params] = useRoute('/legal/:section?');
  const [selectedSection, setSelectedSection] = useState<string | null>(params?.section || null);

  // Fetch all legal pages
  const { data: allPages, isLoading: allPagesLoading, error: allPagesError } = useQuery<LegalPagesData>({
    queryKey: ['/api/legal'],
    queryFn: () => fetch('/api/legal?app=ApplyCaptain').then(res => res.json()),
  });

  // Fetch specific page if section is selected
  const { data: specificPage, isLoading: pageLoading, error: pageError } = useQuery<LegalPageData>({
    queryKey: ['/api/legal', selectedSection],
    queryFn: () => fetch(`/api/legal/${selectedSection}?app=ApplyCaptain`).then(res => res.json()),
    enabled: !!selectedSection,
  });

  const currentContent = selectedSection ? specificPage?.content : null;
  const isLoading = selectedSection ? pageLoading : allPagesLoading;
  const hasError = selectedSection ? pageError : allPagesError;

  const handleBackToOverview = () => {
    setSelectedSection(null);
    window.history.pushState({}, '', '/legal');
  };

  const handleSectionSelect = (sectionId: string) => {
    setSelectedSection(sectionId);
    window.history.pushState({}, '', `/legal/${sectionId}`);
  };

  // Set initial section from URL
  useEffect(() => {
    if (params?.section && !selectedSection) {
      setSelectedSection(params.section);
    }
  }, [params?.section, selectedSection]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                <span>Unable to Load Legal Content</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                We're having trouble loading the legal content from our content management system. 
                This may be due to a temporary connection issue.
              </p>
              <Button onClick={() => window.location.reload()} className="flex items-center space-x-2">
                <RefreshCw className="h-4 w-4" />
                <span>Retry</span>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-8">
          {selectedSection ? (
            <div className="flex items-center space-x-4 mb-6">
              <Button
                variant="ghost"
                onClick={handleBackToOverview}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Legal Overview</span>
              </Button>
            </div>
          ) : null}
          
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {selectedSection ? 
                legalSections.find(s => s.id === selectedSection)?.title || 'Legal Document' :
                'Legal Information'
              }
            </h1>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              {selectedSection ?
                legalSections.find(s => s.id === selectedSection)?.description :
                'Important legal documents and policies for ApplyCaptain users'
              }
            </p>
            <div className="flex items-center justify-center space-x-2 mt-4">
              <Badge variant="outline" className="text-xs">
                Content from WrelikBrands.com
              </Badge>
              <Badge variant="outline" className="text-xs">
                Last updated: {(selectedSection ? specificPage?.lastUpdated : allPages?.lastUpdated) || 'Recently'}
              </Badge>
            </div>
          </div>
        </div>

        {/* Content */}
        {selectedSection && currentContent ? (
          <Card>
            <CardContent className="pt-6">
              <div 
                className="prose prose-gray dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: currentContent }}
              />
              
              {/* Additional navigation */}
              <Separator className="my-8" />
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={handleBackToOverview}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back to Overview</span>
                </Button>
                
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Questions? Contact us at help@applycaptain.com
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Overview Accordion */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Legal Documents Overview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {legalSections.map((section) => {
                    const Icon = section.icon;
                    const content = allPages?.pages?.[section.id];
                    
                    return (
                      <AccordionItem key={section.id} value={section.id}>
                        <AccordionTrigger className="text-left">
                          <div className="flex items-center space-x-3">
                            <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                            <div>
                              <div className="font-medium">{section.title}</div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                {section.description}
                              </div>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          {content ? (
                            <div>
                              <div 
                                className="prose prose-sm prose-gray dark:prose-invert max-w-none mb-4"
                                dangerouslySetInnerHTML={{ 
                                  __html: content.length > 500 ? 
                                    content.substring(0, 500) + '...' : 
                                    content 
                                }}
                              />
                              <Button
                                onClick={() => handleSectionSelect(section.id)}
                                className="flex items-center space-x-2"
                              >
                                <span>Read Full Document</span>
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <div className="text-gray-500 dark:text-gray-400">
                              Content loading...
                            </div>
                          )}
                        </AccordionContent>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Navigation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {legalSections.map((section) => {
                    const Icon = section.icon;
                    return (
                      <Button
                        key={section.id}
                        variant="outline"
                        onClick={() => handleSectionSelect(section.id)}
                        className="flex items-center justify-start space-x-3 h-auto p-4"
                      >
                        <Icon className="h-5 w-5" />
                        <div className="text-left">
                          <div className="font-medium">{section.title}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {section.description}
                          </div>
                        </div>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle>Contact & Support</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <div className="font-medium">Legal Questions</div>
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        For questions about these legal documents, contact us at help@applycaptain.com
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                      <ExternalLink className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <div className="font-medium">Support Center</div>
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        Visit our knowledge base at /admin/docs for additional help
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* SEO and accessibility */}
        <div className="mt-8 text-center">
          <div className="text-xs text-gray-400 dark:text-gray-500 space-y-1">
            <div>ApplyCaptain - AI-Powered Job Application Assistant</div>
            <div>Legal content sourced from WrelikBrands.com content management system</div>
            <div>Variable substitution applied for brand-specific information</div>
          </div>
        </div>
      </div>
    </div>
  );
}