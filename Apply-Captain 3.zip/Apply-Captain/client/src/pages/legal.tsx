import { useState, useEffect } from 'react';
import { useRoute } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Anchor, Scale, Shield, Cookie, Database, FileText } from 'lucide-react';

interface LegalContent {
  id: string;
  title: string;
  content: string;
  lastUpdated: string;
  icon: any;
}

const defaultLegalContent: LegalContent[] = [
  {
    id: 'privacy-policy',
    title: 'Privacy Policy',
    icon: Shield,
    lastUpdated: '2025-06-18',
    content: `
      <h2>Privacy Policy for ApplyCaptain</h2>
      <p>At ApplyCaptain, we are committed to protecting your privacy and ensuring the security of your personal information. This privacy policy explains how we collect, use, and protect your data when you use our job application automation service.</p>
      
      <h3>Information We Collect</h3>
      <ul>
        <li><strong>Account Information:</strong> Name, email address, and authentication credentials</li>
        <li><strong>Professional Data:</strong> Resume content, work experience, skills, and career preferences</li>
        <li><strong>Application Data:</strong> Job applications, cover letters, and application history</li>
        <li><strong>Usage Analytics:</strong> App usage patterns, feature interactions, and performance metrics</li>
      </ul>
      
      <h3>How We Use Your Information</h3>
      <ul>
        <li>Provide and improve our job application automation services</li>
        <li>Match you with relevant job opportunities</li>
        <li>Generate personalized cover letters and application materials</li>
        <li>Communicate important updates about your applications</li>
        <li>Enhance our AI matching algorithms</li>
      </ul>
      
      <h3>Data Security</h3>
      <p>We implement industry-standard security measures including encryption, secure data storage, and regular security audits. Your personal information is stored securely and accessed only by authorized personnel.</p>
      
      <h3>Data Sharing</h3>
      <p>We do not sell or share your personal information with third parties except:</p>
      <ul>
        <li>When applying to jobs on your behalf through authorized job boards</li>
        <li>With your explicit consent for specific integrations</li>
        <li>As required by law or legal process</li>
      </ul>
      
      <h3>Your Rights</h3>
      <p>You have the right to access, update, or delete your personal information at any time through your account settings. You may also request a copy of your data or opt-out of certain communications.</p>
      
      <h3>Contact Us</h3>
      <p>For privacy-related questions, contact us at privacy@wrelikbrands.com</p>
    `
  },
  {
    id: 'terms-of-service',
    title: 'Terms of Service',
    icon: Scale,
    lastUpdated: '2025-06-18',
    content: `
      <h2>Terms of Service for ApplyCaptain</h2>
      <p>Welcome to ApplyCaptain! These terms govern your use of our job application automation platform. By using our service, you agree to these terms.</p>
      
      <h3>Service Description</h3>
      <p>ApplyCaptain is an AI-powered job application automation platform that helps users streamline their job search process through intelligent matching, automated applications, and career management tools.</p>
      
      <h3>User Responsibilities</h3>
      <ul>
        <li>Provide accurate and truthful information in your profile and applications</li>
        <li>Use the service in compliance with all applicable laws and regulations</li>
        <li>Respect intellectual property rights and platform guidelines</li>
        <li>Maintain the confidentiality of your account credentials</li>
      </ul>
      
      <h3>Service Availability</h3>
      <p>We strive to maintain 99.9% uptime but cannot guarantee uninterrupted service. We reserve the right to modify features, suspend service for maintenance, or discontinue features with appropriate notice.</p>
      
      <h3>Payment Terms</h3>
      <ul>
        <li>Subscription fees are billed monthly or annually as selected</li>
        <li>All payments are processed securely through Stripe</li>
        <li>Refunds are available within 30 days of purchase</li>
        <li>Subscription cancellations take effect at the end of the current billing period</li>
      </ul>
      
      <h3>Intellectual Property</h3>
      <p>ApplyCaptain and its features are proprietary to Wrelik Brands. Users retain ownership of their personal content while granting us license to use it for service provision.</p>
      
      <h3>Limitation of Liability</h3>
      <p>ApplyCaptain is provided "as is" without warranties. We are not liable for job application outcomes, employment decisions, or third-party actions related to your job search.</p>
      
      <h3>Termination</h3>
      <p>Either party may terminate the service agreement with appropriate notice. Upon termination, you retain access to your data for 30 days for export purposes.</p>
      
      <h3>Governing Law</h3>
      <p>These terms are governed by the laws of the jurisdiction where Wrelik Brands operates.</p>
    `
  },
  {
    id: 'cookie-policy',
    title: 'Cookie Policy',
    icon: Cookie,
    lastUpdated: '2025-06-18',
    content: `
      <h2>Cookie Policy for ApplyCaptain</h2>
      <p>This cookie policy explains how ApplyCaptain uses cookies and similar technologies to enhance your user experience.</p>
      
      <h3>What Are Cookies</h3>
      <p>Cookies are small text files stored on your device that help us provide and improve our services. We use both session cookies (temporary) and persistent cookies (stored longer-term).</p>
      
      <h3>Types of Cookies We Use</h3>
      
      <h4>Essential Cookies</h4>
      <ul>
        <li><strong>Authentication:</strong> Keep you logged in securely</li>
        <li><strong>Security:</strong> Protect against unauthorized access</li>
        <li><strong>Functionality:</strong> Remember your preferences and settings</li>
      </ul>
      
      <h4>Analytics Cookies</h4>
      <ul>
        <li><strong>Usage Analytics:</strong> Understand how you use our platform</li>
        <li><strong>Performance Monitoring:</strong> Identify and fix technical issues</li>
        <li><strong>Feature Usage:</strong> Improve popular features and remove unused ones</li>
      </ul>
      
      <h4>Functional Cookies</h4>
      <ul>
        <li><strong>Onboarding State:</strong> Remember your progress through setup</li>
        <li><strong>Interface Preferences:</strong> Save your dashboard layout and themes</li>
        <li><strong>Search History:</strong> Improve job matching recommendations</li>
      </ul>
      
      <h3>Third-Party Cookies</h3>
      <p>We use select third-party services that may set their own cookies:</p>
      <ul>
        <li><strong>Clerk:</strong> Authentication and user management</li>
        <li><strong>Stripe:</strong> Secure payment processing</li>
        <li><strong>Job Board APIs:</strong> Application submission tracking</li>
      </ul>
      
      <h3>Managing Cookies</h3>
      <p>You can control cookies through your browser settings. Note that disabling essential cookies may impact platform functionality. You can:</p>
      <ul>
        <li>Block all cookies (may break functionality)</li>
        <li>Block third-party cookies only</li>
        <li>Delete existing cookies</li>
        <li>Set cookie preferences in your account settings</li>
      </ul>
      
      <h3>Cookie Consent</h3>
      <p>By using ApplyCaptain, you consent to our use of cookies as described in this policy. We'll notify you of any significant changes to our cookie practices.</p>
    `
  },
  {
    id: 'data-retention',
    title: 'Data Retention Policy',
    icon: Database,
    lastUpdated: '2025-06-18',
    content: `
      <h2>Data Retention Policy for ApplyCaptain</h2>
      <p>This policy outlines how long we retain your personal information and the procedures for data deletion.</p>
      
      <h3>Active Account Data</h3>
      <p>While your account is active, we retain all your data to provide continuous service:</p>
      <ul>
        <li><strong>Profile Information:</strong> Retained indefinitely while account is active</li>
        <li><strong>Application History:</strong> Retained for analytical and reporting purposes</li>
        <li><strong>Resume Versions:</strong> All versions kept for comparison and optimization</li>
        <li><strong>Job Matching Data:</strong> Used to improve recommendations over time</li>
      </ul>
      
      <h3>Post-Cancellation Retention</h3>
      <p>After account cancellation or subscription termination:</p>
      <ul>
        <li><strong>30 Days:</strong> Grace period for data export and account reactivation</li>
        <li><strong>90 Days:</strong> Anonymized usage data retained for product improvement</li>
        <li><strong>1 Year:</strong> Financial records retained for accounting and tax purposes</li>
        <li><strong>7 Years:</strong> Legal and compliance records as required by law</li>
      </ul>
      
      <h3>Automatic Data Deletion</h3>
      <p>We automatically delete certain types of data on scheduled intervals:</p>
      <ul>
        <li><strong>Session Logs:</strong> Deleted after 30 days</li>
        <li><strong>Error Logs:</strong> Deleted after 90 days</li>
        <li><strong>Temporary Files:</strong> Deleted after 7 days</li>
        <li><strong>Email Logs:</strong> Deleted after 1 year</li>
      </ul>
      
      <h3>Data Export</h3>
      <p>You can request a complete export of your data at any time:</p>
      <ul>
        <li>JSON format for technical users</li>
        <li>PDF format for general use</li>
        <li>CSV format for analytics data</li>
        <li>ZIP archive containing all files and documents</li>
      </ul>
      
      <h3>Right to Deletion</h3>
      <p>You have the right to request immediate deletion of your data:</p>
      <ul>
        <li>Complete account deletion within 30 days</li>
        <li>Selective data deletion for specific information</li>
        <li>Anonymization instead of deletion where legally required</li>
      </ul>
      
      <h3>Data Backup and Recovery</h3>
      <p>We maintain secure backups of your data:</p>
      <ul>
        <li><strong>Daily Backups:</strong> Retained for 30 days</li>
        <li><strong>Weekly Backups:</strong> Retained for 12 weeks</li>
        <li><strong>Monthly Backups:</strong> Retained for 12 months</li>
        <li><strong>Annual Backups:</strong> Retained for 7 years for compliance</li>
      </ul>
      
      <h3>Contact for Data Requests</h3>
      <p>For data retention questions or deletion requests, contact us at data@wrelikbrands.com with your account details and specific request.</p>
    `
  }
];

export default function Legal() {
  const [, params] = useRoute('/legal/:section?');
  const [legalContent, setLegalContent] = useState<LegalContent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In production, this would fetch from WordPress CMS
    // For now, using default content with brand replacement
    const processedContent = defaultLegalContent.map(item => ({
      ...item,
      content: item.content.replace(/{Brand Name}/g, 'ApplyCaptain')
    }));
    
    setLegalContent(processedContent);
    setLoading(false);
  }, []);

  const currentSection = params?.section;
  const selectedContent = currentSection 
    ? legalContent.find(item => item.id === currentSection)
    : null;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (selectedContent) {
    const IconComponent = selectedContent.icon;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Breadcrumbs */}
          <nav className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
            <a href="/" className="hover:text-blue-600 dark:hover:text-blue-400">ApplyCaptain</a>
            <span>/</span>
            <a href="/legal" className="hover:text-blue-600 dark:hover:text-blue-400">Legal</a>
            <span>/</span>
            <span className="text-gray-900 dark:text-white">{selectedContent.title}</span>
          </nav>

          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <IconComponent className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <CardTitle className="text-2xl">{selectedContent.title}</CardTitle>
                  <Badge variant="secondary" className="mt-1">
                    Last updated: {new Date(selectedContent.lastUpdated).toLocaleDateString()}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div 
                className="prose prose-lg dark:prose-invert max-w-none blog-content"
                dangerouslySetInnerHTML={{ __html: selectedContent.content }}
              />
            </CardContent>
          </Card>

          <div className="text-center">
            <a 
              href="/legal"
              className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200"
            >
              ← Back to Legal Overview
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Anchor className="h-8 w-8 text-blue-600 dark:text-blue-400 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              Legal Information
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Important legal documents and policies for ApplyCaptain users
          </p>
        </div>

        {/* Legal Documents Accordion */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Legal Documents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {legalContent.map((item) => {
                const IconComponent = item.icon;
                return (
                  <AccordionItem key={item.id} value={item.id}>
                    <AccordionTrigger className="text-left">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                          <IconComponent className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                          <div className="font-semibold">{item.title}</div>
                          <div className="text-sm text-gray-500">
                            Updated {new Date(item.lastUpdated).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="pl-11">
                        <div 
                          className="prose dark:prose-invert max-w-none blog-content text-sm"
                          dangerouslySetInnerHTML={{ 
                            __html: item.content.substring(0, 500) + '...' 
                          }}
                        />
                        <a 
                          href={`/legal/${item.id}`}
                          className="inline-flex items-center mt-4 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200 font-medium"
                        >
                          Read Full Document →
                        </a>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle>Legal Contact Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">General Legal Inquiries</h3>
                <p className="text-gray-600 dark:text-gray-300">legal@wrelikbrands.com</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Privacy & Data Protection</h3>
                <p className="text-gray-600 dark:text-gray-300">privacy@wrelikbrands.com</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Data Requests & Deletion</h3>
                <p className="text-gray-600 dark:text-gray-300">data@wrelikbrands.com</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Business Address</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Wrelik Brands<br/>
                  Legal Department<br/>
                  [Address will be updated]
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}