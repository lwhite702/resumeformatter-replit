import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { OnboardingTest, OnboardingMetrics } from "@/components/ui/onboarding-test";
import { 
  CheckCircle, 
  Clock, 
  User, 
  Upload, 
  Settings, 
  Compass, 
  Target,
  Play,
  AlertCircle,
  Info
} from "lucide-react";

export default function OnboardingTestPage() {
  const [testPhase, setTestPhase] = useState<"overview" | "testing" | "completed">("overview");
  const [testResults, setTestResults] = useState<any>(null);
  const [startTime, setStartTime] = useState<number>(0);

  const testScenarios = [
    {
      id: "sign-up",
      title: "Sign-Up Flow",
      description: "Test user registration and account creation",
      steps: [
        "Access landing page",
        "Click 'Get Started' or 'Sign Up'",
        "Complete Clerk authentication",
        "Verify account creation",
        "Land on dashboard"
      ],
      targetTime: 60 // seconds
    },
    {
      id: "onboarding-tour",
      title: "Guided Onboarding Tour",
      description: "Complete the full onboarding experience",
      steps: [
        "Trigger onboarding tour",
        "Navigate through 5 steps",
        "Upload resume",
        "Set preferences",
        "Create auto-apply rule",
        "Check daily queue"
      ],
      targetTime: 300 // 5 minutes
    },
    {
      id: "help-accessibility",
      title: "Help System Accessibility",
      description: "Verify help is accessible within 2 clicks",
      steps: [
        "Access floating help widget",
        "Test contextual tooltips",
        "Navigate to knowledge base",
        "Use inline help components",
        "Verify quick actions work"
      ],
      targetTime: 30 // seconds
    }
  ];

  const startTest = () => {
    setTestPhase("testing");
    setStartTime(Date.now());
  };

  const completeTest = () => {
    const totalTime = Date.now() - startTime;
    setTestResults({
      totalTime: Math.round(totalTime / 1000),
      success: totalTime < 300000, // 5 minutes
      completedScenarios: testScenarios.length
    });
    setTestPhase("completed");
  };

  if (testPhase === "testing") {
    return <OnboardingTest onComplete={completeTest} />;
  }

  if (testPhase === "completed") {
    return (
      <main className="p-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Onboarding Test Results</h1>
            <p className="text-gray-600">Complete analysis of the user onboarding experience</p>
          </div>

          <div className="grid gap-6 mb-8">
            <Card className={`border-2 ${testResults.success ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {testResults.success ? (
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  ) : (
                    <AlertCircle className="h-6 w-6 text-orange-600" />
                  )}
                  Test Results Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {Math.floor(testResults.totalTime / 60)}:{(testResults.totalTime % 60).toString().padStart(2, '0')}
                    </div>
                    <p className="text-sm text-gray-600">Total Completion Time</p>
                    <Badge variant={testResults.totalTime < 300 ? "default" : "destructive"}>
                      {testResults.totalTime < 300 ? "Under 5 min target" : "Over target"}
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {testResults.completedScenarios}/3
                    </div>
                    <p className="text-sm text-gray-600">Scenarios Completed</p>
                    <Badge variant="default">All Tests</Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">
                      {testResults.success ? "PASS" : "REVIEW"}
                    </div>
                    <p className="text-sm text-gray-600">Overall Result</p>
                    <Badge variant={testResults.success ? "default" : "destructive"}>
                      {testResults.success ? "Meets Requirements" : "Needs Optimization"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <OnboardingMetrics />
          </div>

          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Feature Verification Checklist</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium">Core Onboarding Features</h4>
                    {[
                      "Guided tour under 5 minutes",
                      "Resume upload workflow",
                      "Preferences configuration",
                      "Auto-apply rules setup",
                      "Daily queue introduction"
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium">Help System Features</h4>
                    {[
                      "Help accessible within 2 clicks",
                      "Floating help widget",
                      "Contextual tooltips",
                      "Knowledge base integration",
                      "Quick action shortcuts"
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Journey Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                      <h4 className="font-medium">Sign-Up</h4>
                      <p className="text-sm text-gray-600">Quick account creation</p>
                      <Badge variant="default">1 min</Badge>
                    </div>
                    
                    <div className="text-center p-4 border rounded-lg">
                      <User className="h-8 w-8 text-green-600 mx-auto mb-2" />
                      <h4 className="font-medium">Onboarding</h4>
                      <p className="text-sm text-gray-600">Guided setup process</p>
                      <Badge variant="default">4 min</Badge>
                    </div>
                    
                    <div className="text-center p-4 border rounded-lg">
                      <Play className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                      <h4 className="font-medium">First Use</h4>
                      <p className="text-sm text-gray-600">Ready to apply jobs</p>
                      <Badge variant="default">Immediate</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 text-center">
            <Button onClick={() => setTestPhase("overview")}>
              Run Test Again
            </Button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Onboarding & Sign-Up Test</h1>
          <p className="text-gray-600">
            Comprehensive testing of user onboarding flow and help system accessibility
          </p>
        </div>

        <div className="grid gap-6 mb-8">
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-blue-600" />
                Test Objectives
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Time Requirements</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <Clock className="h-4 w-4 text-blue-600 mr-2" />
                      Complete onboarding under 5 minutes
                    </li>
                    <li className="flex items-center">
                      <Clock className="h-4 w-4 text-blue-600 mr-2" />
                      Sign-up process under 1 minute
                    </li>
                    <li className="flex items-center">
                      <Clock className="h-4 w-4 text-blue-600 mr-2" />
                      Help access within 2 clicks
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-medium mb-3">Success Criteria</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      All onboarding steps completed
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      Help system fully accessible
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      User ready for job applications
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {testScenarios.map((scenario) => (
              <Card key={scenario.id}>
                <CardHeader>
                  <CardTitle className="text-lg">{scenario.title}</CardTitle>
                  <CardDescription>{scenario.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Target Time:</span>
                      <Badge variant="outline">
                        {scenario.targetTime < 60 
                          ? `${scenario.targetTime}s` 
                          : `${Math.floor(scenario.targetTime / 60)}m`
                        }
                      </Badge>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Test Steps:</p>
                      <ul className="space-y-1">
                        {scenario.steps.map((step, index) => (
                          <li key={index} className="text-xs text-gray-600 flex items-start">
                            <span className="w-4 h-4 bg-gray-200 rounded-full flex items-center justify-center mr-2 mt-0.5 text-xs">
                              {index + 1}
                            </span>
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Button size="lg" onClick={startTest} className="gap-2">
            <Play className="h-5 w-5" />
            Start Onboarding Test
          </Button>
          <p className="text-sm text-gray-600 mt-2">
            This will simulate a new user's complete journey through ApplyCaptain
          </p>
        </div>
      </div>
    </main>
  );
}