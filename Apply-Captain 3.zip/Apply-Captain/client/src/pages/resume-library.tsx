import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLoadingModal } from "@/components/loading-modal";

export default function ResumeLibrary() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const { show: showLoading, hide: hideLoading } = useLoadingModal();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: resumes, isLoading } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: isAuthenticated,
    retry: false,
  });

  const syncResumesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/resumes/sync", {});
      return response.json();
    },
    onSuccess: (data) => {
      hideLoading();
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Resumes synced successfully",
        description: `Synced ${data.synced} resumes from ResumeFormatter.io`,
      });
    },
    onError: (error) => {
      hideLoading();
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Sync failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSyncResumes = () => {
    showLoading("Syncing Resumes", "Fetching latest resumes from ResumeFormatter.io...");
    syncResumesMutation.mutate();
  };

  const getSkillCoverage = (resume: any) => {
    // Calculate skill coverage based on skills array length
    const skillCount = resume.skills ? (resume.skills as string[]).length : 0;
    return Math.min(100, Math.max(60, skillCount * 8)); // Range between 60-100%
  };

  const getFocusColor = (focus: string) => {
    switch (focus) {
      case "frontend":
        return "bg-emerald-100 text-emerald-800";
      case "backend":
        return "bg-gray-100 text-gray-800";
      case "fullstack":
        return "bg-blue-100 text-blue-800";
      case "enterprise":
        return "bg-amber-100 text-amber-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getFocusLabel = (focus: string) => {
    switch (focus) {
      case "frontend":
        return "Most Used";
      case "backend":
        return "Backend Focus";
      case "fullstack":
        return "Full Stack";
      case "enterprise":
        return "Enterprise Focus";
      default:
        return "General";
    }
  };

  const handleDownloadResume = async (resume: any) => {
    try {
      const response = await apiRequest("GET", `/api/integrations/resume-formatter/download/${resume.externalId}`, {});
      const data = await response.json();
      window.open(data.downloadUrl, '_blank');
      toast({
        title: "Download started",
        description: `Downloading ${resume.name}...`,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to get download link",
        variant: "destructive",
      });
    }
  };

  const handleEditResume = async (resume: any) => {
    try {
      const response = await apiRequest("GET", `/api/integrations/resume-formatter/edit/${resume.externalId}`, {});
      const data = await response.json();
      window.open(data.editUrl, '_blank');
      toast({
        title: "Opening ResumeFormatter.io",
        description: "Redirecting to edit your resume...",
      });
    } catch (error) {
      toast({
        title: "Edit failed",
        description: "Failed to get edit link",
        variant: "destructive",
      });
    }
  };

  const handlePreviewResume = (resume: any) => {
    toast({
      title: "Preview",
      description: `Opening preview for ${resume.name}`,
    });
  };

  if (authLoading || !isAuthenticated) {
    return null;
  }

  if (isLoading) {
    return (
      <main className="p-6">
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Resume Library</h3>
              <p className="text-gray-600">Resumes synced from ResumeFormatter.io - AutoApply will automatically select the best match</p>
            </div>
          </div>
        </div>
        <div className="animate-pulse space-y-6">
          <div className="h-16 bg-gray-200 rounded-lg"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-2">Resume Library</h3>
            <p className="text-gray-600">Resumes synced from ResumeFormatter.io - AutoApply will automatically select the best match</p>
          </div>
          <Button 
            onClick={handleSyncResumes}
            disabled={syncResumesMutation.isPending}
            className="bg-wrelik-green hover:bg-green-600"
          >
            <i className="fas fa-sync-alt mr-2"></i>
            {syncResumesMutation.isPending ? "Syncing..." : "Sync from ResumeFormatter"}
          </Button>
        </div>
      </div>

      {/* Connection Status */}
      <Card className="mb-6 bg-emerald-50 border-emerald-200">
        <CardContent className="p-4">
          <div className="flex items-center">
            <i className="fas fa-check-circle text-emerald-600 mr-3"></i>
            <div>
              <p className="text-sm font-medium text-emerald-800">Connected to ResumeFormatter.io</p>
              <p className="text-sm text-emerald-600">
                Last synced: {resumes?.length ? "2 hours ago" : "Never"} • {resumes?.length || 0} resumes available
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resume Grid */}
      {!resumes || resumes.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <i className="fas fa-file-alt text-gray-400 text-4xl mb-4"></i>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No resumes found</h3>
            <p className="text-gray-600 mb-6">
              Sync your resumes from ResumeFormatter.io to get started with AutoApply.
            </p>
            <Button 
              onClick={handleSyncResumes}
              disabled={syncResumesMutation.isPending}
              className="bg-wrelik-green hover:bg-green-600"
            >
              <i className="fas fa-sync-alt mr-2"></i>
              Sync Your First Resume
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {resumes.map((resume: any) => {
            const skillCoverage = getSkillCoverage(resume);
            const skills = resume.skills as string[] || [];
            const displaySkills = skills.slice(0, 3);
            const remainingSkills = skills.length - 3;

            return (
              <Card key={resume.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <i className="fas fa-file-alt text-wrelik-blue text-2xl mr-3"></i>
                      <div>
                        <h4 className="font-semibold text-gray-900">{resume.name}</h4>
                        <p className="text-sm text-gray-500">
                          Last updated {resume.lastSyncedAt 
                            ? new Date(resume.lastSyncedAt).toLocaleDateString()
                            : new Date(resume.updatedAt).toLocaleDateString()
                          }
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleDownloadResume(resume)}
                        className="p-1 text-gray-400 hover:text-gray-600"
                      >
                        <i className="fas fa-download"></i>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleEditResume(resume)}
                        className="p-1 text-gray-400 hover:text-gray-600"
                      >
                        <i className="fas fa-external-link-alt"></i>
                      </Button>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">Skill Coverage</span>
                      <span className="text-sm text-gray-500">{skillCoverage}%</span>
                    </div>
                    <Progress value={skillCoverage} className="h-2" />
                  </div>

                  <div className="mb-4">
                    <h5 className="text-sm font-medium text-gray-700 mb-2">Key Skills</h5>
                    <div className="flex flex-wrap gap-1">
                      {displaySkills.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {remainingSkills > 0 && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                          +{remainingSkills} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge className={getFocusColor(resume.focus)}>
                      {getFocusLabel(resume.focus)}
                    </Badge>
                    <Button 
                      variant="link" 
                      size="sm"
                      onClick={() => handlePreviewResume(resume)}
                      className="text-wrelik-blue hover:text-blue-700 p-0"
                    >
                      Preview
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Resume Analytics */}
      {resumes && resumes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Resume Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {stats ? Math.round((stats.interviews / Math.max(stats.totalApplications, 1)) * 100) : 0}%
                </div>
                <div className="text-sm text-gray-600">Average Match Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{stats?.totalApplications || 0}</div>
                <div className="text-sm text-gray-600">Applications Sent</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{stats?.profileViews || 0}</div>
                <div className="text-sm text-gray-600">Profile Views</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
