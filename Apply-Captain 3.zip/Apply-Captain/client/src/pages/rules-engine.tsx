import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLoadingModal } from "@/components/loading-modal";

export default function RulesEngine() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const { show: showLoading, hide: hideLoading } = useLoadingModal();

  // Form state
  const [isEnabled, setIsEnabled] = useState(false);
  const [jobTitles, setJobTitles] = useState("");
  const [excludedKeywords, setExcludedKeywords] = useState("");
  const [preferredLocations, setPreferredLocations] = useState("");
  const [minSalary, setMinSalary] = useState<number>(100000);
  const [workTypes, setWorkTypes] = useState<string[]>(["remote", "hybrid"]);
  const [employmentTypes, setEmploymentTypes] = useState<string[]>(["full-time"]);
  const [experienceLevels, setExperienceLevels] = useState<string[]>(["mid"]);
  const [preferredCompanies, setPreferredCompanies] = useState("");
  const [blacklistedCompanies, setBlacklistedCompanies] = useState("");
  const [dailyLimit, setDailyLimit] = useState<number>(5);
  const [minMatchScore, setMinMatchScore] = useState<number>(80);
  const [reviewMode, setReviewMode] = useState("auto");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: rules, isLoading } = useQuery({
    queryKey: ["/api/rules"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Load existing rules into form
  useEffect(() => {
    if (rules) {
      setIsEnabled((rules as any).isEnabled || false);
      setJobTitles((rules as any).jobTitles?.join('\n') || "");
      setExcludedKeywords((rules as any).excludedKeywords?.join('\n') || "");
      setPreferredLocations((rules as any).preferredLocations?.join(', ') || "");
      setMinSalary((rules as any).minSalary || 100000);
      setWorkTypes((rules as any).workTypes || ["remote", "hybrid"]);
      setEmploymentTypes((rules as any).employmentTypes || ["full-time"]);
      setExperienceLevels((rules as any).experienceLevels || ["mid"]);
      setPreferredCompanies((rules as any).preferredCompanies?.join('\n') || "");
      setBlacklistedCompanies((rules as any).blacklistedCompanies?.join('\n') || "");
      setDailyLimit((rules as any).dailyLimit || 5);
      setMinMatchScore((rules as any).minMatchScore || 80);
      setReviewMode((rules as any).reviewMode || "auto");
    }
  }, [rules]);

  const saveRulesMutation = useMutation({
    mutationFn: async (rulesData: any) => {
      const response = await apiRequest("POST", "/api/rules", rulesData);
      return response.json();
    },
    onSuccess: () => {
      hideLoading();
      queryClient.invalidateQueries({ queryKey: ["/api/rules"] });
      toast({
        title: "Rules saved successfully",
        description: "Your auto-apply preferences have been updated",
      });
    },
    onError: (error) => {
      hideLoading();
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to save rules",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSaveRules = () => {
    showLoading("Saving Rules", "Updating your auto-apply preferences...");
    
    const rulesData = {
      isEnabled,
      jobTitles: jobTitles.split('\n').filter(t => t.trim()),
      excludedKeywords: excludedKeywords.split('\n').filter(k => k.trim()),
      preferredLocations: preferredLocations.split(',').map(l => l.trim()).filter(l => l),
      minSalary,
      workTypes,
      employmentTypes,
      experienceLevels,
      preferredCompanies: preferredCompanies.split('\n').filter(c => c.trim()),
      blacklistedCompanies: blacklistedCompanies.split('\n').filter(c => c.trim()),
      dailyLimit,
      minMatchScore,
      reviewMode,
    };

    saveRulesMutation.mutate(rulesData);
  };

  const toggleWorkType = (type: string) => {
    setWorkTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const toggleEmploymentType = (type: string) => {
    setEmploymentTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const toggleExperienceLevel = (level: string) => {
    setExperienceLevels(prev => 
      prev.includes(level) 
        ? prev.filter(l => l !== level)
        : [...prev, level]
    );
  };

  const handleTestRules = () => {
    toast({
      title: "Test Rules",
      description: "Rules testing functionality will be implemented in the next version",
    });
  };

  const handleResetToDefaults = () => {
    setIsEnabled(false);
    setJobTitles("Frontend Developer\nReact Developer\nSoftware Engineer\nJavaScript Developer");
    setExcludedKeywords("Senior\nLead\nManager\nPrincipal");
    setPreferredLocations("San Francisco, CA; New York, NY; Remote");
    setMinSalary(100000);
    setWorkTypes(["remote", "hybrid"]);
    setEmploymentTypes(["full-time"]);
    setExperienceLevels(["mid"]);
    setPreferredCompanies("Google\nMeta\nApple\nMicrosoft\nNetflix");
    setBlacklistedCompanies("Bad Company Inc\nSketchy Startup\nLow Pay Corp");
    setDailyLimit(5);
    setMinMatchScore(80);
    setReviewMode("auto");
    
    toast({
      title: "Reset to defaults",
      description: "Form has been reset to default values",
    });
  };

  if (authLoading || !isAuthenticated) {
    return null;
  }

  if (isLoading) {
    return (
      <main className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h3 className="text-2xl font-semibold text-gray-900 mb-2">Auto-Apply Rules</h3>
            <p className="text-gray-600">Configure smart rules to automatically find and apply to relevant job listings</p>
          </div>
          <div className="animate-pulse space-y-6">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-64 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h3 className="text-2xl font-semibold text-gray-900 mb-2">Auto-Apply Rules</h3>
          <p className="text-gray-600">Configure smart rules to automatically find and apply to relevant job listings</p>
        </div>

        {/* Auto-Apply Master Toggle */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-semibold text-gray-900">Auto-Apply Mode</h4>
                <p className="text-gray-600 mt-1">When enabled, AutoApply will automatically submit applications that match your rules</p>
              </div>
              <button 
                onClick={() => setIsEnabled(!isEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-wrelik-green focus:ring-offset-2 ${
                  isEnabled ? "bg-wrelik-green" : "bg-gray-200"
                }`}
              >
                <span 
                  className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                    isEnabled ? "translate-x-6" : "translate-x-1"
                  }`} 
                />
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Job Preferences */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Job Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="job-titles">Job Titles/Keywords</Label>
                <Textarea
                  id="job-titles"
                  value={jobTitles}
                  onChange={(e) => setJobTitles(e.target.value)}
                  rows={3}
                  className="mt-2"
                  placeholder="e.g., Frontend Developer, React Developer, Software Engineer"
                />
                <p className="text-xs text-gray-500 mt-1">Enter one job title per line</p>
              </div>

              <div>
                <Label htmlFor="excluded-keywords">Excluded Keywords</Label>
                <Textarea
                  id="excluded-keywords"
                  value={excludedKeywords}
                  onChange={(e) => setExcludedKeywords(e.target.value)}
                  rows={3}
                  className="mt-2"
                  placeholder="e.g., Senior, Lead, Manager"
                />
                <p className="text-xs text-gray-500 mt-1">Jobs containing these keywords will be skipped</p>
              </div>

              <div>
                <Label htmlFor="preferred-locations">Preferred Locations</Label>
                <Input
                  id="preferred-locations"
                  value={preferredLocations}
                  onChange={(e) => setPreferredLocations(e.target.value)}
                  className="mt-2"
                  placeholder="e.g., San Francisco, New York, Remote"
                />
              </div>

              <div>
                <Label htmlFor="salary-range">Minimum Salary</Label>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="text-gray-500">$</span>
                  <Input
                    type="number"
                    value={minSalary}
                    onChange={(e) => setMinSalary(parseInt(e.target.value) || 0)}
                    className="flex-1"
                    placeholder="80000"
                  />
                  <span className="text-gray-500">per year</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Work Preferences */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Work Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label className="text-sm font-medium text-gray-700 mb-3 block">Work Type</Label>
                <div className="space-y-2">
                  {["remote", "hybrid", "onsite"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox
                        id={`work-${type}`}
                        checked={workTypes.includes(type)}
                        onCheckedChange={() => toggleWorkType(type)}
                      />
                      <Label htmlFor={`work-${type}`} className="text-sm text-gray-700 capitalize">
                        {type === "onsite" ? "On-site" : type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-700 mb-3 block">Employment Type</Label>
                <div className="space-y-2">
                  {["full-time", "part-time", "contract"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox
                        id={`employment-${type}`}
                        checked={employmentTypes.includes(type)}
                        onCheckedChange={() => toggleEmploymentType(type)}
                      />
                      <Label htmlFor={`employment-${type}`} className="text-sm text-gray-700 capitalize">
                        {type.replace("-", " ")}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-700 mb-3 block">Experience Level</Label>
                <div className="space-y-2">
                  {["entry", "mid", "senior"].map((level) => (
                    <div key={level} className="flex items-center space-x-2">
                      <Checkbox
                        id={`experience-${level}`}
                        checked={experienceLevels.includes(level)}
                        onCheckedChange={() => toggleExperienceLevel(level)}
                      />
                      <Label htmlFor={`experience-${level}`} className="text-sm text-gray-700 capitalize">
                        {level} Level
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Company Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Company Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="preferred-companies">Preferred Companies</Label>
                <Textarea
                  id="preferred-companies"
                  value={preferredCompanies}
                  onChange={(e) => setPreferredCompanies(e.target.value)}
                  rows={3}
                  className="mt-2"
                  placeholder="e.g., Google, Meta, Apple"
                />
                <p className="text-xs text-gray-500 mt-1">Jobs from these companies will be prioritized</p>
              </div>

              <div>
                <Label htmlFor="blacklisted-companies">Blacklisted Companies</Label>
                <Textarea
                  id="blacklisted-companies"
                  value={blacklistedCompanies}
                  onChange={(e) => setBlacklistedCompanies(e.target.value)}
                  rows={3}
                  className="mt-2"
                  placeholder="Companies to avoid"
                />
                <p className="text-xs text-gray-500 mt-1">Jobs from these companies will be automatically skipped</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Application Limits */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Application Limits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="daily-limit">Daily Application Limit</Label>
                <Input
                  type="number"
                  id="daily-limit"
                  value={dailyLimit}
                  onChange={(e) => setDailyLimit(parseInt(e.target.value) || 1)}
                  className="mt-2"
                  min="1"
                  max="50"
                />
                <p className="text-xs text-gray-500 mt-1">Maximum applications per day</p>
              </div>

              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">Minimum Match Score</Label>
                <div className="flex items-center space-x-2">
                  <Slider
                    value={[minMatchScore]}
                    onValueChange={(value) => setMinMatchScore(value[0])}
                    min={50}
                    max={100}
                    step={5}
                    className="flex-1"
                  />
                  <span className="text-sm font-medium text-gray-900 w-12">{minMatchScore}%</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Only apply to jobs above this match threshold</p>
              </div>

              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-3">Review Mode</Label>
                <RadioGroup value={reviewMode} onValueChange={setReviewMode}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="auto" id="review-auto" />
                    <Label htmlFor="review-auto" className="text-sm text-gray-700">Fully Automatic</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="review" id="review-manual" />
                    <Label htmlFor="review-manual" className="text-sm text-gray-700">Review Before Send</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button 
              variant="link" 
              onClick={handleTestRules}
              className="text-wrelik-green hover:text-green-700"
            >
              <i className="fas fa-flask mr-2"></i>
              Test Rules
            </Button>
            <Button 
              variant="link" 
              onClick={handleResetToDefaults}
              className="text-gray-600 hover:text-gray-700"
            >
              Reset to Defaults
            </Button>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              Cancel
            </Button>
            <Button 
              onClick={handleSaveRules}
              disabled={saveRulesMutation.isPending}
              className="bg-wrelik-green hover:bg-green-600"
            >
              {saveRulesMutation.isPending ? "Saving..." : "Save Rules"}
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
}
