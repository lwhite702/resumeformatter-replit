import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLoadingModal } from "@/components/loading-modal";

export default function Settings() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const { show: showLoading, hide: hideLoading } = useLoadingModal();

  // Form state
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(false);
  const [weeklyReport, setWeeklyReport] = useState(true);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Load user data into form
  useEffect(() => {
    if (user) {
      setFirstName(user.firstName || "");
      setLastName(user.lastName || "");
      setEmail(user.email || "");
    }
  }, [user]);

  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Load settings into form
  useEffect(() => {
    if (settings) {
      setEmailNotifications(settings.emailNotifications ?? true);
      setPushNotifications(settings.pushNotifications ?? false);
      setWeeklyReport(settings.weeklyReport ?? true);
    }
  }, [settings]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (settingsData: any) => {
      const response = await apiRequest("POST", "/api/settings", settingsData);
      return response.json();
    },
    onSuccess: () => {
      hideLoading();
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings saved successfully",
        description: "Your preferences have been updated",
      });
    },
    onError: (error) => {
      hideLoading();
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to save settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSaveSettings = () => {
    showLoading("Saving Settings", "Updating your account preferences...");
    
    const settingsData = {
      emailNotifications,
      pushNotifications,
      weeklyReport,
      resumeFormatterConnected: true, // Assume connected for demo
      prepPairConnected: true, // Assume connected for demo
      emailParsingConnected: false,
      subscriptionStatus: "pro",
    };

    saveSettingsMutation.mutate(settingsData);
  };

  const handleManageIntegration = async (service: string) => {
    if (service === "ResumeFormatter.io") {
      try {
        const response = await apiRequest("POST", "/api/resumes/sync", {});
        const data = await response.json();
        toast({
          title: "Resumes synced",
          description: `Synced ${data.synced} resumes from ResumeFormatter.io`,
        });
      } catch (error) {
        toast({
          title: "Sync failed",
          description: "Failed to sync resumes",
          variant: "destructive",
        });
      }
    } else if (service === "PrepPair.me") {
      try {
        const response = await apiRequest("POST", "/api/integrations/prep-pair/sync", {});
        const data = await response.json();
        toast({
          title: "Applications synced",
          description: `Synced ${data.synced} applications to PrepPair.me`,
        });
      } catch (error) {
        toast({
          title: "Sync failed", 
          description: "Failed to sync applications",
          variant: "destructive",
        });
      }
    }
  };

  const handleConnectEmail = () => {
    toast({
      title: "Connect Email",
      description: "Email parsing integration will be implemented in the next version",
    });
  };

  const handleManageBilling = () => {
    toast({
      title: "Manage Billing",
      description: "Billing management will be implemented in the next version",
    });
  };

  const handleExportData = () => {
    toast({
      title: "Export started",
      description: "Your data export will be ready shortly",
    });
  };

  const handleDeleteAccount = () => {
    toast({
      title: "Account deletion",
      description: "Please contact support to delete your account",
      variant: "destructive",
    });
  };

  const createToggle = (
    enabled: boolean, 
    setEnabled: (value: boolean) => void
  ) => (
    <button 
      onClick={() => setEnabled(!enabled)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-wrelik-green focus:ring-offset-2 ${
        enabled ? "bg-wrelik-green" : "bg-gray-200"
      }`}
    >
      <span 
        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
          enabled ? "translate-x-6" : "translate-x-1"
        }`} 
      />
    </button>
  );

  if (authLoading || !isAuthenticated) {
    return null;
  }

  if (settingsLoading) {
    return (
      <main className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h3 className="text-2xl font-semibold text-gray-900 mb-2">Settings</h3>
            <p className="text-gray-600">Manage your account, integrations, and preferences</p>
          </div>
          <div className="animate-pulse space-y-6">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-48 bg-gray-200 rounded-lg"></div>
            <div className="h-64 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h3 className="text-2xl font-semibold text-gray-900 mb-2">Settings</h3>
          <p className="text-gray-600">Manage your account, integrations, and preferences</p>
        </div>

        {/* Account Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="first-name">First Name</Label>
                <Input
                  id="first-name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="last-name">Last Name</Label>
                <Input
                  id="last-name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="mt-2"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  className="mt-2"
                  readOnly
                  disabled
                />
                <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Integrations */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Connected Services</CardTitle>
          </CardHeader>
          <CardContent>
            {/* ResumeFormatter.io */}
            <div className="flex items-center justify-between py-4 border-b border-gray-200">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                  <i className="fas fa-file-alt text-blue-600"></i>
                </div>
                <div>
                  <h5 className="font-medium text-gray-900">ResumeFormatter.io</h5>
                  <p className="text-sm text-gray-600">Resume management and optimization</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Badge className="bg-emerald-100 text-emerald-800">
                  Connected
                </Badge>
                <Button 
                  variant="link" 
                  size="sm"
                  onClick={() => handleManageIntegration("ResumeFormatter.io")}
                  className="text-wrelik-green hover:text-green-700"
                >
                  Manage
                </Button>
              </div>
            </div>

            {/* PrepPair.me */}
            <div className="flex items-center justify-between py-4 border-b border-gray-200">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                  <i className="fas fa-chart-line text-purple-600"></i>
                </div>
                <div>
                  <h5 className="font-medium text-gray-900">PrepPair.me</h5>
                  <p className="text-sm text-gray-600">Job application tracking and analytics</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Badge className="bg-emerald-100 text-emerald-800">
                  Connected
                </Badge>
                <Button 
                  variant="link" 
                  size="sm"
                  onClick={() => handleManageIntegration("PrepPair.me")}
                  className="text-wrelik-green hover:text-green-700"
                >
                  Manage
                </Button>
              </div>
            </div>

            {/* Gmail/Email */}
            <div className="flex items-center justify-between py-4">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                  <i className="fas fa-envelope text-red-600"></i>
                </div>
                <div>
                  <h5 className="font-medium text-gray-900">Email Parsing</h5>
                  <p className="text-sm text-gray-600">Auto-detect job opportunities from emails</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                  Not Connected
                </Badge>
                <Button 
                  size="sm"
                  onClick={handleConnectEmail}
                  className="bg-wrelik-green hover:bg-green-600"
                >
                  Connect
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Subscription</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-medium text-gray-900">Wrelik Pro Plan</h5>
                <p className="text-sm text-gray-600">Unlimited auto-applications • Next billing: Jan 15, 2024</p>
              </div>
              <div className="flex items-center space-x-3">
                <Badge className="bg-emerald-100 text-emerald-800">
                  Active
                </Badge>
                <Button 
                  variant="link" 
                  size="sm"
                  onClick={handleManageBilling}
                  className="text-wrelik-green hover:text-green-700"
                >
                  Manage Billing
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Preferences */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-medium text-gray-900">Email Notifications</h5>
                  <p className="text-sm text-gray-600">Receive daily job suggestions and application updates</p>
                </div>
                {createToggle(emailNotifications, setEmailNotifications)}
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-medium text-gray-900">Push Notifications</h5>
                  <p className="text-sm text-gray-600">Get notified about application responses and new opportunities</p>
                </div>
                {createToggle(pushNotifications, setPushNotifications)}
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-medium text-gray-900">Weekly Summary</h5>
                  <p className="text-sm text-gray-600">Receive weekly reports on application performance</p>
                </div>
                {createToggle(weeklyReport, setWeeklyReport)}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="text-red-900">Danger Zone</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-red-100">
                <div>
                  <h5 className="font-medium text-gray-900">Export Data</h5>
                  <p className="text-sm text-gray-600">Download all your application data and history</p>
                </div>
                <Button variant="outline" onClick={handleExportData}>
                  Export
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-medium text-red-900">Delete Account</h5>
                  <p className="text-sm text-gray-600">Permanently delete your account and all associated data</p>
                </div>
                <Button 
                  variant="destructive"
                  onClick={handleDeleteAccount}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Delete Account
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Actions */}
        <div className="flex justify-end mt-6">
          <Button 
            onClick={handleSaveSettings}
            disabled={saveSettingsMutation.isPending}
            className="bg-wrelik-green hover:bg-green-600"
          >
            {saveSettingsMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </div>
    </main>
  );
}
