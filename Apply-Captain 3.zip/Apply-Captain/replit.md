# AutoApply by Wrelik - Replit.md

## Overview

AutoApply is an AI-powered job application automation platform that helps users automatically discover, analyze, and apply to job postings. The system intelligently matches job requirements with user resumes, generates personalized cover letters using OpenAI, and manages the entire application lifecycle through a comprehensive dashboard interface.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side navigation
- **State Management**: TanStack Query for server state, Zustand for local UI state
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom Wrelik brand colors
- **Build Tool**: Vite with custom configuration for client/server separation

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **Authentication**: Replit Auth with OpenID Connect integration
- **Session Management**: Express sessions with PostgreSQL storage
- **API Design**: RESTful endpoints with comprehensive error handling

### Database Architecture
- **Primary Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Migration Strategy**: Drizzle Kit for schema management
- **Connection**: Connection pooling with @neondatabase/serverless

## Key Components

### Authentication System
- **Provider**: Replit Auth (OpenID Connect)
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **User Management**: Automatic user creation/update on authentication
- **Security**: HTTP-only cookies with secure flags

### Job Management System
- **Job Discovery**: URL-based job posting analysis and manual entry
- **AI Analysis**: OpenAI integration for job requirement extraction
- **Matching Engine**: Skills-based matching algorithm with scoring
- **Application Tracking**: Complete lifecycle management from discovery to follow-up

### Resume Management
- **Multi-Resume Support**: Users can maintain multiple resume versions
- **Skills Extraction**: Structured skill data for matching algorithms
- **Best-Fit Selection**: Automatic selection of optimal resume per job

### Auto-Apply Rules Engine
- **Configurable Filters**: Job title, salary, location, work type preferences
- **Company Preferences**: Preferred and blacklisted company management
- **Daily Limits**: Rate limiting for application submissions
- **Review Modes**: Manual review vs automatic application

### AI Services
- **Cover Letter Generation**: OpenAI GPT-4o for personalized cover letters
- **Job Analysis**: Automatic extraction of requirements, salary, and metadata
- **Match Scoring**: AI-powered compatibility scoring between jobs and resumes

## Data Flow

### Job Application Workflow
1. **Discovery**: User inputs job URL or description
2. **Analysis**: AI extracts job details and requirements
3. **Matching**: System calculates compatibility with user's resumes
4. **Review**: User reviews AI-generated cover letter and job match
5. **Application**: System applies based on user rules or manual approval
6. **Tracking**: Application status and follow-up management

### Authentication Flow
1. **Login Request**: User clicks login, redirected to Replit Auth
2. **OAuth Flow**: Standard OpenID Connect authentication
3. **Token Exchange**: Server exchanges code for user tokens
4. **Session Creation**: Persistent session stored in PostgreSQL
5. **User Sync**: User profile synchronized with local database

### Data Synchronization
- **Real-time Updates**: TanStack Query provides optimistic updates
- **Error Recovery**: Comprehensive error handling with user feedback
- **State Persistence**: Critical state maintained in database

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit Auth service
- **AI Services**: OpenAI API for GPT-4o model access
- **Hosting**: Replit deployment platform

### Development Tools
- **Package Manager**: npm with lockfile version 3
- **TypeScript**: Strict type checking with path mapping
- **Linting**: Built-in TypeScript compiler checks
- **Development**: Hot reload via Vite development server

### Third-Party Libraries
- **UI Components**: Comprehensive Radix UI component library
- **Form Management**: React Hook Form with Zod validation
- **Date Handling**: date-fns for date manipulation
- **Utilities**: clsx, tailwind-merge for styling utilities

## Deployment Strategy

### Development Environment
- **Runtime**: Node.js 20 with PostgreSQL 16
- **Development Server**: Vite dev server with HMR
- **Database**: Automatically provisioned Neon PostgreSQL
- **Port Configuration**: Frontend on 5000, mapped to external port 80

### Production Build
- **Client Build**: Vite production build to dist/public
- **Server Build**: esbuild bundle for Node.js ESM format
- **Static Assets**: Client assets served from server/public
- **Process Management**: Single Node.js process serving both API and static files

### Environment Configuration
- **Database**: DATABASE_URL environment variable required
- **Authentication**: REPLIT_DOMAINS and SESSION_SECRET required
- **AI Services**: OPENAI_API_KEY required for cover letter generation
- **Sessions**: Secure cookie configuration for production

## Changelog
- June 17, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.