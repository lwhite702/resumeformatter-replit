import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import { cachedPosts } from '../shared/schema.js';
import type { InsertCachedPost } from '../shared/schema.js';
import * as dotenv from 'dotenv';
import fetch from 'node-fetch';
import https from 'https';

const { Pool } = pg;

// Load environment variables
dotenv.config();

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt?: string;
  content?: string;
  date: string;
}

interface BlogAPIResponse {
  posts: BlogPost[];
  total: number;
  success: boolean;
}

/**
 * Universal blog cache service that supports multiple CMS platforms
 * Supports WordPress, custom APIs, RSS feeds, and other blog formats
 */
class BlogCacheService {
  private pool: InstanceType<typeof Pool>;
  private db: ReturnType<typeof drizzle>;
  private readonly endpoints = {
    wordpress: 'https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date',
    graphql: 'https://wrelikbrands.com/graphql',
    customApi: 'https://wrelikbrands.com/api/blog/posts',
    apiV1: 'https://wrelikbrands.com/api/v1/posts',
    apiV2: 'https://wrelikbrands.com/api/v2/posts',
    blogApi: 'https://wrelikbrands.com/blog/api/posts',
    rss: 'https://wrelikbrands.com/feed',
    rssBlog: 'https://wrelikbrands.com/blog/feed',
    atom: 'https://wrelikbrands.com/feed/atom',
    jsonFeed: 'https://wrelikbrands.com/feed.json'
  };

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }

    this.pool = new Pool({ 
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
    });
    this.db = drizzle(this.pool);
  }

  /**
   * Test multiple blog endpoints to find available content source
   */
  private async detectBlogPlatform(): Promise<{ platform: string; endpoint: string } | null> {
    const agent = new https.Agent({ rejectUnauthorized: false });
    
    for (const [platform, endpoint] of Object.entries(this.endpoints)) {
      try {
        console.log(`Testing ${platform} endpoint: ${endpoint}`);
        
        let fetchOptions: any = {
          headers: {
            'User-Agent': 'WrelikBrands-Blog-Cache/1.0',
            'Accept': 'application/json, application/rss+xml, text/xml',
          },
          agent: agent,
          timeout: 10000
        };

        // GraphQL requires POST with query
        if (platform === 'graphql') {
          fetchOptions.method = 'POST';
          fetchOptions.headers['Content-Type'] = 'application/json';
          fetchOptions.body = JSON.stringify({
            query: `{
              posts(first: 10) {
                edges {
                  node {
                    id
                    title
                    slug
                    excerpt
                    content
                    date
                  }
                }
              }
            }`
          });
        }
        
        const response = await fetch(endpoint, fetchOptions);

        if (response.ok) {
          console.log(`✓ Found working endpoint: ${platform} (${response.status})`);
          return { platform, endpoint };
        }
        
        console.log(`✗ ${platform}: ${response.status} ${response.statusText}`);
      } catch (error) {
        console.log(`✗ ${platform}: Connection failed`);
      }
    }
    
    return null;
  }

  /**
   * Parse WordPress API response
   */
  private parseWordPressResponse(data: any[]): BlogPost[] {
    return data.map(post => ({
      id: post.id,
      title: post.title?.rendered || post.title,
      slug: post.slug,
      excerpt: post.excerpt?.rendered || '',
      content: post.content?.rendered || '',
      date: post.date
    }));
  }

  /**
   * Parse GraphQL API response
   */
  private parseGraphQLResponse(data: any): BlogPost[] {
    const posts = data?.data?.posts?.edges || data?.posts?.edges || [];
    return posts.map((edge: any, index: number) => {
      const post = edge.node || edge;
      return {
        id: post.id || index + 1,
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt || '',
        content: post.content || '',
        date: post.date || new Date().toISOString()
      };
    });
  }

  /**
   * Parse custom API response
   */
  private parseCustomAPIResponse(data: any): BlogPost[] {
    if (data.posts && Array.isArray(data.posts)) {
      return data.posts;
    }
    if (Array.isArray(data)) {
      return data;
    }
    return [];
  }

  /**
   * Parse RSS feed (basic XML parsing)
   */
  private parseRSSResponse(xmlText: string): BlogPost[] {
    const posts: BlogPost[] = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    let id = 1;

    while ((match = itemRegex.exec(xmlText)) !== null) {
      const item = match[1];
      const title = this.extractXMLValue(item, 'title');
      const link = this.extractXMLValue(item, 'link');
      const description = this.extractXMLValue(item, 'description');
      const pubDate = this.extractXMLValue(item, 'pubDate');
      
      if (title && link) {
        posts.push({
          id: id++,
          title,
          slug: this.generateSlugFromUrl(link),
          excerpt: description || '',
          content: description || '',
          date: pubDate || new Date().toISOString()
        });
      }
    }

    return posts.slice(0, 10); // Limit to 10 posts
  }

  /**
   * Extract value from XML string
   */
  private extractXMLValue(xml: string, tag: string): string {
    const regex = new RegExp(`<${tag}[^>]*>(.*?)<\/${tag}>`, 's');
    const match = xml.match(regex);
    return match ? match[1].trim() : '';
  }

  /**
   * Generate slug from URL
   */
  private generateSlugFromUrl(url: string): string {
    return url.split('/').pop()?.replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'post';
  }

  /**
   * Fetch blog posts from detected platform
   */
  private async fetchBlogPosts(): Promise<BlogPost[]> {
    const detection = await this.detectBlogPlatform();
    
    if (!detection) {
      throw new Error('No accessible blog endpoints found');
    }

    const agent = new https.Agent({ rejectUnauthorized: false });
    const response = await fetch(detection.endpoint, {
      headers: {
        'User-Agent': 'WrelikBrands-Blog-Cache/1.0',
        'Accept': 'application/json, application/rss+xml, text/xml',
      },
      agent: agent
    } as any);

    if (!response.ok) {
      throw new Error(`Failed to fetch from ${detection.platform}: ${response.status}`);
    }

    const contentType = response.headers.get('content-type') || '';
    
    if (contentType.includes('json')) {
      const data = await response.json();
      
      if (detection.platform === 'wordpress') {
        return this.parseWordPressResponse(data as any[]);
      } else if (detection.platform === 'graphql') {
        return this.parseGraphQLResponse(data);
      } else {
        return this.parseCustomAPIResponse(data);
      }
    } else if (contentType.includes('xml') || contentType.includes('rss')) {
      const xmlText = await response.text();
      return this.parseRSSResponse(xmlText);
    }

    throw new Error(`Unsupported content type: ${contentType}`);
  }

  /**
   * Clean HTML content
   */
  private cleanHtmlContent(html: string): string {
    return html
      .replace(/<[^>]*>/g, '') // Strip HTML tags
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Transform blog post to database format
   */
  private transformPost(blogPost: BlogPost): InsertCachedPost {
    return {
      wpId: blogPost.id,
      title: this.cleanHtmlContent(blogPost.title),
      slug: blogPost.slug,
      excerpt: blogPost.excerpt ? this.cleanHtmlContent(blogPost.excerpt) : null,
      content: blogPost.content ? this.cleanHtmlContent(blogPost.content) : null,
      publishedAt: new Date(blogPost.date),
    };
  }

  /**
   * Upsert blog post to database
   */
  private async upsertPost(post: InsertCachedPost): Promise<void> {
    try {
      const existing = await this.db
        .select()
        .from(cachedPosts)
        .where(eq(cachedPosts.wpId, post.wpId))
        .limit(1);

      if (existing.length > 0) {
        await this.db
          .update(cachedPosts)
          .set({
            title: post.title,
            slug: post.slug,
            excerpt: post.excerpt,
            content: post.content,
            publishedAt: post.publishedAt,
            updatedAt: new Date(),
          })
          .where(eq(cachedPosts.wpId, post.wpId));
      } else {
        await this.db
          .insert(cachedPosts)
          .values(post);
      }
    } catch (error) {
      console.error(`Failed to upsert post ${post.wpId}:`, error);
      throw error;
    }
  }

  /**
   * Main caching function
   */
  async cacheBlogPosts(): Promise<number> {
    let cachedCount = 0;
    
    try {
      console.log('🚀 Starting blog posts cache process...');
      console.log('🔍 Detecting available blog platform...');
      
      const blogPosts = await this.fetchBlogPosts();
      console.log(`📥 Fetched ${blogPosts.length} posts from blog API`);

      for (const blogPost of blogPosts) {
        const transformedPost = this.transformPost(blogPost);
        await this.upsertPost(transformedPost);
        cachedCount++;
      }

      console.log(`✅ Cached ${cachedCount} posts from blog.`);
      return cachedCount;

    } catch (error) {
      console.error('❌ Blog caching failed:', error);
      console.log('💡 Suggestions:');
      console.log('   - Verify blog platform and API endpoints');
      console.log('   - Check if blog content exists on the website');
      console.log('   - Contact site administrator for correct API access');
      console.log('   - Consider alternative content sources (RSS, sitemap)');
      throw error;
    }
  }

  /**
   * Get recent cached posts
   */
  async getRecentPosts(limit: number = 5) {
    try {
      const posts = await this.db
        .select()
        .from(cachedPosts)
        .orderBy(cachedPosts.publishedAt)
        .limit(limit);
      
      return posts;
    } catch (error) {
      console.error('Failed to fetch recent posts:', error);
      throw error;
    }
  }

  /**
   * Close database connection
   */
  async close(): Promise<void> {
    await this.pool.end();
  }
}

// Main execution function
async function main() {
  const cacheService = new BlogCacheService();
  
  try {
    await cacheService.cacheBlogPosts();
  } catch (error) {
    console.error('Cache process failed:', error);
    process.exit(1);
  } finally {
    await cacheService.close();
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { BlogCacheService };