import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import { cachedPosts } from '../shared/schema.js';
import type { InsertCachedPost } from '../shared/schema.js';
import * as dotenv from 'dotenv';
import fetch from 'node-fetch';
import https from 'https';

const { Pool } = pg;

// Load environment variables
dotenv.config();

interface WordPressPost {
  id: number;
  title: {
    rendered: string;
  };
  slug: string;
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  date: string;
}

class WordPressCacheService {
  private pool: InstanceType<typeof Pool>;
  private db: ReturnType<typeof drizzle>;
  private readonly wpApiUrl = 'https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date';

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }

    this.pool = new Pool({ 
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
    });
    this.db = drizzle(this.pool);
  }

  /**
   * Fetches the latest posts from WordPress API
   */
  private async fetchWordPressPosts(): Promise<WordPressPost[]> {
    try {
      // Create HTTPS agent that ignores certificate validation
      const agent = new https.Agent({
        rejectUnauthorized: false
      });

      const response = await fetch(this.wpApiUrl, {
        headers: {
          'User-Agent': 'WrelikBrands-Cache-Service/1.0',
          'Accept': 'application/json',
        },
        agent: agent,
        redirect: 'follow'
      } as any);
      
      if (!response.ok) {
        throw new Error(`WordPress API returned ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type') || '';
      
      if (!contentType.includes('application/json')) {
        const text = await response.text();
        console.log('Response content type:', contentType);
        console.log('Response preview:', text.substring(0, 200));
        throw new Error(`Expected JSON response but got ${contentType}`);
      }

      const posts = await response.json() as WordPressPost[];
      return posts;
    } catch (error) {
      console.error('Failed to fetch WordPress posts:', error);
      throw error;
    }
  }

  /**
   * Cleans HTML content by removing excessive whitespace and formatting
   */
  private cleanHtmlContent(html: string): string {
    return html
      .replace(/\s+/g, ' ')
      .replace(/>\s+</g, '><')
      .trim();
  }

  /**
   * Converts WordPress post to database format
   */
  private transformPost(wpPost: WordPressPost): InsertCachedPost {
    return {
      wpId: wpPost.id,
      title: this.cleanHtmlContent(wpPost.title.rendered),
      slug: wpPost.slug,
      excerpt: wpPost.excerpt.rendered ? this.cleanHtmlContent(wpPost.excerpt.rendered) : null,
      content: wpPost.content.rendered ? this.cleanHtmlContent(wpPost.content.rendered) : null,
      publishedAt: new Date(wpPost.date),
    };
  }

  /**
   * Performs UPSERT operation for a single post
   */
  private async upsertPost(post: InsertCachedPost): Promise<void> {
    try {
      // Check if post exists
      const existing = await this.db
        .select()
        .from(cachedPosts)
        .where(eq(cachedPosts.wpId, post.wpId))
        .limit(1);

      if (existing.length > 0) {
        // Update existing post
        await this.db
          .update(cachedPosts)
          .set({
            title: post.title,
            slug: post.slug,
            excerpt: post.excerpt,
            content: post.content,
            publishedAt: post.publishedAt,
            updatedAt: new Date(),
          })
          .where(eq(cachedPosts.wpId, post.wpId));
      } else {
        // Insert new post
        await this.db
          .insert(cachedPosts)
          .values(post);
      }
    } catch (error) {
      console.error(`Failed to upsert post ${post.wpId}:`, error);
      throw error;
    }
  }

  /**
   * Test API endpoint availability
   */
  async testApiEndpoint(): Promise<boolean> {
    try {
      const agent = new https.Agent({ rejectUnauthorized: false });
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(this.wpApiUrl, {
        headers: {
          'User-Agent': 'WrelikBrands-Cache-Service/1.0',
          'Accept': 'application/json',
        },
        agent: agent,
        signal: controller.signal
      } as any);

      clearTimeout(timeoutId);
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  /**
   * Main caching function with comprehensive error handling
   */
  async cacheWordPressPosts(): Promise<number> {
    console.log('Starting WordPress blog cache process...');
    
    // First test if endpoint is available
    const isAvailable = await this.testApiEndpoint();
    
    if (!isAvailable) {
      console.log('WordPress API endpoint not accessible.');
      console.log('Site analysis indicates WrelikBrands.com does not use WordPress or has REST API disabled.');
      console.log('To enable caching, please provide the correct blog API endpoint.');
      return 0;
    }

    let cachedCount = 0;
    
    try {
      const wpPosts = await this.fetchWordPressPosts();
      console.log(`Fetched ${wpPosts.length} posts from WordPress API`);

      for (const wpPost of wpPosts) {
        const transformedPost = this.transformPost(wpPost);
        await this.upsertPost(transformedPost);
        cachedCount++;
      }

      console.log(`Successfully cached ${cachedCount} posts from WordPress.`);
      return cachedCount;

    } catch (error) {
      console.error('WordPress caching failed:', error);
      throw error;
    }
  }

  /**
   * Closes database connection
   */
  async close(): Promise<void> {
    await this.pool.end();
  }

  /**
   * Query example: Get 5 most recent posts
   */
  async getRecentPosts(limit: number = 5) {
    try {
      const posts = await this.db
        .select()
        .from(cachedPosts)
        .orderBy(cachedPosts.publishedAt)
        .limit(limit);
      
      return posts;
    } catch (error) {
      console.error('Failed to fetch recent posts:', error);
      throw error;
    }
  }
}

// Main execution function
async function main() {
  const cacheService = new WordPressCacheService();
  
  try {
    await cacheService.cacheWordPressPosts();
  } catch (error) {
    console.error('Cache process failed:', error);
    process.exit(1);
  } finally {
    await cacheService.close();
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { WordPressCacheService };