import fetch from 'node-fetch';
import https from 'https';
import { db } from './db';
import { cachedPosts } from '../shared/schema';
import type { InsertCachedPost } from '../shared/schema';

interface WordPressPost {
  id: number;
  title: {
    rendered: string;
  };
  slug: string;
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  date: string;
}

async function directCacheWordPress() {
  console.log('🚀 Starting direct WordPress cache...');
  
  const httpsAgent = new https.Agent({ rejectUnauthorized: false });
  const apiUrl = 'https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date';
  
  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'WrelikBrands-DirectCache/1.0',
        'Accept': 'application/json'
      },
      agent: httpsAgent
    } as any);
    
    if (!response.ok) {
      console.log(`❌ API returned ${response.status}: ${response.statusText}`);
      return;
    }
    
    const posts = await response.json() as WordPressPost[];
    console.log(`📝 Retrieved ${posts.length} posts from WordPress API`);
    
    let cachedCount = 0;
    
    for (const post of posts) {
      const cachedPost: InsertCachedPost = {
        wpId: post.id,
        title: post.title.rendered,
        slug: post.slug,
        excerpt: post.excerpt?.rendered?.replace(/<[^>]*>/g, '') || '',
        content: post.content?.rendered || '',
        publishedAt: new Date(post.date),
        cachedAt: new Date()
      };
      
      // Upsert the post
      await db.insert(cachedPosts)
        .values(cachedPost)
        .onConflictDoUpdate({
          target: cachedPosts.wpId,
          set: {
            title: cachedPost.title,
            slug: cachedPost.slug,
            excerpt: cachedPost.excerpt,
            content: cachedPost.content,
            publishedAt: cachedPost.publishedAt,
            cachedAt: cachedPost.cachedAt
          }
        });
      
      cachedCount++;
      console.log(`✓ Cached: ${post.title.rendered}`);
    }
    
    console.log(`🎉 Successfully cached ${cachedCount} WordPress posts`);
    
    // Display recent posts
    const recentPosts = await db.select({
      id: cachedPosts.id,
      title: cachedPosts.title,
      slug: cachedPosts.slug,
      publishedAt: cachedPosts.publishedAt
    })
    .from(cachedPosts)
    .orderBy(cachedPosts.publishedAt)
    .limit(5);
    
    console.log('\n📋 Recent cached posts:');
    recentPosts.forEach(post => {
      console.log(`  - ${post.title} (${post.publishedAt.toDateString()})`);
    });
    
  } catch (error) {
    console.error('❌ Cache process failed:', error);
  }
}

directCacheWordPress();