import fetch from 'node-fetch';
import https from 'https';

// Comprehensive final test of all possible WrelikBrands blog endpoints
const testEndpoints = [
  // Primary domain variations
  'https://wrelikbrands.com/wp-json/wp/v2/posts',
  'https://www.wrelikbrands.com/wp-json/wp/v2/posts',
  'https://wrelik.com/wp-json/wp/v2/posts',
  'https://www.wrelik.com/wp-json/wp/v2/posts',
  'https://blog.wrelikbrands.com/wp-json/wp/v2/posts',
  'https://blog.wrelik.com/wp-json/wp/v2/posts',
  
  // GraphQL endpoints
  'https://wrelikbrands.com/graphql',
  'https://wrelik.com/graphql',
  'https://blog.wrelikbrands.com/graphql',
  
  // Custom API endpoints
  'https://wrelikbrands.com/api/posts',
  'https://wrelik.com/api/posts',
  'https://wrelikbrands.com/api/blog',
  
  // RSS/XML feeds
  'https://wrelikbrands.com/feed',
  'https://wrelik.com/feed',
  'https://blog.wrelikbrands.com/feed',
  
  // Alternative blog paths
  'https://wrelikbrands.com/blog/wp-json/wp/v2/posts',
  'https://wrelik.com/blog/wp-json/wp/v2/posts'
];

async function testAllEndpoints() {
  console.log('Final comprehensive test of WrelikBrands blog endpoints...');
  
  const agent = new https.Agent({ rejectUnauthorized: false });
  const workingEndpoints: string[] = [];
  
  for (const endpoint of testEndpoints) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);
      
      const isGraphQL = endpoint.includes('graphql');
      const response = await fetch(endpoint, {
        method: isGraphQL ? 'POST' : 'GET',
        headers: {
          'User-Agent': 'WrelikBrands-Final-Test/1.0',
          'Accept': 'application/json, text/xml, application/rss+xml',
          ...(isGraphQL && { 'Content-Type': 'application/json' })
        },
        ...(isGraphQL && {
          body: JSON.stringify({
            query: '{ posts(first: 1) { edges { node { id title } } } }'
          })
        }),
        agent: agent,
        signal: controller.signal
      } as any);
      
      clearTimeout(timeoutId);
      
      const contentType = response.headers.get('content-type') || '';
      
      if (response.ok) {
        if (contentType.includes('json') || contentType.includes('xml') || contentType.includes('rss')) {
          workingEndpoints.push(endpoint);
          console.log(`✓ FOUND: ${endpoint} (${response.status}) - ${contentType}`);
          
          // Get sample content
          const content = await response.text();
          console.log(`  Sample: ${content.substring(0, 100)}...`);
        } else {
          console.log(`✗ ${endpoint} - Returns HTML (${response.status})`);
        }
      } else {
        console.log(`✗ ${endpoint} - ${response.status} ${response.statusText}`);
      }
      
    } catch (error: any) {
      console.log(`✗ ${endpoint} - ${error.name}: ${error.message}`);
    }
  }
  
  console.log(`\nFinal Results:`);
  console.log(`- Tested ${testEndpoints.length} potential blog endpoints`);
  console.log(`- Found ${workingEndpoints.length} accessible endpoints`);
  
  if (workingEndpoints.length === 0) {
    console.log('\nConclusion: WrelikBrands.com does not have accessible blog content via standard endpoints.');
    console.log('The caching system is ready but requires the correct blog API endpoint to function.');
  } else {
    console.log('\nWorking endpoints found:');
    workingEndpoints.forEach(endpoint => console.log(`  - ${endpoint}`));
  }
}

testAllEndpoints();