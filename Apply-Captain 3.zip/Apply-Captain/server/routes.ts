import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertJobSchema, 
  insertApplicationSchema, 
  insertAutoApplyRulesSchema, 
  insertUserSettingsSchema, 
  insertFeatureFlagSchema,
  insertBillingPlanSchema,
  insertAdminLogSchema,
  insertKnowledgeDocSchema,
  cachedPosts 
} from "@shared/schema";
import { jobMatcher } from "./services/jobMatcher";
import { generateCoverLetter } from "./services/openai";
import { resumeFormatterService } from "./services/resumeFormatter";
import { prepPairService } from "./services/prepPair";
import { legalContentService } from "./services/legalContentService";
import { db } from "./db";
import { desc, eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getApplicationStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Job suggestions
  app.get('/api/jobs/suggestions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobs = await storage.getJobsByUser(userId);
      
      // Filter for high-match, undiscovered jobs as suggestions
      const suggestions = jobs
        .filter(job => job.status === 'discovered' && (job.matchScore || 0) >= 80)
        .slice(0, 5);
      
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching job suggestions:", error);
      res.status(500).json({ message: "Failed to fetch suggestions" });
    }
  });

  // Analyze job
  app.post('/api/jobs/analyze', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { url, description } = req.body;

      if (!url && !description) {
        return res.status(400).json({ message: "Job URL or description is required" });
      }

      // Get user's resumes for matching
      const resumes = await storage.getResumesByUser(userId);
      
      // Analyze job and calculate match score
      const jobAnalysis = await jobMatcher.analyzeJob(url, description, resumes);
      
      // Save job to database
      const job = await storage.createJob({
        userId,
        ...jobAnalysis,
        status: 'discovered',
      });

      res.json(job);
    } catch (error) {
      console.error("Error analyzing job:", error);
      res.status(500).json({ message: "Failed to analyze job" });
    }
  });

  // Generate cover letter
  app.post('/api/jobs/:id/cover-letter', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.id);
      
      const job = await storage.getJobById(jobId);
      if (!job || job.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      const resumes = await storage.getResumesByUser(userId);
      const bestResume = resumes[0]; // Assume first is best match

      const coverLetter = await generateCoverLetter(job, bestResume);
      
      res.json({ coverLetter, resume: bestResume });
    } catch (error) {
      console.error("Error generating cover letter:", error);
      res.status(500).json({ message: "Failed to generate cover letter" });
    }
  });

  // Submit application
  app.post('/api/jobs/:id/apply', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.id);
      const { coverLetter, resumeUsed } = req.body;
      
      const job = await storage.getJobById(jobId);
      if (!job || job.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      // Create application record
      const application = await storage.createApplication({
        userId,
        jobId,
        jobTitle: job.title,
        company: job.company,
        status: 'sent',
        resumeUsed,
        coverLetter,
        source: job.source || 'manual',
        appliedAt: new Date(),
      });

      // Update job status
      await storage.updateJob(jobId, { status: 'applied' });

      // Sync to PrepPair.me
      try {
        await prepPairService.syncApplications(userId, [application]);
      } catch (error) {
        console.error("Failed to sync to PrepPair.me:", error);
        // Don't fail the request if sync fails
      }

      res.json(application);
    } catch (error) {
      console.error("Error submitting application:", error);
      res.status(500).json({ message: "Failed to submit application" });
    }
  });

  // Applications
  app.get('/api/applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getApplicationsByUser(userId);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.get('/api/applications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = parseInt(req.params.id);
      
      const application = await storage.getApplicationById(applicationId);
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      res.json(application);
    } catch (error) {
      console.error("Error fetching application:", error);
      res.status(500).json({ message: "Failed to fetch application" });
    }
  });

  app.put('/api/applications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = parseInt(req.params.id);
      
      const application = await storage.getApplicationById(applicationId);
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      const updates = req.body;
      const updatedApplication = await storage.updateApplication(applicationId, updates);
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error updating application:", error);
      res.status(500).json({ message: "Failed to update application" });
    }
  });

  app.delete('/api/applications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = parseInt(req.params.id);
      
      const application = await storage.getApplicationById(applicationId);
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      await storage.deleteApplication(applicationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting application:", error);
      res.status(500).json({ message: "Failed to delete application" });
    }
  });

  // Resumes
  app.get('/api/resumes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumes = await storage.getResumesByUser(userId);
      res.json(resumes);
    } catch (error) {
      console.error("Error fetching resumes:", error);
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });

  app.post('/api/resumes/sync', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Sync resumes from ResumeFormatter.io
      const resumesFromAPI = await resumeFormatterService.syncUserResumes(userId);
      
      const createdResumes = [];
      for (const resumeData of resumesFromAPI) {
        const existing = await storage.getResumesByUser(userId);
        const existingResume = existing.find(r => r.externalId === resumeData.externalId);
        
        if (!existingResume) {
          const resume = await storage.createResume(resumeData);
          createdResumes.push(resume);
        } else {
          // Update existing resume with latest data
          const updatedResume = await storage.updateResume(existingResume.id!, {
            name: resumeData.name,
            fileName: resumeData.fileName,
            skills: resumeData.skills,
            experience: resumeData.experience,
            focus: resumeData.focus,
            lastSyncedAt: new Date(),
          });
          createdResumes.push(updatedResume);
        }
      }
      
      res.json({ synced: createdResumes.length, resumes: createdResumes });
    } catch (error) {
      console.error("Error syncing resumes:", error);
      res.status(500).json({ message: "Failed to sync resumes" });
    }
  });

  // Auto-apply rules
  app.get('/api/rules', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rules = await storage.getAutoApplyRules(userId);
      res.json(rules);
    } catch (error) {
      console.error("Error fetching rules:", error);
      res.status(500).json({ message: "Failed to fetch rules" });
    }
  });

  app.post('/api/rules', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rulesData = insertAutoApplyRulesSchema.parse({
        userId,
        ...req.body,
      });
      
      const rules = await storage.upsertAutoApplyRules(rulesData);
      res.json(rules);
    } catch (error) {
      console.error("Error saving rules:", error);
      res.status(500).json({ message: "Failed to save rules" });
    }
  });

  // User settings
  app.get('/api/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const settings = await storage.getUserSettings(userId);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.post('/api/settings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const settingsData = insertUserSettingsSchema.parse({
        userId,
        ...req.body,
      });
      
      const settings = await storage.upsertUserSettings(settingsData);
      res.json(settings);
    } catch (error) {
      console.error("Error saving settings:", error);
      res.status(500).json({ message: "Failed to save settings" });
    }
  });

  // Integration management endpoints
  app.get('/api/integrations/resume-formatter/download/:resumeId', isAuthenticated, async (req: any, res) => {
    try {
      const resumeId = req.params.resumeId;
      const downloadUrl = await resumeFormatterService.downloadResume(resumeId);
      res.json({ downloadUrl });
    } catch (error) {
      console.error("Error getting download URL:", error);
      res.status(500).json({ message: "Failed to get download URL" });
    }
  });

  app.get('/api/integrations/resume-formatter/edit/:resumeId', isAuthenticated, async (req: any, res) => {
    try {
      const resumeId = req.params.resumeId;
      const editUrl = await resumeFormatterService.getEditUrl(resumeId);
      res.json({ editUrl });
    } catch (error) {
      console.error("Error getting edit URL:", error);
      res.status(500).json({ message: "Failed to get edit URL" });
    }
  });

  app.get('/api/integrations/prep-pair/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const analytics = await prepPairService.getAnalytics(userId);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching PrepPair analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.post('/api/integrations/prep-pair/sync', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getApplicationsByUser(userId);
      await prepPairService.syncApplications(userId, applications);
      res.json({ synced: applications.length });
    } catch (error) {
      console.error("Error syncing to PrepPair:", error);
      res.status(500).json({ message: "Failed to sync to PrepPair" });
    }
  });

  app.post('/api/integrations/prep-pair/reminder/:applicationId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = req.params.applicationId;
      const { followUpDate } = req.body;
      
      const application = await storage.getApplicationById(parseInt(applicationId));
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      await prepPairService.createFollowUpReminder(applicationId, new Date(followUpDate));
      res.json({ success: true });
    } catch (error) {
      console.error("Error creating reminder:", error);
      res.status(500).json({ message: "Failed to create reminder" });
    }
  });

  // Blog endpoints
  app.get("/api/blog/posts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const posts = await db.select({
        id: cachedPosts.id,
        wpId: cachedPosts.wpId,
        title: cachedPosts.title,
        slug: cachedPosts.slug,
        excerpt: cachedPosts.excerpt,
        publishedAt: cachedPosts.publishedAt
      })
      .from(cachedPosts)
      .orderBy(desc(cachedPosts.publishedAt))
      .limit(limit)
      .offset(offset);

      res.json({ posts, total: posts.length });
    } catch (error) {
      console.error('Failed to fetch blog posts:', error);
      res.status(500).json({ error: 'Failed to fetch blog posts' });
    }
  });

  app.get("/api/blog/posts/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      
      const [post] = await db.select()
        .from(cachedPosts)
        .where(eq(cachedPosts.slug, slug))
        .limit(1);

      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }

      res.json(post);
    } catch (error) {
      console.error('Failed to fetch blog post:', error);
      res.status(500).json({ error: 'Failed to fetch blog post' });
    }
  });

  app.get("/api/blog/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 3;
      
      const posts = await db.select({
        id: cachedPosts.id,
        title: cachedPosts.title,
        slug: cachedPosts.slug,
        excerpt: cachedPosts.excerpt,
        publishedAt: cachedPosts.publishedAt
      })
      .from(cachedPosts)
      .orderBy(desc(cachedPosts.publishedAt))
      .limit(limit);

      res.json(posts);
    } catch (error) {
      console.error('Failed to fetch recent posts:', error);
      res.status(500).json({ error: 'Failed to fetch recent posts' });
    }
  });

  // Admin middleware for role checking
  const isAdmin = async (req: any, res: any, next: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Check if user has admin role (you can adjust this logic based on your role system)
      if (!user || !req.user.claims.metadata?.role || req.user.claims.metadata.role !== 'admin') {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      next();
    } catch (error) {
      console.error("Error checking admin role:", error);
      res.status(500).json({ error: "Failed to verify admin access" });
    }
  };

  // Admin routes - Feature Flags
  app.get('/api/admin/feature-flags', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { app } = req.query;
      const flags = await storage.getFeatureFlags(app);
      res.json(flags);
    } catch (error) {
      console.error("Error fetching feature flags:", error);
      res.status(500).json({ error: "Failed to fetch feature flags" });
    }
  });

  app.post('/api/admin/feature-flags', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const flagData = insertFeatureFlagSchema.parse(req.body);
      const flag = await storage.createFeatureFlag(flagData);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "create_feature_flag",
        target: "feature_flag",
        targetId: flag.id.toString(),
        changes: flagData,
      });
      
      res.json(flag);
    } catch (error) {
      console.error("Error creating feature flag:", error);
      res.status(500).json({ error: "Failed to create feature flag" });
    }
  });

  app.patch('/api/admin/feature-flags/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const flag = await storage.updateFeatureFlag(parseInt(id), updates);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "update_feature_flag",
        target: "feature_flag",
        targetId: id,
        changes: updates,
      });
      
      res.json(flag);
    } catch (error) {
      console.error("Error updating feature flag:", error);
      res.status(500).json({ error: "Failed to update feature flag" });
    }
  });

  app.delete('/api/admin/feature-flags/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteFeatureFlag(parseInt(id));
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "delete_feature_flag",
        target: "feature_flag",
        targetId: id,
        changes: {},
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting feature flag:", error);
      res.status(500).json({ error: "Failed to delete feature flag" });
    }
  });

  // Admin routes - Billing Plans
  app.get('/api/admin/billing-plans', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { app } = req.query;
      const plans = await storage.getBillingPlans(app);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching billing plans:", error);
      res.status(500).json({ error: "Failed to fetch billing plans" });
    }
  });

  app.post('/api/admin/billing-plans', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const planData = insertBillingPlanSchema.parse(req.body);
      const plan = await storage.createBillingPlan(planData);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "create_billing_plan",
        target: "billing_plan",
        targetId: plan.id.toString(),
        changes: planData,
      });
      
      res.json(plan);
    } catch (error) {
      console.error("Error creating billing plan:", error);
      res.status(500).json({ error: "Failed to create billing plan" });
    }
  });

  app.patch('/api/admin/billing-plans/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const plan = await storage.updateBillingPlan(parseInt(id), updates);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "update_billing_plan",
        target: "billing_plan",
        targetId: id,
        changes: updates,
      });
      
      res.json(plan);
    } catch (error) {
      console.error("Error updating billing plan:", error);
      res.status(500).json({ error: "Failed to update billing plan" });
    }
  });

  app.delete('/api/admin/billing-plans/:id', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteBillingPlan(parseInt(id));
      
      // Log admin action
      await storage.createAdminLog({
        adminId: req.user.claims.sub,
        action: "delete_billing_plan",
        target: "billing_plan",
        targetId: id,
        changes: {},
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting billing plan:", error);
      res.status(500).json({ error: "Failed to delete billing plan" });
    }
  });

  // Admin routes - System Stats
  app.get('/api/admin/system-stats', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getSystemStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching system stats:", error);
      res.status(500).json({ error: "Failed to fetch system stats" });
    }
  });

  // Admin routes - Audit Logs
  app.get('/api/admin/logs', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getAdminLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching admin logs:", error);
      res.status(500).json({ error: "Failed to fetch admin logs" });
    }
  });

  // Legal content API routes
  app.get('/api/legal/:slug', async (req, res) => {
    try {
      const { slug } = req.params;
      const { app } = req.query;
      const appName = (app as string) || 'ApplyCaptain';
      
      const content = await legalContentService.fetchLegalPage(slug, appName);
      
      if (!content) {
        return res.status(404).json({ error: 'Legal page not found' });
      }
      
      res.json({ 
        slug,
        content,
        appName,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error(`Error fetching legal page ${req.params.slug}:`, error);
      res.status(500).json({ error: 'Failed to fetch legal content' });
    }
  });

  app.get('/api/legal', async (req, res) => {
    try {
      const { app } = req.query;
      const appName = (app as string) || 'ApplyCaptain';
      
      const allPages = await legalContentService.fetchAllLegalPages(appName);
      
      res.json({
        pages: allPages,
        appName,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error fetching all legal pages:', error);
      res.status(500).json({ error: 'Failed to fetch legal content' });
    }
  });

  app.post('/api/legal/clear-cache', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      legalContentService.clearCache();
      res.json({ success: true, message: 'Legal content cache cleared' });
    } catch (error) {
      console.error('Error clearing legal cache:', error);
      res.status(500).json({ error: 'Failed to clear cache' });
    }
  });

  app.get('/api/legal/test/wordpress-connection', isAuthenticated, isAdmin, async (req: any, res) => {
    try {
      const isConnected = await legalContentService.testWordPressConnection();
      res.json({ 
        connected: isConnected,
        endpoint: 'https://wrelikbrands.com/wp-json/wp/v2',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error testing WordPress connection:', error);
      res.status(500).json({ error: 'Failed to test connection' });
    }
  });

  // Daily Queue Management
  app.get('/api/daily-queue', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.query;
      const queueEntries = await storage.getDailyQueueByUser(userId, date);
      res.json(queueEntries);
    } catch (error) {
      console.error("Error fetching daily queue:", error);
      res.status(500).json({ message: "Failed to fetch daily queue" });
    }
  });

  app.post('/api/daily-queue/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.body;
      
      // Clear existing queue for the date
      const existing = await storage.getDailyQueueByUser(userId, date);
      for (const entry of existing) {
        await storage.deleteDailyQueueEntry(entry.id);
      }
      
      // Generate new queue
      const queueEntries = await storage.generateDailyQueue(userId, date);
      res.json({ count: queueEntries.length, entries: queueEntries });
    } catch (error) {
      console.error("Error generating daily queue:", error);
      res.status(500).json({ message: "Failed to generate daily queue" });
    }
  });

  app.post('/api/daily-queue/process', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { date, mode } = req.body;
      
      const queueEntries = await storage.getDailyQueueByUser(userId, date);
      const pendingEntries = queueEntries.filter((entry: any) => entry.status === "pending");
      
      let applied = 0;
      let failed = 0;
      
      for (const entry of pendingEntries) {
        try {
          // Update status to processing
          await storage.updateDailyQueueEntry(entry.id, { 
            status: "processing",
            processedAt: new Date()
          });
          
          if (mode === "auto") {
            // Get job details
            const job = await storage.getJobById(entry.jobId);
            if (!job) {
              throw new Error("Job not found");
            }
            
            const application = {
              userId,
              jobId: entry.jobId,
              jobTitle: job.title,
              company: job.company,
              status: "sent",
              source: "auto_apply",
              notes: "Applied automatically via daily queue"
            };
            
            await storage.createApplication(application);
            await storage.updateJob(entry.jobId, { status: "applied" });
            await storage.updateDailyQueueEntry(entry.id, { status: "completed" });
            applied++;
          } else {
            // Review mode - mark as completed but don't auto-apply
            await storage.updateDailyQueueEntry(entry.id, { status: "completed" });
            applied++;
          }
        } catch (error) {
          console.error(`Error processing queue entry ${entry.id}:`, error);
          await storage.updateDailyQueueEntry(entry.id, { 
            status: "failed",
            errorMessage: error.message
          });
          failed++;
        }
      }
      
      res.json({ applied, failed, total: pendingEntries.length });
    } catch (error) {
      console.error("Error processing daily queue:", error);
      res.status(500).json({ message: "Failed to process daily queue" });
    }
  });

  app.patch('/api/daily-queue/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entryId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify ownership
      const queueEntries = await storage.getDailyQueueByUser(userId);
      const entry = queueEntries.find((e: any) => e.id === entryId);
      if (!entry) {
        return res.status(404).json({ message: "Queue entry not found" });
      }
      
      const updatedEntry = await storage.updateDailyQueueEntry(entryId, updates);
      res.json(updatedEntry);
    } catch (error) {
      console.error("Error updating queue entry:", error);
      res.status(500).json({ message: "Failed to update queue entry" });
    }
  });

  // Email Jobs Management
  app.get('/api/email-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const emailJobs = await storage.getEmailJobsByUser(userId);
      res.json(emailJobs);
    } catch (error) {
      console.error("Error fetching email jobs:", error);
      res.status(500).json({ message: "Failed to fetch email jobs" });
    }
  });

  app.post('/api/email-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const emailJobData = { ...req.body, userId };
      const emailJob = await storage.createEmailJob(emailJobData);
      res.json(emailJob);
    } catch (error) {
      console.error("Error creating email job:", error);
      res.status(500).json({ message: "Failed to create email job" });
    }
  });

  app.patch('/api/email-jobs/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const emailJobId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify ownership
      const emailJobs = await storage.getEmailJobsByUser(userId);
      const emailJob = emailJobs.find(e => e.id === emailJobId);
      if (!emailJob) {
        return res.status(404).json({ message: "Email job not found" });
      }
      
      const updatedEmailJob = await storage.updateEmailJob(emailJobId, updates);
      res.json(updatedEmailJob);
    } catch (error) {
      console.error("Error updating email job:", error);
      res.status(500).json({ message: "Failed to update email job" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
