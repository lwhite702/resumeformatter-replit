import { db } from './db';
import { featureFlags, billingPlans } from '@shared/schema';

export async function seedAdminData() {
  try {
    console.log('Seeding admin data...');

    // Sample feature flags for ApplyCaptain
    const sampleFlags = [
      {
        app: 'ApplyCaptain',
        name: 'ai_resume_matching',
        description: 'Enable AI-powered resume matching and optimization',
        enabled: true,
        planRequired: 'pro_monthly'
      },
      {
        app: 'ApplyCaptain',
        name: 'bulk_applications',
        description: 'Allow users to apply to multiple jobs at once',
        enabled: true,
        planRequired: 'pro_monthly'
      },
      {
        app: 'ApplyCaptain',
        name: 'priority_support',
        description: 'Access to priority customer support',
        enabled: true,
        planRequired: 'pro_monthly'
      },
      {
        app: 'ApplyCaptain',
        name: 'email_integration',
        description: 'Automatic job parsing from email',
        enabled: false,
        planRequired: null
      },
      {
        app: 'ResumeFormatter.io',
        name: 'advanced_templates',
        description: 'Access to premium resume templates',
        enabled: true,
        planRequired: 'pro_monthly'
      }
    ];

    // Sample billing plans
    const samplePlans = [
      {
        app: 'ApplyCaptain',
        planKey: 'free',
        displayName: 'Free Plan',
        price: null,
        currency: 'USD',
        interval: null,
        features: ['Basic job search', 'Manual applications', 'Community support'],
        isActive: true,
        metadata: { maxApplicationsPerDay: 5 }
      },
      {
        app: 'ApplyCaptain',
        planKey: 'pro_monthly',
        stripePriceId: 'price_applycaptain_pro_monthly',
        displayName: 'Pro Monthly',
        price: 29.99,
        currency: 'USD',
        interval: 'month',
        features: ['AI Resume Matching', 'Bulk Applications', 'Priority Support', 'Advanced Analytics'],
        isActive: true,
        metadata: { maxApplicationsPerDay: 50 }
      },
      {
        app: 'ApplyCaptain',
        planKey: 'pro_quarterly',
        stripePriceId: 'price_applycaptain_pro_quarterly',
        displayName: 'Pro Quarterly',
        price: 79.99,
        currency: 'USD',
        interval: 'quarter',
        features: ['AI Resume Matching', 'Bulk Applications', 'Priority Support', 'Advanced Analytics', '20% Savings'],
        isActive: true,
        metadata: { maxApplicationsPerDay: 50, savings: '20%' }
      },
      {
        app: 'ResumeFormatter.io',
        planKey: 'free',
        displayName: 'Free Plan',
        price: null,
        currency: 'USD',
        interval: null,
        features: ['Basic templates', 'PDF export'],
        isActive: true,
        metadata: { maxResumes: 3 }
      },
      {
        app: 'ResumeFormatter.io',
        planKey: 'pro_monthly',
        stripePriceId: 'price_resumeformatter_pro_monthly',
        displayName: 'Pro Monthly',
        price: 19.99,
        currency: 'USD',
        interval: 'month',
        features: ['Advanced templates', 'ATS optimization', 'Unlimited exports'],
        isActive: true,
        metadata: { maxResumes: -1 }
      }
    ];

    // Insert feature flags
    for (const flag of sampleFlags) {
      await db.insert(featureFlags)
        .values(flag)
        .onConflictDoNothing();
    }

    // Insert billing plans
    for (const plan of samplePlans) {
      await db.insert(billingPlans)
        .values(plan)
        .onConflictDoNothing();
    }

    console.log('Admin data seeded successfully');
  } catch (error) {
    console.error('Error seeding admin data:', error);
  }
}