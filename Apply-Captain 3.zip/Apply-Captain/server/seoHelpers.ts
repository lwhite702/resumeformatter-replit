
// SEO Helper Functions
export interface SEOData {
  title: string;
  description: string;
  keywords?: string;
  ogImage?: string;
  canonicalUrl?: string;
  structuredData?: any;
}

export function generateSEOData(page: string, data?: any): SEOData {
  const baseUrl = 'https://autoapply.wrelik.com';
  
  const seoConfigs: Record<string, SEOData> = {
    home: {
      title: 'AutoApply by Wrelik – AI That Applies to Jobs for You',
      description: 'Automate your job search with AI. Find jobs, optimize resumes, generate cover letters, and track applications automatically.',
      keywords: 'job application automation, AI job search, resume optimization, cover letter generator',
      canonicalUrl: baseUrl,
      structuredData: {
        '@context': 'https://schema.org',
        '@type': 'WebApplication',
        name: 'AutoApply by Wrelik',
        description: 'AI-powered job application automation platform',
        url: baseUrl
      }
    },
    blog: {
      title: 'Job Search Tips & Career Advice | AutoApply Blog',
      description: 'Expert job search tips, career advice, and AI-powered application strategies. Learn how to optimize your job hunt.',
      keywords: 'job search tips, career advice, resume tips, interview preparation, job hunting strategies',
      canonicalUrl: `${baseUrl}/blog`
    },
    dashboard: {
      title: 'Dashboard | AutoApply by Wrelik',
      description: 'Manage your automated job applications, track progress, and optimize your job search strategy.',
      canonicalUrl: `${baseUrl}/dashboard`
    }
  };

  return seoConfigs[page] || seoConfigs.home;
}

export function generateBlogPostSEO(post: any): SEOData {
  const baseUrl = 'https://autoapply.wrelik.com';
  
  return {
    title: `${post.title} | AutoApply Blog`,
    description: post.excerpt || post.summary,
    keywords: `job search, career advice, ${post.tags?.join(', ') || ''}`,
    canonicalUrl: `${baseUrl}/blog/${post.slug}`,
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'BlogPosting',
      headline: post.title,
      description: post.excerpt || post.summary,
      author: {
        '@type': 'Organization',
        name: 'Wrelik Brands'
      },
      publisher: {
        '@type': 'Organization',
        name: 'AutoApply by Wrelik',
        logo: {
          '@type': 'ImageObject',
          url: `${baseUrl}/logo-color.png`
        }
      },
      datePublished: post.publishedAt,
      dateModified: post.updatedAt || post.publishedAt,
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': `${baseUrl}/blog/${post.slug}`
      }
    }
  };
}
