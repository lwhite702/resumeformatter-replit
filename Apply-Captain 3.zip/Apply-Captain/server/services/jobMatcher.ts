import { analyzeJobPosting, calculateMatchScore } from "./openai";
import type { Resume } from "@shared/schema";

class JobMatcher {
  async analyzeJob(url?: string, description?: string, resumes: Resume[] = []) {
    let jobText = description || "";
    
    // If URL is provided, we would normally fetch the job posting
    // For now, we'll use the description or create a sample based on URL patterns
    if (url && !description) {
      jobText = this.extractJobInfoFromUrl(url);
    }

    if (!jobText) {
      throw new Error("No job information provided");
    }

    // Analyze job posting with AI
    const jobInfo = await analyzeJobPosting(jobText);
    
    // Calculate match score with best resume
    let matchScore = 0;
    let bestResume: Resume | null = null;
    
    if (resumes.length > 0) {
      for (const resume of resumes) {
        const candidateSkills = (resume.skills as string[]) || [];
        const matchResult = await calculateMatchScore(jobInfo.requirements, candidateSkills);
        
        if (matchResult.score > matchScore) {
          matchScore = matchResult.score;
          bestResume = resume;
        }
      }
    }

    return {
      title: jobInfo.title,
      company: jobInfo.company,
      location: jobInfo.location,
      workType: jobInfo.workType,
      employmentType: jobInfo.employmentType,
      salaryMin: jobInfo.salaryRange?.min,
      salaryMax: jobInfo.salaryRange?.max,
      description: jobText,
      requirements: jobInfo.requirements,
      url: url,
      source: this.determineSource(url),
      matchScore: Math.round(matchScore),
    };
  }

  private extractJobInfoFromUrl(url: string): string {
    // Determine platform from URL and return sample job description
    // In a real implementation, this would scrape the job posting
    
    if (url.includes('linkedin.com')) {
      return `Senior Frontend Developer position at a leading technology company. 
        Requirements include React, TypeScript, 5+ years experience, and knowledge of modern frontend tools.
        Competitive salary range $120,000 - $150,000. Remote-friendly position.`;
    } else if (url.includes('indeed.com')) {
      return `Full Stack Developer role with focus on React and Node.js development.
        Looking for 3-5 years experience with JavaScript, React, Node.js, and database management.
        Salary: $90,000 - $120,000 annually. Hybrid work environment.`;
    } else {
      return `Software Engineer position requiring strong programming skills and experience
        with modern web technologies. Competitive compensation and benefits package.`;
    }
  }

  private determineSource(url?: string): string {
    if (!url) return 'manual';
    
    if (url.includes('linkedin.com')) return 'linkedin';
    if (url.includes('indeed.com')) return 'indeed';
    if (url.includes('glassdoor.com')) return 'glassdoor';
    if (url.includes('monster.com')) return 'monster';
    
    return 'other';
  }

  async findSuggestedJobs(userId: string, rules: any, existingJobs: any[] = []) {
    // In a real implementation, this would:
    // 1. Use job board APIs to search for relevant positions
    // 2. Apply user's auto-apply rules as filters
    // 3. Calculate match scores for each job
    // 4. Return top matches
    
    // For now, return empty array as this requires external integrations
    return [];
  }
}

export const jobMatcher = new JobMatcher();
