import fetch from 'node-fetch';

interface LegalPage {
  id: number;
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  slug: string;
  modified: string;
}

interface AppVariables {
  appName: string;
  appUrl: string;
  supportEmail: string;
  supportCenterUrl: string;
  knowledgeBaseUrl: string;
  appFeatures: string[];
  privacyRoute: string;
  termsRoute: string;
  cookieRoute: string;
  dataRetentionRoute: string;
}

class LegalContentService {
  private readonly wpApiUrl = 'https://wrelikbrands.com/wp-json/wp/v2';
  private cache = new Map<string, { content: string; lastFetch: number }>();
  private readonly cacheTimeout = 3600000; // 1 hour

  private getAppVariables(appName: string = 'ApplyCaptain'): AppVariables {
    const variables: Record<string, AppVariables> = {
      'ApplyCaptain': {
        appName: 'ApplyCaptain',
        appUrl: 'https://applycaptain.wrelik.com',
        supportEmail: 'help@applycaptain.com',
        supportCenterUrl: 'https://applycaptain.wrelik.com/support',
        knowledgeBaseUrl: 'https://applycaptain.wrelik.com/admin/docs',
        appFeatures: [
          'AI-powered job matching',
          'Automated application submission',
          'Resume optimization',
          'Daily job queue management',
          'Application tracking',
          'Email integration',
          'Priority support'
        ],
        privacyRoute: '/legal/privacy-policy',
        termsRoute: '/legal/terms-of-service',
        cookieRoute: '/legal/cookie-policy',
        dataRetentionRoute: '/legal/data-retention'
      },
      'ResumeFormatter.io': {
        appName: 'ResumeFormatter.io',
        appUrl: 'https://resumeformatter.io',
        supportEmail: 'help@resumeformatter.io',
        supportCenterUrl: 'https://resumeformatter.io/support',
        knowledgeBaseUrl: 'https://resumeformatter.io/docs',
        appFeatures: [
          'Professional resume templates',
          'ATS optimization',
          'Real-time preview',
          'PDF export',
          'Multiple formats',
          'Industry-specific layouts'
        ],
        privacyRoute: '/privacy',
        termsRoute: '/terms',
        cookieRoute: '/cookies',
        dataRetentionRoute: '/data-policy'
      },
      'PrepPair.me': {
        appName: 'PrepPair.me',
        appUrl: 'https://preppair.me',
        supportEmail: 'help@preppair.me',
        supportCenterUrl: 'https://preppair.me/support',
        knowledgeBaseUrl: 'https://preppair.me/knowledge',
        appFeatures: [
          'AI interview preparation',
          'Mock interview sessions',
          'Question databases',
          'Performance analytics',
          'Industry-specific prep',
          'Video practice sessions'
        ],
        privacyRoute: '/legal/privacy',
        termsRoute: '/legal/terms',
        cookieRoute: '/legal/cookies',
        dataRetentionRoute: '/legal/data'
      },
      'NameDrop.cv': {
        appName: 'NameDrop.cv',
        appUrl: 'https://namedrop.cv',
        supportEmail: 'help@namedrop.cv',
        supportCenterUrl: 'https://namedrop.cv/support',
        knowledgeBaseUrl: 'https://namedrop.cv/help',
        appFeatures: [
          'Professional networking',
          'CV showcase platform',
          'Industry connections',
          'Portfolio management',
          'Career insights',
          'Recruitment tools'
        ],
        privacyRoute: '/privacy-policy',
        termsRoute: '/terms-of-service',
        cookieRoute: '/cookie-policy',
        dataRetentionRoute: '/data-retention'
      }
    };

    return variables[appName] || variables['ApplyCaptain'];
  }

  private substituteVariables(content: string, appName: string = 'ApplyCaptain'): string {
    const variables = this.getAppVariables(appName);
    
    let processedContent = content;

    // Clean up HTML artifacts from WordPress
    processedContent = processedContent.replace(/<br \/>\s*\n/g, '\n');
    processedContent = processedContent.replace(/<!DOCTYPE html>[\s\S]*?<body>/g, '');
    processedContent = processedContent.replace(/<\/body>[\s\S]*?<\/html>/g, '');

    // Replace WordPress/generic variables (both formats)
    processedContent = processedContent.replace(/\{Brand Name\}/g, variables.appName);
    processedContent = processedContent.replace(/\{\{Brand Name\}\}/g, variables.appName);
    processedContent = processedContent.replace(/\{appurl\}/g, variables.appUrl.replace('https://', ''));
    processedContent = processedContent.replace(/\{\{appurl\}\}/g, variables.appUrl.replace('https://', ''));
    
    // Handle specific WordPress template variables found in the content
    processedContent = processedContent.replace(/\{Brand Name\}/g, variables.appName);
    processedContent = processedContent.replace(/support@\{appurl\}/g, variables.supportEmail);

    // Replace basic variables
    processedContent = processedContent.replace(/\{\{App Name\}\}/g, variables.appName);
    processedContent = processedContent.replace(/\{\{App URL\}\}/g, variables.appUrl);
    processedContent = processedContent.replace(/\{\{Support Email\}\}/g, variables.supportEmail);
    processedContent = processedContent.replace(/\{\{Support Center URL\}\}/g, variables.supportCenterUrl);
    processedContent = processedContent.replace(/\{\{Knowledge Base URL\}\}/g, variables.knowledgeBaseUrl);

    // Replace email placeholders
    processedContent = processedContent.replace(/support@\{appurl\}/g, variables.supportEmail);
    processedContent = processedContent.replace(/support@\{\{appurl\}\}/g, variables.supportEmail);
    processedContent = processedContent.replace(/help@\{\{App URL\}\}/g, variables.supportEmail);

    // Replace legal page routes
    processedContent = processedContent.replace(/\{\{Privacy Route\}\}/g, variables.privacyRoute);
    processedContent = processedContent.replace(/\{\{Terms Route\}\}/g, variables.termsRoute);
    processedContent = processedContent.replace(/\{\{Cookie Route\}\}/g, variables.cookieRoute);
    processedContent = processedContent.replace(/\{\{Data Retention Route\}\}/g, variables.dataRetentionRoute);

    // Replace app features with bulleted list
    if (content.includes('{{App Features}}')) {
      const featuresList = variables.appFeatures
        .map(feature => `<li>${feature}</li>`)
        .join('');
      const featuresHtml = `<ul class="list-disc list-inside space-y-1 my-3">${featuresList}</ul>`;
      processedContent = processedContent.replace(/\{\{App Features\}\}/g, featuresHtml);
    }

    // Handle other legal page routes dynamically
    const legalRoutePattern = /\{\{Other Legal Page \(([^)]+)\) Route\}\}/g;
    processedContent = processedContent.replace(legalRoutePattern, (match, pageName) => {
      const routeMap: Record<string, string> = {
        'Privacy Policy': variables.privacyRoute,
        'Terms of Service': variables.termsRoute,
        'Cookie Policy': variables.cookieRoute,
        'Data Retention': variables.dataRetentionRoute
      };
      return routeMap[pageName] || match;
    });

    // Clean up remaining template placeholders that might exist
    processedContent = processedContent.replace(/\{[^}]+\}/g, (match) => {
      console.log(`Unhandled template variable: ${match}`);
      return match; // Keep unhandled variables for debugging
    });

    return processedContent;
  }

  async fetchLegalPage(slug: string, appName: string = 'ApplyCaptain'): Promise<string | null> {
    const cacheKey = `${slug}-${appName}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && (Date.now() - cached.lastFetch) < this.cacheTimeout) {
      return cached.content;
    }

    try {
      // Try to fetch specific legal page by slug
      const response = await fetch(`${this.wpApiUrl}/pages?slug=${slug}&_fields=id,title,content,slug,modified`);
      
      if (!response.ok) {
        console.error(`Failed to fetch legal page ${slug}:`, response.status);
        return null;
      }

      const pages: LegalPage[] = await response.json() as LegalPage[];
      
      if (!pages || pages.length === 0) {
        console.log(`No legal page found for slug: ${slug}`);
        return this.getFallbackContent(slug, appName);
      }

      const page = pages[0];
      const processedContent = this.substituteVariables(page.content.rendered, appName);
      
      // Cache the processed content
      this.cache.set(cacheKey, {
        content: processedContent,
        lastFetch: Date.now()
      });

      return processedContent;
    } catch (error) {
      console.error(`Error fetching legal page ${slug}:`, error);
      return this.getFallbackContent(slug, appName);
    }
  }

  async fetchAllLegalPages(appName: string = 'ApplyCaptain'): Promise<Record<string, string>> {
    const legalSlugs = ['privacy-policy', 'terms-of-service', 'cookie-policy', 'data-retention'];
    const results: Record<string, string> = {};

    await Promise.all(
      legalSlugs.map(async (slug) => {
        const content = await this.fetchLegalPage(slug, appName);
        if (content) {
          results[slug] = content;
        }
      })
    );

    return results;
  }

  private getFallbackContent(slug: string, appName: string): string {
    const variables = this.getAppVariables(appName);
    
    const fallbackContent: Record<string, string> = {
      'privacy-policy': `
        <h1>Privacy Policy</h1>
        <p><strong>Last updated:</strong> ${new Date().toLocaleDateString()}</p>
        
        <h2>Information We Collect</h2>
        <p>{{App Name}} collects information you provide directly to us, such as when you create an account, use our services, or contact us for support.</p>
        
        <h2>How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        {{App Features}}
        
        <h2>Contact Us</h2>
        <p>If you have questions about this Privacy Policy, please contact us at {{Support Email}} or visit our {{Support Center URL}}.</p>
        
        <p>For more information, see our {{Terms Route}} and {{Cookie Route}}.</p>
      `,
      'terms-of-service': `
        <h1>Terms of Service</h1>
        <p><strong>Last updated:</strong> ${new Date().toLocaleDateString()}</p>
        
        <h2>Acceptance of Terms</h2>
        <p>By accessing and using {{App Name}} at {{App URL}}, you accept and agree to be bound by the terms and provision of this agreement.</p>
        
        <h2>Service Description</h2>
        <p>{{App Name}} provides the following services:</p>
        {{App Features}}
        
        <h2>Contact Information</h2>
        <p>Questions about the Terms of Service should be sent to us at {{Support Email}}.</p>
        
        <p>Please also review our {{Privacy Route}} and {{Cookie Route}}.</p>
      `,
      'cookie-policy': `
        <h1>Cookie Policy</h1>
        <p><strong>Last updated:</strong> ${new Date().toLocaleDateString()}</p>
        
        <h2>What Are Cookies</h2>
        <p>Cookies are small pieces of text sent by your web browser by a website you visit. A cookie file is stored in your web browser and allows {{App Name}} or a third-party to recognize you.</p>
        
        <h2>How We Use Cookies</h2>
        <p>{{App Name}} uses cookies to enhance your experience and provide our services:</p>
        {{App Features}}
        
        <h2>Contact Us</h2>
        <p>If you have any questions about this Cookie Policy, please contact us at {{Support Email}}.</p>
        
        <p>For more information, visit our {{Privacy Route}} and {{Terms Route}}.</p>
      `,
      'data-retention': `
        <h1>Data Retention Policy</h1>
        <p><strong>Last updated:</strong> ${new Date().toLocaleDateString()}</p>
        
        <h2>Data Retention</h2>
        <p>{{App Name}} retains personal data for as long as necessary to provide our services and fulfill the purposes outlined in our {{Privacy Route}}.</p>
        
        <h2>Data Deletion</h2>
        <p>You may request deletion of your personal data by contacting us at {{Support Email}}. We will process such requests in accordance with applicable law.</p>
        
        <h2>Service Data</h2>
        <p>Data related to {{App Name}} services includes:</p>
        {{App Features}}
        
        <p>For complete details, please review our {{Privacy Route}} and {{Terms Route}}.</p>
      `
    };

    const content = fallbackContent[slug] || fallbackContent['privacy-policy'];
    return this.substituteVariables(content, appName);
  }

  clearCache(): void {
    this.cache.clear();
  }

  async testWordPressConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.wpApiUrl}/pages?per_page=1`);
      return response.ok;
    } catch (error) {
      console.error('WordPress connection test failed:', error);
      return false;
    }
  }
}

export const legalContentService = new LegalContentService();