import OpenAI from "openai";
import type { Job, Resume } from "@shared/schema";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export async function generateCoverLetter(job: Job, resume: Resume): Promise<string> {
  try {
    const prompt = `Write a professional cover letter for the following job position. Make it personalized and compelling.

Job Details:
- Title: ${job.title}
- Company: ${job.company}
- Description: ${job.description || 'Not provided'}
- Requirements: ${job.requirements ? JSON.stringify(job.requirements) : 'Not specified'}

Candidate Profile:
- Name: [Use placeholder - will be filled in later]
- Skills: ${resume.skills ? (resume.skills as string[]).join(', ') : 'Various technical skills'}
- Experience: ${resume.experience || 'Relevant experience'}
- Focus: ${resume.focus || 'Software development'}

Please write a cover letter that:
1. Shows enthusiasm for the specific role and company
2. Highlights relevant skills that match the job requirements
3. Demonstrates understanding of the role
4. Is professional but personable
5. Is 2-3 paragraphs long
6. Ends with a strong call to action

Format it as a complete cover letter ready to send.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a professional career coach who writes compelling cover letters. Write personalized, engaging cover letters that help candidates stand out."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 800,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "Unable to generate cover letter at this time.";
  } catch (error) {
    console.error("Error generating cover letter:", error);
    throw new Error("Failed to generate cover letter");
  }
}

export async function analyzeJobPosting(jobText: string): Promise<{
  title: string;
  company: string;
  location?: string;
  requirements: string[];
  salaryRange?: { min: number; max: number };
  workType?: string;
  employmentType?: string;
}> {
  try {
    const prompt = `Analyze the following job posting and extract key information. Return the response in JSON format with the following structure:
{
  "title": "job title",
  "company": "company name",
  "location": "location if mentioned",
  "requirements": ["list", "of", "key", "requirements", "and", "skills"],
  "salaryRange": {"min": 80000, "max": 120000},
  "workType": "remote|hybrid|onsite",
  "employmentType": "full-time|part-time|contract"
}

Job Posting:
${jobText}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert at analyzing job postings and extracting structured information. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Error analyzing job posting:", error);
    throw new Error("Failed to analyze job posting");
  }
}

export async function calculateMatchScore(jobRequirements: string[], candidateSkills: string[]): Promise<{
  score: number;
  matchedSkills: string[];
  missingSkills: string[];
}> {
  try {
    const prompt = `Calculate a match score between a job's requirements and a candidate's skills.

Job Requirements: ${jobRequirements.join(', ')}
Candidate Skills: ${candidateSkills.join(', ')}

Analyze the match and return JSON with:
{
  "score": 85,
  "matchedSkills": ["skills that match"],
  "missingSkills": ["important skills candidate lacks"]
}

Score should be 0-100 based on:
- Direct skill matches (highest weight)
- Related/transferable skills 
- Overall coverage of requirements
- Experience level alignment`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert at matching job requirements with candidate skills. Provide accurate match scores and analysis."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 500,
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      score: Math.max(0, Math.min(100, result.score || 0)),
      matchedSkills: result.matchedSkills || [],
      missingSkills: result.missingSkills || [],
    };
  } catch (error) {
    console.error("Error calculating match score:", error);
    return {
      score: 0,
      matchedSkills: [],
      missingSkills: jobRequirements,
    };
  }
}
