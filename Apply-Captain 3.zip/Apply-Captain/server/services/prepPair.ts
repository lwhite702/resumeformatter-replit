
import type { Application } from "@shared/schema";

interface PrepPairApplication {
  id: string;
  jobTitle: string;
  company: string;
  status: string;
  appliedDate: string;
  source: string;
  notes?: string;
  followUpDate?: string;
}

interface PrepPairAnalytics {
  totalApplications: number;
  responseRate: number;
  interviewRate: number;
  successRate: number;
  averageResponseTime: number;
  topSources: { source: string; count: number }[];
  statusBreakdown: { status: string; count: number }[];
}

class PrepPairService {
  private apiKey: string;
  private baseUrl = "https://api.preppair.me";

  constructor() {
    this.apiKey = process.env.PREP_PAIR_API_KEY || "";
  }

  async syncApplications(userId: string, applications: Application[]): Promise<void> {
    try {
      if (!this.apiKey) {
        console.log("PrepPair.me sync (mock mode): Applications would be synced");
        return;
      }

      const prepPairData = applications.map(app => ({
        externalId: app.id?.toString(),
        jobTitle: app.jobTitle,
        company: app.company,
        status: this.mapStatusToPrepPair(app.status),
        appliedDate: app.appliedAt.toISOString(),
        source: app.source,
        resumeUsed: app.resumeUsed,
        coverLetter: app.coverLetter,
      }));

      const response = await fetch(`${this.baseUrl}/v1/applications/sync`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ applications: prepPairData }),
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.statusText}`);
      }

      console.log(`Synced ${applications.length} applications to PrepPair.me`);
    } catch (error) {
      console.error("Error syncing to PrepPair.me:", error);
    }
  }

  async getAnalytics(userId: string): Promise<PrepPairAnalytics> {
    try {
      if (!this.apiKey) {
        return this.getMockAnalytics();
      }

      const response = await fetch(`${this.baseUrl}/v1/analytics`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Error fetching analytics from PrepPair.me:", error);
      return this.getMockAnalytics();
    }
  }

  async createFollowUpReminder(applicationId: string, followUpDate: Date): Promise<void> {
    try {
      if (!this.apiKey) {
        console.log("PrepPair.me reminder (mock mode): Reminder would be created");
        return;
      }

      await fetch(`${this.baseUrl}/v1/reminders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          applicationId,
          followUpDate: followUpDate.toISOString(),
          type: 'follow-up',
        }),
      });
    } catch (error) {
      console.error("Error creating follow-up reminder:", error);
    }
  }

  private mapStatusToPrepPair(status: string): string {
    const statusMap: Record<string, string> = {
      'sent': 'applied',
      'viewed': 'viewed',
      'interview': 'interview',
      'offer': 'offer',
      'rejected': 'rejected',
      'withdrawn': 'withdrawn',
    };
    return statusMap[status] || 'applied';
  }

  private getMockAnalytics(): PrepPairAnalytics {
    return {
      totalApplications: 45,
      responseRate: 22.5,
      interviewRate: 8.9,
      successRate: 4.4,
      averageResponseTime: 5.2,
      topSources: [
        { source: 'linkedin', count: 18 },
        { source: 'indeed', count: 12 },
        { source: 'manual', count: 8 },
        { source: 'glassdoor', count: 7 },
      ],
      statusBreakdown: [
        { status: 'sent', count: 25 },
        { status: 'viewed', count: 10 },
        { status: 'interview', count: 4 },
        { status: 'rejected', count: 5 },
        { status: 'offer', count: 1 },
      ],
    };
  }
}

export const prepPairService = new PrepPairService();
