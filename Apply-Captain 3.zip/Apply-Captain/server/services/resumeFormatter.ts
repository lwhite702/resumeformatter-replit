
import type { Resume } from "@shared/schema";

interface ResumeFormatterAPI {
  id: string;
  name: string;
  fileName: string;
  skills: string[];
  experience: string;
  focus: string;
  lastModified: string;
  downloadUrl: string;
}

class ResumeFormatterService {
  private apiKey: string;
  private baseUrl = "https://api.resumeformatter.io";

  constructor() {
    this.apiKey = process.env.RESUME_FORMATTER_API_KEY || "";
  }

  async syncUserResumes(userId: string): Promise<Resume[]> {
    try {
      if (!this.apiKey) {
        // Return mock data for development
        return this.getMockResumes(userId);
      }

      const response = await fetch(`${this.baseUrl}/v1/resumes`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`ResumeFormatter API error: ${response.statusText}`);
      }

      const data: ResumeFormatterAPI[] = await response.json();
      
      return data.map(resume => ({
        userId,
        name: resume.name,
        fileName: resume.fileName,
        skills: resume.skills,
        experience: resume.experience,
        focus: resume.focus,
        matchHistory: [],
        timesUsed: 0,
        externalId: resume.id,
        lastSyncedAt: new Date(),
      }));
    } catch (error) {
      console.error("Error syncing resumes from ResumeFormatter.io:", error);
      // Fallback to mock data
      return this.getMockResumes(userId);
    }
  }

  async downloadResume(resumeId: string): Promise<string> {
    try {
      if (!this.apiKey) {
        return `https://resumeformatter.io/download/${resumeId}`;
      }

      const response = await fetch(`${this.baseUrl}/v1/resumes/${resumeId}/download`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to get download URL: ${response.statusText}`);
      }

      const data = await response.json();
      return data.downloadUrl;
    } catch (error) {
      console.error("Error getting download URL:", error);
      return `https://resumeformatter.io/download/${resumeId}`;
    }
  }

  async getEditUrl(resumeId: string): Promise<string> {
    return `https://resumeformatter.io/edit/${resumeId}`;
  }

  private getMockResumes(userId: string): Resume[] {
    return [
      {
        userId,
        name: "Frontend Developer Resume",
        fileName: "Frontend_Developer_Resume_v3.pdf",
        skills: ["React", "TypeScript", "Next.js", "TailwindCSS", "GraphQL", "AWS"],
        experience: "5+ years",
        focus: "frontend",
        matchHistory: [],
        timesUsed: 25,
        externalId: "rf_001",
        lastSyncedAt: new Date(),
      },
      {
        userId,
        name: "Full Stack Developer Resume",
        fileName: "Full_Stack_Developer_Resume.pdf",
        skills: ["Node.js", "Python", "AWS", "Docker", "React", "PostgreSQL"],
        experience: "4+ years",
        focus: "fullstack",
        matchHistory: [],
        timesUsed: 15,
        externalId: "rf_002",
        lastSyncedAt: new Date(),
      },
      {
        userId,
        name: "Senior Backend Engineer Resume",
        fileName: "Backend_Engineer_Resume.pdf",
        skills: ["Java", "Spring Boot", "Microservices", "Kubernetes", "Redis", "MongoDB"],
        experience: "6+ years",
        focus: "backend",
        matchHistory: [],
        timesUsed: 8,
        externalId: "rf_003",
        lastSyncedAt: new Date(),
      },
    ];
  }
}

export const resumeFormatterService = new ResumeFormatterService();
