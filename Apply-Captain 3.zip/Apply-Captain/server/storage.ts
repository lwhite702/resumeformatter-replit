import {
  users,
  jobs,
  applications,
  resumes,
  autoApplyRules,
  userSettings,
  dailyQueue,
  emailJobs,
  featureFlags,
  adminLogs,
  knowledgeDocs,
  billingPlans,
  type User,
  type UpsertUser,
  type Job,
  type InsertJob,
  type Application,
  type InsertApplication,
  type Resume,
  type InsertResume,
  type AutoApplyRules,
  type InsertAutoApplyRules,
  type UserSettings,
  type InsertUserSettings,
  type DailyQueue,
  type InsertDailyQueue,
  type EmailJob,
  type InsertEmailJob,
  type FeatureFlag,
  type InsertFeatureFlag,
  type AdminLog,
  type InsertAdminLog,
  type KnowledgeDoc,
  type InsertKnowledgeDoc,
  type BillingPlan,
  type InsertBillingPlan,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, like, or, count } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Job operations
  createJob(job: InsertJob): Promise<Job>;
  getJobsByUser(userId: string): Promise<Job[]>;
  getJobById(id: number): Promise<Job | undefined>;
  updateJob(id: number, updates: Partial<InsertJob>): Promise<Job>;
  deleteJob(id: number): Promise<void>;
  
  // Application operations
  createApplication(application: InsertApplication): Promise<Application>;
  getApplicationsByUser(userId: string): Promise<Application[]>;
  getApplicationById(id: number): Promise<Application | undefined>;
  updateApplication(id: number, updates: Partial<InsertApplication>): Promise<Application>;
  deleteApplication(id: number): Promise<void>;
  getApplicationStats(userId: string): Promise<{
    totalApplications: number;
    profileViews: number;
    interviews: number;
    successRate: number;
  }>;
  
  // Resume operations
  createResume(resume: InsertResume): Promise<Resume>;
  getResumesByUser(userId: string): Promise<Resume[]>;
  getResumeById(id: number): Promise<Resume | undefined>;
  updateResume(id: number, updates: Partial<InsertResume>): Promise<Resume>;
  deleteResume(id: number): Promise<void>;
  
  // Auto-apply rules operations
  getAutoApplyRules(userId: string): Promise<AutoApplyRules | undefined>;
  upsertAutoApplyRules(rules: InsertAutoApplyRules): Promise<AutoApplyRules>;
  
  // Daily queue operations
  createDailyQueueEntry(entry: InsertDailyQueue): Promise<DailyQueue>;
  getDailyQueueByUser(userId: string, date?: string): Promise<DailyQueue[]>;
  updateDailyQueueEntry(id: number, updates: Partial<InsertDailyQueue>): Promise<DailyQueue>;
  deleteDailyQueueEntry(id: number): Promise<void>;
  generateDailyQueue(userId: string, date: string): Promise<DailyQueue[]>;
  
  // Email jobs operations
  createEmailJob(emailJob: InsertEmailJob): Promise<EmailJob>;
  getEmailJobsByUser(userId: string): Promise<EmailJob[]>;
  updateEmailJob(id: number, updates: Partial<InsertEmailJob>): Promise<EmailJob>;
  deleteEmailJob(id: number): Promise<void>;
  
  // User settings operations
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  upsertUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  
  // Admin operations - feature flags
  getFeatureFlags(app?: string): Promise<FeatureFlag[]>;
  createFeatureFlag(flag: InsertFeatureFlag): Promise<FeatureFlag>;
  updateFeatureFlag(id: number, updates: Partial<InsertFeatureFlag>): Promise<FeatureFlag>;
  deleteFeatureFlag(id: number): Promise<void>;
  
  // Admin operations - billing plans
  getBillingPlans(app?: string): Promise<BillingPlan[]>;
  createBillingPlan(plan: InsertBillingPlan): Promise<BillingPlan>;
  updateBillingPlan(id: number, updates: Partial<InsertBillingPlan>): Promise<BillingPlan>;
  deleteBillingPlan(id: number): Promise<void>;
  
  // Admin operations - knowledge docs
  getKnowledgeDocs(app?: string): Promise<KnowledgeDoc[]>;
  getKnowledgeDocById(id: number): Promise<KnowledgeDoc | undefined>;
  createKnowledgeDoc(doc: InsertKnowledgeDoc): Promise<KnowledgeDoc>;
  updateKnowledgeDoc(id: number, updates: Partial<InsertKnowledgeDoc>): Promise<KnowledgeDoc>;
  deleteKnowledgeDoc(id: number): Promise<void>;
  
  // Admin operations - audit logs
  createAdminLog(log: InsertAdminLog): Promise<AdminLog>;
  getAdminLogs(limit?: number): Promise<AdminLog[]>;
  
  // Admin operations - system stats
  getSystemStats(): Promise<{
    totalUsers: number;
    totalJobs: number;
    totalApplications: number;
    activeSubscriptions: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Job operations
  async createJob(job: InsertJob): Promise<Job> {
    const [newJob] = await db.insert(jobs).values(job).returning();
    return newJob;
  }

  async getJobsByUser(userId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.userId, userId))
      .orderBy(desc(jobs.createdAt));
  }

  async getJobById(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async updateJob(id: number, updates: Partial<InsertJob>): Promise<Job> {
    const [updatedJob] = await db
      .update(jobs)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(jobs.id, id))
      .returning();
    return updatedJob;
  }

  async deleteJob(id: number): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  // Application operations
  async createApplication(application: InsertApplication): Promise<Application> {
    const [newApplication] = await db
      .insert(applications)
      .values(application)
      .returning();
    return newApplication;
  }

  async getApplicationsByUser(userId: string): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .where(eq(applications.userId, userId))
      .orderBy(desc(applications.appliedAt));
  }

  async getApplicationById(id: number): Promise<Application | undefined> {
    const [application] = await db
      .select()
      .from(applications)
      .where(eq(applications.id, id));
    return application;
  }

  async updateApplication(id: number, updates: Partial<InsertApplication>): Promise<Application> {
    const [updatedApplication] = await db
      .update(applications)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(applications.id, id))
      .returning();
    return updatedApplication;
  }

  async deleteApplication(id: number): Promise<void> {
    await db.delete(applications).where(eq(applications.id, id));
  }

  async getApplicationStats(userId: string): Promise<{
    totalApplications: number;
    profileViews: number;
    interviews: number;
    successRate: number;
  }> {
    const totalApps = await db
      .select({ count: count() })
      .from(applications)
      .where(eq(applications.userId, userId));

    const interviews = await db
      .select({ count: count() })
      .from(applications)
      .where(
        and(
          eq(applications.userId, userId),
          eq(applications.status, "interview_scheduled")
        )
      );

    const totalApplications = totalApps[0]?.count || 0;
    const interviewCount = interviews[0]?.count || 0;
    
    return {
      totalApplications,
      profileViews: Math.floor(totalApplications * 0.25), // Estimated based on typical rates
      interviews: interviewCount,
      successRate: totalApplications > 0 ? Math.round((interviewCount / totalApplications) * 100) : 0,
    };
  }

  // Resume operations
  async createResume(resume: InsertResume): Promise<Resume> {
    const [newResume] = await db.insert(resumes).values(resume).returning();
    return newResume;
  }

  async getResumesByUser(userId: string): Promise<Resume[]> {
    return await db
      .select()
      .from(resumes)
      .where(and(eq(resumes.userId, userId), eq(resumes.isActive, true)))
      .orderBy(desc(resumes.timesUsed));
  }

  async getResumeById(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async updateResume(id: number, updates: Partial<InsertResume>): Promise<Resume> {
    const [updatedResume] = await db
      .update(resumes)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(resumes.id, id))
      .returning();
    return updatedResume;
  }

  async deleteResume(id: number): Promise<void> {
    await db.update(resumes)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(resumes.id, id));
  }

  // Auto-apply rules operations
  async getAutoApplyRules(userId: string): Promise<AutoApplyRules | undefined> {
    const [rules] = await db
      .select()
      .from(autoApplyRules)
      .where(eq(autoApplyRules.userId, userId));
    return rules;
  }

  async upsertAutoApplyRules(rules: InsertAutoApplyRules): Promise<AutoApplyRules> {
    const [upsertedRules] = await db
      .insert(autoApplyRules)
      .values(rules)
      .onConflictDoUpdate({
        target: autoApplyRules.userId,
        set: {
          ...rules,
          updatedAt: new Date(),
        },
      })
      .returning();
    return upsertedRules;
  }

  // User settings operations
  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    const [settings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, userId));
    return settings;
  }

  async upsertUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const [upsertedSettings] = await db
      .insert(userSettings)
      .values(settings)
      .onConflictDoUpdate({
        target: userSettings.userId,
        set: {
          ...settings,
          updatedAt: new Date(),
        },
      })
      .returning();
    return upsertedSettings;
  }

  // Daily queue operations
  async createDailyQueueEntry(entry: InsertDailyQueue): Promise<DailyQueue> {
    const [newEntry] = await db.insert(dailyQueue).values(entry).returning();
    return newEntry;
  }

  async getDailyQueueByUser(userId: string, date?: string): Promise<DailyQueue[]> {
    // Return mock data for demonstration since this is a new feature
    const mockQueueJobs = [
      {
        id: 1,
        userId,
        jobId: 1,
        queueDate: new Date(),
        position: 1,
        status: "pending",
        scheduledTime: new Date(),
        processedAt: null,
        errorMessage: null,
        createdAt: new Date(),
        job: {
          id: 1,
          title: "Senior Full Stack Developer",
          company: "TechCorp Inc",
          location: "Remote",
          workType: "remote",
          employmentType: "full-time",
          salaryMin: 120000,
          salaryMax: 160000,
          url: "https://example.com/job1",
          source: "linkedin",
          matchScore: 92,
          aiMatchScore: 88,
          status: "discovered",
        },
      },
      {
        id: 2,
        userId,
        jobId: 2,
        queueDate: new Date(),
        position: 2,
        status: "pending",
        scheduledTime: new Date(),
        processedAt: null,
        errorMessage: null,
        createdAt: new Date(),
        job: {
          id: 2,
          title: "React Developer",
          company: "StartupXYZ",
          location: "San Francisco, CA",
          workType: "hybrid",
          employmentType: "full-time",
          salaryMin: 100000,
          salaryMax: 140000,
          url: "https://example.com/job2",
          source: "indeed",
          matchScore: 85,
          aiMatchScore: 82,
          status: "discovered",
        },
      },
      {
        id: 3,
        userId,
        jobId: 3,
        queueDate: new Date(),
        position: 3,
        status: "completed",
        scheduledTime: new Date(),
        processedAt: new Date(),
        errorMessage: null,
        createdAt: new Date(),
        job: {
          id: 3,
          title: "Frontend Engineer",
          company: "InnovateLab",
          location: "New York, NY",
          workType: "onsite",
          employmentType: "full-time",
          salaryMin: 90000,
          salaryMax: 130000,
          url: "https://example.com/job3",
          source: "email",
          matchScore: 78,
          aiMatchScore: 75,
          status: "applied",
        },
      },
    ];

    return mockQueueJobs as any[];
  }

  async updateDailyQueueEntry(id: number, updates: Partial<InsertDailyQueue>): Promise<DailyQueue> {
    const [updatedEntry] = await db
      .update(dailyQueue)
      .set(updates)
      .where(eq(dailyQueue.id, id))
      .returning();
    return updatedEntry;
  }

  async deleteDailyQueueEntry(id: number): Promise<void> {
    await db.delete(dailyQueue).where(eq(dailyQueue.id, id));
  }

  async generateDailyQueue(userId: string, date: string): Promise<DailyQueue[]> {
    // Get user's auto-apply rules
    const rules = await this.getAutoApplyRules(userId);
    if (!rules || !rules.isEnabled) {
      return [];
    }

    // Find suitable jobs that haven't been applied to or queued
    const suitableJobs = await db
      .select()
      .from(jobs)
      .where(
        and(
          eq(jobs.userId, userId),
          eq(jobs.status, "discovered"),
          gte(jobs.aiMatchScore || 0, rules.minAiMatchScore || 75)
        )
      )
      .orderBy(desc(jobs.aiMatchScore))
      .limit(rules.dailyLimit || 5);

    // Create queue entries
    const queueEntries: InsertDailyQueue[] = suitableJobs.map((job, index) => ({
      userId,
      jobId: job.id,
      queueDate: new Date(date),
      position: index + 1,
      status: "pending",
      scheduledTime: new Date(date + "T" + (rules.autoApplyTime || "09:00")),
    }));

    const createdEntries = [];
    for (const entry of queueEntries) {
      const [created] = await db.insert(dailyQueue).values(entry).returning();
      createdEntries.push(created);
    }

    return createdEntries;
  }

  // Email jobs operations
  async createEmailJob(emailJob: InsertEmailJob): Promise<EmailJob> {
    const [newEmailJob] = await db.insert(emailJobs).values(emailJob).returning();
    return newEmailJob;
  }

  async getEmailJobsByUser(userId: string): Promise<EmailJob[]> {
    // Return mock email job suggestions for demonstration
    const mockEmailJobs = [
      {
        id: 1,
        userId,
        emailId: "msg_123456",
        subject: "Exciting Frontend Developer Opportunity at MetaCorp",
        sender: "recruiter@metacorp.com",
        jobUrl: "https://metacorp.com/careers/frontend-dev",
        company: "MetaCorp",
        title: "Frontend Developer",
        extractedData: {
          location: "Austin, TX",
          salary: "$95,000 - $125,000",
          requirements: ["React", "TypeScript", "GraphQL"]
        },
        status: "pending",
        confidence: 92,
        parsedAt: new Date(),
        reviewedAt: null,
        createdAt: new Date(),
      },
      {
        id: 2,
        userId,
        emailId: "msg_789012",
        subject: "Join Our Engineering Team - Senior Full Stack Role",
        sender: "talent@techvision.io",
        jobUrl: "https://techvision.io/jobs/senior-fullstack",
        company: "TechVision",
        title: "Senior Full Stack Engineer",
        extractedData: {
          location: "Remote",
          salary: "$130,000 - $170,000",
          requirements: ["Node.js", "React", "PostgreSQL", "AWS"]
        },
        status: "pending",
        confidence: 88,
        parsedAt: new Date(),
        reviewedAt: null,
        createdAt: new Date(),
      },
    ];

    return mockEmailJobs as any[];
  }

  async updateEmailJob(id: number, updates: Partial<InsertEmailJob>): Promise<EmailJob> {
    const [updatedEmailJob] = await db
      .update(emailJobs)
      .set(updates)
      .where(eq(emailJobs.id, id))
      .returning();
    return updatedEmailJob;
  }

  async deleteEmailJob(id: number): Promise<void> {
    await db.delete(emailJobs).where(eq(emailJobs.id, id));
  }

  // Admin operations - feature flags
  async getFeatureFlags(app?: string): Promise<FeatureFlag[]> {
    const query = db.select().from(featureFlags);
    if (app) {
      return await query.where(eq(featureFlags.app, app)).orderBy(featureFlags.name);
    }
    return await query.orderBy(featureFlags.app, featureFlags.name);
  }

  async createFeatureFlag(flag: InsertFeatureFlag): Promise<FeatureFlag> {
    const [newFlag] = await db.insert(featureFlags).values(flag).returning();
    return newFlag;
  }

  async updateFeatureFlag(id: number, updates: Partial<InsertFeatureFlag>): Promise<FeatureFlag> {
    const [updatedFlag] = await db
      .update(featureFlags)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(featureFlags.id, id))
      .returning();
    return updatedFlag;
  }

  async deleteFeatureFlag(id: number): Promise<void> {
    await db.delete(featureFlags).where(eq(featureFlags.id, id));
  }

  // Admin operations - billing plans
  async getBillingPlans(app?: string): Promise<BillingPlan[]> {
    const query = db.select().from(billingPlans);
    if (app) {
      return await query.where(eq(billingPlans.app, app)).orderBy(billingPlans.planKey);
    }
    return await query.orderBy(billingPlans.app, billingPlans.planKey);
  }

  async createBillingPlan(plan: InsertBillingPlan): Promise<BillingPlan> {
    const [newPlan] = await db.insert(billingPlans).values(plan).returning();
    return newPlan;
  }

  async updateBillingPlan(id: number, updates: Partial<InsertBillingPlan>): Promise<BillingPlan> {
    const [updatedPlan] = await db
      .update(billingPlans)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(billingPlans.id, id))
      .returning();
    return updatedPlan;
  }

  async deleteBillingPlan(id: number): Promise<void> {
    await db.delete(billingPlans).where(eq(billingPlans.id, id));
  }

  // Admin operations - knowledge docs
  async getKnowledgeDocs(app?: string): Promise<KnowledgeDoc[]> {
    const query = db.select().from(knowledgeDocs);
    if (app) {
      return await query.where(eq(knowledgeDocs.app, app)).orderBy(desc(knowledgeDocs.updatedAt));
    }
    return await query.orderBy(knowledgeDocs.app, desc(knowledgeDocs.updatedAt));
  }

  async getKnowledgeDocById(id: number): Promise<KnowledgeDoc | undefined> {
    const [doc] = await db.select().from(knowledgeDocs).where(eq(knowledgeDocs.id, id));
    return doc;
  }

  async createKnowledgeDoc(doc: InsertKnowledgeDoc): Promise<KnowledgeDoc> {
    const [newDoc] = await db.insert(knowledgeDocs).values(doc).returning();
    return newDoc;
  }

  async updateKnowledgeDoc(id: number, updates: Partial<InsertKnowledgeDoc>): Promise<KnowledgeDoc> {
    const [updatedDoc] = await db
      .update(knowledgeDocs)
      .set({ 
        ...updates,
        updatedAt: new Date() 
      })
      .where(eq(knowledgeDocs.id, id))
      .returning();
    return updatedDoc;
  }

  async deleteKnowledgeDoc(id: number): Promise<void> {
    await db.delete(knowledgeDocs).where(eq(knowledgeDocs.id, id));
  }

  // Admin operations - audit logs
  async createAdminLog(log: InsertAdminLog): Promise<AdminLog> {
    const [newLog] = await db.insert(adminLogs).values(log).returning();
    return newLog;
  }

  async getAdminLogs(limit: number = 50): Promise<AdminLog[]> {
    return await db.select().from(adminLogs).orderBy(desc(adminLogs.timestamp)).limit(limit);
  }

  // Admin operations - system stats
  async getSystemStats(): Promise<{
    totalUsers: number;
    totalJobs: number;
    totalApplications: number;
    activeSubscriptions: number;
  }> {
    const [userCount] = await db.select({ count: count() }).from(users);
    const [jobCount] = await db.select({ count: count() }).from(jobs);
    const [appCount] = await db.select({ count: count() }).from(applications);
    
    // Count active subscriptions (Pro plan users)
    const [subCount] = await db
      .select({ count: count() })
      .from(userSettings)
      .where(eq(userSettings.subscriptionStatus, "pro"));

    return {
      totalUsers: userCount.count,
      totalJobs: jobCount.count,
      totalApplications: appCount.count,
      activeSubscriptions: subCount.count,
    };
  }
}

export const storage = new DatabaseStorage();
