import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  decimal,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Job listings table
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location"),
  workType: text("work_type"), // remote, hybrid, onsite
  employmentType: text("employment_type"), // full-time, part-time, contract
  salaryMin: integer("salary_min"),
  salaryMax: integer("salary_max"),
  description: text("description"),
  requirements: jsonb("requirements"), // Array of skill requirements
  url: text("url"),
  source: text("source"), // linkedin, indeed, email, browser_extension, manual
  matchScore: integer("match_score"), // User-defined match score 0-100
  aiMatchScore: integer("ai_match_score"), // AI-calculated fit score 0-100
  status: text("status").default("discovered"), // discovered, queued, applying, applied, failed, rejected, interview
  queuePosition: integer("queue_position"), // Position in daily queue
  applicationMode: text("application_mode").default("manual"), // manual, scheduled, auto
  companyValues: jsonb("company_values"), // Extracted company values/culture
  hiringManager: text("hiring_manager"), // Detected hiring manager name
  techStack: jsonb("tech_stack"), // Required technologies
  retryCount: integer("retry_count").default(0),
  lastRetryAt: timestamp("last_retry_at"),
  failureReason: text("failure_reason"), // captcha, blocked, network_error, ats_incompatible
  queuedAt: timestamp("queued_at"), // When added to daily queue
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Applications table
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobId: integer("job_id").references(() => jobs.id),
  jobTitle: text("job_title").notNull(),
  company: text("company").notNull(),
  status: text("status").default("sent"), // sent, under_review, interview_scheduled, rejected, offer
  appliedAt: timestamp("applied_at").defaultNow(),
  resumeUsed: text("resume_used"),
  coverLetter: text("cover_letter"),
  notes: text("notes"),
  source: text("source"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resume library table
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  fileName: text("file_name"),
  skills: jsonb("skills"), // Array of skills
  experience: text("experience"),
  focus: text("focus"), // frontend, backend, fullstack, etc.
  matchHistory: jsonb("match_history"), // Historical match scores
  timesUsed: integer("times_used").default(0),
  isActive: boolean("is_active").default(true),
  externalId: text("external_id"), // ResumeFormatter.io ID
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Auto-apply rules table
export const autoApplyRules = pgTable("auto_apply_rules", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  isEnabled: boolean("is_enabled").default(false),
  jobTitles: jsonb("job_titles"), // Array of preferred job titles
  excludedKeywords: jsonb("excluded_keywords"), // Array of excluded keywords
  preferredLocations: jsonb("preferred_locations"), // Array of locations
  minSalary: integer("min_salary"),
  maxSalary: integer("max_salary"),
  workTypes: jsonb("work_types"), // Array: remote, hybrid, onsite
  employmentTypes: jsonb("employment_types"), // Array: full-time, part-time, contract
  experienceLevels: jsonb("experience_levels"), // Array: entry, mid, senior
  preferredCompanies: jsonb("preferred_companies"), // Array of company names
  blacklistedCompanies: jsonb("blacklisted_companies"), // Array of company names
  requiredTechStack: jsonb("required_tech_stack"), // Must-have technologies
  preferredTechStack: jsonb("preferred_tech_stack"), // Nice-to-have technologies
  dailyLimit: integer("daily_limit").default(5),
  minMatchScore: integer("min_match_score").default(80),
  minAiMatchScore: integer("min_ai_match_score").default(75),
  reviewMode: text("review_mode").default("review"), // manual, review, scheduled, auto
  autoApplyTime: text("auto_apply_time").default("09:00"), // When to run daily queue
  weekendApplications: boolean("weekend_applications").default(false),
  coverLetterTone: text("cover_letter_tone").default("professional"), // professional, friendly, enthusiastic
  retryFailedApplications: boolean("retry_failed_applications").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily queue management table
export const dailyQueue = pgTable("daily_queue", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobId: integer("job_id").notNull().references(() => jobs.id),
  queueDate: timestamp("queue_date").notNull(),
  position: integer("position").notNull(),
  status: text("status").default("pending"), // pending, processing, completed, failed, skipped
  scheduledTime: timestamp("scheduled_time"),
  processedAt: timestamp("processed_at"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Email parsing and job suggestions table
export const emailJobs = pgTable("email_jobs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  emailId: text("email_id").notNull(), // Gmail/Outlook message ID
  subject: text("subject").notNull(),
  sender: text("sender").notNull(),
  jobUrl: text("job_url"),
  company: text("company"),
  title: text("title"),
  extractedData: jsonb("extracted_data"), // Full parsed job details
  status: text("status").default("pending"), // pending, reviewed, added_to_queue, dismissed
  confidence: integer("confidence"), // AI confidence in extraction 0-100
  parsedAt: timestamp("parsed_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User settings table
export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  emailNotifications: boolean("email_notifications").default(true),
  pushNotifications: boolean("push_notifications").default(false),
  weeklyReport: boolean("weekly_report").default(true),
  resumeFormatterConnected: boolean("resume_formatter_connected").default(false),
  prepPairConnected: boolean("prep_pair_connected").default(false),
  emailParsingConnected: boolean("email_parsing_connected").default(false),
  nylasAccessToken: text("nylas_access_token"), // Encrypted email access token
  subscriptionStatus: text("subscription_status").default("free"), // free, pro
  dailyQueueEnabled: boolean("daily_queue_enabled").default(false),
  browserExtensionEnabled: boolean("browser_extension_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Support tickets table for AI agent integration
export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  brand: varchar("brand").notNull().default("applycaptain"),
  category: varchar("category").notNull(), // technical, billing, ai-assistance, job-search
  priority: varchar("priority").notNull().default("medium"), // low, medium, high, urgent
  status: varchar("status").notNull().default("open"), // open, in-progress, resolved, closed
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  resolution: text("resolution"),
  tags: text("tags").array().default([]),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Knowledge base articles for AI assistance
export const knowledgeArticles = pgTable("knowledge_articles", {
  id: serial("id").primaryKey(),
  brand: varchar("brand").notNull().default("applycaptain"),
  category: varchar("category").notNull(), // getting-started, features, troubleshooting
  title: text("title").notNull(),
  content: text("content").notNull(),
  summary: text("summary"),
  keywords: text("keywords").array().default([]),
  tags: text("tags").array().default([]),
  viewCount: integer("view_count").default(0),
  helpfulCount: integer("helpful_count").default(0),
  unhelpfulCount: integer("unhelpful_count").default(0),
  isPublished: boolean("is_published").default(true),
  authorId: varchar("author_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// WordPress blog cache table for WrelikBrands.com
export const cachedPosts = pgTable("cached_posts", {
  id: serial("id").primaryKey(),
  wpId: integer("wp_id").unique().notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  excerpt: text("excerpt"),
  content: text("content"),
  publishedAt: timestamp("published_at"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Feature flags for admin control across Wrelik Brands apps
export const featureFlags = pgTable("feature_flags", {
  id: serial("id").primaryKey(),
  app: text("app").notNull(), // ApplyCaptain, ResumeFormatter.io, PrepPair.me, NameDrop.cv
  name: text("name").notNull(),
  description: text("description"),
  enabled: boolean("enabled").default(false),
  planRequired: text("plan_required"), // free, pro_monthly, pro_quarterly
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Admin activity logs for audit trail
export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminId: varchar("admin_id").notNull().references(() => users.id),
  action: text("action").notNull(),
  target: text("target"), // feature_flag, billing_plan, knowledge_doc
  targetId: text("target_id"),
  changes: jsonb("changes"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Knowledge base documents (admin-only, version controlled)
export const knowledgeDocs = pgTable("knowledge_docs", {
  id: serial("id").primaryKey(),
  app: text("app").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  version: integer("version").default(1),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  updatedBy: varchar("updated_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Billing plans configuration with Stripe integration
export const billingPlans = pgTable("billing_plans", {
  id: serial("id").primaryKey(),
  app: text("app").notNull(),
  planKey: text("plan_key").notNull(), // free, pro_monthly, pro_quarterly
  stripePriceId: text("stripe_price_id"),
  displayName: text("display_name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }),
  currency: text("currency").default("USD"),
  interval: text("interval"), // month, year, null for free
  features: text("features").array(),
  isActive: boolean("is_active").default(true),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  jobs: many(jobs),
  applications: many(applications),
  resumes: many(resumes),
  dailyQueue: many(dailyQueue),
  emailJobs: many(emailJobs),
  supportTickets: many(supportTickets),
  knowledgeArticles: many(knowledgeArticles),
  autoApplyRules: one(autoApplyRules),
  settings: one(userSettings),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  user: one(users, { fields: [jobs.userId], references: [users.id] }),
  application: one(applications),
  queueEntry: one(dailyQueue),
}));

export const applicationsRelations = relations(applications, ({ one }) => ({
  user: one(users, { fields: [applications.userId], references: [users.id] }),
  job: one(jobs, { fields: [applications.jobId], references: [jobs.id] }),
}));

export const resumesRelations = relations(resumes, ({ one }) => ({
  user: one(users, { fields: [resumes.userId], references: [users.id] }),
}));

export const dailyQueueRelations = relations(dailyQueue, ({ one }) => ({
  user: one(users, { fields: [dailyQueue.userId], references: [users.id] }),
  job: one(jobs, { fields: [dailyQueue.jobId], references: [jobs.id] }),
}));

export const emailJobsRelations = relations(emailJobs, ({ one }) => ({
  user: one(users, { fields: [emailJobs.userId], references: [users.id] }),
}));

export const autoApplyRulesRelations = relations(autoApplyRules, ({ one }) => ({
  user: one(users, { fields: [autoApplyRules.userId], references: [users.id] }),
}));

export const userSettingsRelations = relations(userSettings, ({ one }) => ({
  user: one(users, { fields: [userSettings.userId], references: [users.id] }),
}));

export const supportTicketsRelations = relations(supportTickets, ({ one }) => ({
  user: one(users, { fields: [supportTickets.userId], references: [users.id] }),
}));

export const knowledgeArticlesRelations = relations(knowledgeArticles, ({ one }) => ({
  author: one(users, { fields: [knowledgeArticles.authorId], references: [users.id] }),
}));

// Insert schemas
export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertResumeSchema = createInsertSchema(resumes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDailyQueueSchema = createInsertSchema(dailyQueue).omit({
  id: true,
  createdAt: true,
});

export const insertEmailJobSchema = createInsertSchema(emailJobs).omit({
  id: true,
  createdAt: true,
});

export const insertAutoApplyRulesSchema = createInsertSchema(autoApplyRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  resolvedAt: true,
});

export const insertKnowledgeArticleSchema = createInsertSchema(knowledgeArticles).omit({
  id: true,
  viewCount: true,
  helpfulCount: true,
  unhelpfulCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCachedPostSchema = createInsertSchema(cachedPosts).omit({
  id: true,
  updatedAt: true,
});

export const insertFeatureFlagSchema = createInsertSchema(featureFlags).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({
  id: true,
  timestamp: true,
});

export const insertKnowledgeDocSchema = createInsertSchema(knowledgeDocs).omit({
  id: true,
  version: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBillingPlanSchema = createInsertSchema(billingPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type DailyQueue = typeof dailyQueue.$inferSelect;
export type InsertDailyQueue = z.infer<typeof insertDailyQueueSchema>;
export type EmailJob = typeof emailJobs.$inferSelect;
export type InsertEmailJob = z.infer<typeof insertEmailJobSchema>;
export type AutoApplyRules = typeof autoApplyRules.$inferSelect;
export type InsertAutoApplyRules = z.infer<typeof insertAutoApplyRulesSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
export type KnowledgeArticle = typeof knowledgeArticles.$inferSelect;
export type InsertKnowledgeArticle = z.infer<typeof insertKnowledgeArticleSchema>;
export type CachedPost = typeof cachedPosts.$inferSelect;
export type InsertCachedPost = z.infer<typeof insertCachedPostSchema>;
export type FeatureFlag = typeof featureFlags.$inferSelect;
export type InsertFeatureFlag = z.infer<typeof insertFeatureFlagSchema>;
export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;
export type KnowledgeDoc = typeof knowledgeDocs.$inferSelect;
export type InsertKnowledgeDoc = z.infer<typeof insertKnowledgeDocSchema>;
export type BillingPlan = typeof billingPlans.$inferSelect;
export type InsertBillingPlan = z.infer<typeof insertBillingPlanSchema>;
