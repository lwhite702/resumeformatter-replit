# PrepPair Technical Implementation Guide
*Version 2.0 - January 2025*

## Architecture Overview

### Frontend Stack
- **React 18** with TypeScript for type safety
- **Vite** for fast development and optimized builds
- **Tailwind CSS** with shadcn/ui component library
- **Wouter** for lightweight client-side routing
- **TanStack Query** for state management and data fetching
- **Framer Motion** for animations and transitions

### Backend Infrastructure
- **Express.js** with TypeScript for API development
- **Drizzle ORM** with PostgreSQL for database management
- **OpenAI API** for AI-powered features
- **Stripe** for payment processing and subscription management
- **Passport.js** with OpenID Connect for authentication

### Database Schema
The platform uses a comprehensive PostgreSQL schema supporting:
- User authentication and profiles
- Resume storage and optimization tracking
- Job applications and status management
- Interview practice sessions and recordings
- Subscription and billing management
- Analytics and performance metrics

## Enhanced User Experience Components

### 1. Enhanced Tooltip System
**File**: `/client/src/components/ui/enhanced-tooltip.tsx`

```typescript
interface EnhancedTooltipProps {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  action?: {
    label: string;
    onClick: () => void;
  };
  side?: "top" | "right" | "bottom" | "left";
  children: React.ReactNode;
}
```

**Key Features**:
- Smart positioning with viewport detection
- Rich content support with icons and actions
- Accessibility compliance with ARIA attributes
- Performance optimization with lazy rendering
- Responsive design for mobile devices

**Implementation Pattern**:
```typescript
<EnhancedTooltip
  title="Feature Name"
  description="Detailed explanation of functionality"
  icon={<Icon className="w-4 h-4" />}
  action={{
    label: "Try Now",
    onClick: () => handleAction()
  }}
>
  <TriggerElement />
</EnhancedTooltip>
```

### 2. Multi-Step Onboarding Wizard
**File**: `/client/src/components/onboarding-wizard.tsx`

**Data Structure**:
```typescript
interface OnboardingData {
  personalInfo: {
    firstName: string;
    lastName: string;
    currentRole: string;
    experience: string;
    targetRole: string;
    targetCompany: string;
    timeline: string;
  };
  preferences: {
    industries: string[];
    jobTypes: string[];
    priorities: string[];
  };
  goals: {
    primaryGoal: string;
    specificChallenges: string[];
    preparation: string;
  };
}
```

**Validation System**:
- Real-time form validation with Zod schemas
- Progressive disclosure of form fields
- Smart defaults based on user selections
- Error handling with helpful guidance
- Data persistence across sessions

### 3. Progressive Disclosure System
**File**: `/client/src/components/progressive-disclosure.tsx`

**Feature Unlocking Logic**:
```typescript
const steps: FeatureStep[] = [
  {
    id: 'getting-started',
    title: 'Getting Started',
    isCompleted: progress.onboardingCompleted && progress.resumeUploaded,
    isLocked: false,
    requirements: ['complete onboarding', 'upload resume']
  },
  {
    id: 'interview-prep',
    title: 'Interview Preparation',
    isCompleted: progress.firstPracticeCompleted,
    isLocked: !steps[0].isCompleted,
    requirements: ['complete 5 practice questions']
  }
];
```

**Benefits**:
- Reduces cognitive load for new users
- Increases feature adoption rates
- Provides clear progression pathway
- Maintains user motivation through achievements
- Adapts to individual user pace

### 4. Smart Notification System
**File**: `/client/src/components/smart-notifications.tsx`

**Notification Intelligence**:
```typescript
interface SmartNotification {
  id: string;
  type: 'tip' | 'reminder' | 'achievement' | 'suggestion';
  title: string;
  message: string;
  priority: 'low' | 'medium' | 'high';
  triggerConditions: {
    userInactive?: number; // hours
    featureUnused?: string;
    progressStalled?: boolean;
    achievement?: string;
  };
}
```

**Behavioral Triggers**:
- Time-based reminders for inactive users
- Feature discovery for unused capabilities
- Achievement celebrations for milestones
- Contextual tips based on current activity
- Personalized recommendations from usage patterns

### 5. Performance Monitoring
**File**: `/client/src/components/performance-monitor.tsx`

**Metrics Collection**:
```typescript
interface PerformanceMetrics {
  loadTime: number;
  renderTime: number;
  apiResponseTime: number;
  memoryUsage: number;
  networkLatency: number;
  cacheHitRate: number;
  errorRate: number;
  userInteractions: number;
}
```

**Optimization Suggestions**:
- Automatic performance issue detection
- Real-time optimization recommendations
- Resource usage monitoring
- Network efficiency analysis
- User experience impact assessment

### 6. Conversion Optimization
**File**: `/client/src/components/conversion-optimizer.tsx`

**Analytics Tracking**:
```typescript
interface ConversionFunnel {
  step: string;
  visitors: number;
  conversions: number;
  rate: number;
  optimizations: string[];
}
```

**Optimization Strategies**:
- A/B testing framework integration
- Social proof element positioning
- Urgency and scarcity messaging
- Feature adoption improvement
- User journey optimization

## API Integration Patterns

### Authentication Flow
```typescript
// Replit OAuth integration
app.get('/api/login', passport.authenticate('replitauth'));
app.get('/api/callback', passport.authenticate('replitauth', {
  successReturnToOrRedirect: '/',
  failureRedirect: '/api/login'
}));
```

### Data Fetching Patterns
```typescript
// TanStack Query implementation
const { data: user, isLoading } = useQuery({
  queryKey: ['/api/auth/user'],
  retry: false,
  staleTime: 5 * 60 * 1000, // 5 minutes
});
```

### Error Handling
```typescript
// Centralized error handling
const handleAPIError = (error: Error) => {
  if (isUnauthorizedError(error)) {
    toast({
      title: "Session Expired",
      description: "Please log in again",
      variant: "destructive"
    });
    window.location.href = '/api/login';
  }
};
```

## Database Integration

### Drizzle ORM Schema
```typescript
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  onboardingCompleted: boolean("onboarding_completed").default(false),
  resumeUploaded: boolean("resume_uploaded").default(false),
  firstPracticeCompleted: boolean("first_practice_completed").default(false),
  featuresUnlocked: jsonb("features_unlocked").default([]),
  lastActiveAt: timestamp("last_active_at").defaultNow(),
});
```

### Migration Strategy
```bash
# Database schema updates
npm run db:push

# Generate migrations for production
npm run db:generate
npm run db:migrate
```

## Performance Optimization

### Code Splitting
```typescript
// Lazy loading components
const ResumeOptimizer = lazy(() => import('./pages/resume-optimizer'));
const InterviewGuide = lazy(() => import('./pages/interview-guide'));

// Route-based splitting
<Route path="/resume-optimizer">
  <Suspense fallback={<LoadingSpinner />}>
    <ResumeOptimizer />
  </Suspense>
</Route>
```

### Caching Strategy
```typescript
// TanStack Query caching
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
    },
  },
});
```

### Image Optimization
```typescript
// Responsive image loading
<img
  src={`${imageUrl}?w=400&h=300&fit=crop`}
  srcSet={`
    ${imageUrl}?w=200&h=150&fit=crop 200w,
    ${imageUrl}?w=400&h=300&fit=crop 400w,
    ${imageUrl}?w=800&h=600&fit=crop 800w
  `}
  sizes="(max-width: 768px) 200px, (max-width: 1024px) 400px, 800px"
  loading="lazy"
  alt="Description"
/>
```

## Security Implementation

### Authentication Security
```typescript
// Session configuration
const sessionConfig = {
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  },
};
```

### Data Validation
```typescript
// Zod schema validation
const userUpdateSchema = z.object({
  firstName: z.string().min(1).max(50),
  lastName: z.string().min(1).max(50),
  email: z.string().email(),
  preferences: z.object({
    industries: z.array(z.string()),
    jobTypes: z.array(z.string()),
  }),
});
```

### API Security
```typescript
// Rate limiting
import rateLimit from 'express-rate-limit';

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP',
});

app.use('/api/', apiLimiter);
```

## Testing Strategy

### Unit Testing
```typescript
// Component testing with React Testing Library
import { render, screen, fireEvent } from '@testing-library/react';
import { OnboardingWizard } from './onboarding-wizard';

test('completes onboarding flow', async () => {
  const onComplete = jest.fn();
  render(<OnboardingWizard isOpen={true} onComplete={onComplete} />);
  
  // Test form interactions
  fireEvent.change(screen.getByLabelText('First Name'), {
    target: { value: 'John' }
  });
  
  // Verify completion
  expect(onComplete).toHaveBeenCalled();
});
```

### Integration Testing
```typescript
// API endpoint testing
import request from 'supertest';
import { app } from '../server/index';

describe('User API', () => {
  test('GET /api/auth/user returns user data', async () => {
    const response = await request(app)
      .get('/api/auth/user')
      .set('Authorization', 'Bearer valid-token')
      .expect(200);
    
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('email');
  });
});
```

## Deployment Configuration

### Environment Variables
```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/preppair

# Authentication
SESSION_SECRET=your-session-secret
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc

# AI Services
OPENAI_API_KEY=your-openai-key

# Payment Processing
STRIPE_SECRET_KEY=sk_test_your-stripe-key
VITE_STRIPE_PUBLIC_KEY=pk_test_your-stripe-public-key

# Performance
NODE_ENV=production
PORT=5000
```

### Build Optimization
```typescript
// Vite configuration
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['@radix-ui/react-dialog', '@radix-ui/react-tooltip'],
          utils: ['date-fns', 'zod', 'clsx'],
        },
      },
    },
    chunkSizeWarningLimit: 1000,
  },
  optimizeDeps: {
    include: ['react', 'react-dom', '@tanstack/react-query'],
  },
});
```

## Monitoring and Analytics

### Error Tracking
```typescript
// Error boundary implementation
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Application error:', error, errorInfo);
    // Send to monitoring service
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback />;
    }
    return this.props.children;
  }
}
```

### Performance Metrics
```typescript
// Performance monitoring
const observer = new PerformanceObserver((list) => {
  for (const entry of list.getEntries()) {
    if (entry.entryType === 'measure') {
      console.log(`${entry.name}: ${entry.duration}ms`);
    }
  }
});

observer.observe({ entryTypes: ['measure', 'navigation'] });
```

This technical implementation guide provides comprehensive coverage of the enhanced PrepPair platform architecture, focusing on the new user experience components, performance optimizations, and best practices for maintaining and extending the system.