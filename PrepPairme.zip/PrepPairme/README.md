# PrepPair.me v3 - AI-Powered Interview Preparation & Career Development

A cutting-edge AI-powered career development platform that transforms job application and professional growth through intelligent, interactive technologies.

## 🚀 Features

### Core Functionality
- **AI Interview Guide Generator** - Create personalized interview preparation materials using job descriptions and resume analysis
- **Resume Optimizer** - ATS-friendly resume analysis with keyword optimization and improvement suggestions
- **Job Application Tracker** - Comprehensive pipeline management for job applications and interview scheduling
- **Career Mood Board** - Emotional journey tracking with reflection prompts and progress visualization
- **Video Practice** - Record and analyze interview performance with AI feedback
- **Questions Database** - Extensive library of interview questions across industries and roles

### Advanced Features
- **Job Board Integrations** - Sync applications from LinkedIn, Indeed, and other platforms
- **Email Intelligence** - Automatic parsing of job-related emails and application updates
- **Skill Extraction** - One-click skill highlights generator from resume content
- **AI Fine-tuning** - Industry-specific AI model optimization for targeted preparation
- **WrelikBrands Blog Integration** - Career development content with PrepPair.me styling

### User Experience
- **Interactive Onboarding** - 3-step guided tour with feature discovery
- **Accessibility-Friendly Theme Toggle** - Light/Dark/System themes with smooth transitions
- **Contextual Feature Tooltips** - Progressive feature discovery system
- **Comprehensive Knowledge Base** - Detailed guides and tutorials
- **Mobile-Responsive Design** - Optimized for all devices

## 🛠 Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling and development
- **Tailwind CSS** for styling
- **shadcn/ui** component library
- **Aceternity UI** for advanced animations
- **Framer Motion** for smooth transitions
- **React Query** for state management
- **Wouter** for routing

### Backend
- **Express.js** with TypeScript
- **PostgreSQL** database
- **Drizzle ORM** for database operations
- **OpenAI API** for AI-powered features
- **Passport.js** for OAuth authentication
- **Node.js** runtime environment

### Infrastructure
- **Replit** for development and hosting
- **PostgreSQL** for data persistence
- **OAuth** authentication with multiple providers
- **RESTful API** architecture

## 📋 Prerequisites

- Node.js 18+ 
- PostgreSQL database
- OpenAI API key
- OAuth provider credentials (Google, GitHub, etc.)

## 🚦 Getting Started

### Installation

1. Clone the repository:
```bash
git clone https://github.com/lwhite702/PrepPairmev3.git
cd PrepPairmev3
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

4. Configure your `.env` file:
```env
DATABASE_URL=your_postgresql_connection_string
OPENAI_API_KEY=your_openai_api_key
OAUTH_CLIENT_ID=your_oauth_client_id
OAUTH_CLIENT_SECRET=your_oauth_client_secret
SESSION_SECRET=your_session_secret
```

5. Run database migrations:
```bash
npm run db:push
```

6. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 📁 Project Structure

```
PrepPairmev3/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Application pages
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utility functions
├── server/                # Backend Express application
│   ├── routes.ts          # API route definitions
│   ├── db.ts              # Database configuration
│   ├── openai.ts          # OpenAI integration
│   └── storage.ts         # Data access layer
├── shared/                # Shared types and schemas
│   └── schema.ts          # Database schema definitions
├── knowledgebase/         # Documentation and guides
└── attached_assets/       # Static assets and branding
```

## 🔧 Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run db:push      # Push schema changes to database
npm run db:studio    # Open Drizzle Studio
npm run type-check   # Run TypeScript checks
```

## 🎯 Key Features Implementation

### Authentication System
- OAuth integration with multiple providers
- Secure session management
- User profile and preference storage

### AI-Powered Interview Preparation
- OpenAI GPT integration for content generation
- Industry-specific question databases
- STAR method story generation
- Personalized improvement suggestions

### Resume Optimization
- ATS score calculation
- Keyword density analysis
- Bullet point improvement suggestions
- Skills extraction and highlighting

### Job Application Management
- Application status tracking
- Interview scheduling
- Company research integration
- Progress analytics and insights

### Emotional Journey Tracking
- Mood logging with emoji interface
- Reflection prompt system
- Progress visualization
- Goal setting and tracking

## 🔐 Security Features

- Secure OAuth authentication
- Session-based user management
- Environment variable protection
- SQL injection prevention with Drizzle ORM
- XSS protection with Content Security Policy

## 🎨 Design System

### Branding
- Official PrepPair.me logo with purple/cyan gradient
- Consistent color scheme across all components
- Professional typography with Roboto font family
- Accessibility-compliant contrast ratios

### Theme System
- Light/Dark/System theme options
- Smooth transitions between themes
- WCAG 2.1 AA accessibility compliance
- Keyboard navigation support

## 📱 Mobile Optimization

- Responsive design for all screen sizes
- Touch-friendly interface elements
- Progressive Web App capabilities
- Optimized performance on mobile devices

## 🔄 API Integration

### External Services
- OpenAI for AI-powered content generation
- Job board APIs for application syncing
- Email service providers for automated parsing
- OAuth providers for authentication

### Internal APIs
- RESTful endpoint structure
- Comprehensive error handling
- Rate limiting and security measures
- Detailed API documentation

## 📊 Analytics & Monitoring

- User engagement tracking
- Feature adoption metrics
- Performance monitoring
- Error logging and reporting

## 🚀 Deployment

### Production Setup
1. Set up PostgreSQL database
2. Configure environment variables
3. Run database migrations
4. Build the application
5. Deploy to your hosting platform

### Environment Configuration
- Production database connection
- API key management
- OAuth provider setup
- Security headers configuration

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Email: support@preppair.me
- GitHub Issues: [Create an issue](https://github.com/lwhite702/PrepPairmev3/issues)
- Documentation: Available in the `/knowledgebase` directory

## 🏆 Acknowledgments

- OpenAI for AI capabilities
- shadcn/ui for component library
- Aceternity UI for advanced animations
- The React and Node.js communities
- All contributors and beta testers

---

**PrepPair.me** - Transforming careers through intelligent interview preparation and professional development tools.