# WordPress Blog Post Caching System Implementation

## Overview
Successfully implemented a comprehensive WordPress blog post caching system for WrelikBrands.com integration with PrepPair's unified support platform. The system fetches blog posts from WordPress REST API and caches them in PostgreSQL for improved performance.

## Implementation Details

### Core Components

1. **WordPress Caching Script** (`server/cacheWpPosts.ts`)
   - Fetches posts from WordPress REST API
   - Cleans HTML content and sanitizes data
   - Stores posts in PostgreSQL with upsert functionality
   - Handles SSL certificate issues for problematic domains
   - Configurable API endpoints via environment variables

2. **Database Schema** 
   - Table: `cached_posts`
   - Fields: id, wp_id, title, slug, excerpt, content, published_at, updated_at
   - Indexes on wp_id and published_at for performance
   - Automatic table creation and migration handling

3. **API Endpoints** (Added to `server/routes.ts`)
   - `GET /api/wp-posts` - Retrieve cached posts (public)
   - `POST /api/wp-posts/refresh` - Manual cache refresh (admin only)
   - Query parameters: limit (default 10)

4. **Background Script** (`server/wp-cache-runner.js`)
   - Standalone runner for cron job execution
   - Error handling and logging
   - Can be scheduled via cron for automatic updates

## Configuration

### Environment Variables
```bash
# Required
DATABASE_URL=postgresql://username:password@host:port/database

# Optional - WordPress API Configuration
WORDPRESS_API_URL=https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date
```

### Cron Job Setup (Example)
```bash
# Update WordPress cache every 6 hours
0 */6 * * * cd /path/to/project && node server/wp-cache-runner.js >> logs/wp-cache.log 2>&1
```

## Features

### Data Processing
- HTML tag removal and content sanitization
- HTML entity decoding (quotes, ampersands, etc.)
- Whitespace normalization
- Duplicate post handling via upsert operations

### Security & Reliability
- SSL certificate validation bypass for specific domains
- Custom User-Agent headers
- Error handling and connection pooling
- Transaction safety for database operations

### Performance Optimizations
- Database indexing on frequently queried fields
- Connection pooling for PostgreSQL
- Efficient upsert operations
- Configurable result limits

## Testing Results

### Successful Test Run
```
✅ Successfully tested with TechCrunch WordPress API
✅ Cached 10 posts from live WordPress site
✅ Database table creation and indexing working
✅ API endpoints responding correctly
✅ Content sanitization functioning properly
```

### Sample Cached Posts
1. After Shopify bought his last startup, Birk Jernström wants to help developers build one-person unicorns
2. Police shut down Cluely's party, the 'cheat at everything' startup  
3. Sam Altman says Meta tried and failed to poach OpenAI's talent with $100M offers
4. OpenAI's $200M DoD contract could squeeze frenemy Microsoft
5. EVs dominate the most American-made cars index and it's not just because of Tesla

## Integration Points

### WrelikBrands.com Setup
For WrelikBrands.com integration, configure:
```bash
WORDPRESS_API_URL=https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date
```

**Note**: If WrelikBrands.com doesn't have WordPress REST API enabled, the WordPress administrator needs to:
1. Enable WordPress REST API
2. Ensure the `/wp-json/wp/v2/posts` endpoint is accessible
3. Configure CORS if needed for cross-domain requests

### Unified Support Desk Integration
- Posts are cached in `cached_posts` table
- API endpoints provide JSON responses for frontend integration
- Admin-only refresh capability for manual updates
- Public endpoint for displaying recent blog posts

## Usage Instructions

### Manual Cache Update
```bash
# Direct script execution
cd server && npx tsx cacheWpPosts.ts

# Via background runner
node server/wp-cache-runner.js
```

### API Usage Examples
```bash
# Get recent posts
curl "https://preppair.me/api/wp-posts?limit=5"

# Admin refresh cache
curl -X POST "https://preppair.me/api/wp-posts/refresh" \
  -H "Authorization: Bearer <admin-token>"
```

### Response Format
```json
{
  "success": true,
  "posts": [
    {
      "wp_id": 123456,
      "title": "Blog Post Title",
      "slug": "blog-post-slug",
      "excerpt": "Post excerpt...",
      "published_at": "2025-06-17T10:30:00.000Z",
      "updated_at": "2025-06-18T11:02:15.123Z"
    }
  ],
  "count": 1,
  "cached": true
}
```

## Maintenance

### Monitoring
- Check logs for failed API calls
- Monitor database table size growth
- Verify cron job execution status
- Monitor API endpoint response times

### Troubleshooting
- **SSL Issues**: System handles certificate problems automatically
- **API 404 Errors**: Verify WordPress REST API is enabled on target site
- **Database Errors**: Check PostgreSQL connection and permissions
- **Rate Limiting**: Implement delays if WordPress site has rate limits

## Security Considerations
- Admin authentication required for cache refresh endpoint
- SQL injection prevention via parameterized queries
- Content sanitization to prevent XSS attacks
- Secure database connection handling

## Next Steps
1. Configure WrelikBrands.com WordPress REST API access
2. Set up production cron job for automatic updates
3. Monitor performance and adjust caching frequency as needed
4. Integrate cached posts into PrepPair's unified support interface