import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { ErrorBoundary } from "react-error-boundary";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { AtlasClientProvider } from "./atlas";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Landing from "@/pages/landing";
import SocialLanding from "@/pages/landing-social";
import AdsLanding from "@/pages/landing-ads";
import WrelikLanding from "@/pages/landing-wrelik";
import MarketingAnalytics from "@/pages/marketing-analytics";
import { SmartLandingRouter } from "@/components/smart-landing-router";
import Dashboard from "@/pages/dashboard";
import Features from "@/pages/features";
import Pricing from "@/pages/pricing";
import QuestionsDatabase from "@/pages/questions-database";
import AIFineTuning from "@/pages/ai-fine-tuning";
import TermsGlossary from "@/pages/terms-glossary";
import Blog from "@/pages/blog";
import BlogPost from "@/pages/blog-post";
import Newsletter from "@/pages/newsletter";
import Subscribe from "@/pages/subscribe";
import Checkout from "@/pages/checkout";
import CheckoutSuccess from "@/pages/checkout-success";
import CareerVisualization from "@/pages/career-visualization";
import InterviewGuide from "@/pages/interview-guide";
import ResumeOptimizer from "@/pages/resume-optimizer";
import JobTracker from "@/pages/job-tracker";
import JobTracking from "@/pages/job-tracking";
import JobBoardIntegrations from "@/pages/job-board-integrations";
import VideoPractice from "@/pages/video-practice";
import VideoPracticeEnhanced from "@/pages/video-practice-enhanced";
import SkillHighlights from "@/pages/skill-highlights";
import ResumeImport from "@/pages/resume-import";
import CareerMoodBoard from "@/pages/career-mood-board";
import AdminDashboard from "@/pages/admin-dashboard";
import SupportApiTest from "@/pages/support-api-test";
import BrandingDemo from "@/pages/branding-demo";
import KnowledgeBaseGuide from "@/pages/knowledge-base-guide";
import HelpCenter from "@/pages/help-center";
import ClerkLanding from "@/pages/clerk-landing";
import AuthDemo from "@/pages/auth-demo";
import AutoApplyIntegration from "@/pages/autoapply-integration";
import { ClerkSignIn } from "@/components/clerk-signin";
import TravelConnectSignIn from "@/components/ui/travel-connect-signin-1";
import SignInPage from "@/pages/sign-in";
import SignUpPage from "@/pages/sign-up";
import Legal from "@/pages/legal";
import AdminPortal from "@/pages/admin-portal";
import AdminSettings from "@/pages/admin-settings";
import AdminKnowledgeFile from "@/pages/admin-knowledge-file";
import PremiumFeatures from "@/pages/premium-features";
import NotFound from "@/pages/not-found";

function ErrorFallback({error}: {error: Error}) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-destructive mb-4">Something went wrong</h2>
        <p className="text-muted-foreground mb-4">{error.message}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
        >
          Reload page
        </button>
      </div>
    </div>
  );
}

function AuthenticatedRoute({ component: Component, fallback: Fallback, ...props }: any) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  try {
    return isAuthenticated ? <Component {...props} /> : <Fallback {...props} />;
  } catch (error) {
    console.error('AuthenticatedRoute error:', error);
    return <Fallback {...props} />;
  }
}

function Router() {
  return (
    <Switch>
      {/* Specialized Landing Pages */}
      <Route path="/landing/social" component={SocialLanding} />
      <Route path="/landing/ads" component={AdsLanding} />
      <Route path="/landing/wrelik" component={WrelikLanding} />
      
      {/* Public routes - always accessible */}
      <Route path="/features" component={Features} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/premium-features" component={PremiumFeatures} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route path="/newsletter" component={Newsletter} />
      <Route path="/terms-glossary" component={TermsGlossary} />
      <Route path="/legal" component={Legal} />
      
      {/* Authentication-based root route with smart landing detection */}
      <Route path="/" component={() => (
        <AuthenticatedRoute component={Dashboard} fallback={SmartLandingRouter} />
      )} />
      
      {/* Basic authenticated routes - free tier */}
      <Route path="/dashboard" component={() => (
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      )} />
      
      <Route path="/questions-database" component={() => (
        <ProtectedRoute feature="basic_interview_prep">
          <QuestionsDatabase />
        </ProtectedRoute>
      )} />
      
      <Route path="/help-center" component={() => (
        <ProtectedRoute>
          <HelpCenter />
        </ProtectedRoute>
      )} />

      {/* Pro plan required routes */}
      <Route path="/interview-guide" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="advanced_interview_prep">
          <InterviewGuide />
        </ProtectedRoute>
      )} />
      
      <Route path="/resume-optimizer" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="resume_optimization">
          <ResumeOptimizer />
        </ProtectedRoute>
      )} />
      
      <Route path="/job-tracker" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="job_tracking">
          <JobTracker />
        </ProtectedRoute>
      )} />
      
      <Route path="/job-tracking" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="job_tracking">
          <JobTracking />
        </ProtectedRoute>
      )} />
      
      <Route path="/video-practice" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="video_practice">
          <VideoPracticeEnhanced />
        </ProtectedRoute>
      )} />
      
      <Route path="/skill-highlights" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="skill_extraction">
          <SkillHighlights />
        </ProtectedRoute>
      )} />
      
      <Route path="/resume-import" component={() => (
        <ProtectedRoute requiredPlan="pro">
          <ResumeImport />
        </ProtectedRoute>
      )} />

      {/* Career Coach plan required routes */}
      <Route path="/ai-tuning" component={() => (
        <ProtectedRoute requiredPlan="career_coach" feature="ai_fine_tuning">
          <AIFineTuning />
        </ProtectedRoute>
      )} />
      
      <Route path="/career-visualization" component={() => (
        <ProtectedRoute requiredPlan="career_coach" feature="career_visualization">
          <CareerVisualization />
        </ProtectedRoute>
      )} />
      
      <Route path="/job-board-integrations" component={() => (
        <ProtectedRoute requiredPlan="career_coach" feature="job_board_integrations">
          <JobBoardIntegrations />
        </ProtectedRoute>
      )} />
      
      <Route path="/career-mood-board" component={() => (
        <ProtectedRoute requiredPlan="career_coach">
          <CareerMoodBoard />
        </ProtectedRoute>
      )} />

      {/* Admin only routes */}
      <Route path="/admin" component={() => (
        <ProtectedRoute requiredRole="admin">
          <AdminPortal />
        </ProtectedRoute>
      )} />
      
      <Route path="/admin/dashboard" component={() => (
        <ProtectedRoute requiredRole="admin">
          <AdminDashboard />
        </ProtectedRoute>
      )} />
      
      <Route path="/admin/settings" component={() => (
        <ProtectedRoute requiredRole="admin">
          <AdminSettings />
        </ProtectedRoute>
      )} />
      
      <Route path="/admin/content/knowledge-file" component={() => (
        <ProtectedRoute requiredRole="admin">
          <AdminKnowledgeFile />
        </ProtectedRoute>
      )} />
      
      <Route path="/admin/marketing-analytics" component={() => (
        <ProtectedRoute requiredRole="admin">
          <MarketingAnalytics />
        </ProtectedRoute>
      )} />
      
      <Route path="/admin-dashboard" component={() => (
        <ProtectedRoute requiredRole="admin" feature="admin_dashboard">
          <AdminDashboard />
        </ProtectedRoute>
      )} />

      {/* Payment and subscription routes */}
      <Route path="/subscribe" component={() => (
        <ProtectedRoute>
          <Subscribe />
        </ProtectedRoute>
      )} />
      
      <Route path="/checkout" component={() => (
        <ProtectedRoute>
          <Checkout />
        </ProtectedRoute>
      )} />
      
      <Route path="/checkout/success" component={() => (
        <ProtectedRoute>
          <CheckoutSuccess />
        </ProtectedRoute>
      )} />

      {/* Development and testing routes */}
      <Route path="/support-api-test" component={() => (
        <ProtectedRoute requiredRole="admin">
          <SupportApiTest />
        </ProtectedRoute>
      )} />
      
      <Route path="/branding-demo" component={BrandingDemo} />
      <Route path="/knowledge-base-guide" component={KnowledgeBaseGuide} />
      <Route path="/clerk-auth" component={ClerkLanding} />
      <Route path="/auth-demo" component={() => (
        <ProtectedRoute>
          <AuthDemo />
        </ProtectedRoute>
      )} />
      <Route path="/autoapply-integration" component={() => (
        <ProtectedRoute requiredPlan="pro" feature="job_board_integrations">
          <AutoApplyIntegration />
        </ProtectedRoute>
      )} />
      <Route path="/sign-in" component={SignInPage} />
      <Route path="/sign-up" component={SignUpPage} />
      <Route path="/auth-selector" component={() => <ClerkSignIn />} />
      <Route path="/travel-signin" component={() => <TravelConnectSignIn />} />
      
      {/* 404 catch-all */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <AtlasClientProvider>
        <QueryClientProvider client={queryClient}>
          <ThemeProvider defaultTheme="system" storageKey="prepair-theme">
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </ThemeProvider>
        </QueryClientProvider>
      </AtlasClientProvider>
    </ErrorBoundary>
  );
}

export default App;