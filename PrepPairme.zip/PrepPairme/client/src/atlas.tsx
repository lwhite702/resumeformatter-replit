import { useAuth, useUser } from "@clerk/clerk-react";
import { AtlasProvider } from "@runonatlas/react";
import { useLocation } from "wouter";
import { useCallback } from "react";

export function AtlasClientProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [, setLocation] = useLocation();
  const { getToken, userId, isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();

  const loginCallback = useCallback(() => {
    setLocation("/sign-in");
  }, [setLocation]);

  // Enhanced auth function that includes user ID in headers
  const getAuthWithContext = useCallback(async () => {
    const token = await getToken();
    return token;
  }, [getToken]);

  return (
    <AtlasProvider
      getAuth={getAuthWithContext}
      loginCallback={loginCallback}
      host={`${window.location.origin}/api/atlas`}
      userId={userId || undefined}
      userEmail={user?.primaryEmailAddress?.emailAddress || undefined}
      userName={user?.fullName || undefined}
      isUserLoading={!isLoaded}
    >
      {children}
    </AtlasProvider>
  );
}