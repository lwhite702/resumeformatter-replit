import { useAuth, useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function AtlasDebugger() {
  const { getToken, userId, isLoaded } = useAuth();
  const { user } = useUser();

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="text-sm">Atlas Debug Info</CardTitle>
      </CardHeader>
      <CardContent className="text-xs space-y-2">
        <div>User ID: {userId || "Not available"}</div>
        <div>User Email: {user?.primaryEmailAddress?.emailAddress || "Not available"}</div>
        <div>User Name: {user?.fullName || "Not available"}</div>
        <div>Auth Loaded: {isLoaded ? "Yes" : "No"}</div>
        <div>User Loaded: {user ? "Yes" : "No"}</div>
      </CardContent>
    </Card>
  );
}