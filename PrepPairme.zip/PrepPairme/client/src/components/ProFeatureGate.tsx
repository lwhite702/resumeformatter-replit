import { ReactNode } from "react";
import { useFeatureAccess } from "@/hooks/useFeatureAccess";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Lock, Zap } from "lucide-react";
import { useLocation } from "wouter";

interface ProFeatureGateProps {
  feature: string;
  children: ReactNode;
  fallback?: ReactNode;
  title?: string;
  description?: string;
}

export function ProFeatureGate({ 
  feature, 
  children, 
  fallback,
  title = "Premium Feature",
  description = "This feature requires a Pro subscription"
}: ProFeatureGateProps) {
  const [, setLocation] = useLocation();
  const { canAccess, requiresUpgrade } = useFeatureAccess(feature);

  if (canAccess) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center mb-2">
          <Crown className="w-8 h-8 text-purple-600 mr-2" />
          <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-300">
            Pro Feature
          </Badge>
        </div>
        <CardTitle className="text-xl text-purple-900">{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <p className="text-purple-700">{description}</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button 
            onClick={() => setLocation('/subscribe')}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Zap className="w-4 h-4 mr-2" />
            Upgrade to Pro
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/pricing')}
            className="border-purple-300 text-purple-700 hover:bg-purple-50"
          >
            View Pricing
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

interface ProtectedRouteProps {
  children: ReactNode;
  requiresAuth?: boolean;
  requiresPro?: boolean;
  requiresAdmin?: boolean;
}

export function ProtectedRoute({ 
  children, 
  requiresAuth = false,
  requiresPro = false,
  requiresAdmin = false 
}: ProtectedRouteProps) {
  const [, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();

  if (requiresAuth && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader className="text-center">
            <Lock className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <CardTitle>Authentication Required</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600">Please log in to access this feature</p>
            <Button onClick={() => window.location.href = '/api/login'}>
              Log In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (requiresPro && (!(user as any)?.isPro)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <ProFeatureGate 
          feature="pro-access"
          title="Pro Subscription Required"
          description="This page is only available to Pro subscribers"
        >
          {children}
        </ProFeatureGate>
      </div>
    );
  }

  if (requiresAdmin && (user as any)?.role !== 'admin' && (user as any)?.role !== 'super_admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader className="text-center">
            <Lock className="w-12 h-12 text-red-600 mx-auto mb-4" />
            <CardTitle className="text-red-900">Admin Access Required</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-red-600">This area is restricted to administrators only</p>
            <Button 
              variant="outline" 
              onClick={() => setLocation('/')}
              className="border-red-300 text-red-700"
            >
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
}