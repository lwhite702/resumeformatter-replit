import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredPlan?: 'free' | 'pro' | 'career_coach';
  requiredRole?: 'user' | 'admin';
  fallback?: React.ReactNode;
  feature?: string;
}

export function ProtectedRoute({ 
  children, 
  requiredPlan = 'free',
  requiredRole = 'user',
  fallback,
  feature 
}: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to access this feature",
        variant: "destructive",
      });
    }
  }, [isAuthenticated, isLoading, toast]);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Redirect to sign in if not authenticated
  if (!isAuthenticated) {
    if (fallback) {
      return <>{fallback}</>;
    }
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Authentication Required</h2>
          <p className="text-muted-foreground">You need to sign in to access this page.</p>
          <button 
            onClick={() => window.location.href = '/'}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
          >
            Go to Sign In
          </button>
        </div>
      </div>
    );
  }

  // Check plan requirements
  const userPlan = user?.publicMetadata?.plan || 'free';
  const userRole = user?.publicMetadata?.role || 'user';

  const planHierarchy = { 'free': 0, 'pro': 1, 'career_coach': 2 };
  const hasRequiredPlan = planHierarchy[userPlan as keyof typeof planHierarchy] >= planHierarchy[requiredPlan];

  // Check role requirements
  const hasRequiredRole = userRole === requiredRole || userRole === 'admin';

  if (!hasRequiredPlan || !hasRequiredRole) {
    const upgradeMessage = requiredPlan === 'pro' 
      ? "This feature requires a Pro plan. Upgrade to access advanced functionality."
      : requiredPlan === 'career_coach'
      ? "This feature requires a Career Coach plan. Upgrade for full access to all features."
      : "You don't have permission to access this feature.";

    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4 max-w-md">
          <div className="w-16 h-16 mx-auto bg-yellow-100 dark:bg-yellow-900 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-yellow-600 dark:text-yellow-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m0 0v3m0-3h3m-3 0h-3m-3-2l3-3m0 0l3 3m-3-3V4m0 0L9 7m3-3l3 3" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold">Upgrade Required</h2>
          <p className="text-muted-foreground">{upgradeMessage}</p>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Current plan: <span className="font-medium capitalize">{userPlan}</span>
            </p>
            {feature && (
              <p className="text-sm text-muted-foreground">
                Feature: <span className="font-medium">{feature}</span>
              </p>
            )}
          </div>
          <div className="flex gap-2 justify-center">
            <button 
              onClick={() => window.location.href = '/pricing'}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
            >
              View Pricing
            </button>
            <button 
              onClick={() => window.location.href = '/dashboard'}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</> as JSX.Element;
}