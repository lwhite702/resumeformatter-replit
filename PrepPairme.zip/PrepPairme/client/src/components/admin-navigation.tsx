import { useState } from "react";
import { useLocation } from "wouter";
import { useUser } from "@clerk/clerk-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Users, 
  CreditCard, 
  FileText, 
  BookOpen, 
  LifeBuoy, 
  Settings,
  Menu,
  X,
  Home,
  LogOut
} from "lucide-react";

interface AdminNavigationProps {
  currentPage: string;
}

export function AdminNavigation({ currentPage }: AdminNavigationProps) {
  const [, setLocation] = useLocation();
  const { user, signOut } = useUser();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigationItems = [
    { name: "Dashboard", href: "/admin/dashboard", icon: BarChart3 },
    { name: "Users", href: "/admin/users", icon: Users },
    { name: "Subscriptions", href: "/admin/subscriptions", icon: CreditCard },
    { name: "Blog", href: "/admin/content/blog", icon: FileText },
    { name: "Legal", href: "/admin/content/legal", icon: BookOpen },
    { name: "Knowledge", href: "/admin/content/knowledge-file", icon: BookOpen },
    { name: "Support", href: "/admin/support/tickets", icon: LifeBuoy },
    { name: "Settings", href: "/admin/settings", icon: Settings }
  ];

  const handleSignOut = async () => {
    await signOut();
    setLocation("/");
  };

  return (
    <>
      {/* SEO Protection for Admin Routes */}
      <head>
        <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
      </head>

      {/* Desktop Navigation */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
        <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white dark:bg-gray-900 px-6 pb-4 shadow-xl">
          <div className="flex h-16 shrink-0 items-center border-b">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              PrepPair Admin
            </h1>
            <Badge variant="outline" className="ml-auto text-xs">
              v2.1.0
            </Badge>
          </div>
          
          <nav className="flex flex-1 flex-col">
            <ul role="list" className="flex flex-1 flex-col gap-y-7">
              <li>
                <ul role="list" className="-mx-2 space-y-1">
                  {navigationItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentPage === item.name;
                    
                    return (
                      <li key={item.name}>
                        <button
                          onClick={() => setLocation(item.href)}
                          className={`group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold transition-colors ${
                            isActive
                              ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
                              : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-blue-400 dark:hover:bg-gray-800'
                          }`}
                        >
                          <Icon className="h-6 w-6 shrink-0" />
                          {item.name}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </li>
              
              <li className="mt-auto">
                <div className="border-t pt-4 space-y-2">
                  <button
                    onClick={() => setLocation("/")}
                    className="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold text-gray-700 hover:text-blue-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-blue-400 dark:hover:bg-gray-800"
                  >
                    <Home className="h-6 w-6 shrink-0" />
                    Back to App
                  </button>
                  
                  <button
                    onClick={handleSignOut}
                    className="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold text-gray-700 hover:text-red-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-red-400 dark:hover:bg-gray-800"
                  >
                    <LogOut className="h-6 w-6 shrink-0" />
                    Sign Out
                  </button>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden">
        {/* Mobile header */}
        <div className="flex items-center gap-x-6 bg-white dark:bg-gray-900 px-4 py-4 shadow-sm sm:px-6">
          <button
            type="button"
            className="-m-2.5 p-2.5 text-gray-700 dark:text-gray-400"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex-1 text-sm font-semibold leading-6 text-gray-900 dark:text-white">
            PrepPair Admin - {currentPage}
          </div>
          <div className="text-xs text-gray-500">
            {user?.firstName || user?.emailAddresses[0]?.emailAddress}
          </div>
        </div>

        {/* Mobile sidebar */}
        {mobileMenuOpen && (
          <div className="relative z-50 lg:hidden">
            <div className="fixed inset-0 bg-gray-900/80" onClick={() => setMobileMenuOpen(false)} />
            <div className="fixed inset-0 flex">
              <div className="relative mr-16 flex w-full max-w-xs flex-1">
                <div className="absolute left-full top-0 flex w-16 justify-center pt-5">
                  <button
                    type="button"
                    className="-m-2.5 p-2.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <X className="h-6 w-6 text-white" />
                  </button>
                </div>
                
                <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white dark:bg-gray-900 px-6 pb-4">
                  <div className="flex h-16 shrink-0 items-center border-b">
                    <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                      PrepPair Admin
                    </h1>
                  </div>
                  
                  <nav className="flex flex-1 flex-col">
                    <ul role="list" className="flex flex-1 flex-col gap-y-7">
                      <li>
                        <ul role="list" className="-mx-2 space-y-1">
                          {navigationItems.map((item) => {
                            const Icon = item.icon;
                            const isActive = currentPage === item.name;
                            
                            return (
                              <li key={item.name}>
                                <button
                                  onClick={() => {
                                    setLocation(item.href);
                                    setMobileMenuOpen(false);
                                  }}
                                  className={`group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold ${
                                    isActive
                                      ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
                                      : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-blue-400 dark:hover:bg-gray-800'
                                  }`}
                                >
                                  <Icon className="h-6 w-6 shrink-0" />
                                  {item.name}
                                </button>
                              </li>
                            );
                          })}
                        </ul>
                      </li>
                      
                      <li className="mt-auto">
                        <div className="border-t pt-4 space-y-2">
                          <button
                            onClick={() => {
                              setLocation("/");
                              setMobileMenuOpen(false);
                            }}
                            className="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold text-gray-700 hover:text-blue-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-blue-400 dark:hover:bg-gray-800"
                          >
                            <Home className="h-6 w-6 shrink-0" />
                            Back to App
                          </button>
                          
                          <button
                            onClick={() => {
                              handleSignOut();
                              setMobileMenuOpen(false);
                            }}
                            className="group flex w-full gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold text-gray-700 hover:text-red-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:text-red-400 dark:hover:bg-gray-800"
                          >
                            <LogOut className="h-6 w-6 shrink-0" />
                            Sign Out
                          </button>
                        </div>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main content wrapper */}
      <div className="lg:pl-72">
        {/* Environment indicator */}
        <div className="sticky top-0 z-40 flex h-12 shrink-0 items-center gap-x-4 border-b border-gray-200 dark:border-gray-800 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm px-4 shadow-sm sm:gap-x-6 sm:px-6 lg:px-8">
          <div className="flex flex-1 gap-x-4 self-stretch lg:gap-x-6">
            <div className="flex items-center gap-x-2">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Production
              </Badge>
              <span className="text-sm text-gray-500">
                Last updated: {new Date().toLocaleTimeString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}