import {
  Brain,
  FileText,
  Video,
  Target,
  BarChart3,
} from "lucide-react";

import { BentoCard, BentoGrid } from "@/components/ui/bento-grid";

const features = [
  {
    Icon: Brain,
    name: "AI Interview Guide",
    description: "Generate personalized interview questions and STAR method answers tailored to any job posting.",
    href: "/interview-guide",
    cta: "Generate Guide",
    background: (
      <div className="absolute -right-20 -top-20 opacity-60">
        <div className="bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl p-6 shadow-2xl transform rotate-12">
          <div className="space-y-3">
            <div className="w-32 h-3 bg-blue-100 rounded"></div>
            <div className="w-28 h-2 bg-blue-200 rounded"></div>
            <div className="w-36 h-2 bg-blue-200 rounded"></div>
            <div className="bg-white rounded-lg p-3 mt-4">
              <div className="w-20 h-2 bg-gray-300 rounded mb-2"></div>
              <div className="w-16 h-1 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    ),
    className: "lg:row-start-1 lg:row-end-4 lg:col-start-2 lg:col-end-3",
  },
  {
    Icon: FileText,
    name: "Resume Optimizer",
    description: "Get instant ATS scoring and optimization suggestions that actually work.",
    href: "/resume-optimizer",
    cta: "Analyze Resume",
    background: (
      <div className="absolute -right-20 -top-20 opacity-60">
        <div className="bg-gradient-to-br from-green-400 to-green-600 rounded-xl p-6 shadow-2xl transform -rotate-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="w-16 h-2 bg-green-100 rounded"></div>
              <div className="text-white font-bold text-lg">92%</div>
            </div>
            <div className="w-full h-2 bg-green-200 rounded-full">
              <div className="w-4/5 h-2 bg-white rounded-full"></div>
            </div>
            <div className="w-24 h-1 bg-green-200 rounded mt-3"></div>
            <div className="w-20 h-1 bg-green-200 rounded"></div>
          </div>
        </div>
      </div>
    ),
    className: "lg:col-start-1 lg:col-end-2 lg:row-start-1 lg:row-end-3",
  },
  {
    Icon: Video,
    name: "Video Practice",
    description: "Practice with AI-powered feedback on your body language and speaking confidence.",
    href: "/video-practice",
    cta: "Start Practice",
    background: (
      <div className="absolute -right-20 -top-20 opacity-60">
        <div className="bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl p-6 shadow-2xl transform rotate-3">
          <div className="bg-white rounded-lg p-3">
            <div className="w-16 h-12 bg-purple-100 rounded mb-2 flex items-center justify-center">
              <Video className="w-6 h-6 text-purple-600" />
            </div>
            <div className="w-12 h-1 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    ),
    className: "lg:col-start-1 lg:col-end-2 lg:row-start-3 lg:row-end-4",
  },
  {
    Icon: Target,
    name: "Job Tracker",
    description: "Track applications, interviews, and follow-ups in one organized dashboard.",
    href: "/job-tracker",
    cta: "Track Jobs",
    background: (
      <div className="absolute -right-20 -top-20 opacity-60">
        <div className="bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl p-6 shadow-2xl transform -rotate-12">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-100 rounded-full"></div>
              <div className="w-16 h-2 bg-orange-100 rounded"></div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <div className="w-14 h-2 bg-white rounded"></div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-200 rounded-full"></div>
              <div className="w-18 h-2 bg-orange-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    ),
    className: "lg:col-start-3 lg:col-end-3 lg:row-start-1 lg:row-end-2",
  },
  {
    Icon: BarChart3,
    name: "Career Analytics",
    description: "Visualize your progress with interactive charts and insights to accelerate your career growth.",
    href: "/career-visualization",
    cta: "View Analytics",
    background: (
      <div className="absolute -right-20 -top-20 opacity-60">
        <div className="bg-gradient-to-br from-indigo-400 to-indigo-600 rounded-xl p-6 shadow-2xl transform rotate-6">
          <div className="bg-white rounded-lg p-3">
            <div className="flex items-end gap-1 h-8 mb-2">
              <div className="w-2 bg-indigo-200 rounded-t" style={{height: '40%'}}></div>
              <div className="w-2 bg-indigo-300 rounded-t" style={{height: '60%'}}></div>
              <div className="w-2 bg-indigo-400 rounded-t" style={{height: '80%'}}></div>
              <div className="w-2 bg-indigo-500 rounded-t" style={{height: '100%'}}></div>
            </div>
            <div className="w-16 h-1 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    ),
    className: "lg:col-start-3 lg:col-end-3 lg:row-start-2 lg:row-end-4",
  },
];

export function BentoFeatures() {
  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent">
              Everything You Need
            </span>
            <br />
            <span className="text-gray-900 dark:text-white">
              to Land Your Dream Job
            </span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            From AI-powered interview preparation to career analytics, PrepPair provides all the tools you need for career success.
          </p>
        </div>
        
        <BentoGrid className="lg:grid-rows-3">
          {features.map((feature) => (
            <BentoCard key={feature.name} {...feature} />
          ))}
        </BentoGrid>
      </div>
    </section>
  );
}