import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Globe, Brain, FileText, Target, Users, Video, Star, Briefcase } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Features() {
    return (
        <section className="dark:bg-muted/25 bg-zinc-50 py-16 md:py-32">
            <div className="mx-auto max-w-7xl px-6">
                {/* Hero Section */}
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
                        AI-Powered Career Tools
                    </h2>
                    <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                        Transform your career with intelligent interview preparation, resume optimization, and job tracking tools
                    </p>
                </div>

                {/* Main Features Grid */}
                <div className="mx-auto grid gap-2 sm:grid-cols-5 mb-16">
                    <Card id="interview-guide" className="group overflow-hidden shadow-black/5 dark:shadow-white/5 sm:col-span-3 sm:rounded-none sm:rounded-tl-xl dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <CardHeader>
                            <div className="md:p-6">
                                <div className="flex items-center gap-3 mb-4">
                                    <Brain className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                                    <p className="font-medium text-gray-900 dark:text-white text-lg">AI Interview Guide Generator</p>
                                </div>
                                <p className="text-muted-foreground dark:text-gray-300 mt-3 max-w-sm text-sm">
                                    Generate personalized interview questions, STAR method answers, and talking points tailored to any job posting and your resume.
                                </p>
                            </div>
                        </CardHeader>

                        <div className="relative h-fit pl-6 md:pl-12">
                            <div className="absolute -inset-6 [background:radial-gradient(75%_95%_at_50%_0%,transparent,hsl(var(--background))_100%)]"></div>
                            <div className="bg-background dark:bg-gray-800 overflow-hidden rounded-tl-lg border-l border-t border-gray-200 dark:border-gray-600 pl-2 pt-2">
                                <div className="bg-white dark:bg-gray-900 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                                    <div className="space-y-3">
                                        <div className="flex items-center gap-2">
                                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                            <span className="text-sm font-medium text-gray-900 dark:text-white">Interview Questions Ready</span>
                                        </div>
                                        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded text-sm text-gray-700 dark:text-gray-300">
                                            "Tell me about a time you led a challenging project..."
                                        </div>
                                        <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded text-sm text-blue-800 dark:text-blue-200">
                                            <strong>STAR Answer:</strong> At my previous role, I managed a cross-functional team...
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="px-6 pb-6 md:px-12 md:pb-12">
                                <Button className="w-full" size="sm">
                                    Generate Interview Guide
                                </Button>
                            </div>
                        </div>
                    </Card>

                    <Card id="resume-optimizer" className="group overflow-hidden shadow-zinc-950/5 dark:shadow-white/5 sm:col-span-2 sm:rounded-none sm:rounded-tr-xl dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <div className="p-6">
                            <div className="flex items-center gap-3 mb-4">
                                <FileText className="w-8 h-8 text-green-600 dark:text-green-400" />
                                <p className="text-lg font-semibold text-gray-900 dark:text-white">Resume Optimizer</p>
                            </div>
                            <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                                Instantly analyze and improve your resume with ATS optimization and keyword matching.
                            </p>
                        </div>

                        <CardContent className="mt-auto h-fit">
                            <div className="relative mb-6 sm:mb-0">
                                <div className="absolute -inset-6 [background:radial-gradient(50%_75%_at_75%_50%,transparent,hsl(var(--background))_100%)]"></div>
                                <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center">
                                            <span className="text-sm text-gray-600 dark:text-gray-400">ATS Score</span>
                                            <span className="text-lg font-bold text-green-600 dark:text-green-400">92%</span>
                                        </div>
                                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                            <div className="bg-green-500 h-2 rounded-full" style={{width: '92%'}}></div>
                                        </div>
                                        <p className="text-xs text-gray-500 dark:text-gray-400">Keywords matched: 18/20</p>
                                    </div>
                                </div>
                            </div>
                            <div className="px-6 pb-6">
                                <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800" size="sm">
                                    Analyze My Resume
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    <Card id="video-practice" className="group p-6 shadow-black/5 dark:shadow-white/5 sm:col-span-2 sm:rounded-none sm:rounded-bl-xl md:p-12 dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3 mb-8">
                            <Video className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                            <p className="text-lg font-semibold text-gray-900 dark:text-white">Video Practice</p>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-12 text-center">
                            Practice interviews with AI feedback on delivery, confidence, and content quality.
                        </p>

                        <div className="flex justify-center gap-6">
                            <div className="bg-muted/35 dark:bg-gray-800 relative flex aspect-square size-16 items-center rounded-[7px] border border-gray-200 dark:border-gray-600 p-3 shadow-lg">
                                <span className="absolute right-2 top-1 block text-xs text-gray-500 dark:text-gray-400">REC</span>
                                <Video className="mt-auto size-4 text-purple-600 dark:text-purple-400" />
                            </div>
                            <div className="bg-muted/35 dark:bg-gray-800 flex aspect-square size-16 items-center justify-center rounded-[7px] border border-gray-200 dark:border-gray-600 p-3 shadow-lg">
                                <Star className="size-4 text-yellow-500" />
                            </div>
                        </div>
                        <div className="mt-8">
                            <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800" size="sm">
                                Start Practice Session
                            </Button>
                        </div>
                    </Card>

                    <Card id="job-tracker" className="group relative shadow-black/5 dark:shadow-white/5 sm:col-span-3 sm:rounded-none sm:rounded-br-xl dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <CardHeader className="p-6 md:p-12">
                            <div className="flex items-center gap-3 mb-4">
                                <Briefcase className="w-8 h-8 text-orange-600 dark:text-orange-400" />
                                <p className="font-medium text-gray-900 dark:text-white text-lg">Job Application Tracker</p>
                            </div>
                            <p className="text-muted-foreground dark:text-gray-300 mt-2 max-w-sm text-sm">
                                Track applications, sync with job boards, and get AI insights on your job search progress.
                            </p>
                        </CardHeader>
                        <CardContent className="relative h-fit px-6 pb-6 md:px-12 md:pb-12">
                            <div className="grid grid-cols-4 gap-2 md:grid-cols-6">
                                <div className="aspect-square border border-dashed border-gray-300 dark:border-gray-600 rounded-lg"></div>
                                <div className="bg-muted/50 dark:bg-gray-800 flex aspect-square items-center justify-center border border-gray-200 dark:border-gray-600 p-4 rounded-lg">
                                    <Target className="size-6 text-blue-600 dark:text-blue-400" />
                                </div>
                                <div className="aspect-square border border-dashed border-gray-300 dark:border-gray-600 rounded-lg"></div>
                                <div className="bg-muted/50 dark:bg-gray-800 flex aspect-square items-center justify-center border border-gray-200 dark:border-gray-600 p-4 rounded-lg">
                                    <Users className="size-6 text-green-600 dark:text-green-400" />
                                </div>
                                <div className="aspect-square border border-dashed border-gray-300 dark:border-gray-600 rounded-lg"></div>
                                <div className="bg-muted/50 dark:bg-gray-800 flex aspect-square items-center justify-center border border-gray-200 dark:border-gray-600 p-4 rounded-lg">
                                    <Globe className="size-6 text-purple-600 dark:text-purple-400" />
                                </div>
                            </div>
                            <div className="px-6 pb-6 md:px-12 md:pb-12">
                                <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800" size="sm">
                                    Track Applications
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Additional Features Grid */}
                <div className="grid md:grid-cols-3 gap-6 mb-16">
                    <Card id="skill-highlights" className="p-6 dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3 mb-4">
                            <Star className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Skill Highlights</h3>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                            AI-powered skill extraction and verification from your resume and experience.
                        </p>
                        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600 mb-4">
                            <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium text-gray-900 dark:text-white">JavaScript</span>
                                    <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 text-xs rounded-full">Expert</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium text-gray-900 dark:text-white">Project Management</span>
                                    <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs rounded-full">Advanced</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium text-gray-900 dark:text-white">AWS</span>
                                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-xs rounded-full">Intermediate</span>
                                </div>
                            </div>
                        </div>
                        <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800">
                            Extract My Skills
                        </Button>
                    </Card>

                    <Card id="career-visualization" className="p-6 dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3 mb-4">
                            <Target className="w-8 h-8 text-red-600 dark:text-red-400" />
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Career Visualization</h3>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                            Interactive charts and analytics to track your career progress and goals.
                        </p>
                        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600 mb-4">
                            <div className="flex items-center justify-between mb-3">
                                <span className="text-sm font-medium text-gray-900 dark:text-white">Job Search Progress</span>
                                <span className="text-sm text-gray-500 dark:text-gray-400">78%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-4">
                                <div className="bg-red-500 h-2 rounded-full" style={{width: '78%'}}></div>
                            </div>
                            <div className="grid grid-cols-3 gap-2 text-center">
                                <div>
                                    <div className="text-lg font-bold text-gray-900 dark:text-white">24</div>
                                    <div className="text-xs text-gray-500 dark:text-gray-400">Applied</div>
                                </div>
                                <div>
                                    <div className="text-lg font-bold text-blue-600 dark:text-blue-400">8</div>
                                    <div className="text-xs text-gray-500 dark:text-gray-400">Interviews</div>
                                </div>
                                <div>
                                    <div className="text-lg font-bold text-green-600 dark:text-green-400">3</div>
                                    <div className="text-xs text-gray-500 dark:text-gray-400">Offers</div>
                                </div>
                            </div>
                        </div>
                        <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800">
                            View Analytics
                        </Button>
                    </Card>

                    <Card id="questions-database" className="p-6 dark:bg-gray-900/50 border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3 mb-4">
                            <Brain className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Questions Database</h3>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-6">
                            Access thousands of real interview questions organized by industry, role, and difficulty level.
                        </p>
                        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600 mb-4">
                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                                    <span className="text-sm text-gray-900 dark:text-white">Tell me about yourself</span>
                                    <span className="ml-auto text-xs text-gray-500 dark:text-gray-400">General</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                    <span className="text-sm text-gray-900 dark:text-white">Describe a challenging project</span>
                                    <span className="ml-auto text-xs text-gray-500 dark:text-gray-400">Behavioral</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <span className="text-sm text-gray-900 dark:text-white">System design question</span>
                                    <span className="ml-auto text-xs text-gray-500 dark:text-gray-400">Technical</span>
                                </div>
                            </div>
                        </div>
                        <Button variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800">
                            Browse Questions
                        </Button>
                    </Card>
                </div>

                {/* CTA Section */}
                <div className="text-center">
                    <Card className="p-8 md:p-16 border-2 border-primary/20 dark:border-primary/30 bg-gradient-to-br from-primary/5 to-primary/10 dark:from-primary/10 dark:to-primary/20">
                        <div className="max-w-4xl mx-auto">
                            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
                                Ready to Land Your Dream Job?
                            </h2>
                            <p className="text-xl text-gray-600 dark:text-gray-300 mb-4 max-w-3xl mx-auto">
                                Join over 50,000 professionals who've accelerated their career growth with PrepPair.me
                            </p>
                            <div className="flex items-center justify-center gap-6 mb-8 text-sm text-gray-600 dark:text-gray-400">
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <span>14-day free trial</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                    <span>No credit card required</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                                    <span>Cancel anytime</span>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Button size="lg" className="px-12 py-4 text-lg font-semibold" onClick={() => window.location.href = '/subscribe'}>
                                    Start Free Trial Today
                                </Button>
                                <Button variant="outline" size="lg" className="px-8 py-4 text-lg dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800" onClick={() => window.location.href = '/pricing'}>
                                    View Pricing
                                </Button>
                            </div>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-6">
                                Trusted by professionals at Google, Microsoft, Amazon, and 500+ other companies
                            </p>
                        </div>
                    </Card>
                </div>
            </div>
        </section>
    )
}