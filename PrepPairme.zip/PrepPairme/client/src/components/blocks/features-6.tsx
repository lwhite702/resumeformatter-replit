import { Cpu, Lock, Sparkles, Zap } from 'lucide-react'

export function Features() {
    return (
        <section className="py-16 md:py-32">
            <div className="mx-auto max-w-5xl space-y-12 px-6">
                <div className="relative z-10 grid items-center gap-4 md:grid-cols-2 md:gap-12">
                    <h2 className="text-4xl font-semibold text-gray-900 dark:text-white">AI-powered career acceleration at your fingertips</h2>
                    <p className="max-w-sm sm:ml-auto text-gray-600 dark:text-gray-300">Transform your job search with intelligent tools that adapt to your needs, whether you're preparing for interviews or optimizing your applications.</p>
                </div>
                <div className="relative rounded-3xl p-3 md:-mx-8 lg:col-span-3">
                    <div className="aspect-[88/36] relative">
                        <div className="bg-gradient-to-t z-1 from-background absolute inset-0 to-transparent"></div>
                        <div className="absolute inset-0 z-10 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                            {/* Dashboard Screenshot Background */}
                            <div className="absolute inset-4 bg-white dark:bg-gray-900 rounded-xl shadow-2xl overflow-hidden opacity-20">
                                <div className="p-4 h-full">
                                    {/* Dashboard Header */}
                                    <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-200 dark:border-gray-700">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 bg-blue-600 rounded-lg"></div>
                                            <span className="font-semibold text-gray-900 dark:text-white">PrepPair Dashboard</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
                                            <div className="w-20 h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                                        </div>
                                    </div>
                                    
                                    {/* Dashboard Grid */}
                                    <div className="grid grid-cols-4 gap-3 h-full">
                                        {/* Stats Cards */}
                                        <div className="space-y-2">
                                            <div className="bg-blue-100 dark:bg-blue-900 rounded-lg p-3">
                                                <div className="w-full h-2 bg-blue-200 dark:bg-blue-800 rounded mb-1"></div>
                                                <div className="w-3/4 h-1 bg-blue-300 dark:bg-blue-700 rounded"></div>
                                            </div>
                                            <div className="bg-green-100 dark:bg-green-900 rounded-lg p-3">
                                                <div className="w-full h-2 bg-green-200 dark:bg-green-800 rounded mb-1"></div>
                                                <div className="w-2/3 h-1 bg-green-300 dark:bg-green-700 rounded"></div>
                                            </div>
                                        </div>
                                        
                                        {/* Chart Area */}
                                        <div className="col-span-2 bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                                            <div className="w-1/2 h-2 bg-gray-300 dark:bg-gray-600 rounded mb-2"></div>
                                            <div className="flex items-end gap-1 h-16">
                                                <div className="w-3 bg-blue-400 rounded-t" style={{height: '40%'}}></div>
                                                <div className="w-3 bg-blue-500 rounded-t" style={{height: '60%'}}></div>
                                                <div className="w-3 bg-blue-600 rounded-t" style={{height: '80%'}}></div>
                                                <div className="w-3 bg-blue-700 rounded-t" style={{height: '100%'}}></div>
                                                <div className="w-3 bg-blue-500 rounded-t" style={{height: '70%'}}></div>
                                            </div>
                                        </div>
                                        
                                        {/* Activity Feed */}
                                        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                                            <div className="space-y-2">
                                                <div className="w-full h-1 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                                <div className="w-4/5 h-1 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                                <div className="w-3/4 h-1 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                                <div className="w-full h-1 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {/* Content Overlay */}
                            <div className="relative z-20 p-8 md:p-12 h-full flex items-center justify-center">
                                <div className="text-center">
                                    <div className="inline-flex items-center gap-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full border border-gray-200 dark:border-gray-600 mb-6 shadow-lg">
                                        <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                        <span className="text-sm font-medium text-gray-900 dark:text-white">AI-Powered Platform</span>
                                    </div>
                                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-4">
                                        Your Complete Career Toolkit
                                    </h3>
                                    <p className="text-gray-600 dark:text-gray-300 max-w-lg mx-auto">
                                        From interview preparation to resume optimization, everything you need to land your dream job in one intelligent platform.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="relative mx-auto grid grid-cols-2 gap-x-3 gap-y-6 sm:gap-8 lg:grid-cols-4">
                    <div className="space-y-3">
                        <div className="flex items-center gap-2">
                            <Zap className="size-4 text-yellow-600 dark:text-yellow-400" />
                            <h3 className="text-sm font-medium text-gray-900 dark:text-white">Lightning Fast</h3>
                        </div>
                        <p className="text-muted-foreground dark:text-gray-400 text-sm">Generate personalized interview guides and resume optimizations in seconds.</p>
                    </div>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <Cpu className="size-4 text-blue-600 dark:text-blue-400" />
                            <h3 className="text-sm font-medium text-gray-900 dark:text-white">Intelligent</h3>
                        </div>
                        <p className="text-muted-foreground dark:text-gray-400 text-sm">Advanced AI analyzes job requirements and tailors content to your experience.</p>
                    </div>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <Lock className="size-4 text-green-600 dark:text-green-400" />
                            <h3 className="text-sm font-medium text-gray-900 dark:text-white">Secure</h3>
                        </div>
                        <p className="text-muted-foreground dark:text-gray-400 text-sm">Your data is encrypted and protected with enterprise-grade security.</p>
                    </div>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <Sparkles className="size-4 text-purple-600 dark:text-purple-400" />
                            <h3 className="text-sm font-medium text-gray-900 dark:text-white">AI Powered</h3>
                        </div>
                        <p className="text-muted-foreground dark:text-gray-400 text-sm">Cutting-edge AI technology that learns and improves with every interaction.</p>
                    </div>
                </div>
            </div>
        </section>
    )
}