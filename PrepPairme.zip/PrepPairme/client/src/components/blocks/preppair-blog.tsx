import { ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

interface Post {
  id: string;
  title: string;
  summary: string;
  label: string;
  author: string;
  published: string;
  url: string;
  image: string;
}

interface PrepPairBlogProps {
  tagline?: string;
  heading?: string;
  description?: string;
  buttonText?: string;
  buttonUrl?: string;
  posts?: Post[];
  isLoading?: boolean;
  hasError?: boolean;
}

const defaultPosts: Post[] = [
  {
    id: "interview-prep-2024",
    title: "Mastering Technical Interviews in 2024",
    summary: "Learn the latest strategies for acing technical interviews, from algorithm practice to system design. Discover how AI can help you prepare more effectively.",
    label: "Interview Prep",
    author: "PrepPair Team",
    published: "Dec 15, 2024",
    url: "/blog/mastering-technical-interviews-2024",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&h=450&fit=crop"
  },
  {
    id: "resume-ats-guide",
    title: "The Complete ATS Resume Optimization Guide",
    summary: "Understand how Applicant Tracking Systems work and optimize your resume to pass ATS screening. Includes real examples and keyword strategies.",
    label: "Resume Tips",
    author: "PrepPair Team", 
    published: "Dec 10, 2024",
    url: "/blog/ats-resume-optimization-guide",
    image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&h=450&fit=crop"
  },
  {
    id: "career-transition-guide",
    title: "How to Successfully Transition Your Career",
    summary: "A comprehensive guide to changing careers, including networking strategies, skill development, and leveraging transferable experience.",
    label: "Career Growth",
    author: "PrepPair Team",
    published: "Dec 5, 2024", 
    url: "/blog/career-transition-guide",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=450&fit=crop"
  }
];

export function PrepPairBlog({
  tagline = "Career Insights",
  heading = "Latest Career Development Tips",
  description = "Stay ahead in your career journey with expert insights, practical tips, and proven strategies from our team of career development specialists.",
  buttonText = "Read All Articles",
  buttonUrl = "/blog",
  posts,
  isLoading = false,
  hasError = false
}: PrepPairBlogProps) {
  const displayPosts = posts || defaultPosts;

  return (
    <section className="py-24 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto flex flex-col items-center gap-16 lg:px-16">
        <div className="text-center">
          <Badge variant="secondary" className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            {tagline}
          </Badge>
          <h2 className="mb-3 text-pretty text-3xl font-semibold text-gray-900 dark:text-white md:mb-4 md:text-4xl lg:mb-6 lg:max-w-3xl lg:text-5xl">
            {heading}
          </h2>
          <p className="mb-8 text-gray-600 dark:text-gray-300 md:text-base lg:max-w-2xl lg:text-lg">
            {description}
          </p>
          <Button variant="outline" className="w-full sm:w-auto" asChild>
            <a href={buttonUrl}>
              {buttonText}
              <ArrowRight className="ml-2 size-4" />
            </a>
          </Button>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="grid grid-rows-[auto_auto_1fr_auto] animate-pulse">
                <div className="aspect-[16/9] w-full bg-gray-200 dark:bg-gray-700 rounded-t-lg"></div>
                <CardHeader>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2 w-16"></div>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : hasError ? (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Unable to load blog posts at the moment.
            </p>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
            {displayPosts.map((post) => (
              <Card key={post.id} className="grid grid-rows-[auto_auto_1fr_auto] hover:shadow-lg transition-shadow duration-200 dark:bg-gray-800/50 dark:border-gray-700">
                <div className="aspect-[16/9] w-full overflow-hidden rounded-t-lg">
                  <a
                    href={post.url}
                    className="transition-opacity duration-200 hover:opacity-70"
                  >
                    <img
                      src={post.image}
                      alt={post.title}
                      className="h-full w-full object-cover object-center"
                    />
                  </a>
                </div>
                <CardHeader>
                  <Badge variant="outline" className="w-fit mb-2 text-xs">
                    {post.label}
                  </Badge>
                  <h3 className="text-lg font-semibold hover:underline md:text-xl text-gray-900 dark:text-white">
                    <a href={post.url}>
                      {post.title}
                    </a>
                  </h3>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300">{post.summary}</p>
                </CardContent>
                <CardFooter className="flex items-center justify-between">
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    <span>{post.author}</span> • <span>{post.published}</span>
                  </div>
                  <a
                    href={post.url}
                    className="flex items-center text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Read more
                    <ArrowRight className="ml-2 size-4" />
                  </a>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}