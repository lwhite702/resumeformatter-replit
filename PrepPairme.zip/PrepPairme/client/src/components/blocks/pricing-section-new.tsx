"use client"

import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Check, Crown, Sparkles, Zap, ArrowRight, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { SimpleTooltip } from "@/components/ui/enhanced-tooltip";

interface PricingFeature {
  text: string;
  included: boolean;
}

interface PricingTier {
  name: string;
  description: string;
  monthlyPrice: number;
  quarterlyPrice?: number;
  yearlyDiscount?: number;
  features: PricingFeature[];
  popular?: boolean;
  cta: string;
  icon: React.ReactNode;
  planId: string;
}

const pricingTiers: PricingTier[] = [
  {
    name: "Free",
    description: "Perfect for getting started with interview prep",
    monthlyPrice: 0,
    features: [
      { text: "3 AI interview guides per month", included: true },
      { text: "Basic resume optimization", included: true },
      { text: "Standard question database access", included: true },
      { text: "Email support", included: true },
      { text: "Advanced analytics", included: false },
      { text: "Priority support", included: false },
      { text: "Custom templates", included: false },
    ],
    cta: "Get Started Free",
    icon: <Sparkles className="w-6 h-6" />,
    planId: "free"
  },
  {
    name: "Pro",
    description: "Unlimited access to all premium features",
    monthlyPrice: 19,
    quarterlyPrice: 14.25,
    yearlyDiscount: 25,
    features: [
      { text: "Unlimited AI interview guides", included: true },
      { text: "Advanced resume optimization", included: true },
      { text: "Full question database access", included: true },
      { text: "Priority email support", included: true },
      { text: "Advanced analytics & insights", included: true },
      { text: "Custom templates & themes", included: true },
      { text: "Video practice sessions", included: true },
    ],
    popular: true,
    cta: "Start Pro Trial",
    icon: <Crown className="w-6 h-6" />,
    planId: "pro"
  },
];

export default function PricingSectionNew() {
  const [, setLocation] = useLocation();
  const [billingCycle, setBillingCycle] = useState<"monthly" | "quarterly">("monthly");
  const [isAnnual, setIsAnnual] = useState(false);

  const handlePlanSelect = (planId: string) => {
    if (planId === "free") {
      setLocation("/dashboard");
      return;
    }

    if (planId === "pro") {
      const cycle = isAnnual ? "quarterly" : "monthly";
      const plan = isAnnual ? "pro_quarterly" : "pro_monthly";
      setLocation(`/checkout?plan=${plan}&cycle=${cycle}`);
      return;
    }
  };

  const getPrice = (tier: PricingTier) => {
    if (tier.monthlyPrice === 0) return "Free";
    
    if (isAnnual && tier.quarterlyPrice) {
      return `$${tier.quarterlyPrice}/mo`;
    }
    
    return `$${tier.monthlyPrice}/mo`;
  };

  const getBillingNote = (tier: PricingTier) => {
    if (tier.monthlyPrice === 0) return "";
    
    if (isAnnual && tier.quarterlyPrice) {
      return "Billed quarterly";
    }
    
    return "Billed monthly";
  };

  return (
    <section className="py-24 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Choose Your Plan
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Start free, upgrade when ready. No hidden fees.
          </p>
          
          <div className="flex items-center justify-center gap-4 mb-8">
            <Label htmlFor="billing-toggle" className={cn("text-sm", !isAnnual && "text-gray-900 dark:text-white font-medium")}>
              Monthly
            </Label>
            <Switch
              id="billing-toggle"
              checked={isAnnual}
              onCheckedChange={setIsAnnual}
            />
            <div className="flex items-center gap-2">
              <Label htmlFor="billing-toggle" className={cn("text-sm", isAnnual && "text-gray-900 dark:text-white font-medium")}>
                Quarterly
              </Label>
              <div className="flex items-center gap-1">
                <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                  Save 25%
                </Badge>
                <SimpleTooltip
                  content="Pay quarterly and save 25% compared to monthly billing. Cancel anytime."
                  title="Quarterly Savings"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {pricingTiers.map((tier) => (
            <Card
              key={tier.name}
              className={cn(
                "relative h-full",
                tier.popular && "ring-2 ring-purple-500 shadow-xl scale-105 bg-purple-50 dark:bg-purple-900/20"
              )}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-purple-500 text-white px-3 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-6">
                <div className="flex items-center justify-center mb-4">
                  <div className={cn(
                    "p-3 rounded-full",
                    tier.popular ? "bg-purple-100 text-purple-600" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                  )}>
                    {tier.icon}
                  </div>
                </div>
                
                <CardTitle className={cn(
                  "text-2xl font-bold",
                  tier.popular && "text-purple-900 dark:text-purple-100"
                )}>{tier.name}</CardTitle>
                <p className={cn(
                  "text-sm",
                  tier.popular 
                    ? "text-purple-700 dark:text-purple-300" 
                    : "text-gray-600 dark:text-gray-400"
                )}>{tier.description}</p>
                
                <div className="mt-4">
                  <div className={cn(
                    "text-4xl font-bold",
                    tier.popular 
                      ? "text-purple-900 dark:text-purple-100" 
                      : "text-gray-900 dark:text-white"
                  )}>
                    {getPrice(tier)}
                  </div>
                  {getBillingNote(tier) && (
                    <p className={cn(
                      "text-sm mt-1",
                      tier.popular 
                        ? "text-purple-600 dark:text-purple-400" 
                        : "text-gray-500"
                    )}>{getBillingNote(tier)}</p>
                  )}
                  {isAnnual && tier.quarterlyPrice && (
                    <p className="text-sm text-green-600 mt-1 font-medium">
                      Save ${((tier.monthlyPrice - tier.quarterlyPrice) * 12).toFixed(0)}/year
                    </p>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-6 flex-1 flex flex-col">
                <Button
                  onClick={() => handlePlanSelect(tier.planId)}
                  className={cn(
                    "w-full h-12",
                    tier.popular
                      ? "bg-purple-600 hover:bg-purple-700 text-white shadow-lg"
                      : "bg-gray-900 hover:bg-gray-800 text-white dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100"
                  )}
                >
                  {tier.cta}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                <div className="space-y-3 flex-1">
                  <h4 className={cn(
                    "font-semibold",
                    tier.popular 
                      ? "text-purple-900 dark:text-purple-100" 
                      : "text-gray-900 dark:text-white"
                  )}>
                    What's included:
                  </h4>
                  <ul className="space-y-2">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className={cn(
                          "rounded-full p-1 flex-shrink-0 mt-0.5",
                          feature.included 
                            ? "bg-green-100 text-green-600" 
                            : "bg-gray-100 text-gray-400"
                        )}>
                          <Check className="w-3 h-3" />
                        </div>
                        <span className={cn(
                          "text-sm",
                          feature.included 
                            ? tier.popular 
                              ? "text-purple-800 dark:text-purple-200" 
                              : "text-gray-700 dark:text-gray-300"
                            : "text-gray-400 line-through"
                        )}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Career Coach Section - Smaller and Less Featured */}
        <div className="border-t border-gray-200 dark:border-gray-700 pt-12">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Team & Educator Plans
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              For career counselors, educators, and team managers
            </p>
          </div>

          <div className="max-w-xl mx-auto bg-gray-50 dark:bg-gray-800 rounded-lg p-6 border">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white">Career Coach</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">$39/user/month</p>
                </div>
              </div>
              <Button
                onClick={() => setLocation('/checkout?plan=career_coach&users=3')}
                variant="outline"
                size="sm"
              >
                Learn More
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-3">
              Team management, bulk user access, advanced analytics • Minimum 3 users • Quarterly billing
            </p>
            <div className="flex flex-wrap gap-1">
              {["Team Dashboard", "Progress Tracking", "Bulk Management", "Priority Support"].map((feature) => (
                <Badge key={feature} variant="secondary" className="text-xs">
                  {feature}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center mt-16">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            All plans include a 14-day free trial. No credit card required for Free plan.
            <br />
            Cancel anytime. Questions?{" "}
            <button className="text-purple-600 hover:underline">Contact support</button>
          </p>
        </div>
      </div>
    </section>
  );
}