import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star } from "lucide-react";

interface PricingPlan {
  name: string;
  price: string;
  originalPrice?: string;
  period: string;
  billingOptions?: { monthly: string; quarterly: string; discount?: string; };
  description: string;
  features: string[];
  cta: string;
  popular?: boolean;
  href: string;
  badge?: string;
  teamFeatures?: boolean;
}

const pricingPlans: PricingPlan[] = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for getting started with interview preparation",
    features: [
      "5 AI-generated interview questions per month",
      "Basic resume analysis (1 per month)",
      "1 practice session per month",
      "Access to community resources",
      "Basic job application tracking"
    ],
    cta: "Get Started Free",
    href: "/api/login"
  },
  {
    name: "Pro",
    price: "$19",
    originalPrice: "$25",
    period: "per month",
    billingOptions: {
      monthly: "$19/month",
      quarterly: "$14.25/month",
      discount: "Save 25% with quarterly billing"
    },
    description: "Everything you need to ace your interviews and land your dream job",
    features: [
      "Unlimited AI interview questions",
      "Advanced ATS resume optimization",
      "Unlimited practice sessions",
      "Industry-specific preparation",
      "Video interview analysis with AI feedback",
      "Personal career insights dashboard",
      "Priority email support",
      "Advanced job application tracking",
      "Interview performance analytics"
    ],
    cta: "Start Pro Trial",
    popular: true,
    href: "/api/login"
  },
  {
    name: "Career Coach",
    price: "$39",
    period: "per user/month",
    badge: "Quarterly Billing Only",
    description: "For educators, career coaches, and professionals managing multiple students or clients",
    features: [
      "Everything in Pro for each user",
      "Team dashboard with student progress tracking",
      "Bulk student/client management (3+ users)",
      "Custom interview templates and scenarios",
      "Advanced analytics and reporting",
      "White-label coaching tools",
      "Dedicated account support",
      "Student progress sharing with institutions",
      "Custom branding options",
      "Prorated billing for additional users"
    ],
    cta: "Contact Sales",
    href: "/contact",
    teamFeatures: true
  }
];

export function PricingSection() {
  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            Pricing
          </Badge>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
            Choose Your Path to Success
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Start free and upgrade when you're ready. All plans include our core features to help you succeed.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {pricingPlans.map((plan) => (
            <Card 
              key={plan.name} 
              className={`relative ${
                plan.popular 
                  ? 'border-blue-500 shadow-xl scale-105 dark:border-blue-400' 
                  : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-500 text-white px-3 py-1 flex items-center gap-1">
                    <Star className="w-3 h-3" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
                  {plan.name}
                </CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">
                    {plan.price}
                  </span>
                  <span className="text-gray-600 dark:text-gray-400 ml-2">
                    {plan.period}
                  </span>
                </div>
                <p className="text-gray-600 dark:text-gray-300 mt-2">
                  {plan.description}
                </p>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4">
                  <Button 
                    className={`w-full ${
                      plan.popular 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : 'bg-gray-900 hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100'
                    }`}
                    asChild
                  >
                    <a href={plan.href}>{plan.cta}</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            All plans include 30-day money-back guarantee
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500">
            No setup fees • Cancel anytime • Secure payment
          </p>
        </div>
      </div>
    </section>
  );
}