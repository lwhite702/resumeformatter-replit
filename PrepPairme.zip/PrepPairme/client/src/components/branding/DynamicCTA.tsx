import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Zap } from "lucide-react";
import { getRandomCTA, getRandomSlogan } from "@/lib/branding";

interface DynamicCTAProps {
  variant?: "primary" | "secondary" | "gradient";
  size?: "sm" | "md" | "lg";
  className?: string;
  href?: string;
  onClick?: () => void;
  showSlogan?: boolean;
}

export function DynamicCTA({ 
  variant = "primary", 
  size = "md", 
  className = "",
  href = "/api/login",
  onClick,
  showSlogan = true
}: DynamicCTAProps) {
  
  const { ctaText, slogan } = useMemo(() => ({
    ctaText: getRandomCTA(),
    slogan: getRandomSlogan()
  }), []);

  const buttonVariants = {
    primary: "bg-blue-600 hover:bg-blue-700 text-white",
    secondary: "bg-gray-100 hover:bg-gray-200 text-gray-900 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-white",
    gradient: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
  };

  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };

  const iconMap = {
    "Start Practicing Now": <Zap className="ml-2 h-4 w-4" />,
    "Get Interview Ready": <Star className="ml-2 h-4 w-4" />,
    "Begin Your Prep": <ArrowRight className="ml-2 h-4 w-4" />,
    "Try PrepPair Free": <ArrowRight className="ml-2 h-4 w-4" />,
    "Start Your Success Story": <Star className="ml-2 h-4 w-4" />,
    "Ace Your Next Interview": <Zap className="ml-2 h-4 w-4" />
  };

  const icon = iconMap[ctaText as keyof typeof iconMap] || <ArrowRight className="ml-2 h-4 w-4" />;

  const buttonContent = (
    <>
      {ctaText}
      {icon}
    </>
  );

  if (showSlogan) {
    return (
      <div className={`text-center space-y-3 ${className}`}>
        <p className="text-sm text-muted-foreground font-medium">
          {slogan}
        </p>
        {href ? (
          <Button 
            className={`${buttonVariants[variant]} ${sizeClasses[size]} font-semibold transform hover:scale-105 transition-all duration-200 shadow-lg`}
            asChild
          >
            <a href={href}>
              {buttonContent}
            </a>
          </Button>
        ) : (
          <Button 
            className={`${buttonVariants[variant]} ${sizeClasses[size]} font-semibold transform hover:scale-105 transition-all duration-200 shadow-lg`}
            onClick={onClick}
          >
            {buttonContent}
          </Button>
        )}
      </div>
    );
  }

  return href ? (
    <Button 
      className={`${buttonVariants[variant]} ${sizeClasses[size]} font-semibold transform hover:scale-105 transition-all duration-200 shadow-lg ${className}`}
      asChild
    >
      <a href={href}>
        {buttonContent}
      </a>
    </Button>
  ) : (
    <Button 
      className={`${buttonVariants[variant]} ${sizeClasses[size]} font-semibold transform hover:scale-105 transition-all duration-200 shadow-lg ${className}`}
      onClick={onClick}
    >
      {buttonContent}
    </Button>
  );
}

export default DynamicCTA;