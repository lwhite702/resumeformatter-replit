import { useMemo } from "react";

// Brand constants for social sharing and meta descriptions
export const SOCIAL_ALT = "PrepPair.me gives you friendly, AI-powered interview prep — personalized and stress-free.";

export const META_DESCRIPTIONS = [
  "AI-generated interview guides built just for your resume and job goals.",
  "Your interview prep sidekick — smart, supportive, and easy to use."
];

// Slogans data
const SLOGANS = {
  primary: "Interview smarter. Prepare together.",
  alternate: [
    "Your AI-powered interview prep partner.",
    "Built for every job seeker, from first-time to high-stakes.",
    "Smart questions. Better answers. Real confidence.",
    "We prep, you win.",
    "From resume upload to thank-you note — we've got you.",
    "Big interview coming up? We've got your back."
  ]
};

interface PrepSloganProps {
  variant?: "primary" | "random";
  className?: string;
}

export function PrepSlogan({ variant = "random", className = "" }: PrepSloganProps) {
  const slogan = useMemo(() => {
    if (variant === "primary") {
      return SLOGANS.primary;
    }
    
    // Random selection from all slogans (primary + alternates)
    const allSlogans = [SLOGANS.primary, ...SLOGANS.alternate];
    const randomIndex = Math.floor(Math.random() * allSlogans.length);
    return allSlogans[randomIndex];
  }, [variant]);

  return (
    <p className={`text-muted-foreground ${className}`}>
      {slogan}
    </p>
  );
}

// Export individual slogans for programmatic use
export const getPrimarySlogan = () => SLOGANS.primary;

export const getRandomSlogan = () => {
  const allSlogans = [SLOGANS.primary, ...SLOGANS.alternate];
  const randomIndex = Math.floor(Math.random() * allSlogans.length);
  return allSlogans[randomIndex];
};

export const getAllSlogans = () => ({
  primary: SLOGANS.primary,
  alternate: SLOGANS.alternate
});

export const getRandomMetaDescription = () => {
  const randomIndex = Math.floor(Math.random() * META_DESCRIPTIONS.length);
  return META_DESCRIPTIONS[randomIndex];
};

export default PrepSlogan;