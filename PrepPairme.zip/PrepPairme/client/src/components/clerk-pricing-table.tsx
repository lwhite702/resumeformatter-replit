import { useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Zap } from "lucide-react";
import { useFeatureAccess } from "@/hooks/useFeatureAccess";

interface PricingPlan {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  popular?: boolean;
  current?: boolean;
}

const pricingPlans: PricingPlan[] = [
  {
    id: "free",
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for getting started with interview preparation",
    features: [
      "Basic interview questions database",
      "Community access",
      "Basic resume review",
      "5 practice sessions per month",
      "Email support"
    ]
  },
  {
    id: "pro",
    name: "Pro",
    price: "$29",
    period: "month",
    description: "Advanced features for serious job seekers",
    popular: true,
    features: [
      "Everything in Free",
      "Advanced interview preparation",
      "AI-powered resume optimization",
      "Video practice sessions with feedback",
      "Job application tracking",
      "Career path visualization",
      "Priority support",
      "Unlimited practice sessions"
    ]
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "$99",
    period: "month",
    description: "For teams and organizations",
    features: [
      "Everything in Pro",
      "Team management dashboard",
      "Advanced analytics",
      "Custom integrations",
      "Dedicated support",
      "Training sessions",
      "API access"
    ]
  }
];

export function ClerkPricingTable() {
  const { user } = useUser();
  const { getUserPlan, isPro } = useFeatureAccess();
  const currentPlan = getUserPlan();

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      // Redirect to sign-in
      window.location.href = '/sign-in';
      return;
    }

    try {
      // Create checkout session through Clerk billing
      const response = await fetch('/api/billing/create-checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId,
          userId: user.id
        })
      });

      if (response.ok) {
        const { checkoutUrl } = await response.json();
        window.location.href = checkoutUrl;
      } else {
        console.error('Failed to create checkout session');
      }
    } catch (error) {
      console.error('Error creating checkout session:', error);
    }
  };

  const handleManageSubscription = async () => {
    try {
      const response = await fetch('/api/billing/manage-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        const { portalUrl } = await response.json();
        window.location.href = portalUrl;
      }
    } catch (error) {
      console.error('Error accessing billing portal:', error);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Unlock your career potential with our comprehensive interview preparation and career development tools
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {pricingPlans.map((plan) => {
          const isCurrentPlan = currentPlan.plan === plan.id;
          const isFreeUser = currentPlan.plan === 'free' || !currentPlan.plan;
          
          return (
            <Card 
              key={plan.id} 
              className={`relative ${plan.popular ? 'ring-2 ring-primary shadow-lg' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground px-3 py-1">
                    <Crown className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  {isCurrentPlan && (
                    <Badge variant="secondary">Current Plan</Badge>
                  )}
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="pt-4">
                  {isCurrentPlan ? (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={handleManageSubscription}
                    >
                      Manage Subscription
                    </Button>
                  ) : plan.id === 'free' ? (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      disabled={isFreeUser}
                    >
                      {isFreeUser ? 'Current Plan' : 'Downgrade'}
                    </Button>
                  ) : (
                    <Button 
                      className="w-full" 
                      onClick={() => handleSubscribe(plan.id)}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      {isPro && plan.id === 'pro' ? 'Current Plan' : 'Subscribe'}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="text-center mt-12">
        <p className="text-muted-foreground mb-4">
          All plans include a 14-day free trial. Cancel anytime.
        </p>
        <div className="flex justify-center gap-6 text-sm text-muted-foreground">
          <span>✓ Secure payments</span>
          <span>✓ No setup fees</span>
          <span>✓ Cancel anytime</span>
        </div>
      </div>
    </div>
  );
}