import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SignIn, SignUp } from "@clerk/clerk-react";
import { Shield, Users, ArrowRight, CheckCircle, LogIn, UserPlus } from "lucide-react";
import { useState } from "react";
import logoWithText from "@assets/3_1749272880173.png";

export function ClerkSignIn() {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-6">
              <img src={logoWithText} alt="PrepPair.me" className="h-12" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Welcome to PrepPair
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-300">
              Sign in to access your AI-powered career development platform
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 items-start">
            {/* Authentication Form */}
            <div className="order-2 lg:order-1">
              <Card>
                <CardHeader className="text-center">
                  <div className="flex justify-center gap-2 mb-4">
                    <Button
                      variant={authMode === 'signin' ? 'default' : 'outline'}
                      onClick={() => setAuthMode('signin')}
                      className="flex-1"
                    >
                      <LogIn className="w-4 h-4 mr-2" />
                      Sign In
                    </Button>
                    <Button
                      variant={authMode === 'signup' ? 'default' : 'outline'}
                      onClick={() => setAuthMode('signup')}
                      className="flex-1"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Sign Up
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center">
                    {authMode === 'signin' ? (
                      <SignIn 
                        appearance={{
                          elements: {
                            formButtonPrimary: 'bg-blue-600 hover:bg-blue-700 text-white',
                            card: 'shadow-none border-none',
                            headerTitle: 'hidden',
                            headerSubtitle: 'hidden'
                          }
                        }}
                        redirectUrl="/dashboard"
                      />
                    ) : (
                      <SignUp 
                        appearance={{
                          elements: {
                            formButtonPrimary: 'bg-blue-600 hover:bg-blue-700 text-white',
                            card: 'shadow-none border-none',
                            headerTitle: 'hidden',
                            headerSubtitle: 'hidden'
                          }
                        }}
                        redirectUrl="/dashboard"
                      />
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Features and Security Info */}
            <div className="order-1 lg:order-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-blue-600" />
                    Secure Authentication
                  </CardTitle>
                  <CardDescription>
                    Multiple sign-in options with enterprise-grade security
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium">Multiple Sign-In Options</h4>
                        <p className="text-sm text-muted-foreground">Email, Google, GitHub, LinkedIn, and more</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium">Enhanced Security</h4>
                        <p className="text-sm text-muted-foreground">Two-factor authentication and fraud detection</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium">Profile Management</h4>
                        <p className="text-sm text-muted-foreground">Built-in user preferences and settings</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium">Mobile Optimized</h4>
                        <p className="text-sm text-muted-foreground">Works seamlessly on all devices</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4 text-center">What you'll get access to:</h3>
                  <div className="grid grid-cols-1 gap-4 text-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                      <div>
                        <div className="font-medium">AI Interview Practice</div>
                        <div className="text-muted-foreground">Video analysis with personalized feedback</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-purple-600 rounded-full flex-shrink-0"></div>
                      <div>
                        <div className="font-medium">Resume Optimization</div>
                        <div className="text-muted-foreground">ATS-friendly suggestions and scoring</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-green-600 rounded-full flex-shrink-0"></div>
                      <div>
                        <div className="font-medium">Job Application Tracking</div>
                        <div className="text-muted-foreground">Organize and manage your applications</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-orange-600 rounded-full flex-shrink-0"></div>
                      <div>
                        <div className="font-medium">Career Path Visualization</div>
                        <div className="text-muted-foreground">Interactive career progression tools</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}