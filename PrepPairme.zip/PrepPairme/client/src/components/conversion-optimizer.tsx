"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  Users, 
  Target, 
  Zap, 
  ArrowRight, 
  CheckCircle,
  Clock,
  Star,
  Gift
} from "lucide-react";

interface ConversionData {
  visitorCount: number;
  signupRate: number;
  trialToProRate: number;
  engagementScore: number;
  timeOnPage: number;
  featureUsage: Record<string, number>;
  conversionFunnelSteps: Array<{
    step: string;
    visitors: number;
    conversions: number;
    rate: number;
  }>;
}

interface ConversionOptimizerProps {
  userProgress?: {
    hasCompletedOnboarding?: boolean;
    hasUploadedResume?: boolean;
    hasUsedAI?: boolean;
    isPro?: boolean;
    daysActive?: number;
  };
  onOptimizationApplied?: (optimization: string) => void;
}

export function ConversionOptimizer({ 
  userProgress = {}, 
  onOptimizationApplied 
}: ConversionOptimizerProps) {
  const [conversionData, setConversionData] = useState<ConversionData>({
    visitorCount: 0,
    signupRate: 0,
    trialToProRate: 0,
    engagementScore: 0,
    timeOnPage: 0,
    featureUsage: {},
    conversionFunnelSteps: []
  });
  
  const [optimizations, setOptimizations] = useState<Array<{
    id: string;
    title: string;
    description: string;
    impact: 'high' | 'medium' | 'low';
    effort: 'low' | 'medium' | 'high';
    category: string;
    action: () => void;
  }>>([]);

  useEffect(() => {
    generateConversionData();
    generateOptimizations();
  }, [userProgress]);

  const generateConversionData = () => {
    // Simulate real conversion data
    const data: ConversionData = {
      visitorCount: Math.floor(Math.random() * 1000) + 500,
      signupRate: Math.random() * 20 + 15,
      trialToProRate: Math.random() * 15 + 8,
      engagementScore: Math.random() * 30 + 70,
      timeOnPage: Math.random() * 300 + 120,
      featureUsage: {
        'Interview Guide': Math.random() * 80 + 20,
        'Resume Optimizer': Math.random() * 70 + 30,
        'Job Tracker': Math.random() * 60 + 20,
        'Video Practice': Math.random() * 40 + 10,
        'Analytics': Math.random() * 30 + 5
      },
      conversionFunnelSteps: [
        { step: 'Landing Page', visitors: 1000, conversions: 850, rate: 85 },
        { step: 'Sign Up Started', visitors: 850, conversions: 680, rate: 80 },
        { step: 'Onboarding Complete', visitors: 680, conversions: 544, rate: 80 },
        { step: 'First Feature Used', visitors: 544, conversions: 380, rate: 70 },
        { step: 'Pro Upgrade', visitors: 380, conversions: 46, rate: 12 }
      ]
    };
    setConversionData(data);
  };

  const generateOptimizations = () => {
    const baseOptimizations = [
      {
        id: 'social-proof',
        title: 'Add Social Proof Elements',
        description: 'Display user testimonials and success stories on landing page',
        impact: 'high' as const,
        effort: 'low' as const,
        category: 'Landing Page',
        action: () => applyOptimization('social-proof')
      },
      {
        id: 'urgency-cta',
        title: 'Create Urgency in CTAs',
        description: 'Add time-sensitive offers and limited-time bonuses',
        impact: 'medium' as const,
        effort: 'low' as const,
        category: 'Call-to-Action',
        action: () => applyOptimization('urgency-cta')
      },
      {
        id: 'onboarding-gamification',
        title: 'Gamify Onboarding Process',
        description: 'Add progress indicators and achievement badges',
        impact: 'high' as const,
        effort: 'medium' as const,
        category: 'User Experience',
        action: () => applyOptimization('onboarding-gamification')
      },
      {
        id: 'feature-discovery',
        title: 'Improve Feature Discovery',
        description: 'Implement progressive disclosure and guided tours',
        impact: 'high' as const,
        effort: 'medium' as const,
        category: 'Product Experience',
        action: () => applyOptimization('feature-discovery')
      },
      {
        id: 'pricing-optimization',
        title: 'Optimize Pricing Display',
        description: 'Highlight most popular plan and add value props',
        impact: 'high' as const,
        effort: 'low' as const,
        category: 'Pricing',
        action: () => applyOptimization('pricing-optimization')
      }
    ];

    // Add user-specific optimizations based on progress
    const userSpecificOptimizations = [];

    if (!userProgress.hasCompletedOnboarding) {
      userSpecificOptimizations.push({
        id: 'onboarding-reminder',
        title: 'Onboarding Completion Nudge',
        description: 'Send personalized reminder to complete setup',
        impact: 'high' as const,
        effort: 'low' as const,
        category: 'Retention',
        action: () => applyOptimization('onboarding-reminder')
      });
    }

    if (!userProgress.hasUsedAI && userProgress.daysActive && userProgress.daysActive > 3) {
      userSpecificOptimizations.push({
        id: 'ai-feature-highlight',
        title: 'Highlight AI Features',
        description: 'Show AI capabilities with interactive demo',
        impact: 'medium' as const,
        effort: 'low' as const,
        category: 'Feature Adoption',
        action: () => applyOptimization('ai-feature-highlight')
      });
    }

    setOptimizations([...baseOptimizations, ...userSpecificOptimizations]);
  };

  const applyOptimization = (optimizationId: string) => {
    const optimization = optimizations.find(opt => opt.id === optimizationId);
    if (optimization && onOptimizationApplied) {
      onOptimizationApplied(optimization.title);
    }
  };

  const getImpactColor = (impact: 'high' | 'medium' | 'low') => {
    switch (impact) {
      case 'high': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    }
  };

  const getEffortColor = (effort: 'high' | 'medium' | 'low') => {
    switch (effort) {
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Conversion Metrics Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>Conversion Analytics</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {conversionData.signupRate.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Sign-up Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {conversionData.trialToProRate.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Trial to Pro</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {conversionData.engagementScore.toFixed(0)}
              </div>
              <div className="text-sm text-gray-600">Engagement Score</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Math.floor(conversionData.timeOnPage)}s
              </div>
              <div className="text-sm text-gray-600">Avg. Time on Page</div>
            </div>
          </div>

          {/* Conversion Funnel */}
          <div>
            <h4 className="text-sm font-medium mb-3">Conversion Funnel</h4>
            <div className="space-y-2">
              {conversionData.conversionFunnelSteps.map((step, index) => (
                <div key={step.step} className="flex items-center space-x-3">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{step.step}</span>
                      <span className="text-sm text-gray-600">
                        {step.conversions} / {step.visitors} ({step.rate}%)
                      </span>
                    </div>
                    <Progress value={step.rate} className="h-2" />
                  </div>
                  {index < conversionData.conversionFunnelSteps.length - 1 && (
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Optimization Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-green-600" />
            <span>Optimization Opportunities</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {optimizations.slice(0, 5).map((optimization) => (
              <div
                key={optimization.id}
                className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="font-medium">{optimization.title}</h4>
                      <Badge className={getImpactColor(optimization.impact)}>
                        {optimization.impact} impact
                      </Badge>
                      <Badge className={getEffortColor(optimization.effort)}>
                        {optimization.effort} effort
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">
                      {optimization.description}
                    </p>
                    <div className="text-xs text-gray-500">
                      Category: {optimization.category}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={optimization.action}
                    className="ml-4"
                  >
                    Apply
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Feature Usage Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-purple-600" />
            <span>Feature Adoption</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(conversionData.featureUsage).map(([feature, usage]) => (
              <div key={feature}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{feature}</span>
                  <span className="text-sm text-gray-600">{usage.toFixed(1)}%</span>
                </div>
                <Progress value={usage} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Wins Section */}
      <Card className="border-green-200 dark:border-green-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-700 dark:text-green-400">
            <Zap className="w-5 h-5" />
            <span>Quick Wins</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Gift className="w-4 h-4 text-green-600" />
                <span className="font-medium text-green-800 dark:text-green-200">
                  Add Trial Extension
                </span>
              </div>
              <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                Offer 7-day trial extension for users who complete onboarding
              </p>
              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                Implement Now
              </Button>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Star className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-blue-800 dark:text-blue-200">
                  Success Stories
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
                Display user success metrics on dashboard
              </p>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                Add Stories
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Hook for tracking conversion events
export function useConversionTracking() {
  const trackEvent = (eventName: string, properties?: Record<string, any>) => {
    // Track conversion events
    console.log('Conversion Event:', eventName, properties);
    
    // Store in local storage for analytics
    const events = JSON.parse(localStorage.getItem('conversionEvents') || '[]');
    events.push({
      event: eventName,
      properties,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('conversionEvents', JSON.stringify(events.slice(-100))); // Keep last 100 events
  };

  return { trackEvent };
}