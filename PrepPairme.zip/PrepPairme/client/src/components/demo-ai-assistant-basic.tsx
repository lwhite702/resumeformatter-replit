import * as React from "react"
import Index from "@/components/ui/travel-connect-signin-1"

function DemoAiAssistantBasic() {
  return (
      <Index/>
  )
}

export { DemoAiAssistantBasic }