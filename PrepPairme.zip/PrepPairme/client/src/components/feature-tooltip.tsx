import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Lightbulb, ArrowRight } from "lucide-react";

interface FeatureTooltipProps {
  feature: string;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
  position?: "top" | "bottom" | "left" | "right";
  children: React.ReactNode;
}

export function FeatureTooltip({ 
  feature, 
  title, 
  description, 
  actionText, 
  onAction, 
  position = "top",
  children 
}: FeatureTooltipProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem(`tooltip_dismissed_${feature}`);
    const used = localStorage.getItem(`feature_used_${feature}`);
    
    if (!dismissed && !used) {
      // Show tooltip after a brief delay when component mounts
      const timer = setTimeout(() => setShowTooltip(true), 500);
      return () => clearTimeout(timer);
    }
  }, [feature]);

  const handleDismiss = () => {
    setShowTooltip(false);
    setIsDismissed(true);
    localStorage.setItem(`tooltip_dismissed_${feature}`, 'true');
  };

  const handleAction = () => {
    localStorage.setItem(`feature_used_${feature}`, 'true');
    setShowTooltip(false);
    onAction?.();
  };

  const positionClasses = {
    top: "bottom-full mb-2",
    bottom: "top-full mt-2",
    left: "right-full mr-2",
    right: "left-full ml-2"
  };

  if (isDismissed || !showTooltip) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      {children}
      
      {showTooltip && (
        <div className={`absolute z-50 ${positionClasses[position]} w-80`}>
          <Card className="border-2 border-purple-200 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center">
                  <Lightbulb className="w-4 h-4 text-purple-600 mr-2" />
                  <Badge variant="outline" className="text-purple-600 border-purple-600 text-xs">
                    New Feature
                  </Badge>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleDismiss}
                  className="h-6 w-6 p-0"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
              
              <h4 className="font-semibold text-gray-900 mb-1">{title}</h4>
              <p className="text-sm text-gray-600 mb-3">{description}</p>
              
              {actionText && onAction && (
                <Button 
                  size="sm" 
                  onClick={handleAction}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  {actionText}
                  <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              )}
            </CardContent>
          </Card>
          
          {/* Arrow pointer */}
          <div 
            className={`absolute w-3 h-3 bg-white border-l border-t border-purple-200 transform rotate-45 ${
              position === 'top' ? 'top-full -mt-1.5' : 
              position === 'bottom' ? 'bottom-full -mb-1.5' :
              position === 'left' ? 'left-full -ml-1.5' :
              'right-full -mr-1.5'
            } ${
              position === 'top' || position === 'bottom' ? 'left-1/2 -translate-x-1/2' :
              'top-1/2 -translate-y-1/2'
            }`}
          />
        </div>
      )}
    </div>
  );
}

// Hook for managing feature discovery tips
export function useFeatureDiscovery() {
  const [currentTip, setCurrentTip] = useState(0);
  const [showTips, setShowTips] = useState(false);

  const tips = [
    {
      id: "mood-board",
      title: "Track Your Career Journey",
      description: "Log your emotions and reflect on your job search experience with our new mood board feature.",
      actionText: "Try Mood Board",
      route: "/career-mood-board"
    },
    {
      id: "video-practice",
      title: "Practice with Video",
      description: "Record yourself answering interview questions and get AI feedback on your performance.",
      actionText: "Start Recording",
      route: "/video-practice"
    },
    {
      id: "job-integrations",
      title: "Connect Job Boards",
      description: "Sync your applications from LinkedIn, Indeed, and other job platforms automatically.",
      actionText: "Connect Now",
      route: "/integrations"
    }
  ];

  useEffect(() => {
    const hasSeenTips = localStorage.getItem('feature_tips_shown');
    if (!hasSeenTips) {
      setTimeout(() => setShowTips(true), 2000);
    }
  }, []);

  const nextTip = () => {
    if (currentTip < tips.length - 1) {
      setCurrentTip(currentTip + 1);
    } else {
      setShowTips(false);
      localStorage.setItem('feature_tips_shown', 'true');
    }
  };

  const dismissTips = () => {
    setShowTips(false);
    localStorage.setItem('feature_tips_shown', 'true');
  };

  return {
    currentTip: tips[currentTip],
    showTips,
    nextTip,
    dismissTips,
    tipNumber: currentTip + 1,
    totalTips: tips.length
  };
}