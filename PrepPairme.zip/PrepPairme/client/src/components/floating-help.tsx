import { useState } from "react";
import { HelpCircle, X, MessageCircle, Mail, Book } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useIsMobile } from "@/hooks/use-mobile";

export function FloatingHelp() {
  const [isOpen, setIsOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className={`floating-help ${isMobile ? 'h-14 w-14' : ''}`}
        size={isMobile ? "default" : "icon"}
      >
        <HelpCircle className={`${isMobile ? 'h-6 w-6' : 'h-5 w-5'}`} />
      </Button>
      {/* Help Dialog */}
    </>
  );
}