import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { UserButton, SignedIn, SignedOut, SignInButton, SignUpButton } from "@clerk/clerk-react";
import { 
  FileText,
  Upload,
  Briefcase,
  VideoIcon,
  Brain,
  BookOpen,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import logoIcon from "@assets/1_1749272880173.png";
import logoWithText from "@assets/3_1749272880173.png";
import { ThemeToggle } from "@/components/theme-toggle";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function NavigationHeader() {
  const [, setLocation] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { name: 'Interview Prep', path: '/questions-database', icon: Brain },
    { name: 'Resume Optimizer', path: '/resume-optimizer', icon: FileText },
    { name: 'Job Tracking', path: '/job-tracker', icon: Briefcase },
    { name: 'Video Practice', path: '/video-practice', icon: VideoIcon },
    { name: 'Career Paths', path: '/career-visualization', icon: BookOpen },
  ];

  return (
    <div className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <header className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <button 
              onClick={() => setLocation('/')}
              className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
            >
              <img src={logoIcon} alt="PrepPair" className="h-8 w-8" />
              <img src={logoWithText} alt="PrepPair" className="h-6 hidden sm:block" />
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="font-medium">
                  Features
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-56">
                {navItems.map((item) => (
                  <DropdownMenuItem 
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className="cursor-pointer"
                  >
                    <item.icon className="mr-2 h-4 w-4" />
                    <span>{item.name}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/pricing')}
              className="font-medium"
            >
              Pricing
            </Button>
            
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/blog')}
              className="font-medium"
            >
              Blog
            </Button>
          </nav>

          {/* User Section */}
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            
            <SignedIn>
              <UserButton 
                appearance={{
                  elements: {
                    avatarBox: "w-10 h-10",
                    userButtonPopoverCard: "shadow-lg border border-gray-200 dark:border-gray-700",
                    userButtonPopoverActions: "bg-white dark:bg-gray-800",
                    userButtonPopoverActionButton: "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700",
                    userButtonPopoverActionButtonText: "font-medium"
                  }
                }}
                afterSignOutUrl="/"
              />
            </SignedIn>
            
            <SignedOut>
              <div className="hidden sm:flex items-center space-x-2">
                <SignInButton>
                  <Button variant="ghost" size="sm">
                    Sign In
                  </Button>
                </SignInButton>
                <SignUpButton>
                  <Button size="sm">
                    Sign Up
                  </Button>
                </SignUpButton>
              </div>
            </SignedOut>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => {
                    setLocation(item.path);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.name}
                </Button>
              ))}
              
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  setLocation('/pricing');
                  setIsMobileMenuOpen(false);
                }}
              >
                Pricing
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  setLocation('/blog');
                  setIsMobileMenuOpen(false);
                }}
              >
                Blog
              </Button>

              <SignedOut>
                <div className="flex flex-col space-y-2 pt-2">
                  <SignInButton>
                    <Button variant="ghost" className="w-full">
                      Sign In
                    </Button>
                  </SignInButton>
                  <SignUpButton>
                    <Button className="w-full">
                      Sign Up
                    </Button>
                  </SignUpButton>
                </div>
              </SignedOut>
            </div>
          </div>
        )}
      </header>
    </div>
  );
}