"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Mail, 
  Target, 
  Brain, 
  FileText, 
  MessageCircle, 
  CheckCircle,
  Sparkles,
  Users,
  TrendingUp
} from "lucide-react";

interface NewsletterSignupProps {
  variant?: "landing" | "dashboard" | "footer" | "popup";
  showFreeGuide?: boolean;
  className?: string;
}

export function NewsletterSignup({ 
  variant = "landing", 
  showFreeGuide = true,
  className = "" 
}: NewsletterSignupProps) {
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { toast } = useToast();

  const subscribeMutation = useMutation({
    mutationFn: async (data: { email: string; firstName?: string; source: string }) => {
      return apiRequest("POST", "/api/beehiiv/subscribe", data);
    },
    onSuccess: () => {
      setIsSubscribed(true);
      toast({
        title: "Welcome to The Job Jumpstart!",
        description: "Check your email for your free interview guide and first newsletter.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Subscription Failed",
        description: error.message || "Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    subscribeMutation.mutate({
      email,
      firstName: firstName || undefined,
      source: variant
    });
  };

  if (isSubscribed) {
    return (
      <Card className={`bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 ${className}`}>
        <CardContent className="pt-6">
          <div className="text-center">
            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-2">
              You're In!
            </h3>
            <p className="text-green-700 dark:text-green-300 mb-4">
              Welcome to The Job Jumpstart. Check your email for your free interview guide.
            </p>
            <Button 
              variant="outline" 
              onClick={() => setIsSubscribed(false)}
              className="border-green-300 text-green-700 hover:bg-green-100"
            >
              Subscribe Another Email
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Landing page variant - full featured
  if (variant === "landing") {
    return (
      <Card className={`bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 border-purple-200 dark:border-purple-800 ${className}`}>
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-purple-100 dark:bg-purple-900/30 rounded-full p-3">
              <Mail className="w-8 h-8 text-purple-600" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            📬 The Job Jumpstart Newsletter
          </CardTitle>
          <p className="text-gray-600 dark:text-gray-300 text-lg">
            Smart interview prep in your inbox — tips, templates, and encouragement from your friendly AI sidekick.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Features */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start space-x-3">
              <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg p-2">
                <Target className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">Expert Strategies</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Interview tactics that actually work</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="bg-green-100 dark:bg-green-900/30 rounded-lg p-2">
                <Brain className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">AI-Powered Tips</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Smart talking points & insights</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="bg-orange-100 dark:bg-orange-900/30 rounded-lg p-2">
                <FileText className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">Ready Templates</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Thank-you notes & resume formats</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg p-2">
                <MessageCircle className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">Weekly Support</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">Motivation & career guidance</p>
              </div>
            </div>
          </div>

          {/* Social Proof */}
          <div className="bg-white/60 dark:bg-gray-800/60 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-300">
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>12,000+ subscribers</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span>89% read rate</span>
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4" />
                <span>Weekly delivery</span>
              </div>
            </div>
          </div>

          {/* Signup Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Input
                type="text"
                placeholder="First name (optional)"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className="bg-white/80 dark:bg-gray-800/80"
              />
              <Input
                type="email"
                placeholder="your.email@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white/80 dark:bg-gray-800/80"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              disabled={subscribeMutation.isPending}
            >
              {subscribeMutation.isPending ? "Subscribing..." : "👉 Subscribe & Get Free Interview Guide"}
            </Button>
          </form>

          {showFreeGuide && (
            <div className="text-center">
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200">
                🎁 Instant Access: Complete Interview Strategy Guide
              </Badge>
            </div>
          )}

          <p className="text-xs text-center text-gray-500 dark:text-gray-400">
            Join thousands leveling up with smarter prep, fewer nerves, and better outcomes. Unsubscribe anytime.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Dashboard variant - compact
  if (variant === "dashboard") {
    return (
      <Card className={`bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 ${className}`}>
        <CardContent className="pt-6">
          <div className="flex items-start space-x-4">
            <div className="bg-blue-100 dark:bg-blue-900/30 rounded-full p-2">
              <Mail className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-1">
                Weekly Career Tips
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                Get The Job Jumpstart newsletter with expert interview strategies and AI-powered insights.
              </p>
              <form onSubmit={handleSubmit} className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                  required
                />
                <Button 
                  type="submit" 
                  size="sm"
                  disabled={subscribeMutation.isPending}
                >
                  {subscribeMutation.isPending ? "..." : "Subscribe"}
                </Button>
              </form>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Footer variant - minimal
  if (variant === "footer") {
    return (
      <div className={`${className}`}>
        <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
          📬 The Job Jumpstart
        </h4>
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Weekly AI-powered career tips and interview strategies in your inbox.
        </p>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="bg-white dark:bg-gray-800"
            required
          />
          <Button 
            type="submit" 
            className="w-full"
            disabled={subscribeMutation.isPending}
          >
            {subscribeMutation.isPending ? "Subscribing..." : "Subscribe Free"}
          </Button>
        </form>
      </div>
    );
  }

  // Popup variant - attention-grabbing
  return (
    <Card className={`bg-gradient-to-br from-purple-600 to-blue-600 text-white ${className}`}>
      <CardContent className="pt-6">
        <div className="text-center">
          <div className="bg-white/20 rounded-full p-3 w-fit mx-auto mb-4">
            <Mail className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold mb-2">
            Get Weekly Career Wins
          </h3>
          <p className="text-white/90 mb-4">
            Join 12,000+ job seekers getting smart interview tips and AI-powered strategies.
          </p>
          <form onSubmit={handleSubmit} className="space-y-3">
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
              required
            />
            <Button 
              type="submit" 
              className="w-full bg-white text-purple-600 hover:bg-white/90"
              disabled={subscribeMutation.isPending}
            >
              {subscribeMutation.isPending ? "Subscribing..." : "Get Free Guide + Newsletter"}
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  );
}