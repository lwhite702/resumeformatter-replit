import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle, ArrowRight, Target, FileText, Video, BarChart3, Users } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface OnboardingStep {
  id: number;
  title: string;
  description: string;
  icon: any;
  action: string;
  benefits: string[];
}

interface OnboardingWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export function OnboardingWizard({ isOpen, onClose, onComplete }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const steps: OnboardingStep[] = [
    {
      id: 0,
      title: "Welcome to PrepPair.me",
      description: "Your AI-powered career development partner is ready to transform your job search journey.",
      icon: Target,
      action: "Get Started",
      benefits: [
        "AI-powered interview preparation",
        "Resume optimization with ATS scoring", 
        "Job application tracking",
        "Video practice sessions with feedback"
      ]
    },
    {
      id: 1,
      title: "Optimize Your Resume",
      description: "Upload your resume to get instant ATS scoring and personalized improvement suggestions.",
      icon: FileText,
      action: "Upload Resume",
      benefits: [
        "Instant ATS compatibility scoring",
        "Keyword optimization suggestions",
        "Industry-specific improvements",
        "Professional formatting templates"
      ]
    },
    {
      id: 2,
      title: "Practice Interviews",
      description: "Start with AI-powered mock interviews tailored to your target role and industry.",
      icon: Video,
      action: "Start Practice",
      benefits: [
        "Role-specific interview questions",
        "Real-time AI feedback on responses",
        "Video analysis for body language",
        "STAR method coaching"
      ]
    },
    {
      id: 3,
      title: "Track Applications",
      description: "Organize your job search with our comprehensive application tracking system.",
      icon: BarChart3,
      action: "Set Up Tracking",
      benefits: [
        "Application status monitoring",
        "Interview scheduling reminders",
        "Follow-up email templates",
        "Success analytics dashboard"
      ]
    },
    {
      id: 4,
      title: "Join the Community",
      description: "Connect with other job seekers and share your success stories.",
      icon: Users,
      action: "Explore Community",
      benefits: [
        "Peer support and networking",
        "Success story sharing",
        "Industry insights and tips",
        "Weekly career development challenges"
      ]
    }
  ];

  const progress = ((currentStep + 1) / steps.length) * 100;
  const currentStepData = steps[currentStep];

  const handleNext = () => {
    const newCompletedSteps = [...completedSteps, currentStep];
    setCompletedSteps(newCompletedSteps);

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
      onClose();
    }
  };

  const handleSkip = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between mb-4">
            <DialogTitle className="text-2xl font-bold">
              Getting Started with PrepPair.me
            </DialogTitle>
            <Badge variant="outline">
              Step {currentStep + 1} of {steps.length}
            </Badge>
          </div>
          <Progress value={progress} className="mb-6" />
        </DialogHeader>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full w-fit">
                  <currentStepData.icon className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl mb-2">{currentStepData.title}</CardTitle>
                <CardDescription className="text-base">
                  {currentStepData.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <h4 className="font-semibold text-lg mb-3">What you'll get:</h4>
                  <div className="grid gap-3">
                    {currentStepData.benefits.map((benefit, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center gap-3 p-3 bg-white/60 dark:bg-gray-800/60 rounded-lg"
                      >
                        <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{benefit}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 mt-8">
                  <Button 
                    onClick={handleNext}
                    size="lg" 
                    className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    {currentStep === steps.length - 1 ? "Complete Setup" : currentStepData.action}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  
                  {currentStep < steps.length - 1 && (
                    <Button 
                      variant="outline" 
                      onClick={handleSkip}
                      size="lg"
                      className="sm:w-auto"
                    >
                      Skip for now
                    </Button>
                  )}
                </div>

                {/* Step indicators */}
                <div className="flex justify-center gap-2 mt-6">
                  {steps.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        index === currentStep
                          ? 'bg-blue-600'
                          : completedSteps.includes(index)
                          ? 'bg-green-500'
                          : 'bg-gray-300 dark:bg-gray-600'
                      }`}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}