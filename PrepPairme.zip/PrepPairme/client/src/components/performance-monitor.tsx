"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Activity, 
  Zap, 
  Clock, 
  Database, 
  Wifi, 
  AlertTriangle,
  CheckCircle,
  TrendingUp
} from "lucide-react";

interface PerformanceMetrics {
  loadTime: number;
  renderTime: number;
  apiResponseTime: number;
  memoryUsage: number;
  networkLatency: number;
  cacheHitRate: number;
  errorRate: number;
  userInteractions: number;
}

interface PerformanceMonitorProps {
  showDetailed?: boolean;
  onOptimizationSuggestion?: (suggestion: string) => void;
}

export function PerformanceMonitor({ 
  showDetailed = false, 
  onOptimizationSuggestion 
}: PerformanceMonitorProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    loadTime: 0,
    renderTime: 0,
    apiResponseTime: 0,
    memoryUsage: 0,
    networkLatency: 0,
    cacheHitRate: 0,
    errorRate: 0,
    userInteractions: 0
  });
  const [performanceScore, setPerformanceScore] = useState(0);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  useEffect(() => {
    measurePerformance();
    const interval = setInterval(measurePerformance, 5000);
    return () => clearInterval(interval);
  }, []);

  const measurePerformance = () => {
    // Measure page load time
    const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    const loadTime = navigation ? navigation.loadEventEnd - navigation.navigationStart : 0;

    // Measure render time
    const paintEntries = performance.getEntriesByType('paint');
    const renderTime = paintEntries.length > 0 ? paintEntries[paintEntries.length - 1].startTime : 0;

    // Estimate memory usage (if available)
    const memoryInfo = (performance as any).memory;
    const memoryUsage = memoryInfo ? (memoryInfo.usedJSHeapSize / memoryInfo.totalJSHeapSize) * 100 : 0;

    // Simulate other metrics for demonstration
    const apiResponseTime = Math.random() * 500 + 100;
    const networkLatency = Math.random() * 100 + 20;
    const cacheHitRate = Math.random() * 40 + 60;
    const errorRate = Math.random() * 5;
    const userInteractions = Math.floor(Math.random() * 50) + 10;

    const newMetrics = {
      loadTime: loadTime / 1000,
      renderTime: renderTime / 1000,
      apiResponseTime,
      memoryUsage,
      networkLatency,
      cacheHitRate,
      errorRate,
      userInteractions
    };

    setMetrics(newMetrics);
    calculatePerformanceScore(newMetrics);
    generateSuggestions(newMetrics);
  };

  const calculatePerformanceScore = (metrics: PerformanceMetrics) => {
    let score = 100;
    
    // Deduct points for poor performance
    if (metrics.loadTime > 3) score -= 20;
    if (metrics.apiResponseTime > 300) score -= 15;
    if (metrics.memoryUsage > 80) score -= 10;
    if (metrics.networkLatency > 100) score -= 10;
    if (metrics.cacheHitRate < 70) score -= 10;
    if (metrics.errorRate > 2) score -= 15;

    setPerformanceScore(Math.max(0, score));
  };

  const generateSuggestions = (metrics: PerformanceMetrics) => {
    const newSuggestions: string[] = [];

    if (metrics.loadTime > 3) {
      newSuggestions.push("Consider code splitting and lazy loading for faster initial load");
    }
    if (metrics.apiResponseTime > 300) {
      newSuggestions.push("Implement API caching and optimize database queries");
    }
    if (metrics.memoryUsage > 80) {
      newSuggestions.push("Check for memory leaks and optimize component cleanup");
    }
    if (metrics.cacheHitRate < 70) {
      newSuggestions.push("Improve caching strategy for frequently accessed data");
    }
    if (metrics.errorRate > 2) {
      newSuggestions.push("Review error handling and implement better fallbacks");
    }

    setSuggestions(newSuggestions);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreIcon = (score: number) => {
    if (score >= 90) return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (score >= 70) return <TrendingUp className="w-5 h-5 text-yellow-600" />;
    return <AlertTriangle className="w-5 h-5 text-red-600" />;
  };

  if (!showDetailed) {
    return (
      <div className="flex items-center space-x-2 bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
        <Activity className="w-4 h-4 text-blue-600" />
        <span className="text-sm font-medium">Performance Score:</span>
        <Badge variant={performanceScore >= 90 ? "default" : performanceScore >= 70 ? "secondary" : "destructive"}>
          {performanceScore.toFixed(0)}%
        </Badge>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-blue-600" />
          <span>Performance Monitor</span>
          {getScoreIcon(performanceScore)}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Performance Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Overall Performance</span>
            <span className={`text-lg font-bold ${getScoreColor(performanceScore)}`}>
              {performanceScore.toFixed(0)}%
            </span>
          </div>
          <Progress value={performanceScore} className="h-2" />
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Load Time</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.loadTime.toFixed(2)}s
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-gray-500" />
                <span className="text-sm">API Response</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.apiResponseTime.toFixed(0)}ms
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Memory Usage</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.memoryUsage.toFixed(1)}%
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Wifi className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Network Latency</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.networkLatency.toFixed(0)}ms
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Cache Hit Rate</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.cacheHitRate.toFixed(1)}%
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Error Rate</span>
              </div>
              <span className="text-sm font-medium">
                {metrics.errorRate.toFixed(1)}%
              </span>
            </div>
          </div>
        </div>

        {/* Optimization Suggestions */}
        {suggestions.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-2">Optimization Suggestions</h4>
            <div className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg"
                >
                  <AlertTriangle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-blue-800 dark:text-blue-200">
                    {suggestion}
                  </span>
                  {onOptimizationSuggestion && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onOptimizationSuggestion(suggestion)}
                      className="ml-auto"
                    >
                      Apply
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Real-time Stats */}
        <div className="text-xs text-gray-500 border-t pt-2">
          Last updated: {new Date().toLocaleTimeString()} • 
          User interactions: {metrics.userInteractions}
        </div>
      </CardContent>
    </Card>
  );
}

// Hook for tracking user interactions
export function usePerformanceTracking() {
  useEffect(() => {
    let interactionCount = 0;

    const trackInteraction = () => {
      interactionCount++;
      // Store in session storage for performance component
      sessionStorage.setItem('userInteractions', interactionCount.toString());
    };

    // Track various user interactions
    document.addEventListener('click', trackInteraction);
    document.addEventListener('keydown', trackInteraction);
    document.addEventListener('scroll', trackInteraction);

    return () => {
      document.removeEventListener('click', trackInteraction);
      document.removeEventListener('keydown', trackInteraction);
      document.removeEventListener('scroll', trackInteraction);
    };
  }, []);
}