import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  ChevronDown, 
  ChevronRight, 
  CheckCircle, 
  Lock,
  Sparkles,
  Target,
  FileText,
  Video,
  BarChart3,
  Users,
  Star
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface FeatureStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  isCompleted: boolean;
  isLocked: boolean;
  estimatedTime: string;
  benefits: string[];
  action?: {
    label: string;
    href: string;
  };
  subSteps?: {
    id: string;
    title: string;
    isCompleted: boolean;
  }[];
}

interface ProgressiveDisclosureProps {
  userProgress?: {
    onboardingCompleted?: boolean;
    resumeUploaded?: boolean;
    firstPracticeCompleted?: boolean;
    jobApplicationsAdded?: boolean;
    videoSessionCompleted?: boolean;
    analyticsViewed?: boolean;
    isPro?: boolean;
  };
}

export function ProgressiveDisclosure({ userProgress = {} }: ProgressiveDisclosureProps) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['getting-started']));
  const [features, setFeatures] = useState<FeatureStep[]>([]);

  useEffect(() => {
    const featureSteps = generateFeatureSteps(userProgress);
    setFeatures(featureSteps);
  }, [userProgress]);

  const generateFeatureSteps = (progress: typeof userProgress): FeatureStep[] => {
    return [
      {
        id: 'getting-started',
        title: 'Getting Started',
        description: 'Set up your profile and upload your first resume',
        icon: <Target className="w-5 h-5" />,
        isCompleted: !!progress.onboardingCompleted && !!progress.resumeUploaded,
        isLocked: false,
        estimatedTime: '5 minutes',
        benefits: ['Personalized interview questions', 'ATS optimization', 'Skill analysis'],
        action: {
          label: progress.onboardingCompleted ? 'Upload Resume' : 'Complete Setup',
          href: progress.onboardingCompleted ? '/resumes' : '/onboarding'
        },
        subSteps: [
          {
            id: 'profile-setup',
            title: 'Complete profile setup',
            isCompleted: !!progress.onboardingCompleted
          },
          {
            id: 'resume-upload',
            title: 'Upload your resume',
            isCompleted: !!progress.resumeUploaded
          }
        ]
      },
      {
        id: 'practice-interviews',
        title: 'Practice Interviews',
        description: 'Start with mock interviews to build confidence',
        icon: <Video className="w-5 h-5" />,
        isCompleted: !!progress.firstPracticeCompleted,
        isLocked: !progress.resumeUploaded,
        estimatedTime: '15 minutes',
        benefits: ['Build confidence', 'Improve delivery', 'Get AI feedback'],
        action: {
          label: 'Start Practice',
          href: '/practice'
        },
        subSteps: [
          {
            id: 'behavioral-practice',
            title: 'Practice behavioral questions',
            isCompleted: !!progress.firstPracticeCompleted
          },
          {
            id: 'technical-practice',
            title: 'Technical interview prep',
            isCompleted: false
          }
        ]
      },
      {
        id: 'track-applications',
        title: 'Track Applications',
        description: 'Organize your job search and interview pipeline',
        icon: <FileText className="w-5 h-5" />,
        isCompleted: !!progress.jobApplicationsAdded,
        isLocked: !progress.firstPracticeCompleted,
        estimatedTime: '10 minutes',
        benefits: ['Stay organized', 'Track progress', 'Never miss follow-ups'],
        action: {
          label: 'Add Applications',
          href: '/applications'
        }
      },
      {
        id: 'video-analysis',
        title: 'Video Interview Analysis',
        description: 'Record practice sessions and get detailed feedback',
        icon: <Video className="w-5 h-5" />,
        isCompleted: !!progress.videoSessionCompleted,
        isLocked: !progress.jobApplicationsAdded || !progress.isPro,
        estimatedTime: '20 minutes',
        benefits: ['Body language analysis', 'Speaking pace feedback', 'Confidence scoring'],
        action: {
          label: progress.isPro ? 'Record Session' : 'Upgrade to Pro',
          href: progress.isPro ? '/video-practice' : '/pricing'
        }
      },
      {
        id: 'analytics-insights',
        title: 'Performance Analytics',
        description: 'Track your improvement with detailed insights',
        icon: <BarChart3 className="w-5 h-5" />,
        isCompleted: !!progress.analyticsViewed,
        isLocked: !progress.firstPracticeCompleted,
        estimatedTime: '5 minutes',
        benefits: ['Track improvement', 'Identify weak areas', 'Set goals'],
        action: {
          label: 'View Analytics',
          href: '/analytics'
        }
      },
      {
        id: 'advanced-features',
        title: 'Advanced Features',
        description: 'Unlock premium capabilities for serious job seekers',
        icon: <Star className="w-5 h-5" />,
        isCompleted: !!progress.isPro,
        isLocked: false,
        estimatedTime: '2 minutes',
        benefits: ['Unlimited practice', 'Advanced analytics', 'Priority support'],
        action: {
          label: progress.isPro ? 'Explore Pro Features' : 'Upgrade to Pro',
          href: progress.isPro ? '/dashboard' : '/pricing'
        }
      }
    ];
  };

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const completedSteps = features.filter(f => f.isCompleted).length;
  const totalSteps = features.length;
  const progressPercentage = (completedSteps / totalSteps) * 100;

  const getNextAction = () => {
    const nextIncompleteStep = features.find(f => !f.isCompleted && !f.isLocked);
    return nextIncompleteStep;
  };

  const nextAction = getNextAction();

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Your Progress</CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                {completedSteps} of {totalSteps} features unlocked
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-purple-600">{Math.round(progressPercentage)}%</div>
              <Badge variant="secondary" className="mt-1">
                {completedSteps === totalSteps ? 'Complete' : 'In Progress'}
              </Badge>
            </div>
          </div>
          <Progress value={progressPercentage} className="mt-4" />
        </CardHeader>
      </Card>

      {/* Next Recommended Action */}
      {nextAction && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                <Sparkles className="w-6 h-6 text-orange-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-orange-900">Recommended Next Step</h3>
                <p className="text-sm text-orange-700">{nextAction.title}</p>
              </div>
              <Button 
                size="sm" 
                asChild
                className="bg-orange-600 hover:bg-orange-700"
              >
                <a href={nextAction.action?.href}>
                  {nextAction.action?.label}
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Feature Steps */}
      <div className="space-y-3">
        {features.map((feature, index) => (
          <Card 
            key={feature.id}
            className={`transition-all duration-200 ${
              feature.isCompleted 
                ? 'border-green-200 bg-green-50' 
                : feature.isLocked 
                  ? 'border-gray-200 bg-gray-50 opacity-60'
                  : 'border-blue-200 bg-blue-50 hover:shadow-md'
            }`}
          >
            <CardHeader 
              className="cursor-pointer"
              onClick={() => !feature.isLocked && toggleSection(feature.id)}
            >
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  {feature.isCompleted ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : feature.isLocked ? (
                    <Lock className="w-6 h-6 text-gray-400" />
                  ) : (
                    <div className="w-6 h-6 rounded-full border-2 border-blue-600 flex items-center justify-center">
                      <div className="w-3 h-3 rounded-full bg-blue-600" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      {feature.icon}
                      <h3 className="font-semibold">{feature.title}</h3>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {feature.estimatedTime}
                    </Badge>
                    {feature.isCompleted && (
                      <Badge className="bg-green-100 text-green-800">Complete</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{feature.description}</p>
                </div>

                {!feature.isLocked && (
                  <div className="flex-shrink-0">
                    {expandedSections.has(feature.id) ? (
                      <ChevronDown className="w-5 h-5 text-gray-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    )}
                  </div>
                )}
              </div>
            </CardHeader>

            <AnimatePresence>
              {expandedSections.has(feature.id) && !feature.isLocked && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      {/* Benefits */}
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 mb-2">Benefits:</h4>
                        <ul className="space-y-1">
                          {feature.benefits.map((benefit, i) => (
                            <li key={i} className="text-sm text-gray-600 flex items-center">
                              <CheckCircle className="w-3 h-3 text-green-500 mr-2 flex-shrink-0" />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Sub-steps */}
                      {feature.subSteps && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-900 mb-2">Steps:</h4>
                          <div className="space-y-2">
                            {feature.subSteps.map((subStep) => (
                              <div key={subStep.id} className="flex items-center space-x-2">
                                {subStep.isCompleted ? (
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                ) : (
                                  <div className="w-4 h-4 rounded-full border border-gray-300" />
                                )}
                                <span className={`text-sm ${subStep.isCompleted ? 'text-green-700' : 'text-gray-600'}`}>
                                  {subStep.title}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Action Button */}
                      {feature.action && !feature.isCompleted && (
                        <Button asChild className="w-full">
                          <a href={feature.action.href}>
                            {feature.action.label}
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        ))}
      </div>
    </div>
  );
}