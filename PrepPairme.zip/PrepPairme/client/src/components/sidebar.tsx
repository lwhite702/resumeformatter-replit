import React, { useState } from "react";
import { useLocation, Switch, Route } from "wouter";
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar";
import { useAuth } from "@/hooks/useAuth";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  Home,
  FileText,
  Briefcase,
  Sparkles,
  Target,
  Video,
  TrendingUp,
  Database,
  Users,
  LogOut,
  Zap,
  Brain,
  BookOpen,
  Link2,
  Upload
} from "lucide-react";
import logoIcon from "@assets/1_1749272880173.png";

// Import pages
import Dashboard from "@/pages/dashboard";
import InterviewGuide from "@/pages/interview-guide";
import ResumeOptimizer from "@/pages/resume-optimizer";
import SkillHighlights from "@/pages/skill-highlights";
import JobTracker from "@/pages/job-tracker";
import JobBoardIntegrations from "@/pages/job-board-integrations";
import CareerVisualization from "@/pages/career-visualization";
import QuestionsDatabase from "@/pages/questions-database";
import VideoPractice from "@/pages/video-practice";
import AIFineTuning from "@/pages/ai-fine-tuning";
import TermsGlossary from "@/pages/terms-glossary";
import AdminDashboard from "@/pages/admin-dashboard";
import Subscribe from "@/pages/subscribe";
import NotFound from "@/pages/not-found";

export function AppSidebar() {
  const [open, setOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const navigationSections = [
    {
      title: "Overview",
      links: [
        {
          label: "Dashboard",
          href: "/",
          icon: (
            <Home className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    },
    {
      title: "Resume & Skills",
      links: [
        {
          label: "Resume Optimizer",
          href: "/resume-optimizer",
          icon: (
            <FileText className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "AI Skill Highlights",
          href: "/skill-highlights",
          icon: (
            <Sparkles className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "Resume Import",
          href: "/resume-import",
          icon: (
            <Upload className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    },
    {
      title: "Interview Preparation",
      links: [
        {
          label: "Interview Guides",
          href: "/interview-guide",
          icon: (
            <Target className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "Video Practice",
          href: "/video-practice",
          icon: (
            <Video className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "Questions Database",
          href: "/questions",
          icon: (
            <Database className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    },
    {
      title: "Job Applications",
      links: [
        {
          label: "Job Tracker",
          href: "/job-tracker",
          icon: (
            <Briefcase className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "Job Board Integrations",
          href: "/integrations",
          icon: (
            <Link2 className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    },
    {
      title: "Career Development",
      links: [
        {
          label: "Career Visualization",
          href: "/career-visualization",
          icon: (
            <TrendingUp className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "AI Fine-tuning",
          href: "/ai-tuning",
          icon: (
            <Brain className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
        {
          label: "Terms Glossary",
          href: "/terms",
          icon: (
            <BookOpen className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    }
  ];

  // Add admin section if user is admin
  if (user?.role === "admin" || user?.role === "super_admin") {
    navigationSections.push({
      title: "Administration",
      links: [
        {
          label: "Admin Dashboard",
          href: "/admin",
          icon: (
            <Users className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
          ),
        },
      ]
    });
  }

  return (
    <div
      className={cn(
        "rounded-md flex flex-col md:flex-row bg-gray-100 dark:bg-neutral-800 w-full flex-1 border border-neutral-200 dark:border-neutral-700 overflow-hidden",
        "h-screen"
      )}
    >
      <Sidebar open={open} setOpen={setOpen}>
        <SidebarBody className="justify-between gap-10">
          <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
            {open ? <Logo /> : <LogoIcon />}
            <div className="mt-8 flex flex-col gap-4">
              {navigationSections.map((section) => (
                <div key={section.title}>
                  {open && (
                    <h3 className="text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-2 px-2">
                      {section.title}
                    </h3>
                  )}
                  <div className="flex flex-col gap-1">
                    {section.links.map((link, idx) => (
                      <SidebarLink 
                        key={idx} 
                        link={link}
                        onClick={() => setLocation(link.href)}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            {isAuthenticated && (
              <>
                <SidebarLink
                  link={{
                    label: user?.firstName || user?.email || "User",
                    href: "#",
                    icon: (
                      <div className="h-7 w-7 flex-shrink-0 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600">
                          {user?.firstName?.charAt(0) || user?.email?.charAt(0) || "U"}
                        </span>
                      </div>
                    ),
                  }}
                />
                <SidebarLink
                  link={{
                    label: "Sign Out",
                    href: "#",
                    icon: (
                      <LogOut className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
                    ),
                  }}
                  onClick={() => window.location.href = "/api/logout"}
                />
              </>
            )}
          </div>
        </SidebarBody>
      </Sidebar>
      <div className="flex flex-1">
        <div className="p-2 md:p-10 rounded-tl-2xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 flex flex-col gap-2 flex-1 w-full h-full overflow-auto">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/interview-guide/:id?" component={InterviewGuide} />
            <Route path="/resume-optimizer" component={ResumeOptimizer} />
            <Route path="/skill-highlights" component={SkillHighlights} />
            <Route path="/job-tracker" component={JobTracker} />
            <Route path="/integrations" component={JobBoardIntegrations} />
            <Route path="/career-visualization" component={CareerVisualization} />
            <Route path="/questions" component={QuestionsDatabase} />
            <Route path="/video-practice" component={VideoPractice} />
            <Route path="/ai-tuning" component={AIFineTuning} />
            <Route path="/terms" component={TermsGlossary} />
            <Route path="/admin" component={AdminDashboard} />
            <Route path="/subscribe" component={Subscribe} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    </div>
  );
}

export const Logo = () => {
  return (
    <div className="font-normal flex space-x-2 items-center text-sm text-black py-1 relative z-20">
      <img 
        src={logoIcon} 
        alt="PrepPair.me" 
        className="h-6 w-6 flex-shrink-0"
      />
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="font-medium text-black dark:text-white whitespace-pre"
      >
        PrepPair.me
      </motion.span>
    </div>
  );
};

export const LogoIcon = () => {
  return (
    <div className="font-normal flex space-x-2 items-center text-sm text-black py-1 relative z-20">
      <img 
        src={logoIcon} 
        alt="PrepPair.me" 
        className="h-6 w-6 flex-shrink-0"
      />
    </div>
  );
};