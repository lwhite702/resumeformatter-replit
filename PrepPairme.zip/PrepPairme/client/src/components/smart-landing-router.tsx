import { useEffect } from "react";
import { useLocation } from "wouter";
import Landing from "@/pages/landing";
import SocialLanding from "@/pages/landing-social";
import AdsLanding from "@/pages/landing-ads";
import WrelikLanding from "@/pages/landing-wrelik";

export function SmartLandingRouter() {
  const [location, setLocation] = useLocation();
  
  useEffect(() => {
    // Parse URL parameters to detect acquisition channel
    const urlParams = new URLSearchParams(window.location.search);
    const utmSource = urlParams.get('utm_source');
    const utmMedium = urlParams.get('utm_medium');
    const utmCampaign = urlParams.get('utm_campaign');
    const ref = urlParams.get('ref');
    
    // Determine appropriate landing page based on parameters
    let targetLanding = null;
    
    // Social media campaigns
    if (utmSource === 'social' || 
        utmMedium === 'social' ||
        ['facebook', 'instagram', 'twitter', 'linkedin', 'tiktok', 'youtube'].includes(utmSource?.toLowerCase() || '')) {
      targetLanding = '/landing/social';
    }
    
    // Paid advertising campaigns
    else if (utmSource === 'ads' || 
             utmMedium === 'cpc' || 
             utmMedium === 'paid' ||
             ['google', 'facebook-ads', 'linkedin-ads', 'bing', 'ppc'].includes(utmSource?.toLowerCase() || '')) {
      targetLanding = '/landing/ads';
    }
    
    // Wrelik Brands ecosystem referrals
    else if (utmSource === 'wrelik' || 
             ref === 'wrelik' ||
             ['resumeformatter', 'autoapply', 'careermentor', 'wrelikbrands'].includes(utmSource?.toLowerCase() || '') ||
             utmCampaign?.includes('ecosystem')) {
      targetLanding = '/landing/wrelik';
    }
    
    // Redirect to specialized landing page if detected
    if (targetLanding && location === '/') {
      setLocation(targetLanding + window.location.search);
    }
  }, [location, setLocation]);
  
  // If on root path, determine which landing page to show
  if (location === '/') {
    const urlParams = new URLSearchParams(window.location.search);
    const utmSource = urlParams.get('utm_source');
    const utmMedium = urlParams.get('utm_medium');
    const utmCampaign = urlParams.get('utm_campaign');
    const ref = urlParams.get('ref');
    
    // Social media campaigns
    if (utmSource === 'social' || 
        utmMedium === 'social' ||
        ['facebook', 'instagram', 'twitter', 'linkedin', 'tiktok', 'youtube'].includes(utmSource?.toLowerCase() || '')) {
      return <SocialLanding />;
    }
    
    // Paid advertising campaigns
    if (utmSource === 'ads' || 
        utmMedium === 'cpc' || 
        utmMedium === 'paid' ||
        ['google', 'facebook-ads', 'linkedin-ads', 'bing', 'ppc'].includes(utmSource?.toLowerCase() || '')) {
      return <AdsLanding />;
    }
    
    // Wrelik Brands ecosystem referrals
    if (utmSource === 'wrelik' || 
        ref === 'wrelik' ||
        ['resumeformatter', 'autoapply', 'careermentor', 'wrelikbrands'].includes(utmSource?.toLowerCase() || '') ||
        utmCampaign?.includes('ecosystem')) {
      return <WrelikLanding />;
    }
  }
  
  // Default landing page
  return <Landing />;
}