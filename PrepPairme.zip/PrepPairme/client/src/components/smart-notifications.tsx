import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  X, 
  TrendingUp, 
  Clock, 
  Target, 
  Sparkles,
  ArrowRight,
  Bell
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface SmartNotification {
  id: string;
  type: 'tip' | 'reminder' | 'achievement' | 'suggestion';
  title: string;
  message: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  priority: 'low' | 'medium' | 'high';
  category: string;
  expiresAt?: Date;
}

interface SmartNotificationsProps {
  userActivity?: {
    lastLogin?: Date;
    completedOnboarding?: boolean;
    hasResume?: boolean;
    hasJobApplications?: boolean;
    practiceSessionsCount?: number;
    isPro?: boolean;
  };
}

export function SmartNotifications({ userActivity = {} }: SmartNotificationsProps) {
  const [notifications, setNotifications] = useState<SmartNotification[]>([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const smartNotifications = generateSmartNotifications(userActivity);
    setNotifications(smartNotifications);
    
    if (smartNotifications.length > 0) {
      // Show notifications after a short delay
      const timer = setTimeout(() => setIsVisible(true), 2000);
      return () => clearTimeout(timer);
    }
  }, [userActivity]);

  const generateSmartNotifications = (activity: typeof userActivity): SmartNotification[] => {
    const notifications: SmartNotification[] = [];
    const now = new Date();

    // New user onboarding tip
    if (!activity.completedOnboarding) {
      notifications.push({
        id: 'onboarding-tip',
        type: 'tip',
        title: 'Get Started in 3 Minutes',
        message: 'Complete your profile setup to receive personalized interview preparation.',
        action: {
          label: 'Complete Setup',
          onClick: () => {
            // Trigger onboarding wizard
            window.dispatchEvent(new CustomEvent('openOnboarding'));
          }
        },
        priority: 'high',
        category: 'setup'
      });
    }

    // Resume upload reminder
    if (activity.completedOnboarding && !activity.hasResume) {
      notifications.push({
        id: 'resume-reminder',
        type: 'reminder',
        title: 'Upload Your Resume',
        message: 'Get ATS optimization and tailored interview questions based on your experience.',
        action: {
          label: 'Upload Resume',
          onClick: () => {
            window.location.href = '/resumes';
          }
        },
        priority: 'medium',
        category: 'content'
      });
    }

    // Practice session suggestion
    if (activity.practiceSessionsCount === 0 && activity.hasResume) {
      notifications.push({
        id: 'practice-suggestion',
        type: 'suggestion',
        title: 'Start Your First Practice',
        message: 'Practice makes perfect! Try a mock interview to build confidence.',
        action: {
          label: 'Start Practice',
          onClick: () => {
            window.location.href = '/practice';
          }
        },
        priority: 'medium',
        category: 'practice'
      });
    }

    // Achievement for active users
    if ((activity.practiceSessionsCount || 0) >= 5) {
      notifications.push({
        id: 'practice-achievement',
        type: 'achievement',
        title: 'Practice Champion!',
        message: 'You\'ve completed 5+ practice sessions. You\'re building great habits!',
        priority: 'low',
        category: 'achievement',
        expiresAt: new Date(now.getTime() + 24 * 60 * 60 * 1000) // 24 hours
      });
    }

    // Pro upgrade suggestion for active free users
    if (!activity.isPro && (activity.practiceSessionsCount || 0) >= 3) {
      notifications.push({
        id: 'pro-upgrade',
        type: 'suggestion',
        title: 'Unlock Advanced Features',
        message: 'You\'re making great progress! Upgrade to Pro for unlimited practice and premium features.',
        action: {
          label: 'View Pro',
          onClick: () => {
            window.location.href = '/pricing';
          }
        },
        priority: 'medium',
        category: 'upgrade'
      });
    }

    // Job application tracking tip
    if (!activity.hasJobApplications && activity.hasResume) {
      notifications.push({
        id: 'job-tracking-tip',
        type: 'tip',
        title: 'Track Your Applications',
        message: 'Stay organized by tracking your job applications and interview progress.',
        action: {
          label: 'Add Application',
          onClick: () => {
            window.location.href = '/applications';
          }
        },
        priority: 'low',
        category: 'organization'
      });
    }

    // Welcome back message for returning users
    if (activity.lastLogin) {
      const daysSinceLogin = Math.floor((now.getTime() - activity.lastLogin.getTime()) / (1000 * 60 * 60 * 24));
      if (daysSinceLogin >= 7) {
        notifications.push({
          id: 'welcome-back',
          type: 'tip',
          title: 'Welcome Back!',
          message: 'Ready to continue your interview preparation journey?',
          action: {
            label: 'Continue Learning',
            onClick: () => {
              window.location.href = '/dashboard';
            }
          },
          priority: 'medium',
          category: 'engagement'
        });
      }
    }

    return notifications.slice(0, 2); // Show maximum 2 notifications
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    
    // Store dismissed notification to avoid showing again
    const dismissed = JSON.parse(localStorage.getItem('dismissedNotifications') || '[]');
    dismissed.push(id);
    localStorage.setItem('dismissedNotifications', JSON.stringify(dismissed));
  };

  const getNotificationIcon = (type: SmartNotification['type']) => {
    switch (type) {
      case 'tip': return <Sparkles className="w-5 h-5 text-blue-600" />;
      case 'reminder': return <Clock className="w-5 h-5 text-orange-600" />;
      case 'achievement': return <Target className="w-5 h-5 text-green-600" />;
      case 'suggestion': return <TrendingUp className="w-5 h-5 text-purple-600" />;
      default: return <Bell className="w-5 h-5 text-gray-600" />;
    }
  };

  const getPriorityColor = (priority: SmartNotification['priority']) => {
    switch (priority) {
      case 'high': return 'border-l-red-500 bg-red-50';
      case 'medium': return 'border-l-orange-500 bg-orange-50';
      case 'low': return 'border-l-blue-500 bg-blue-50';
      default: return 'border-l-gray-500 bg-gray-50';
    }
  };

  if (!isVisible || notifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-3 max-w-sm">
      <AnimatePresence>
        {notifications.map((notification, index) => (
          <motion.div
            key={notification.id}
            initial={{ opacity: 0, x: 300, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 300, scale: 0.8 }}
            transition={{ 
              duration: 0.4, 
              delay: index * 0.1,
              type: "spring",
              stiffness: 200,
              damping: 20
            }}
            className="relative"
          >
            <Card className={`shadow-lg border-l-4 ${getPriorityColor(notification.priority)} hover:shadow-xl transition-shadow`}>
              <CardContent className="p-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-1 right-1 h-6 w-6 p-0 hover:bg-gray-200"
                  onClick={() => dismissNotification(notification.id)}
                >
                  <X className="w-3 h-3" />
                </Button>
                
                <div className="flex items-start space-x-3 pr-6">
                  <div className="flex-shrink-0 mt-0.5">
                    {getNotificationIcon(notification.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="text-sm font-semibold text-gray-900">
                        {notification.title}
                      </h4>
                      <Badge variant="secondary" className="text-xs">
                        {notification.type}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">
                      {notification.message}
                    </p>
                    
                    {notification.action && (
                      <Button
                        size="sm"
                        onClick={notification.action.onClick}
                        className="text-xs h-7 px-3"
                      >
                        {notification.action.label}
                        <ArrowRight className="w-3 h-3 ml-1" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// Hook for easy integration
export function useSmartNotifications() {
  const [notifications, setNotifications] = useState<SmartNotification[]>([]);

  const addNotification = (notification: Omit<SmartNotification, 'id'>) => {
    const newNotification: SmartNotification = {
      ...notification,
      id: `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
    
    setNotifications(prev => [...prev, newNotification]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return {
    notifications,
    addNotification,
    removeNotification
  };
}