import { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark" | "system";

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
}

interface ThemeProviderState {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  resolvedTheme: "light" | "dark";
  mounted: boolean;
}

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
  resolvedTheme: "light",
  mounted: false,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "prepair-theme",
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(defaultTheme);
  const [resolvedTheme, setResolvedTheme] = useState<"light" | "dark">("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const root = window.document.documentElement;
    
    // Get stored theme
    const stored = localStorage.getItem(storageKey) as Theme;
    const initialTheme = stored && ["light", "dark", "system"].includes(stored) 
      ? stored 
      : defaultTheme;
    
    // Apply theme
    const applyTheme = (newTheme: Theme) => {
      root.classList.remove("light", "dark");
      
      let actualTheme: "light" | "dark";
      if (newTheme === "system") {
        const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches 
          ? "dark" 
          : "light";
        actualTheme = systemTheme;
      } else {
        actualTheme = newTheme;
      }
      
      root.classList.add(actualTheme);
      setResolvedTheme(actualTheme);
    };
    
    setTheme(initialTheme);
    applyTheme(initialTheme);
    setMounted(true);
  }, [defaultTheme, storageKey]);

  const value = {
    theme,
    setTheme: (newTheme: Theme) => {
      localStorage.setItem(storageKey, newTheme);
      setTheme(newTheme);
      
      const root = window.document.documentElement;
      root.classList.remove("light", "dark");
      
      let actualTheme: "light" | "dark";
      if (newTheme === "system") {
        const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches 
          ? "dark" 
          : "light";
        actualTheme = systemTheme;
      } else {
        actualTheme = newTheme;
      }
      
      root.classList.add(actualTheme);
      setResolvedTheme(actualTheme);
    },
    resolvedTheme,
    mounted,
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider");

  return context;
};