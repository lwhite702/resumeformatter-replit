import { useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface TooltipHelpProps {
  content: string;
  className?: string;
  side?: "top" | "right" | "bottom" | "left";
  size?: "sm" | "md" | "lg";
}

export function TooltipHelp({ 
  content, 
  className, 
  side = "top",
  size = "sm" 
}: TooltipHelpProps) {
  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-4 w-4", 
    lg: "h-5 w-5"
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            className={cn(
              "inline-flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors",
              className
            )}
          >
            <HelpCircle className={sizeClasses[size]} />
          </button>
        </TooltipTrigger>
        <TooltipContent side={side} className="max-w-xs">
          <p className="text-sm">{content}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Pre-defined tooltips for common features
export const tooltips = {
  resumeOptimizer: "Upload your resume to get AI-powered suggestions for improving ATS compatibility and content quality.",
  skillHighlights: "Extract and categorize skills from your resume using AI to create compelling highlight sections.",
  interviewGuides: "Generate personalized interview preparation guides based on job descriptions and your experience.",
  videoPractice: "Practice interviews with AI feedback on your responses, body language, and speaking patterns.",
  questionsDatabase: "Browse and practice with our comprehensive database of interview questions by category and difficulty.",
  jobTracker: "Track your job applications, interview progress, and follow-up activities in one organized dashboard.",
  jobTracking: "Advanced job application tracking with powerful filtering, status management, and progress visualization.",
  jobIntegrations: "Connect with job boards like LinkedIn and Indeed to automatically sync your applications.",
  careerVisualization: "Visualize potential career paths with industry trends, salary projections, and skill requirements.",
  aiFineTuning: "Customize AI responses for industry-specific interview preparation and career guidance.",
  termsGlossary: "Quick reference for job application terms, interview formats, and career development concepts.",
  atsScore: "Applicant Tracking System compatibility score - higher scores increase your chances of passing automated screening.",
  starMethod: "Situation, Task, Action, Result - a structured approach to answering behavioral interview questions effectively.",
  skillProficiency: "AI-assessed skill level based on context and experience mentioned in your resume and responses.",
  industryTrends: "Current market data including hiring patterns, salary ranges, and in-demand skills for your field.",
  networkingTips: "Professional networking strategies tailored to your career level and industry preferences."
};