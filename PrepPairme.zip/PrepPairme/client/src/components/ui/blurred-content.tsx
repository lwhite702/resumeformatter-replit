import { ReactNode, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { Crown, Lock, Star } from "lucide-react";
import { useAuth } from "@clerk/clerk-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./dialog";

interface BlurredContentProps {
  children: ReactNode;
  featureSlug: string;
  featureName: string;
  requiredPlan?: "Essential Plan" | "Professional Plan" | "Enterprise Plan";
  className?: string;
  blurIntensity?: "light" | "medium" | "heavy";
  showPreview?: boolean;
}

export function BlurredContent({
  children,
  featureSlug,
  featureName,
  requiredPlan = "Professional Plan",
  className = "",
  blurIntensity = "medium",
  showPreview = true,
}: BlurredContentProps) {
  const { isSignedIn } = useAuth();
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  // For demo purposes, assume user doesn't have access to premium features
  // In production, this would check against Atlas entitlements
  const hasAccess = false;
  const isLoading = false;

  const blurClasses = {
    light: "blur-sm",
    medium: "blur-md",
    heavy: "blur-lg",
  };

  const planColors = {
    "Essential Plan": "bg-blue-500",
    "Professional Plan": "bg-purple-500",
    "Enterprise Plan": "bg-orange-500",
  };

  const planIcons = {
    "Essential Plan": Star,
    "Professional Plan": Crown,
    "Enterprise Plan": Lock,
  };

  if (isLoading) {
    return (
      <div className={`animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg h-32 ${className}`} />
    );
  }

  if (hasAccess) {
    return <div className={className}>{children}</div>;
  }

  const PlanIcon = planIcons[requiredPlan];

  return (
    <div className={`relative ${className}`}>
      {/* Blurred Content */}
      <div className={`${blurClasses[blurIntensity]} pointer-events-none select-none`}>
        {showPreview ? children : (
          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-8 h-32 flex items-center justify-center">
            <div className="text-center">
              <Lock className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Premium Content</p>
            </div>
          </div>
        )}
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-white/70 dark:bg-gray-900/70 backdrop-blur-sm rounded-lg flex items-center justify-center">
        <Card className="max-w-md mx-4 shadow-lg border-2 border-purple-200 dark:border-purple-700">
          <CardHeader className="text-center pb-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <PlanIcon className="w-6 h-6 text-purple-600" />
              <Badge className={`${planColors[requiredPlan]} text-white`}>
                {requiredPlan}
              </Badge>
            </div>
            <CardTitle className="text-xl">{featureName}</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              This feature requires a {requiredPlan} subscription to unlock advanced capabilities.
            </p>
            
            <div className="space-y-2">
              {isSignedIn ? (
                <Dialog open={showUpgradeModal} onOpenChange={setShowUpgradeModal}>
                  <DialogTrigger asChild>
                    <Button className="w-full" size="sm">
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade Now
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="z-[60] max-w-md border-2 border-purple-200 dark:border-purple-700">
                    <DialogHeader>
                      <DialogTitle>Upgrade to {requiredPlan}</DialogTitle>
                      <DialogDescription>
                        Unlock {featureName} and many more premium features to accelerate your career growth.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                          Choose your plan and start using advanced features immediately.
                        </p>
                      </div>
                      <div className="flex gap-3">
                        <Button 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => setShowUpgradeModal(false)}
                        >
                          Maybe Later
                        </Button>
                        <Button 
                          className="flex-1"
                          onClick={() => {
                            window.location.href = '/pricing';
                          }}
                        >
                          View Plans
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              ) : (
                <>
                  <Button 
                    className="w-full" 
                    size="sm"
                    onClick={() => window.location.href = '/sign-in'}
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Sign In to Upgrade
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => window.location.href = '/pricing'}
                  >
                    View Plans
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}