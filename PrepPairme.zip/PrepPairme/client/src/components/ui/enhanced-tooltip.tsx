"use client";

import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ArrowLeft, ArrowRight, HelpCircle, Info } from "lucide-react";
import { useState } from "react";

export interface TooltipTip {
  title: string;
  description: string;
}

export interface EnhancedTooltipProps {
  tips: TooltipTip[];
  trigger?: React.ReactNode;
  side?: "top" | "bottom" | "left" | "right";
  align?: "start" | "center" | "end";
  showArrow?: boolean;
  maxWidth?: string;
  children?: React.ReactNode;
}

export function EnhancedTooltip({
  tips,
  trigger,
  side = "top",
  align = "center",
  showArrow = true,
  maxWidth = "280px",
  children
}: EnhancedTooltipProps) {
  const [currentTip, setCurrentTip] = useState(0);

  const handleNext = () => {
    if (currentTip < tips.length - 1) {
      setCurrentTip(currentTip + 1);
    }
  };

  const handlePrev = () => {
    if (currentTip > 0) {
      setCurrentTip(currentTip - 1);
    }
  };

  const isFirstTip = currentTip === 0;
  const isLastTip = currentTip === tips.length - 1;

  const defaultTrigger = (
    <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-foreground">
      <HelpCircle size={14} />
    </Button>
  );

  return (
    <Popover>
      <PopoverTrigger asChild>
        {trigger || defaultTrigger}
      </PopoverTrigger>
      <PopoverContent 
        className={`py-3 shadow-lg`} 
        style={{ maxWidth }}
        side={side}
        align={align}
        showArrow={showArrow}
      >
        <div className="space-y-3">
          <div className="space-y-1">
            <p className="text-[13px] font-medium">{tips[currentTip].title}</p>
            <p className="text-xs text-muted-foreground leading-relaxed">{tips[currentTip].description}</p>
          </div>
          {tips.length > 1 && (
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                {currentTip + 1}/{tips.length}
              </span>
              <div className="flex gap-0.5">
                <Button
                  size="icon"
                  variant="ghost"
                  className="size-6"
                  onClick={handlePrev}
                  disabled={isFirstTip}
                  aria-label="Previous tip"
                >
                  <ArrowLeft size={14} strokeWidth={2} aria-hidden="true" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="size-6"
                  onClick={handleNext}
                  disabled={isLastTip}
                  aria-label="Next tip"
                >
                  <ArrowRight size={14} strokeWidth={2} aria-hidden="true" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// Simple tooltip for single tips
export interface SimpleTooltipProps {
  content: string;
  title?: string;
  trigger?: React.ReactNode;
  side?: "top" | "bottom" | "left" | "right";
  align?: "start" | "center" | "end";
  showArrow?: boolean;
}

export function SimpleTooltip({
  content,
  title,
  trigger,
  side = "top",
  align = "center",
  showArrow = true
}: SimpleTooltipProps) {
  const defaultTrigger = (
    <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-foreground">
      <Info size={12} />
    </Button>
  );

  return (
    <Popover>
      <PopoverTrigger asChild>
        {trigger || defaultTrigger}
      </PopoverTrigger>
      <PopoverContent 
        className="py-2 px-3 max-w-[220px]" 
        side={side}
        align={align}
        showArrow={showArrow}
      >
        <div className="space-y-1">
          {title && <p className="text-xs font-medium">{title}</p>}
          <p className="text-xs text-muted-foreground leading-relaxed">{content}</p>
        </div>
      </PopoverContent>
    </Popover>
  );
}