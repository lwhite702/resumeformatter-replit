import { Badge } from "@/components/ui/badge";

export interface FaqItem {
  question: string;
  answer: string;
}

export interface Faq5Props {
  badge?: string;
  heading?: string;
  description?: string;
  faqs?: FaqItem[];
}

const defaultFaqs: FaqItem[] = [
  {
    question: "What is PrepPair and how does it help with interview preparation?",
    answer:
      "PrepPair is an AI-powered career development platform that provides personalized interview preparation, resume optimization, and job search tools. Our platform uses advanced AI to generate tailored interview questions, provide detailed feedback, and help you practice for specific roles and industries.",
  },
  {
    question: "How does the Pro subscription differ from the Free plan?",
    answer:
      "The Pro subscription includes unlimited AI interview guides, advanced resume optimization with ATS scoring, priority support, custom templates, video practice sessions, and detailed analytics. Free users get 3 AI guides per month and basic features.",
  },
  {
    question: "What is included in the Career Coach plan for teams?",
    answer:
      "The Career Coach plan is designed for educators, career counselors, and team managers. It includes team management dashboards, progress tracking for multiple users, bulk user management, advanced analytics, and everything from the Pro plan for each team member. Minimum 3 users, quarterly billing only.",
  },
  {
    question: "Can I cancel my subscription at any time?",
    answer:
      "Yes, you can cancel your subscription at any time. Your access to premium features will continue until the end of your current billing period. There are no cancellation fees or penalties.",
  },
  {
    question: "Do you offer a free trial for premium plans?",
    answer:
      "Yes, we offer a 14-day free trial for all premium plans. You can explore all Pro features without any commitment. No credit card is required to start your free account.",
  },
  {
    question: "How does the AI interview preparation work?",
    answer:
      "Our AI analyzes your target role, industry, and experience level to generate personalized interview questions. It provides STAR method guidance, evaluates your responses, and offers specific improvement suggestions. The system learns from your practice sessions to provide increasingly relevant preparation.",
  },
];

export const Faq5 = ({
  badge = "FAQ",
  heading = "Frequently Asked Questions",
  description = "Everything you need to know about PrepPair and our career development platform.",
  faqs = defaultFaqs,
}: Faq5Props) => {
  return (
    <section className="py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge className="text-xs font-medium mb-4">{badge}</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">{heading}</h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {description}
          </p>
        </div>
        <div className="mx-auto max-w-3xl">
          {faqs.map((faq, index) => (
            <div key={index} className="mb-8 bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
              <div className="flex gap-4">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 font-semibold text-sm">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-3">{faq.question}</h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-12">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Still have questions? We're here to help!
          </p>
          <button className="text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300 font-medium hover:underline">
            Contact Support
          </button>
        </div>
      </div>
    </section>
  );
};