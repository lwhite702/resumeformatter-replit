import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { useLocation } from "wouter";
import { Github, Twitter, Linkedin, Mail, Heart } from "lucide-react";
import logoIcon from "@assets/1_1749272880173.png";

export function Footer() {
  const [, setLocation] = useLocation();

  const footerLinks = {
    product: [
      { label: "Features", href: "/features" },
      { label: "Pricing", href: "/pricing" },
      { label: "The PrepBoard", href: "/blog" },
      { label: "Questions Database", href: "/questions-database" },
    ],
    tools: [
      { label: "Interview Guides", href: "/interview-guide" },
      { label: "Resume Optimizer", href: "/resume-optimizer" },
      { label: "Job Tracker", href: "/job-tracker" },
      { label: "Video Practice", href: "/video-practice" },
    ],
    resources: [
      { label: "Career Visualization", href: "/career-visualization" },
      { label: "Terms Glossary", href: "/terms-glossary" },
      { label: "AI Fine-tuning", href: "/ai-fine-tuning" },
      { label: "Career Mood Board", href: "/career-mood-board" },
    ],
    company: [
      { label: "About", href: "/about" },
      { label: "Privacy Policy", href: "/legal" },
      { label: "Terms of Service", href: "/legal" },
      { label: "Contact", href: "/help-center" },
    ],
  };

  const socialLinks = [
    { icon: Github, href: "https://github.com/lwhite702/PrepPairmev3", label: "GitHub" },
    { icon: Twitter, href: "https://twitter.com/preppairme", label: "Twitter" },
    { icon: Linkedin, href: "https://linkedin.com/company/preppairme", label: "LinkedIn" },
    { icon: Mail, href: "mailto:support@preppair.me", label: "Email" },
  ];

  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center mb-4">
              <img 
                src={logoIcon} 
                alt="PrepPair.me" 
                className="h-8 w-8 mr-2"
              />
              <span className="text-xl font-bold text-gray-900 dark:text-white">PrepPair.me</span>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md">
              AI-powered interview preparation and career development platform. 
              Transform your job search with intelligent tools and personalized guidance.
            </p>
            
            {/* Theme Toggle */}
            <div className="flex items-center gap-4 mb-6">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Theme:</span>
              <ThemeToggle />
            </div>

            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <Button
                  key={social.label}
                  variant="ghost"
                  size="sm"
                  className="w-9 h-9 p-0"
                  onClick={() => window.open(social.href, '_blank')}
                  aria-label={social.label}
                >
                  <social.icon className="h-4 w-4" />
                </Button>
              ))}
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider mb-4">
              Product
            </h3>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setLocation(link.href);
                    }}
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Tools Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider mb-4">
              Tools
            </h3>
            <ul className="space-y-3">
              {footerLinks.tools.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setLocation(link.href);
                    }}
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider mb-4">
              Resources
            </h3>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setLocation(link.href);
                    }}
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider mb-4">
              Company
            </h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setLocation(link.href);
                    }}
                    className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center text-gray-600 dark:text-gray-400 text-sm">
              <span>© 2024 PrepPair.me. Made with</span>
              <Heart className="h-4 w-4 mx-1 text-red-500 fill-current" />
              <span>for career success.</span>
            </div>
            <div className="mt-4 md:mt-0 text-sm text-gray-600 dark:text-gray-400">
              <span>All rights reserved.</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}