import { Button } from "@/components/ui/button";
import {
    NavigationMenu,
    NavigationMenuContent,
    NavigationMenuItem,
    NavigationMenuLink,
    NavigationMenuList,
    NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { Menu, MoveRight, X } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import logoIcon from "@assets/1_1749272880173.png";
import logoWithText from "@assets/3_1749272880173.png";
import { ThemeToggle } from "@/components/theme-toggle";

function Header1() {
    const [, setLocation] = useLocation();
    const { isAuthenticated } = useAuth();
    
    const navigationItems = [
        {
            title: "Home",
            href: "/",
            description: "",
        },
        {
            title: "Features",
            href: "/features",
            description: "",
        },
        {
            title: "Pricing",
            href: "/pricing",
            description: "",
        },
        {
            title: "Tools",
            description: "Comprehensive AI-powered career development tools.",
            items: [
                {
                    title: "Interview Guides",
                    href: "/features#interview-guide",
                },
                {
                    title: "Resume Optimizer",
                    href: "/features#resume-optimizer",
                },
                {
                    title: "Job Tracker",
                    href: "/features#job-tracker",
                },
                {
                    title: "Video Practice",
                    href: "/features#video-practice",
                },
                {
                    title: "Skill Highlights",
                    href: "/features#skill-highlights",
                },
            ],
        },
        {
            title: "Resources",
            description: "Expert insights and career development resources.",
            items: [
                {
                    title: "The PrepBoard",
                    href: "/blog",
                },
                {
                    title: "Questions Database",
                    href: "/features#questions-database",
                },
                {
                    title: "Career Visualization",
                    href: "/features#career-visualization",
                },
                {
                    title: "Terms Glossary",
                    href: "/terms",
                },
            ],
        },
    ];

    const [isOpen, setOpen] = useState(false);
    
    const handleNavigation = (href: string) => {
        setLocation(href);
        setOpen(false);
    };

    return (
        <header className="w-full z-40 fixed top-0 left-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shadow-sm">
            <div className="container relative mx-auto min-h-16 lg:min-h-20 flex gap-2 sm:gap-4 flex-row lg:grid lg:grid-cols-3 items-center px-3 sm:px-4 lg:px-6">
                <div className="justify-start items-center gap-4 lg:flex hidden flex-row">
                    <NavigationMenu className="flex justify-start items-start">
                        <NavigationMenuList className="flex justify-start gap-4 flex-row">
                            {navigationItems.map((item) => (
                                <NavigationMenuItem key={item.title}>
                                    {item.href ? (
                                        <NavigationMenuLink>
                                            <Button 
                                                variant="ghost" 
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    handleNavigation(item.href);
                                                }}
                                            >
                                                {item.title}
                                            </Button>
                                        </NavigationMenuLink>
                                    ) : (
                                        <>
                                            <NavigationMenuTrigger className="font-medium text-sm">
                                                {item.title}
                                            </NavigationMenuTrigger>
                                            <NavigationMenuContent className="!w-[450px] p-4">
                                                <div className="flex flex-col lg:grid grid-cols-2 gap-4">
                                                    <div className="flex flex-col h-full justify-between">
                                                        <div className="flex flex-col">
                                                            <p className="text-base">{item.title}</p>
                                                            <p className="text-muted-foreground text-sm">
                                                                {item.description}
                                                            </p>
                                                        </div>
                                                        <Button 
                                                            size="sm" 
                                                            className="mt-10"
                                                            onClick={(e) => {
                                                                e.preventDefault();
                                                                handleNavigation('/subscribe');
                                                            }}
                                                        >
                                                            Get started today
                                                        </Button>
                                                    </div>
                                                    <div className="flex flex-col text-sm h-full justify-end">
                                                        {item.items?.map((subItem) => (
                                                            <button
                                                                key={subItem.title}
                                                                onClick={(e) => {
                                                                    e.preventDefault();
                                                                    handleNavigation(subItem.href);
                                                                }}
                                                                className="flex flex-row justify-between items-center hover:bg-muted py-2 px-4 rounded text-left"
                                                            >
                                                                <span>{subItem.title}</span>
                                                                <MoveRight className="w-4 h-4 text-muted-foreground" />
                                                            </button>
                                                        ))}
                                                    </div>
                                                </div>
                                            </NavigationMenuContent>
                                        </>
                                    )}
                                </NavigationMenuItem>
                            ))}
                        </NavigationMenuList>
                    </NavigationMenu>
                </div>
                <div className="flex lg:justify-center flex-1 min-w-0">
                    <button 
                        onClick={(e) => {
                            e.preventDefault();
                            handleNavigation('/');
                        }}
                        className="flex items-center transition-transform hover:scale-105 active:scale-95"
                    >
                        <img 
                            src={logoIcon} 
                            alt="PrepPair.me" 
                            className="h-7 w-7 lg:h-8 lg:w-8 mr-2"
                        />
                        <span className="font-bold text-lg lg:text-xl text-gray-900 dark:text-white truncate">PrepPair.me</span>
                    </button>
                </div>
                <div className="flex justify-end items-center gap-2 lg:gap-4 flex-shrink-0">
                    {!isAuthenticated ? (
                        <>
                            <Button 
                                variant="ghost" 
                                className="hidden md:inline"
                                onClick={(e) => {
                                    e.preventDefault();
                                    handleNavigation('/blog');
                                }}
                            >
                                The PrepBoard
                            </Button>
                            <div className="border-r hidden md:inline"></div>
                            <Button 
                                variant="outline"
                                className="hidden sm:inline-flex"
                                onClick={() => window.location.href = '/api/login'}
                            >
                                Sign in
                            </Button>
                            <Button 
                                onClick={(e) => {
                                    e.preventDefault();
                                    handleNavigation('/subscribe');
                                }}
                                className="text-sm px-3 py-2 lg:px-4 lg:py-2"
                            >
                                Get started
                            </Button>
                        </>
                    ) : (
                        <>
                            <Button 
                                variant="ghost" 
                                className="hidden md:inline"
                                onClick={(e) => {
                                    e.preventDefault();
                                    handleNavigation('/dashboard');
                                }}
                            >
                                Dashboard
                            </Button>
                            <Button 
                                variant="outline"
                                className="text-sm px-3 py-2 lg:px-4 lg:py-2"
                                onClick={() => window.location.href = '/api/logout'}
                            >
                                Sign out
                            </Button>
                        </>
                    )}
                </div>
                <div className="flex w-12 shrink lg:hidden items-end justify-end">
                    <Button variant="ghost" onClick={() => setOpen(!isOpen)}>
                        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                    </Button>
                    {isOpen && (
                        <div className="absolute top-16 lg:top-20 border-t flex flex-col w-full right-0 bg-white dark:bg-gray-900 shadow-2xl py-6 px-4 gap-6 animate-in slide-in-from-top-5 duration-300">
                            {navigationItems.map((item) => (
                                <div key={item.title}>
                                    <div className="flex flex-col gap-2">
                                        {item.href ? (
                                            <button
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    handleNavigation(item.href);
                                                }}
                                                className="flex justify-between items-center text-left"
                                            >
                                                <span className="text-lg">{item.title}</span>
                                                <MoveRight className="w-4 h-4 stroke-1 text-muted-foreground" />
                                            </button>
                                        ) : (
                                            <p className="text-lg">{item.title}</p>
                                        )}
                                        {item.items &&
                                            item.items.map((subItem) => (
                                                <button
                                                    key={subItem.title}
                                                    onClick={(e) => {
                                                        e.preventDefault();
                                                        handleNavigation(subItem.href);
                                                    }}
                                                    className="flex justify-between items-center text-left"
                                                >
                                                    <span className="text-muted-foreground">
                                                        {subItem.title}
                                                    </span>
                                                    <MoveRight className="w-4 h-4 stroke-1" />
                                                </button>
                                            ))}
                                    </div>
                                </div>
                            ))}
                            <div className="flex flex-col gap-3 pt-6 border-t border-border/50">
                                {!isAuthenticated ? (
                                    <>
                                        <Button 
                                            variant="outline" 
                                            className="w-full h-12 text-base font-medium"
                                            onClick={() => window.location.href = '/api/login'}
                                        >
                                            Sign in
                                        </Button>
                                        <Button 
                                            className="w-full h-12 text-base font-medium bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                handleNavigation('/subscribe');
                                            }}
                                        >
                                            Get started
                                        </Button>
                                    </>
                                ) : (
                                    <>
                                        <Button 
                                            variant="ghost" 
                                            className="w-full"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                handleNavigation('/dashboard');
                                            }}
                                        >
                                            Dashboard
                                        </Button>
                                        <Button 
                                            variant="outline" 
                                            className="w-full"
                                            onClick={() => window.location.href = '/api/logout'}
                                        >
                                            Sign out
                                        </Button>
                                    </>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}

export { Header1 };