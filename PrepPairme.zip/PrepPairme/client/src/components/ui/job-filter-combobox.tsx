import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Plus } from "lucide-react";
import { useState } from "react";
import { 
  JobFilterType, 
  JobFilter, 
  jobFilterViewOptions,
  ApplicationStatus,
  Company,
  JobType,
  Priority,
  SalaryRange,
  DateRange,
  JobFilterOperator
} from "@/components/ui/job-filters";
import { nanoid } from "nanoid";

const JobFilterCombobox = ({
  filters,
  setFilters,
}: {
  filters: JobFilter[];
  setFilters: (filters: JobFilter[]) => void;
}) => {
  const [open, setOpen] = useState(false);

  const addFilter = (filterType: JobFilterType) => {
    const newFilter: JobFilter = {
      id: nanoid(),
      type: filterType,
      operator: JobFilterOperator.IS,
      value: [],
    };
    setFilters([...filters, newFilter]);
    setOpen(false);
  };

  const existingFilterTypes = filters.map((filter) => filter.type);
  const availableFilters = jobFilterViewOptions
    .flat()
    .filter((option) => !existingFilterTypes.includes(option.name as JobFilterType));

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          Add Filter
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[200px] p-0">
        <Command>
          <CommandInput placeholder="Search filters..." />
          <CommandList>
            <CommandEmpty>No filters found.</CommandEmpty>
            <CommandGroup>
              {availableFilters.map((filter) => (
                <CommandItem
                  key={filter.name}
                  onSelect={() => addFilter(filter.name as JobFilterType)}
                  className="flex items-center gap-2"
                >
                  {filter.icon}
                  {filter.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export { JobFilterCombobox };