import { Checkbox } from "@/components/ui/checkbox";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import {
  Calendar,
  CalendarPlus,
  Check,
  Circle,
  CircleAlert,
  CircleCheck,
  CircleDashed,
  CircleDotDashed,
  CircleEllipsis,
  CircleX,
  SignalHigh,
  SignalLow,
  SignalMedium,
  Building,
  Briefcase,
  DollarSign,
  X,
} from "lucide-react";
import { Dispatch, SetStateAction, useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { AnimatePresence, motion } from "framer-motion";

interface AnimateChangeInHeightProps {
  children: React.ReactNode;
  className?: string;
}

export const AnimateChangeInHeight: React.FC<AnimateChangeInHeightProps> = ({
  children,
  className,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [height, setHeight] = useState<number | "auto">("auto");

  useEffect(() => {
    if (containerRef.current) {
      const resizeObserver = new ResizeObserver((entries) => {
        const observedHeight = entries[0].contentRect.height;
        setHeight(observedHeight);
      });

      resizeObserver.observe(containerRef.current);

      return () => {
        resizeObserver.disconnect();
      };
    }
  }, []);

  return (
    <motion.div
      className={cn(className, "overflow-hidden")}
      style={{ height }}
      animate={{ height }}
      transition={{ duration: 0.1, dampping: 0.2, ease: "easeIn" }}
    >
      <div ref={containerRef}>{children}</div>
    </motion.div>
  );
};

export enum JobFilterType {
  STATUS = "Application Status",
  COMPANY = "Company",
  JOB_TYPE = "Job Type",
  PRIORITY = "Priority",
  SALARY_RANGE = "Salary Range",
  APPLIED_DATE = "Applied Date",
}

export enum JobFilterOperator {
  IS = "is",
  IS_NOT = "is not",
  IS_ANY_OF = "is any of",
  INCLUDE = "include",
  DO_NOT_INCLUDE = "do not include",
  BEFORE = "before",
  AFTER = "after",
}

export enum ApplicationStatus {
  APPLIED = "Applied",
  PHONE_SCREEN = "Phone Screen",
  INTERVIEW = "Interview",
  FINAL_ROUND = "Final Round",
  OFFER = "Offer",
  REJECTED = "Rejected",
}

export enum Company {
  GOOGLE = "Google",
  MICROSOFT = "Microsoft",
  AMAZON = "Amazon",
  META = "Meta",
  APPLE = "Apple",
  NETFLIX = "Netflix",
}

export enum JobType {
  FULL_TIME = "Full-time",
  PART_TIME = "Part-time",
  CONTRACT = "Contract",
  INTERNSHIP = "Internship",
  REMOTE = "Remote",
  HYBRID = "Hybrid",
}

export enum Priority {
  URGENT = "Urgent",
  HIGH = "High",
  MEDIUM = "Medium",
  LOW = "Low",
}

export enum SalaryRange {
  UNDER_50K = "Under $50K",
  BETWEEN_50K_75K = "$50K - $75K",
  BETWEEN_75K_100K = "$75K - $100K",
  BETWEEN_100K_150K = "$100K - $150K",
  BETWEEN_150K_200K = "$150K - $200K",
  OVER_200K = "Over $200K",
}

export enum DateRange {
  LAST_WEEK = "Last week",
  LAST_MONTH = "Last month",
  LAST_3_MONTHS = "Last 3 months",
  LAST_6_MONTHS = "Last 6 months",
  LAST_YEAR = "Last year",
  CUSTOM = "Custom range",
}

export type JobFilterOption = {
  name: JobFilterType | ApplicationStatus | Company | JobType | Priority | SalaryRange | DateRange;
  icon: React.ReactNode | undefined;
  label?: string;
};

export type JobFilter = {
  id: string;
  type: JobFilterType;
  operator: JobFilterOperator;
  value: string[];
};

const JobFilterIcon = ({
  type,
}: {
  type: JobFilterType | ApplicationStatus | Company | JobType | Priority | SalaryRange;
}) => {
  switch (type) {
    case JobFilterType.STATUS:
      return <CircleDashed className="size-3.5" />;
    case JobFilterType.COMPANY:
      return <Building className="size-3.5" />;
    case JobFilterType.JOB_TYPE:
      return <Briefcase className="size-3.5" />;
    case JobFilterType.PRIORITY:
      return <SignalHigh className="size-3.5" />;
    case JobFilterType.SALARY_RANGE:
      return <DollarSign className="size-3.5" />;
    case JobFilterType.APPLIED_DATE:
      return <Calendar className="size-3.5" />;
    case ApplicationStatus.APPLIED:
      return <Circle className="size-3.5 text-blue-500" />;
    case ApplicationStatus.PHONE_SCREEN:
      return <CircleDotDashed className="size-3.5 text-yellow-500" />;
    case ApplicationStatus.INTERVIEW:
      return <CircleEllipsis className="size-3.5 text-orange-500" />;
    case ApplicationStatus.FINAL_ROUND:
      return <CircleAlert className="size-3.5 text-purple-500" />;
    case ApplicationStatus.OFFER:
      return <CircleCheck className="size-3.5 text-green-500" />;
    case ApplicationStatus.REJECTED:
      return <CircleX className="size-3.5 text-red-500" />;
    case Priority.URGENT:
      return <CircleAlert className="size-3.5 text-red-500" />;
    case Priority.HIGH:
      return <SignalHigh className="size-3.5 text-orange-500" />;
    case Priority.MEDIUM:
      return <SignalMedium className="size-3.5 text-yellow-500" />;
    case Priority.LOW:
      return <SignalLow className="size-3.5 text-green-500" />;
    default:
      return <Circle className="size-3.5" />;
  }
};

export const jobFilterViewOptions: JobFilterOption[][] = [
  [
    {
      name: JobFilterType.STATUS,
      icon: <JobFilterIcon type={JobFilterType.STATUS} />,
    },
    {
      name: JobFilterType.COMPANY,
      icon: <JobFilterIcon type={JobFilterType.COMPANY} />,
    },
    {
      name: JobFilterType.JOB_TYPE,
      icon: <JobFilterIcon type={JobFilterType.JOB_TYPE} />,
    },
    {
      name: JobFilterType.PRIORITY,
      icon: <JobFilterIcon type={JobFilterType.PRIORITY} />,
    },
  ],
  [
    {
      name: JobFilterType.SALARY_RANGE,
      icon: <JobFilterIcon type={JobFilterType.SALARY_RANGE} />,
    },
    {
      name: JobFilterType.APPLIED_DATE,
      icon: <JobFilterIcon type={JobFilterType.APPLIED_DATE} />,
    },
  ],
];

export const statusFilterOptions: JobFilterOption[] = Object.values(ApplicationStatus).map(
  (status) => ({
    name: status,
    icon: <JobFilterIcon type={status} />,
  })
);

export const companyFilterOptions: JobFilterOption[] = Object.values(Company).map(
  (company) => ({
    name: company,
    icon: <Building className="size-3.5" />,
  })
);

export const jobTypeFilterOptions: JobFilterOption[] = Object.values(JobType).map(
  (jobType) => ({
    name: jobType,
    icon: <Briefcase className="size-3.5" />,
  })
);

export const priorityFilterOptions: JobFilterOption[] = Object.values(Priority).map(
  (priority) => ({
    name: priority,
    icon: <JobFilterIcon type={priority} />,
  })
);

export const salaryRangeFilterOptions: JobFilterOption[] = Object.values(SalaryRange).map(
  (salaryRange) => ({
    name: salaryRange,
    icon: <DollarSign className="size-3.5" />,
  })
);

export const dateFilterOptions: JobFilterOption[] = Object.values(DateRange).map(
  (date) => ({
    name: date,
    icon: <Calendar className="size-3.5" />,
  })
);

export const jobFilterViewToFilterOptions: Record<JobFilterType, JobFilterOption[]> = {
  [JobFilterType.STATUS]: statusFilterOptions,
  [JobFilterType.COMPANY]: companyFilterOptions,
  [JobFilterType.JOB_TYPE]: jobTypeFilterOptions,
  [JobFilterType.PRIORITY]: priorityFilterOptions,
  [JobFilterType.SALARY_RANGE]: salaryRangeFilterOptions,
  [JobFilterType.APPLIED_DATE]: dateFilterOptions,
};

const jobFilterOperators = ({
  filterType,
  filterValues,
}: {
  filterType: JobFilterType;
  filterValues: string[];
}) => {
  switch (filterType) {
    case JobFilterType.STATUS:
    case JobFilterType.COMPANY:
    case JobFilterType.JOB_TYPE:
    case JobFilterType.PRIORITY:
    case JobFilterType.SALARY_RANGE:
      if (Array.isArray(filterValues) && filterValues.length > 1) {
        return [JobFilterOperator.IS_ANY_OF, JobFilterOperator.IS_NOT];
      } else {
        return [JobFilterOperator.IS, JobFilterOperator.IS_NOT];
      }
    case JobFilterType.APPLIED_DATE:
      return [JobFilterOperator.BEFORE, JobFilterOperator.AFTER];
    default:
      return [];
  }
};

const JobFilterOperatorDropdown = ({
  filterType,
  operator,
  filterValues,
  setOperator,
}: {
  filterType: JobFilterType;
  operator: JobFilterOperator;
  filterValues: string[];
  setOperator: (operator: JobFilterOperator) => void;
}) => {
  const operators = jobFilterOperators({ filterType, filterValues });
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="bg-muted hover:bg-muted/50 px-1.5 py-1 text-muted-foreground hover:text-primary transition shrink-0">
        {operator}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-fit min-w-fit">
        {operators.map((operator) => (
          <DropdownMenuItem
            key={operator}
            onClick={() => setOperator(operator)}
          >
            {operator}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

const JobFilterValueCombobox = ({
  filterType,
  filterValues,
  setFilterValues,
}: {
  filterType: JobFilterType;
  filterValues: string[];
  setFilterValues: (filterValues: string[]) => void;
}) => {
  const [open, setOpen] = useState(false);
  const [commandInput, setCommandInput] = useState("");
  const commandInputRef = useRef<HTMLInputElement>(null);
  const nonSelectedFilterValues = jobFilterViewToFilterOptions[filterType]?.filter(
    (filter) => !filterValues.includes(filter.name)
  );

  return (
    <Popover
      open={open}
      onOpenChange={(open) => {
        setOpen(open);
        if (!open) {
          setTimeout(() => {
            setCommandInput("");
          }, 200);
        }
      }}
    >
      <PopoverTrigger
        className="rounded-none px-1.5 py-1 bg-muted hover:bg-muted/50 transition
  text-muted-foreground hover:text-primary shrink-0"
      >
        <div className="flex gap-1.5 items-center">
          <div className="flex items-center flex-row -space-x-1.5">
            <AnimatePresence mode="popLayout">
              {filterValues?.slice(0, 3).map((value) => (
                <motion.div
                  key={value}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  <JobFilterIcon type={value as JobFilterType} />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          {filterValues?.length === 1
            ? filterValues?.[0]
            : `${filterValues?.length} selected`}
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-[200px] p-0">
        <AnimateChangeInHeight>
          <Command>
            <CommandInput
              placeholder={filterType}
              className="h-9"
              value={commandInput}
              onInputCapture={(e) => {
                setCommandInput(e.currentTarget.value);
              }}
              ref={commandInputRef}
            />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup>
                {filterValues.map((value) => (
                  <CommandItem
                    key={value}
                    className="group flex gap-2 items-center"
                    onSelect={() => {
                      setFilterValues(filterValues.filter((v) => v !== value));
                      setTimeout(() => {
                        setCommandInput("");
                      }, 200);
                      setOpen(false);
                    }}
                  >
                    <Checkbox checked={true} />
                    <JobFilterIcon type={value as JobFilterType} />
                    {value}
                  </CommandItem>
                ))}
              </CommandGroup>
              {nonSelectedFilterValues?.length > 0 && (
                <>
                  <CommandSeparator />
                  <CommandGroup>
                    {nonSelectedFilterValues.map((filter: JobFilterOption) => (
                      <CommandItem
                        className="group flex gap-2 items-center"
                        key={filter.name}
                        value={filter.name}
                        onSelect={(currentValue: string) => {
                          setFilterValues([...filterValues, currentValue]);
                          setTimeout(() => {
                            setCommandInput("");
                          }, 200);
                          setOpen(false);
                        }}
                      >
                        <Checkbox
                          checked={false}
                          className="opacity-0 group-data-[selected=true]:opacity-100"
                        />
                        {filter.icon}
                        <span className="text-accent-foreground">
                          {filter.name}
                        </span>
                        {filter.label && (
                          <span className="text-muted-foreground text-xs ml-auto">
                            {filter.label}
                          </span>
                        )}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </AnimateChangeInHeight>
      </PopoverContent>
    </Popover>
  );
};

export default function JobFilters({
  filters,
  setFilters,
}: {
  filters: JobFilter[];
  setFilters: Dispatch<SetStateAction<JobFilter[]>>;
}) {
  return (
    <div className="flex gap-2">
      {filters
        .filter((filter) => filter.value?.length > 0)
        .map((filter) => (
          <div key={filter.id} className="flex gap-[1px] items-center text-xs">
            <div className="flex gap-1.5 shrink-0 rounded-l bg-muted px-1.5 py-1 items-center">
              <JobFilterIcon type={filter.type} />
              {filter.type}
            </div>
            <JobFilterOperatorDropdown
              filterType={filter.type}
              operator={filter.operator}
              filterValues={filter.value}
              setOperator={(operator) => {
                setFilters((prev) =>
                  prev.map((f) => (f.id === filter.id ? { ...f, operator } : f))
                );
              }}
            />
            <JobFilterValueCombobox
              filterType={filter.type}
              filterValues={filter.value}
              setFilterValues={(filterValues) => {
                setFilters((prev) =>
                  prev.map((f) =>
                    f.id === filter.id ? { ...f, value: filterValues } : f
                  )
                );
              }}
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setFilters((prev) => prev.filter((f) => f.id !== filter.id));
              }}
              className="bg-muted rounded-l-none rounded-r-sm h-6 w-6 text-muted-foreground hover:text-primary hover:bg-muted/50 transition shrink-0"
            >
              <X className="size-3" />
            </Button>
          </div>
        ))}
    </div>
  );
}