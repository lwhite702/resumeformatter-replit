"use client";

import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogFooter,
    DialogTitle,
    DialogDescription,
} from "@/components/ui/dialog";

import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Check, Sparkles, Zap, Star, Users, Briefcase } from "lucide-react";

interface PlanOption {
    id: string;
    name: string;
    price: string;
    description: string;
    features: string[];
    popular?: boolean;
    icon?: any;
}

const prepPairPlans: PlanOption[] = [
    {
        id: "basic",
        name: "Basic",
        price: "$19",
        description: "Perfect for job seekers starting their journey",
        icon: Star,
        features: [
            "AI Resume Analysis & ATS Scoring",
            "Basic Interview Question Database",
            "5 AI-Generated Interview Guides",
            "Job Application Tracking",
            "Email Support"
        ],
    },
    {
        id: "professional",
        name: "Professional",
        price: "$39",
        description: "For serious job seekers and career changers",
        icon: Briefcase,
        popular: true,
        features: [
            "Everything in Basic",
            "Unlimited Interview Guides",
            "Video Interview Practice with AI Feedback",
            "Industry-Specific Question Banks",
            "Career Path Visualization",
            "Priority Support",
            "Resume Templates & Optimization"
        ],
    },
    {
        id: "enterprise",
        name: "Enterprise",
        price: "$79",
        description: "For teams and career coaching professionals",
        icon: Users,
        features: [
            "Everything in Professional",
            "Team Management Dashboard",
            "Custom Branding",
            "Advanced Analytics",
            "API Access",
            "White-label Options",
            "Dedicated Account Manager"
        ],
    },
];

function ModalPricing({
    plans = prepPairPlans,
}: {
    plans?: PlanOption[];
}) {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState("professional");

    return (
        <>
            <div className="flex justify-center">
                <Button
                    onClick={() => setIsOpen(true)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
                >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Upgrade Plan
                </Button>
            </div>

            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="w-[95vw] sm:max-w-[600px] max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-4 sm:p-6">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-xl md:text-2xl font-bold text-gray-900 dark:text-white">
                            <Zap className="h-5 w-5 md:h-6 md:w-6 text-blue-600" />
                            Choose Your PrepPair.me Plan
                        </DialogTitle>
                        <DialogDescription className="text-sm text-gray-600 dark:text-gray-300">
                            Accelerate your career with AI-powered interview preparation. 
                            Upgrade or downgrade at any time.
                        </DialogDescription>
                    </DialogHeader>

                    <RadioGroup
                        defaultValue={selectedPlan}
                        onValueChange={setSelectedPlan}
                        className="gap-4 py-4"
                    >
                        {plans.map((plan) => {
                            const IconComponent = plan.icon || Star;
                            return (
                                <label
                                    key={plan.id}
                                    className={`relative flex flex-col p-3 sm:p-4 cursor-pointer rounded-lg border-2 transition-all
                                        ${
                                            selectedPlan === plan.id
                                                ? "border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/20"
                                                : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                                        }
                                        ${plan.popular ? "ring-1 ring-purple-500 ring-offset-1" : ""}
                                    `}
                                >
                                    <RadioGroupItem
                                        value={plan.id}
                                        className="sr-only"
                                    />
                                    
                                    {plan.popular && (
                                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                                            <span className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-2 py-1 text-xs font-semibold rounded-full">
                                                Popular
                                            </span>
                                        </div>
                                    )}

                                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                                        <div className="flex items-center gap-2 mb-2 sm:mb-0">
                                            <IconComponent className="h-5 w-5 text-blue-600" />
                                            <div>
                                                <h3 className="text-base font-bold text-gray-900 dark:text-white">
                                                    {plan.name}
                                                </h3>
                                                <p className="text-xs text-gray-600 dark:text-gray-400 hidden sm:block">
                                                    {plan.description}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="text-left sm:text-right">
                                            <div className="flex items-baseline">
                                                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                                                    {plan.price}
                                                </span>
                                                <span className="ml-1 text-gray-500 dark:text-gray-400 text-sm">
                                                    /month
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <ul className="space-y-2 mt-2">
                                        {plan.features.slice(0, 4).map((feature, index) => (
                                            <li
                                                key={index}
                                                className="flex items-center text-xs sm:text-sm text-gray-600 dark:text-gray-300"
                                            >
                                                <Check className="w-3 h-3 sm:w-4 sm:h-4 mr-2 text-green-600 flex-shrink-0" />
                                                {feature}
                                            </li>
                                        ))}
                                        {plan.features.length > 4 && (
                                            <li className="text-xs text-gray-500 dark:text-gray-400 ml-5">
                                                +{plan.features.length - 4} more features
                                            </li>
                                        )}
                                    </ul>

                                    {selectedPlan === plan.id && (
                                        <div className="absolute -top-1 -right-1">
                                            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 dark:bg-blue-500">
                                                <Check className="h-3 w-3 text-white" />
                                            </span>
                                        </div>
                                    )}
                                </label>
                            );
                        })}
                    </RadioGroup>

                    <DialogFooter className="flex flex-col gap-3 pt-4">
                        <Button
                            onClick={() => setIsOpen(false)}
                            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3"
                        >
                            Continue with {plans.find(p => p.id === selectedPlan)?.name} Plan
                        </Button>
                        <Button
                            variant="ghost"
                            onClick={() => setIsOpen(false)}
                            className="w-full text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                        >
                            Maybe Later
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}

export { ModalPricing, type PlanOption };