import React from "react";
import { TooltipTerm } from "./tooltip-term";
import { detectTermsInText, getTermByName } from "@/lib/job-terms-database";

interface SmartTextProps {
  children: string;
  className?: string;
  enableAutoDetection?: boolean;
  maxTooltips?: number;
}

export function SmartText({ 
  children, 
  className = "", 
  enableAutoDetection = true,
  maxTooltips = 5 
}: SmartTextProps) {
  if (!enableAutoDetection || !children) {
    return <span className={className}>{children}</span>;
  }

  const detectedTerms = detectTermsInText(children).slice(0, maxTooltips);
  
  if (detectedTerms.length === 0) {
    return <span className={className}>{children}</span>;
  }

  // Sort terms by position in reverse order for proper text splitting
  const sortedTerms = [...detectedTerms].sort((a, b) => b.position - a.position);
  
  let processedText = children;
  const elements: React.ReactNode[] = [];
  let lastIndex = children.length;

  // Process terms from end to beginning to maintain correct indices
  sortedTerms.forEach(({ term, position }) => {
    const termLength = term.term.length;
    const endPos = position + termLength;
    
    // Add text after current term
    if (lastIndex > endPos) {
      elements.unshift(processedText.slice(endPos, lastIndex));
    }
    
    // Add the term with tooltip
    elements.unshift(
      <TooltipTerm
        key={`${term.id}-${position}`}
        term={term.term}
        definition={term.definition}
        category={term.category}
        examples={term.examples}
        relatedTerms={term.relatedTerms}
        learnMoreUrl={term.learnMoreUrl}
        variant="inline"
      />
    );
    
    lastIndex = position;
  });
  
  // Add remaining text at the beginning
  if (lastIndex > 0) {
    elements.unshift(processedText.slice(0, lastIndex));
  }

  return <span className={className}>{elements}</span>;
}

// Hook for manual term enhancement
export function useTermEnhancement() {
  const enhanceTerm = (termName: string) => {
    const term = getTermByName(termName);
    if (!term) return null;
    
    return (
      <TooltipTerm
        term={term.term}
        definition={term.definition}
        category={term.category}
        examples={term.examples}
        relatedTerms={term.relatedTerms}
        learnMoreUrl={term.learnMoreUrl}
        variant="inline"
      />
    );
  };

  const enhanceTerms = (text: string, termNames: string[]) => {
    let enhanced = text;
    termNames.forEach(termName => {
      const term = getTermByName(termName);
      if (term) {
        const regex = new RegExp(`\\b${term.term}\\b`, 'gi');
        enhanced = enhanced.replace(regex, `<enhanced-term data-term="${term.id}">${term.term}</enhanced-term>`);
      }
    });
    return enhanced;
  };

  return { enhanceTerm, enhanceTerms };
}