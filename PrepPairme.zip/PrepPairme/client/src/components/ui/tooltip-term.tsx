import { useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { HelpCircle, ExternalLink } from "lucide-react";

interface TooltipTermProps {
  term: string;
  definition: string;
  category?: string;
  examples?: string[];
  relatedTerms?: string[];
  learnMoreUrl?: string;
  children?: React.ReactNode;
  variant?: "inline" | "badge" | "icon";
  className?: string;
}

export function TooltipTerm({
  term,
  definition,
  category,
  examples = [],
  relatedTerms = [],
  learnMoreUrl,
  children,
  variant = "inline",
  className = "",
}: TooltipTermProps) {
  const [isOpen, setIsOpen] = useState(false);

  const renderTrigger = () => {
    if (children) {
      return children;
    }

    switch (variant) {
      case "badge":
        return (
          <Badge variant="outline" className={`cursor-help ${className}`}>
            {term}
          </Badge>
        );
      case "icon":
        return (
          <HelpCircle className={`h-4 w-4 text-muted-foreground cursor-help ${className}`} />
        );
      case "inline":
      default:
        return (
          <span className={`underline decoration-dotted cursor-help text-primary ${className}`}>
            {term}
          </span>
        );
    }
  };

  const getCategoryColor = (cat?: string) => {
    switch (cat?.toLowerCase()) {
      case "technical":
        return "bg-blue-100 text-blue-800";
      case "process":
        return "bg-green-100 text-green-800";
      case "industry":
        return "bg-purple-100 text-purple-800";
      case "legal":
        return "bg-red-100 text-red-800";
      case "financial":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <TooltipProvider>
      <Tooltip open={isOpen} onOpenChange={setIsOpen}>
        <TooltipTrigger asChild>
          {renderTrigger()}
        </TooltipTrigger>
        <TooltipContent className="max-w-sm p-4 space-y-3" side="top">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-sm">{term}</h4>
              {category && (
                <Badge className={`text-xs ${getCategoryColor(category)}`}>
                  {category}
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {definition}
            </p>
          </div>

          {examples.length > 0 && (
            <div>
              <h5 className="font-medium text-xs text-muted-foreground mb-1">
                Examples:
              </h5>
              <ul className="space-y-1">
                {examples.map((example, index) => (
                  <li key={index} className="text-xs text-muted-foreground">
                    • {example}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {relatedTerms.length > 0 && (
            <div>
              <h5 className="font-medium text-xs text-muted-foreground mb-1">
                Related:
              </h5>
              <div className="flex flex-wrap gap-1">
                {relatedTerms.map((related, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {related}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {learnMoreUrl && (
            <div className="pt-2 border-t">
              <a
                href={learnMoreUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-primary hover:underline flex items-center gap-1"
              >
                Learn more
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}