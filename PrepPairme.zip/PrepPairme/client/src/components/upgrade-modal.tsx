import { useState } from "react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EnhancedBadge } from "@/components/ui/enhanced-badge";
import { Separator } from "@/components/ui/separator";
import { 
  Crown, 
  Check, 
  Zap, 
  Target, 
  FileText, 
  Star,
  Clock,
  Shield,
  ArrowRight,
  X
} from "lucide-react";

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function UpgradeModal({ open, onOpenChange }: UpgradeModalProps) {
  const [, setLocation] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<'pro' | 'credits'>('pro');

  const handleUpgrade = () => {
    if (selectedPlan === 'pro') {
      setLocation('/subscribe');
    } else {
      // Handle credit purchase
      onOpenChange(false);
    }
  };

  const proFeatures = [
    {
      icon: FileText,
      title: "Unlimited Interview Guides",
      description: "Create as many guides as you need without credit limits"
    },
    {
      icon: Star,
      title: "Advanced STAR Stories",
      description: "Get detailed behavioral question examples with full STAR methodology"
    },
    {
      icon: Target,
      title: "Premium Resume Optimization", 
      description: "Advanced ATS analysis with unlimited bullet point improvements"
    },
    {
      icon: Zap,
      title: "Priority AI Processing",
      description: "Faster response times and access to latest AI models"
    },
    {
      icon: Shield,
      title: "Priority Customer Support",
      description: "Direct access to our support team with 4-hour response time"
    },
    {
      icon: Clock,
      title: "Early Access Features",
      description: "Be the first to try new features and improvements"
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center text-xl">
              <Crown className="w-6 h-6 mr-2 text-yellow-500" />
              Upgrade to unlock this feature
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onOpenChange(false)}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <DialogDescription>
            Get unlimited access to all features and take your interview preparation to the next level.
          </DialogDescription>
        </DialogHeader>

        <div className="mt-6">
          {/* Hero Image */}
          <div className="relative mb-6">
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&w=400&h=200&fit=crop" 
              alt="Professional interview preparation" 
              className="w-full h-32 object-cover rounded-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600/80 to-teal-600/80 rounded-lg flex items-center justify-center">
              <div className="text-center text-white">
                <Crown className="w-8 h-8 mx-auto mb-2" />
                <h3 className="text-lg font-semibold">Unlock Your Potential</h3>
              </div>
            </div>
          </div>

          {/* Plan Selection */}
          <div className="space-y-4 mb-6">
            <h3 className="font-semibold text-gray-900">Choose Your Plan</h3>
            
            {/* Pro Plan */}
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                selectedPlan === 'pro' 
                  ? 'border-purple-600 bg-purple-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedPlan('pro')}
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="flex items-center">
                    <Crown className="w-5 h-5 text-purple-600 mr-2" />
                    <h4 className="font-semibold text-gray-900">PrepPair Pro</h4>
                    <Badge className="ml-2 bg-purple-600 text-white">Most Popular</Badge>
                  </div>
                  <p className="text-sm text-gray-600">Monthly subscription with unlimited access</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">$19</div>
                  <div className="text-sm text-gray-600">/month</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {proFeatures.slice(0, 4).map((feature, index) => (
                  <div key={index} className="flex items-center text-sm">
                    <Check className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{feature.title}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Credits Plan */}
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                selectedPlan === 'credits' 
                  ? 'border-blue-600 bg-blue-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedPlan('credits')}
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="flex items-center">
                    <Zap className="w-5 h-5 text-blue-600 mr-2" />
                    <h4 className="font-semibold text-gray-900">10 Credits Pack</h4>
                  </div>
                  <p className="text-sm text-gray-600">One-time purchase • No subscription</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">$9.99</div>
                  <div className="text-sm text-gray-600">one-time</div>
                </div>
              </div>
              <div className="text-sm text-gray-700">
                • 10 AI actions (guides, optimizations, etc.)
                <br />
                • Credits never expire
                <br />
                • Basic features only
              </div>
            </div>
          </div>

          {/* Feature Comparison */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">What You'll Get</h3>
            <div className="space-y-3">
              {proFeatures.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3 flex-shrink-0">
                    <feature.icon className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator className="my-6" />

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button 
              onClick={handleUpgrade}
              className="w-full gradient-bg text-white hover:opacity-90 h-12 text-base"
            >
              {selectedPlan === 'pro' ? (
                <>
                  <Crown className="w-5 h-5 mr-2" />
                  Upgrade to Pro - $19/month
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Buy 10 Credits - $9.99
                </>
              )}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            
            <div className="text-center">
              <p className="text-xs text-gray-500">
                {selectedPlan === 'pro' ? (
                  <>Cancel anytime • 7-day money back guarantee • Instant access</>
                ) : (
                  <>One-time payment • Credits never expire • Instant delivery</>
                )}
              </p>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <Shield className="w-6 h-6 text-green-600 mx-auto mb-1" />
                <p className="text-xs text-gray-600">Secure Payment</p>
              </div>
              <div>
                <Clock className="w-6 h-6 text-blue-600 mx-auto mb-1" />
                <p className="text-xs text-gray-600">Instant Access</p>
              </div>
              <div>
                <Check className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                <p className="text-xs text-gray-600">Cancel Anytime</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
