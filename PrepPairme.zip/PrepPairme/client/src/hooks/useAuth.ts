import { useUser, useAuth as useClerkAuth } from "@clerk/clerk-react";

export function useAuth() {
  try {
    const { isSignedIn, isLoaded, user } = useUser();

    return {
      isAuthenticated: isSignedIn || false,
      isLoading: !isLoaded,
      user: user || null
    };
  } catch (error) {
    console.error('useAuth error:', error);
    return {
      isAuthenticated: false,
      isLoading: false,
      user: null
    };
  }
}