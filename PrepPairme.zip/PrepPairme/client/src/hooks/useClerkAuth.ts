import { useUser, useAuth as useClerkAuth } from "@clerk/clerk-react";
import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const { user: clerkUser, isLoaded: clerkLoaded } = useUser();
  const { isSignedIn } = useClerkAuth();

  // Fetch PrepPair user data based on Clerk user
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/user'],
    enabled: isSignedIn && clerkLoaded,
    retry: false,
  });

  return {
    user: user || null,
    isLoading: !clerkLoaded || (isSignedIn && userLoading),
    isAuthenticated: isSignedIn && !!user,
    clerkUser,
  };
}