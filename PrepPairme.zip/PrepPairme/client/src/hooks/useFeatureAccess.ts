import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@clerk/clerk-react";

interface UserEntitlement {
  slug: string;
  hasAccess: boolean;
  limit?: number;
  usage?: number;
}

interface FeatureAccessResponse {
  entitlements: UserEntitlement[];
}

export function useFeatureAccess(featureSlug: string) {
  const { isSignedIn, getToken } = useAuth();

  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/atlas/user-entitlements", featureSlug],
    queryFn: async () => {
      if (!isSignedIn) {
        return { entitlements: [] };
      }

      const token = await getToken();
      const response = await fetch("/api/atlas/user-entitlements", {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch user entitlements");
      }

      return response.json() as Promise<FeatureAccessResponse>;
    },
    enabled: !!isSignedIn,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });

  const entitlement = data?.entitlements?.find(e => e.slug === featureSlug);
  const hasAccess = isSignedIn ? (entitlement?.hasAccess ?? false) : false;

  return {
    hasAccess,
    isLoading: isSignedIn ? isLoading : false,
    limit: entitlement?.limit,
    usage: entitlement?.usage,
    error,
    // Helper to check if feature is at usage limit
    isAtLimit: entitlement?.limit ? (entitlement.usage ?? 0) >= entitlement.limit : false,
  };
}

// Hook for checking multiple features at once
export function useMultipleFeatureAccess(featureSlugs: string[]) {
  const { isSignedIn, getToken } = useAuth();

  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/atlas/user-entitlements", "multiple", featureSlugs.join(",")],
    queryFn: async () => {
      if (!isSignedIn) {
        return { entitlements: [] };
      }

      const token = await getToken();
      const response = await fetch("/api/atlas/user-entitlements", {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch user entitlements");
      }

      return response.json() as Promise<FeatureAccessResponse>;
    },
    enabled: !!isSignedIn,
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const featureAccess = featureSlugs.reduce((acc, slug) => {
    const entitlement = data?.entitlements?.find(e => e.slug === slug);
    acc[slug] = {
      hasAccess: isSignedIn ? (entitlement?.hasAccess ?? false) : false,
      limit: entitlement?.limit,
      usage: entitlement?.usage,
      isAtLimit: entitlement?.limit ? (entitlement.usage ?? 0) >= entitlement.limit : false,
    };
    return acc;
  }, {} as Record<string, { hasAccess: boolean; limit?: number; usage?: number; isAtLimit: boolean }>);

  return {
    featureAccess,
    isLoading: isSignedIn ? isLoading : false,
    error,
  };
}

// Predefined feature slugs from Atlas configuration
export const FEATURE_SLUGS = {
  AI_INTERVIEW_GUIDES: "AI-Interview-Guides",
  RESUME_OPTIMIZATION: "Resume-Optimization", 
  INTERVIEW_QUESTION_BANK: "Interview-Question-Bank",
  AI_FEEDBACK_VIDEO_PRACTICE: "AI-Feedback-Video-Practice",
  JOB_APPLICATION_TRACKING: "Job-Application-Tracking",
  INDUSTRY_SPECIFIC_TEMPLATES: "Industry-Specific-Templates", 
  ADVANCED_CAREER_ANALYTICS: "Advanced-Career-Analytics",
  PRIORITY_SUPPORT: "Priority-Support",
  BULK_USER_ACCESS: "Bulk-User-Access",
  TEAM_MANAGEMENT: "Team-Management",
  CUSTOMIZABLE_THEMES: "Customizable-Themes",
  THANK_YOU_NOTE_GENERATOR: "Thank-You-Note-Generator",
} as const;

export type FeatureSlug = typeof FEATURE_SLUGS[keyof typeof FEATURE_SLUGS];