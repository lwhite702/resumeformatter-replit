import { useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface MarketingEvent {
  event: string;
  channel: string;
  campaign?: string;
  source?: string;
  medium?: string;
  content?: string;
  term?: string;
  userId?: string;
  sessionId: string;
  timestamp: number;
  page: string;
  referrer?: string;
  userAgent: string;
}

export function useMarketingAnalytics() {
  const trackEventMutation = useMutation({
    mutationFn: async (event: MarketingEvent) => {
      const response = await fetch('/api/marketing/track', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event)
      });
      
      if (!response.ok) {
        throw new Error(`Failed to track event: ${response.statusText}`);
      }
      
      return response.json();
    }
  });

  const getSessionId = () => {
    let sessionId = sessionStorage.getItem('marketing_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('marketing_session_id', sessionId);
    }
    return sessionId;
  };

  const parseUtmParams = () => {
    const urlParams = new URLSearchParams(window.location.search);
    return {
      source: urlParams.get('utm_source') || undefined,
      medium: urlParams.get('utm_medium') || undefined,
      campaign: urlParams.get('utm_campaign') || undefined,
      content: urlParams.get('utm_content') || undefined,
      term: urlParams.get('utm_term') || undefined,
      ref: urlParams.get('ref') || undefined
    };
  };

  const determineChannel = (utmParams: any) => {
    const { source, medium, ref } = utmParams;
    
    // Social media
    if (source === 'social' || 
        medium === 'social' ||
        ['facebook', 'instagram', 'twitter', 'linkedin', 'tiktok', 'youtube'].includes(source?.toLowerCase() || '')) {
      return 'social';
    }
    
    // Paid ads
    if (source === 'ads' || 
        medium === 'cpc' || 
        medium === 'paid' ||
        ['google', 'facebook-ads', 'linkedin-ads', 'bing', 'ppc'].includes(source?.toLowerCase() || '')) {
      return 'ads';
    }
    
    // Wrelik ecosystem
    if (source === 'wrelik' || 
        ref === 'wrelik' ||
        ['resumeformatter', 'autoapply', 'careermentor', 'wrelikbrands'].includes(source?.toLowerCase() || '')) {
      return 'wrelik';
    }
    
    // Organic
    if (document.referrer) {
      const referrerDomain = new URL(document.referrer).hostname;
      if (['google.com', 'bing.com', 'duckduckgo.com'].some(domain => referrerDomain.includes(domain))) {
        return 'organic_search';
      }
      return 'referral';
    }
    
    return 'direct';
  };

  const trackEvent = (eventName: string, additionalData: any = {}) => {
    const utmParams = parseUtmParams();
    const channel = determineChannel(utmParams);
    
    const event: MarketingEvent = {
      event: eventName,
      channel,
      campaign: utmParams.campaign,
      source: utmParams.source,
      medium: utmParams.medium,
      content: utmParams.content,
      term: utmParams.term,
      sessionId: getSessionId(),
      timestamp: Date.now(),
      page: window.location.pathname,
      referrer: document.referrer || undefined,
      userAgent: navigator.userAgent,
      ...additionalData
    };

    trackEventMutation.mutate(event);
  };

  const trackPageView = () => {
    trackEvent('page_view');
  };

  const trackLandingPageView = () => {
    trackEvent('landing_page_view');
  };

  const trackSignupStart = () => {
    trackEvent('signup_start');
  };

  const trackSignupComplete = (userId: string) => {
    trackEvent('signup_complete', { userId });
  };

  const trackTrialStart = (userId: string) => {
    trackEvent('trial_start', { userId });
  };

  const trackPurchase = (userId: string, amount: number, plan: string) => {
    trackEvent('purchase', { userId, amount, plan });
  };

  const trackFeatureUse = (feature: string) => {
    trackEvent('feature_use', { feature });
  };

  const trackCTAClick = (ctaLocation: string, ctaText: string) => {
    trackEvent('cta_click', { ctaLocation, ctaText });
  };

  // Auto-track page views
  useEffect(() => {
    trackPageView();
  }, [window.location.pathname]);

  return {
    trackEvent,
    trackPageView,
    trackLandingPageView,
    trackSignupStart,
    trackSignupComplete,
    trackTrialStart,
    trackPurchase,
    trackFeatureUse,
    trackCTAClick
  };
}