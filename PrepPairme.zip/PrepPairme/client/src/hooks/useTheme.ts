import { useState, useEffect, useCallback } from "react";

type Theme = "light" | "dark" | "system";

export function useTheme() {
  const [theme, setTheme] = useState<Theme>("system");
  const [resolvedTheme, setResolvedTheme] = useState<"light" | "dark">("light");
  const [mounted, setMounted] = useState(false);

  // Get system theme preference
  const getSystemTheme = useCallback((): "light" | "dark" => {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }, []);

  // Apply theme to document
  const applyTheme = useCallback((newTheme: Theme) => {
    const root = document.documentElement;
    
    // Add no-transition class to prevent flash during theme change
    root.classList.add("no-transition");
    
    // Remove existing theme classes
    root.classList.remove("light", "dark");
    
    let actualTheme: "light" | "dark";
    if (newTheme === "system") {
      actualTheme = getSystemTheme();
    } else {
      actualTheme = newTheme;
    }
    
    // Apply theme class
    root.classList.add(actualTheme);
    
    // Update state
    setTheme(newTheme);
    setResolvedTheme(actualTheme);
    
    // Store preference
    localStorage.setItem("theme", newTheme);
    
    // Re-enable transitions after a short delay
    setTimeout(() => {
      root.classList.remove("no-transition");
    }, 100);
  }, [getSystemTheme]);

  // Initialize theme on mount
  useEffect(() => {
    setMounted(true);
    
    // Get stored theme preference
    const stored = localStorage.getItem("theme") as Theme;
    const initialTheme = stored && ["light", "dark", "system"].includes(stored) ? stored : "system";
    
    applyTheme(initialTheme);
  }, [applyTheme]);

  // Listen for system theme changes
  useEffect(() => {
    if (!mounted) return;
    
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = () => {
      if (theme === "system") {
        const systemTheme = getSystemTheme();
        setResolvedTheme(systemTheme);
        
        const root = document.documentElement;
        root.classList.remove("light", "dark");
        root.classList.add(systemTheme);
      }
    };
    
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, [theme, mounted, getSystemTheme]);

  // Theme setter function
  const setThemeValue = useCallback((newTheme: Theme) => {
    applyTheme(newTheme);
  }, [applyTheme]);

  return {
    theme,
    resolvedTheme,
    setTheme: setThemeValue,
    mounted
  };
}