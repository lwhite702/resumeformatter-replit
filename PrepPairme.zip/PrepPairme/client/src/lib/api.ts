import { useAuth } from "@clerk/clerk-react";

// API client with automatic Clerk token handling
export const createApiRequest = () => {
  const { getToken } = useAuth();

  const apiRequest = async (url: string, options: RequestInit = {}) => {
    try {
      // Get the session token from Clerk
      const token = await getToken();
      
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Host': window.location.host,
        'Origin': window.location.origin,
        'Referer': window.location.href,
        'Sec-Fetch-Dest': 'empty',
        'User-Agent': navigator.userAgent,
      } as Record<string, string>;

      // Merge existing headers
      if (options.headers) {
        Object.assign(headers, options.headers);
      }

      // Add authorization header if token is available
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`${response.status}: ${response.statusText} - ${errorData}`);
      }

      return response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  };

  return apiRequest;
};

// Hook for making authenticated API requests
export const useApiRequest = () => {
  return createApiRequest();
};