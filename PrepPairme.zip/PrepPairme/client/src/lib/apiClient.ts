import { useAuth, useUser } from '@clerk/clerk-react';

// Enhanced API client with authentication headers
export const useApiClient = () => {
  const { getToken, userId } = useAuth();
  const { user } = useUser();

  const makeRequest = async (endpoint: string, options: RequestInit = {}) => {
    try {
      // Get the session token from Clerk
      const token = await getToken();
      
      // Prepare headers with user authentication data
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...options.headers as Record<string, string>,
      };

      // Add user context headers if authenticated
      if (userId && user) {
        headers['x-clerk-user-id'] = userId;
        headers['x-clerk-user-email'] = user.emailAddresses?.[0]?.emailAddress || '';
        headers['x-clerk-user-first-name'] = user.firstName || '';
        headers['x-clerk-user-last-name'] = user.lastName || '';
        headers['x-clerk-user-plan'] = (user.publicMetadata?.plan as string) || 'free';
        headers['x-clerk-user-role'] = (user.publicMetadata?.role as string) || 'user';
        
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }
      }

      const response = await fetch(endpoint, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(`${response.status}: ${errorData.message || errorData.error || 'Request failed'}`);
      }

      return response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  };

  return { makeRequest };
};

// Standalone API client function for use outside components
export const apiClientRequest = async (endpoint: string, options: RequestInit = {}) => {
  try {
    const response = await fetch(endpoint, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`${response.status}: ${errorData.message || errorData.error || 'Request failed'}`);
    }

    return response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
};