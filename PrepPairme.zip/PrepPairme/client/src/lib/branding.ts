// PrepPair.me Brand Constants and Utilities

export const BRAND_CONSTANTS = {
  // Primary brand messaging
  TAGLINE: "Interview smarter. Prepare together.",
  
  // Social media and Open Graph
  SOCIAL_ALT: "PrepPair.me gives you friendly, AI-powered interview prep — personalized and stress-free.",
  
  // Dynamic meta descriptions for SEO rotation
  META_DESCRIPTIONS: [
    "AI-generated interview guides built just for your resume and job goals.",
    "Your interview prep sidekick — smart, supportive, and easy to use.",
    "Transform your job search with AI-powered interview preparation, resume optimization, and career development tools. Land your dream job faster with PrepPair.me.",
    "Practice interviews with AI feedback, optimize your resume for ATS systems, and track applications all in one intelligent platform.",
    "Get personalized interview coaching, strategic career guidance, and job search tools powered by advanced AI technology."
  ],
  
  // Alternative slogans for variety
  SLOGANS: [
    "Interview smarter. Prepare together.",
    "Your AI-powered interview prep partner.",
    "Built for every job seeker, from first-time to high-stakes.",
    "Smart questions. Better answers. Real confidence.",
    "We prep, you win.",
    "From resume upload to thank-you note — we've got you.",
    "Big interview coming up? We've got your back.",
    "Practice makes confident. AI makes it perfect.",
    "Your career success starts with better preparation.",
    "Turn interview anxiety into interview advantage."
  ],
  
  // Feature-specific messaging
  FEATURES: {
    INTERVIEW_PREP: {
      headline: "Master Every Interview Question",
      description: "Practice with AI-powered feedback on 1000+ industry-specific questions"
    },
    RESUME_OPTIMIZER: {
      headline: "ATS-Optimized Resume Writing",
      description: "Get your resume past applicant tracking systems and into human hands"
    },
    CAREER_TRACKING: {
      headline: "Smart Job Application Tracking",
      description: "Organize applications, track progress, and never miss a follow-up"
    },
    VIDEO_PRACTICE: {
      headline: "Perfect Your Interview Presence",
      description: "Record practice sessions and get feedback on delivery and body language"
    }
  },
  
  // Call-to-action variations
  CTA_VARIATIONS: [
    "Start Practicing Now",
    "Get Interview Ready",
    "Begin Your Prep",
    "Try PrepPair Free",
    "Start Your Success Story",
    "Ace Your Next Interview"
  ]
};

// Utility functions for dynamic content
export const getRandomSlogan = (): string => {
  const slogans = BRAND_CONSTANTS.SLOGANS;
  return slogans[Math.floor(Math.random() * slogans.length)];
};

export const getRandomMetaDescription = (): string => {
  const descriptions = BRAND_CONSTANTS.META_DESCRIPTIONS;
  return descriptions[Math.floor(Math.random() * descriptions.length)];
};

export const getRandomCTA = (): string => {
  const ctas = BRAND_CONSTANTS.CTA_VARIATIONS;
  return ctas[Math.floor(Math.random() * ctas.length)];
};

// SEO-optimized page titles
export const generatePageTitle = (pageTitle: string): string => {
  return `${pageTitle} | PrepPair.me - AI-Powered Interview Preparation`;
};

// Open Graph data generator
export const generateOGData = (title: string, description?: string) => ({
  title: generatePageTitle(title),
  description: description || getRandomMetaDescription(),
  image: "/assets/3_1749272880173.png", // PrepPair social sharing image
  url: "https://preppair.me",
  siteName: "PrepPair.me",
  type: "website"
});

export default BRAND_CONSTANTS;