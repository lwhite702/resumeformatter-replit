export interface JobTerm {
  id: string;
  term: string;
  definition: string;
  category: "technical" | "process" | "industry" | "legal" | "financial" | "general";
  examples?: string[];
  relatedTerms?: string[];
  learnMoreUrl?: string;
  industries?: string[];
}

export const jobTermsDatabase: JobTerm[] = [
  // Technical Terms
  {
    id: "ats",
    term: "ATS",
    definition: "Applicant Tracking System - Software used by companies to collect, sort, scan, and rank job applications. ATS systems filter resumes based on keywords, formatting, and criteria set by employers.",
    category: "technical",
    examples: [
      "Workday ATS",
      "Greenhouse",
      "BambooHR",
      "Lever"
    ],
    relatedTerms: ["Resume Parsing", "Keyword Optimization", "CV Screening"],
    learnMoreUrl: "https://www.indeed.com/career-advice/finding-a-job/what-is-applicant-tracking-system"
  },
  {
    id: "resume-parsing",
    term: "Resume Parsing",
    definition: "The automated process of extracting and analyzing information from resumes. ATS systems parse resumes to identify contact information, work experience, education, and skills.",
    category: "technical",
    examples: [
      "Extracting contact details",
      "Identifying job titles and dates",
      "Parsing education information",
      "Skills recognition"
    ],
    relatedTerms: ["ATS", "OCR", "Data Extraction"],
    industries: ["technology", "hr", "recruiting"]
  },
  {
    id: "keyword-optimization",
    term: "Keyword Optimization",
    definition: "The practice of strategically including relevant industry keywords and phrases in your resume and cover letter to improve visibility in ATS systems and search results.",
    category: "technical",
    examples: [
      "Including job-specific skills",
      "Using industry terminology",
      "Matching job description language",
      "Technical skill keywords"
    ],
    relatedTerms: ["ATS", "SEO", "Resume Optimization"]
  },

  // Process Terms
  {
    id: "behavioral-interview",
    term: "Behavioral Interview",
    definition: "An interview technique that focuses on past experiences and behaviors to predict future performance. Questions typically start with 'Tell me about a time when...' or 'Give me an example of...'",
    category: "process",
    examples: [
      "Tell me about a time you overcame a challenge",
      "Describe a situation where you had to work with a difficult team member",
      "Give an example of when you showed leadership"
    ],
    relatedTerms: ["STAR Method", "Competency-Based Interview", "Situational Interview"],
    learnMoreUrl: "https://www.indeed.com/career-advice/interviewing/behavioral-interview-questions"
  },
  {
    id: "star-method",
    term: "STAR Method",
    definition: "A structured approach to answering behavioral interview questions. STAR stands for Situation, Task, Action, and Result - providing a framework for comprehensive and compelling responses.",
    category: "process",
    examples: [
      "Situation: Set the context",
      "Task: Explain your responsibility",
      "Action: Describe what you did",
      "Result: Share the outcome"
    ],
    relatedTerms: ["Behavioral Interview", "Interview Preparation", "Storytelling"],
    learnMoreUrl: "https://www.indeed.com/career-advice/interviewing/how-to-use-the-star-method"
  },
  {
    id: "competency-based-interview",
    term: "Competency-Based Interview",
    definition: "An interview format that assesses specific skills, behaviors, and attributes required for the role. Questions focus on demonstrating particular competencies through real examples.",
    category: "process",
    examples: [
      "Leadership competency questions",
      "Problem-solving scenarios",
      "Communication skills assessment",
      "Teamwork evaluation"
    ],
    relatedTerms: ["Behavioral Interview", "Skills Assessment", "Core Competencies"]
  },
  {
    id: "panel-interview",
    term: "Panel Interview",
    definition: "An interview format where multiple interviewers (typically 2-5 people) meet with one candidate simultaneously. Panel members often represent different departments or levels within the organization.",
    category: "process",
    examples: [
      "HR representative + hiring manager + team lead",
      "Cross-functional team interview",
      "Executive panel for senior roles"
    ],
    relatedTerms: ["Group Interview", "Multi-Stage Interview", "Stakeholder Interview"]
  },

  // Industry Terms
  {
    id: "agile-methodology",
    term: "Agile Methodology",
    definition: "A project management and software development approach that emphasizes iterative development, collaboration, and flexibility. Common in technology and product development roles.",
    category: "industry",
    examples: [
      "Scrum framework",
      "Sprint planning",
      "Daily standups",
      "Retrospectives"
    ],
    relatedTerms: ["Scrum", "Kanban", "Sprint", "Product Owner"],
    industries: ["technology", "product management", "software development"],
    learnMoreUrl: "https://www.agilealliance.org/agile101/"
  },
  {
    id: "kpi",
    term: "KPI",
    definition: "Key Performance Indicator - Measurable values that demonstrate how effectively an individual, team, or company is achieving business objectives.",
    category: "industry",
    examples: [
      "Revenue growth percentage",
      "Customer acquisition cost",
      "Employee retention rate",
      "Project completion time"
    ],
    relatedTerms: ["Metrics", "OKR", "Performance Management", "Analytics"],
    industries: ["business", "marketing", "sales", "operations"]
  },
  {
    id: "roi",
    term: "ROI",
    definition: "Return on Investment - A performance measure used to evaluate the efficiency of an investment or compare efficiency between different investments, calculated as (Gain - Cost) / Cost.",
    category: "financial",
    examples: [
      "Marketing campaign ROI",
      "Training program ROI",
      "Technology investment returns",
      "Process improvement savings"
    ],
    relatedTerms: ["KPI", "Cost-Benefit Analysis", "Performance Metrics"],
    industries: ["finance", "business", "marketing", "operations"]
  },

  // Legal Terms
  {
    id: "at-will-employment",
    term: "At-Will Employment",
    definition: "An employment arrangement where either the employer or employee can terminate the working relationship at any time, for any reason (except illegal reasons), without advance notice.",
    category: "legal",
    examples: [
      "Termination without cause",
      "Resignation without notice period",
      "Most US employment contracts"
    ],
    relatedTerms: ["Employment Contract", "Termination", "Labor Law"],
    learnMoreUrl: "https://www.dol.gov/general/topic/termination"
  },
  {
    id: "non-disclosure-agreement",
    term: "NDA",
    definition: "Non-Disclosure Agreement - A legal contract that prevents parties from sharing confidential information with third parties. Common in employment to protect company secrets and intellectual property.",
    category: "legal",
    examples: [
      "Employee confidentiality agreements",
      "Client information protection",
      "Trade secret protection",
      "Interview process NDAs"
    ],
    relatedTerms: ["Confidentiality Agreement", "Non-Compete", "IP Protection"],
    industries: ["technology", "healthcare", "finance", "consulting"]
  },
  {
    id: "non-compete-clause",
    term: "Non-Compete Clause",
    definition: "A contractual agreement that restricts an employee from working for competitors or starting a competing business for a specified period after leaving their current employer.",
    category: "legal",
    examples: [
      "6-month restriction period",
      "Geographic limitations",
      "Industry-specific restrictions",
      "Client solicitation prohibition"
    ],
    relatedTerms: ["NDA", "Employment Contract", "Restrictive Covenant"],
    learnMoreUrl: "https://www.dol.gov/agencies/whd/flsa/non-compete"
  },

  // General Terms
  {
    id: "networking",
    term: "Professional Networking",
    definition: "The practice of building and maintaining professional relationships that can provide career opportunities, industry insights, mentorship, and business connections.",
    category: "general",
    examples: [
      "LinkedIn connections",
      "Industry conferences",
      "Alumni networks",
      "Professional associations"
    ],
    relatedTerms: ["Relationship Building", "Career Development", "Referrals"],
    learnMoreUrl: "https://www.linkedin.com/business/learning/blog/networking/networking-statistics-and-trends"
  },
  {
    id: "elevator-pitch",
    term: "Elevator Pitch",
    definition: "A brief, persuasive speech (30-60 seconds) that summarizes who you are, what you do, and what you're looking for. Named for the time it takes to ride an elevator.",
    category: "general",
    examples: [
      "Networking event introductions",
      "Interview opening statements",
      "Career fair conversations",
      "LinkedIn summary inspiration"
    ],
    relatedTerms: ["Personal Brand", "Networking", "Self-Presentation"]
  },
  {
    id: "culture-fit",
    term: "Culture Fit",
    definition: "How well a candidate's values, beliefs, and behaviors align with the organization's culture, values, and work environment. Often assessed through interviews and team interactions.",
    category: "general",
    examples: [
      "Team collaboration style",
      "Communication preferences",
      "Work-life balance values",
      "Problem-solving approach"
    ],
    relatedTerms: ["Company Culture", "Team Dynamics", "Values Alignment"],
    industries: ["all"]
  },
  {
    id: "onboarding",
    term: "Employee Onboarding",
    definition: "The process of integrating new employees into an organization, including orientation, training, paperwork completion, and introduction to company culture and processes.",
    category: "process",
    examples: [
      "First week orientation",
      "Training programs",
      "Mentor assignment",
      "System access setup"
    ],
    relatedTerms: ["Orientation", "Training", "Integration", "New Hire"],
    industries: ["hr", "all"]
  },

  // Additional Financial Terms
  {
    id: "equity-compensation",
    term: "Equity Compensation",
    definition: "Non-cash compensation in the form of company ownership, including stock options, restricted stock units (RSUs), or employee stock purchase plans (ESPP).",
    category: "financial",
    examples: [
      "Stock options with vesting schedule",
      "RSUs (Restricted Stock Units)",
      "ESPP (Employee Stock Purchase Plan)",
      "Performance-based equity"
    ],
    relatedTerms: ["Vesting Schedule", "Stock Options", "Total Compensation"],
    industries: ["technology", "startups", "finance"],
    learnMoreUrl: "https://www.investopedia.com/terms/e/equity-compensation.asp"
  },
  {
    id: "vesting-schedule",
    term: "Vesting Schedule",
    definition: "A timeline that determines when employees gain full ownership of employer-contributed benefits, such as stock options, retirement contributions, or equity compensation.",
    category: "financial",
    examples: [
      "4-year vesting with 1-year cliff",
      "Monthly vesting over 3 years",
      "Performance-based vesting",
      "Graded vesting schedule"
    ],
    relatedTerms: ["Equity Compensation", "Stock Options", "Cliff Vesting"],
    industries: ["technology", "finance", "startups"]
  },

  // Additional Technical Terms
  {
    id: "api",
    term: "API",
    definition: "Application Programming Interface - A set of protocols and tools that allows different software applications to communicate with each other. Essential in modern software development.",
    category: "technical",
    examples: [
      "REST API integration",
      "GraphQL endpoints",
      "Payment gateway APIs",
      "Social media APIs"
    ],
    relatedTerms: ["Integration", "Web Services", "SDK", "Microservices"],
    industries: ["technology", "software development"],
    learnMoreUrl: "https://www.redhat.com/en/topics/api/what-are-application-programming-interfaces"
  },
  {
    id: "devops",
    term: "DevOps",
    definition: "A methodology that combines software development (Dev) and IT operations (Ops) to shorten development lifecycles and provide continuous delivery with high software quality.",
    category: "technical",
    examples: [
      "Continuous Integration/Deployment",
      "Infrastructure as Code",
      "Automated testing pipelines",
      "Container orchestration"
    ],
    relatedTerms: ["CI/CD", "Automation", "Cloud Computing", "Agile"],
    industries: ["technology", "software development", "IT operations"],
    learnMoreUrl: "https://aws.amazon.com/devops/what-is-devops/"
  }
];

// Helper functions for the terms database
export function getTermById(id: string): JobTerm | undefined {
  return jobTermsDatabase.find(term => term.id === id);
}

export function getTermByName(name: string): JobTerm | undefined {
  return jobTermsDatabase.find(term => 
    term.term.toLowerCase() === name.toLowerCase()
  );
}

export function getTermsByCategory(category: JobTerm['category']): JobTerm[] {
  return jobTermsDatabase.filter(term => term.category === category);
}

export function getTermsByIndustry(industry: string): JobTerm[] {
  return jobTermsDatabase.filter(term => 
    term.industries?.includes(industry.toLowerCase()) || 
    term.industries?.includes('all')
  );
}

export function searchTerms(query: string): JobTerm[] {
  const searchQuery = query.toLowerCase();
  return jobTermsDatabase.filter(term =>
    term.term.toLowerCase().includes(searchQuery) ||
    term.definition.toLowerCase().includes(searchQuery) ||
    term.examples?.some(example => example.toLowerCase().includes(searchQuery)) ||
    term.relatedTerms?.some(related => related.toLowerCase().includes(searchQuery))
  );
}

// Auto-detection function to find terms in text
export function detectTermsInText(text: string): Array<{ term: JobTerm; position: number }> {
  const detectedTerms: Array<{ term: JobTerm; position: number }> = [];
  const textLower = text.toLowerCase();

  jobTermsDatabase.forEach(term => {
    const termLower = term.term.toLowerCase();
    let position = textLower.indexOf(termLower);
    
    while (position !== -1) {
      // Check if it's a whole word match
      const isWholeWord = (
        (position === 0 || !/\w/.test(text[position - 1])) &&
        (position + termLower.length === text.length || !/\w/.test(text[position + termLower.length]))
      );
      
      if (isWholeWord) {
        detectedTerms.push({ term, position });
      }
      
      position = textLower.indexOf(termLower, position + 1);
    }
  });

  // Sort by position and remove duplicates
  return detectedTerms
    .sort((a, b) => a.position - b.position)
    .filter((item, index, arr) => 
      index === 0 || item.position !== arr[index - 1].position
    );
}