import { useEffect } from "react";
import { getRandomMetaDescription, generatePageTitle, generateOGData, BRAND_CONSTANTS } from "./branding";

// SEO utility functions for dynamic meta descriptions and page titles
export class SEOManager {
  private static instance: SEOManager;
  
  static getInstance(): SEOManager {
    if (!SEOManager.instance) {
      SEOManager.instance = new SEOManager();
    }
    return SEOManager.instance;
  }

  // Update document head with SEO meta tags
  updatePageSEO(title: string, description?: string, additionalMeta?: Record<string, string>) {
    if (typeof document === 'undefined') return; // SSR safety

    // Update title
    document.title = generatePageTitle(title);

    // Update or create meta description
    const metaDescription = description || getRandomMetaDescription();
    this.updateMetaTag('description', metaDescription);

    // Update Open Graph tags
    const ogData = generateOGData(title, metaDescription);
    this.updateMetaTag('og:title', ogData.title, 'property');
    this.updateMetaTag('og:description', ogData.description, 'property');
    this.updateMetaTag('og:image', ogData.image, 'property');
    this.updateMetaTag('og:url', ogData.url, 'property');
    this.updateMetaTag('og:site_name', ogData.siteName, 'property');
    this.updateMetaTag('og:type', ogData.type, 'property');

    // Update Twitter Card tags
    this.updateMetaTag('twitter:card', 'summary_large_image', 'name');
    this.updateMetaTag('twitter:title', ogData.title, 'name');
    this.updateMetaTag('twitter:description', ogData.description, 'name');
    this.updateMetaTag('twitter:image', ogData.image, 'name');

    // Update additional meta tags
    if (additionalMeta) {
      Object.entries(additionalMeta).forEach(([key, value]) => {
        this.updateMetaTag(key, value);
      });
    }
  }

  private updateMetaTag(name: string, content: string, attribute: string = 'name') {
    let meta = document.querySelector(`meta[${attribute}="${name}"]`);
    
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute(attribute, name);
      document.head.appendChild(meta);
    }
    
    meta.setAttribute('content', content);
  }
}

// Page-specific SEO configurations
export const PAGE_SEO_CONFIG = {
  landing: {
    title: "AI-Powered Interview Preparation & Career Development",
    description: "Transform your job search with AI-powered interview preparation, resume optimization, and career development tools. Land your dream job faster with PrepPair.me.",
    keywords: "interview preparation, AI career coaching, resume optimization, job search tools, interview practice"
  },
  features: {
    title: "Features - AI Interview Prep & Resume Optimization",
    description: "Discover PrepPair's comprehensive features: AI interview coaching, ATS-optimized resume writing, job tracking, and video practice sessions.",
    keywords: "AI interview coaching, resume optimization, ATS scoring, job tracking, video practice"
  },
  pricing: {
    title: "Pricing Plans - Affordable AI Career Development",
    description: "Choose the perfect PrepPair plan for your career goals. Free tier available with premium AI features for serious job seekers.",
    keywords: "pricing plans, career development subscription, AI interview prep cost, resume optimization pricing"
  },
  dashboard: {
    title: "Dashboard - Your Interview Prep Command Center",
    description: "Access your personalized interview preparation dashboard with AI feedback, resume analysis, and job application tracking.",
    keywords: "interview dashboard, career progress tracking, AI feedback, resume analysis"
  },
  blog: {
    title: "Career Blog - Expert Interview & Job Search Tips",
    description: "Get expert advice on interview preparation, resume writing, and career development from PrepPair's AI-powered insights.",
    keywords: "career blog, interview tips, job search advice, resume writing guide"
  }
};

// Hook for easy SEO management in React components
export function useSEO(pageKey: keyof typeof PAGE_SEO_CONFIG, customDescription?: string) {
  const seoManager = SEOManager.getInstance();
  const config = PAGE_SEO_CONFIG[pageKey];
  
  // Update SEO when component mounts or dependencies change
  useEffect(() => {
    seoManager.updatePageSEO(
      config.title,
      customDescription || config.description,
      {
        keywords: config.keywords,
        'theme-color': '#3b82f6',
        'msapplication-TileColor': '#3b82f6'
      }
    );
  }, [pageKey, customDescription]);
}

export default SEOManager;