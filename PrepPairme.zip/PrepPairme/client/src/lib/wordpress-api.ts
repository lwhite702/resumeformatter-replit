export interface WordPressBlogPost {
  id: number;
  title: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  date: string;
  slug: string;
  link: string;
  featured_media: number;
  featured_media_url?: string;
  categories: number[];
  _embedded?: {
    'wp:featuredmedia'?: Array<{
      source_url: string;
      alt_text: string;
    }>;
  };
}

export interface WordPressApiResponse {
  posts: WordPressBlogPost[];
  total: number;
  totalPages: number;
}

export async function fetchBlogPost(slug: string): Promise<WordPressBlogPost | null> {
  try {
    const response = await fetch('/api/blog-posts');
    
    if (!response.ok) {
      throw new Error(`Blog API error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    const posts = data.posts || [];
    const post = posts.find((p: WordPressBlogPost) => p.slug === slug);
    
    return post || null;
  } catch (error) {
    console.error('Error fetching blog post:', error);
    return null;
  }
}

export async function fetchBlogPosts(categorySlug = 'preppair-me', limit = 3): Promise<WordPressApiResponse> {
  try {
    const response = await fetch('/api/blog-posts');
    
    if (!response.ok) {
      throw new Error(`Blog API error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    const posts = data.posts || [];
    
    // Limit the number of posts returned
    const limitedPosts = posts.slice(0, limit);
    
    return {
      posts: limitedPosts,
      total: data.total || posts.length,
      totalPages: data.totalPages || 1
    };
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    throw error;
  }
}

export function stripHtmlTags(html: string): string {
  return html.replace(/<[^>]*>/g, '').replace(/&[^;]+;/g, ' ').trim();
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}