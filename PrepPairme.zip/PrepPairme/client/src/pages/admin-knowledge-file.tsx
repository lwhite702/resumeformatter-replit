import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AdminNavigation } from "@/components/admin-navigation";
import { useToast } from "@/hooks/use-toast";
import { 
  BookOpen, 
  Edit, 
  Save, 
  History, 
  Download, 
  Upload,
  Eye,
  AlertTriangle
} from "lucide-react";
import ReactMarkdown from 'react-markdown';

interface KnowledgeFile {
  id: number;
  title: string;
  content: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  app: string;
}

interface KnowledgeVersion {
  id: number;
  version: string;
  content: string;
  createdAt: string;
  createdBy: string;
  changeNotes: string;
}

export default function AdminKnowledgeFile() {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState("");
  const [editTitle, setEditTitle] = useState("");
  const [changeNotes, setChangeNotes] = useState("");

  // Fetch current knowledge file
  const { data: knowledgeFile, isLoading } = useQuery({
    queryKey: ['/api/admin/knowledge-file'],
    queryFn: async () => {
      const response = await fetch('/api/admin/knowledge-file');
      if (!response.ok) throw new Error('Failed to fetch knowledge file');
      return response.json();
    }
  });

  // Fetch version history
  const { data: versions } = useQuery({
    queryKey: ['/api/admin/knowledge-file/versions'],
    queryFn: async () => {
      const response = await fetch('/api/admin/knowledge-file/versions');
      if (!response.ok) throw new Error('Failed to fetch versions');
      return response.json();
    }
  });

  // Update knowledge file mutation
  const updateMutation = useMutation({
    mutationFn: async (data: { title: string; content: string; changeNotes: string }) => {
      const response = await fetch('/api/admin/knowledge-file', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to update knowledge file');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/knowledge-file'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/knowledge-file/versions'] });
      setIsEditing(false);
      setChangeNotes("");
      toast({
        title: "Knowledge file updated",
        description: "Changes saved successfully with version control."
      });
    }
  });

  const handleEdit = () => {
    setIsEditing(true);
    setEditTitle(knowledgeFile?.title || "PrepPair.me Knowledge Base");
    setEditContent(knowledgeFile?.content || defaultKnowledgeContent);
  };

  const handleSave = () => {
    if (!changeNotes.trim()) {
      toast({
        title: "Change notes required",
        description: "Please describe what you changed in this version.",
        variant: "destructive"
      });
      return;
    }
    updateMutation.mutate({
      title: editTitle,
      content: editContent,
      changeNotes
    });
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditContent("");
    setEditTitle("");
    setChangeNotes("");
  };

  const defaultKnowledgeContent = `# PrepPair.me Knowledge Base

## Application Overview
PrepPair.me is an AI-powered career development platform that provides interview preparation, resume optimization, and job tracking tools.

### Core Features

#### Interview Preparation
- AI-powered mock interviews
- Industry-specific question databases
- Real-time feedback and scoring
- Video practice sessions with analysis

#### Resume Optimization
- ATS scoring and compatibility checks
- Keyword optimization suggestions
- Professional template library
- Export to multiple formats

#### Job Application Tracking
- Application status monitoring
- Interview scheduling and reminders
- Follow-up email templates
- Analytics and success metrics

#### Career Development Tools
- Career path visualization
- Skill gap analysis
- Industry insights and trends
- Networking opportunity identification

### Pricing Structure

#### Free Plan ($0/month)
- 3 resume optimizations per month
- Basic ATS scoring
- 5 interview practice sessions
- Basic job application tracking
- Community access
- Basic resume templates

#### Pro Monthly ($19/month)
- Unlimited resume optimizations
- Advanced ATS scoring with insights
- Unlimited interview practice
- AI-powered skill highlights
- Job board integrations
- Video interview feedback
- Career path visualization
- Priority support
- Premium templates
- Resume import from external sources
- Thank you note generation
- Industry-specific insights

#### Pro Quarterly ($49/quarter)
- Everything in Pro Monthly
- 3 months of premium access
- Extended analytics history
- Bulk resume processing
- Priority customer support
- Advanced career insights
- Quarterly progress reports
- Best value - Save 18%

### Add-On Services

#### ApplyCaptain Integration ($10/month)
- Automated job application submissions
- Job board integration and sync
- Application status tracking
- Performance analytics
- Available for Pro subscribers only

### Technical Architecture

#### Frontend
- React with TypeScript
- Tailwind CSS for styling
- Clerk for authentication
- Tanstack Query for state management
- Wouter for routing

#### Backend
- Express.js with TypeScript
- PostgreSQL with Drizzle ORM
- Stripe for payment processing
- OpenAI API for AI features
- WordPress API for blog integration

#### Infrastructure
- Deployed on Replit
- PostgreSQL database via Neon
- CDN for static assets
- SSL certificate management
- Auto-scaling capabilities

### Authentication & Security
- Clerk OAuth implementation
- Role-based access control
- Secure API key management
- Data encryption in transit and at rest
- GDPR and CCPA compliance

### API Integrations

#### Third-Party Services
- OpenAI GPT-4 for AI features
- Stripe for billing and subscriptions
- WordPress REST API for blog content
- Clerk for user management
- Job board APIs for application tracking

#### Internal APIs
- Resume analysis and optimization
- Interview question generation
- Career path recommendations
- Skill assessment algorithms
- Analytics and reporting

### Database Schema

#### Users
- Profile information
- Subscription status
- Preferences and settings
- Usage analytics

#### Resumes
- Content and formatting
- ATS scores and feedback
- Version history
- Optimization suggestions

#### Interview Sessions
- Practice session recordings
- Performance metrics
- Feedback and recommendations
- Progress tracking

#### Job Applications
- Application details
- Status updates
- Interview schedules
- Follow-up reminders

### Support & Documentation

#### Customer Support
- In-app help system
- Email support (support@preppair.me)
- Knowledge base articles
- Video tutorials and guides

#### Admin Tools
- User management dashboard
- Subscription monitoring
- Feature flag controls
- Analytics and reporting

### Compliance & Legal

#### Privacy Policy
- Data collection practices
- Cookie usage
- Third-party integrations
- User rights and controls

#### Terms of Service
- Usage guidelines
- Subscription terms
- Refund policies
- Limitation of liability

#### Data Retention
- User data retention periods
- Account deletion procedures
- Backup and recovery policies
- Compliance requirements

### Performance Metrics

#### Key Performance Indicators
- User activation rates
- Subscription conversion rates
- Feature adoption metrics
- Customer satisfaction scores
- Technical performance metrics

#### Success Metrics
- Interview success rates
- Resume ATS score improvements
- Job offer conversion rates
- User engagement levels
- Revenue growth targets

### Development Guidelines

#### Code Standards
- TypeScript for type safety
- ESLint and Prettier for code formatting
- Component-based architecture
- Responsive design principles
- Accessibility best practices

#### Testing Strategy
- Unit tests for core functions
- Integration tests for API endpoints
- End-to-end testing for user flows
- Performance testing and monitoring
- Security testing and audits

### Deployment & Operations

#### Release Process
- Feature branch development
- Code review requirements
- Automated testing pipeline
- Staging environment validation
- Production deployment procedures

#### Monitoring & Alerting
- Application performance monitoring
- Error tracking and logging
- Uptime monitoring
- User analytics tracking
- Security incident response

---

*Last updated: ${new Date().toISOString().split('T')[0]}*
*Version: 1.0.0*
*Maintained by: PrepPair.me Admin Team*`;

  if (!user?.publicMetadata?.role || user.publicMetadata.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Access Denied
            </CardTitle>
            <CardDescription>Admin privileges required.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <AdminNavigation currentPage="Knowledge" />
      
      <div className="lg:pl-72">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Knowledge File Management
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Internal documentation system with version control
              </p>
            </div>

            <Tabs defaultValue="editor" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="editor" className="flex items-center gap-2">
                  <Edit className="h-4 w-4" />
                  Editor
                </TabsTrigger>
                <TabsTrigger value="preview" className="flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  Preview
                </TabsTrigger>
                <TabsTrigger value="versions" className="flex items-center gap-2">
                  <History className="h-4 w-4" />
                  Versions
                </TabsTrigger>
              </TabsList>

              {/* Editor Tab */}
              <TabsContent value="editor" className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <BookOpen className="h-5 w-5" />
                          Knowledge File Editor
                        </CardTitle>
                        <CardDescription>
                          Edit the internal documentation with Markdown support
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        {!isEditing ? (
                          <Button onClick={handleEdit} className="flex items-center gap-2">
                            <Edit className="h-4 w-4" />
                            Edit
                          </Button>
                        ) : (
                          <div className="flex gap-2">
                            <Button variant="outline" onClick={handleCancel}>
                              Cancel
                            </Button>
                            <Button 
                              onClick={handleSave}
                              disabled={updateMutation.isPending}
                              className="flex items-center gap-2"
                            >
                              <Save className="h-4 w-4" />
                              {updateMutation.isPending ? "Saving..." : "Save"}
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {isEditing ? (
                      <>
                        <div>
                          <Label htmlFor="title">Document Title</Label>
                          <Input
                            id="title"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            placeholder="Knowledge file title"
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="content">Content (Markdown)</Label>
                          <Textarea
                            id="content"
                            value={editContent}
                            onChange={(e) => setEditContent(e.target.value)}
                            className="min-h-[500px] font-mono text-sm"
                            placeholder="Write your documentation in Markdown..."
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="notes">Change Notes *</Label>
                          <Input
                            id="notes"
                            value={changeNotes}
                            onChange={(e) => setChangeNotes(e.target.value)}
                            placeholder="Describe what you changed in this version"
                          />
                        </div>
                      </>
                    ) : (
                      <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold">
                            {knowledgeFile?.title || "PrepPair.me Knowledge Base"}
                          </h3>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">
                              v{knowledgeFile?.version || "1.0.0"}
                            </Badge>
                            <Badge variant="secondary">
                              {knowledgeFile?.updatedAt ? 
                                new Date(knowledgeFile.updatedAt).toLocaleDateString() : 
                                new Date().toLocaleDateString()
                              }
                            </Badge>
                          </div>
                        </div>
                        <div className="prose prose-gray dark:prose-invert max-w-none">
                          <ReactMarkdown>
                            {knowledgeFile?.content || defaultKnowledgeContent}
                          </ReactMarkdown>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Preview Tab */}
              <TabsContent value="preview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Live Preview</CardTitle>
                    <CardDescription>
                      How the knowledge file will appear to admin users
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-gray dark:prose-invert max-w-none">
                      <ReactMarkdown>
                        {isEditing ? editContent : (knowledgeFile?.content || defaultKnowledgeContent)}
                      </ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Versions Tab */}
              <TabsContent value="versions" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Version History
                    </CardTitle>
                    <CardDescription>
                      Track changes and restore previous versions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {versions?.versions?.map((version: KnowledgeVersion) => (
                        <div key={version.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">v{version.version}</Badge>
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {new Date(version.createdAt).toLocaleString()}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              by {version.createdBy}
                            </div>
                          </div>
                          <div className="text-sm mb-2">
                            <strong>Changes:</strong> {version.changeNotes}
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="h-3 w-3 mr-1" />
                              Restore
                            </Button>
                          </div>
                        </div>
                      )) || (
                        <div className="text-center py-8 text-gray-500">
                          No version history available
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}