import { useEffect } from "react";
import { useLocation } from "wouter";
import { useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Settings, 
  Users, 
  CreditCard, 
  FileText, 
  BookOpen, 
  LifeBuoy, 
  BarChart3,
  Shield,
  AlertTriangle,
  CheckCircle
} from "lucide-react";

export default function AdminPortal() {
  const [, setLocation] = useLocation();
  const { user, isLoaded } = useUser();

  useEffect(() => {
    // Redirect to admin dashboard by default
    setLocation("/admin/dashboard");
  }, [setLocation]);

  // Check if user has admin role
  const isAdmin = user?.publicMetadata?.role === 'admin' || user?.organizationMemberships?.[0]?.role === 'admin';

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-500" />
              Authentication Required
            </CardTitle>
            <CardDescription>
              Please sign in to access the admin portal.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/api/login")} className="w-full">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Access Denied
            </CardTitle>
            <CardDescription>
              You need admin privileges to access this area.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Current role: {user.publicMetadata?.role || 'user'}
                <br />
                Required role: admin
              </AlertDescription>
            </Alert>
            <Button 
              variant="outline" 
              onClick={() => setLocation("/")} 
              className="w-full mt-4"
            >
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const adminSections = [
    {
      title: "Dashboard",
      description: "System metrics and overview",
      icon: BarChart3,
      href: "/admin/dashboard",
      status: "active"
    },
    {
      title: "User Management",
      description: "Manage users and roles",
      icon: Users,
      href: "/admin/users",
      status: "active"
    },
    {
      title: "Subscriptions",
      description: "Stripe billing and plans",
      icon: CreditCard,
      href: "/admin/subscriptions",
      status: "active"
    },
    {
      title: "Blog Management",
      description: "WordPress content sync",
      icon: FileText,
      href: "/admin/content/blog",
      status: "active"
    },
    {
      title: "Legal Content",
      description: "Policy management",
      icon: BookOpen,
      href: "/admin/content/legal",
      status: "active"
    },
    {
      title: "Knowledge Base",
      description: "Internal documentation",
      icon: BookOpen,
      href: "/admin/content/knowledge-file",
      status: "active"
    },
    {
      title: "Support Tickets",
      description: "Customer feedback",
      icon: LifeBuoy,
      href: "/admin/support/tickets",
      status: "beta"
    },
    {
      title: "Settings",
      description: "Feature flags and config",
      icon: Settings,
      href: "/admin/settings",
      status: "active"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Admin Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                PrepPair.me Admin Portal
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Internal management system
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" />
                Production
              </Badge>
              <Badge variant="secondary">
                Admin: {user.firstName || user.emailAddresses[0]?.emailAddress}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Sections Grid */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {adminSections.map((section) => {
            const Icon = section.icon;
            return (
              <Card 
                key={section.href}
                className="cursor-pointer hover:shadow-lg transition-all duration-200 transform hover:scale-105"
                onClick={() => setLocation(section.href)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <Icon className="h-8 w-8 text-blue-600" />
                    <Badge 
                      variant={section.status === 'active' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {section.status}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg">{section.title}</CardTitle>
                  <CardDescription className="text-sm">
                    {section.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full text-sm">
                    Access {section.title}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Stats */}
        <div className="mt-12">
          <h2 className="text-xl font-semibold mb-6">Quick Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,247</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Active Subscriptions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">289</div>
                <p className="text-xs text-muted-foreground">$5,491 MRR</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">API Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45.2K</div>
                <p className="text-xs text-muted-foreground">Last 24 hours</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">System Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <div className="text-2xl font-bold text-green-600">99.9%</div>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
                <p className="text-xs text-muted-foreground">Uptime this week</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}