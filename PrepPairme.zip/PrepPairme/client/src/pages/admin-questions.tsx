import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Plus, 
  Upload, 
  FileText, 
  Star, 
  Highlighter, 
  Search, 
  Edit, 
  Trash2,
  Eye,
  EyeOff
} from "lucide-react";
import { Question } from "@shared/schema";

const questionSchema = z.object({
  category: z.string().min(1, "Category is required"),
  question: z.string().min(1, "Question is required"),
  sampleAnswer: z.string().optional(),
  explanation: z.string().optional(),
  tags: z.array(z.string()).optional(),
  difficulty: z.enum(["Easy", "Medium", "Hard"]),
  industry: z.string().optional(),
  isHighlighted: z.boolean().default(false),
  isFeatured: z.boolean().default(false),
});

type QuestionFormData = z.infer<typeof questionSchema>;

export default function AdminQuestions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [jsonData, setJsonData] = useState("");
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<QuestionFormData>({
    resolver: zodResolver(questionSchema),
    defaultValues: {
      category: "",
      question: "",
      sampleAnswer: "",
      explanation: "",
      tags: [],
      difficulty: "Medium",
      industry: "",
      isHighlighted: false,
      isFeatured: false,
    },
  });

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ["/api/admin/questions"],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/questions/categories"],
  });

  const createQuestionMutation = useMutation({
    mutationFn: async (questionData: QuestionFormData) => {
      return await apiRequest("POST", "/api/admin/questions", questionData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Question created successfully",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/admin/questions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create question",
        variant: "destructive",
      });
    },
  });

  const updateQuestionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<QuestionFormData> }) => {
      return await apiRequest("PATCH", `/api/admin/questions/${id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Question updated successfully",
      });
      setEditingQuestion(null);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/questions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update question",
        variant: "destructive",
      });
    },
  });

  const deleteQuestionMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/admin/questions/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Question deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/questions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete question",
        variant: "destructive",
      });
    },
  });

  const bulkImportMutation = useMutation({
    mutationFn: async (data: { questions: QuestionFormData[] }) => {
      return await apiRequest("POST", "/api/admin/questions/bulk", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Questions imported successfully",
      });
      setCsvFile(null);
      setJsonData("");
      queryClient.invalidateQueries({ queryKey: ["/api/admin/questions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to import questions",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: QuestionFormData) => {
    const tags = Array.isArray(data.tags) ? data.tags : [];
    createQuestionMutation.mutate({ ...data, tags });
  };

  const handleCsvUpload = async () => {
    if (!csvFile) return;

    const text = await csvFile.text();
    const lines = text.split("\n");
    const headers = lines[0].split(",").map(h => h.trim());
    
    const questions: QuestionFormData[] = lines.slice(1)
      .filter(line => line.trim())
      .map(line => {
        const values = line.split(",").map(v => v.trim());
        const question: any = {};
        
        headers.forEach((header, index) => {
          const value = values[index] || "";
          switch (header.toLowerCase()) {
            case "category":
              question.category = value;
              break;
            case "question":
              question.question = value;
              break;
            case "sampleanswer":
            case "sample_answer":
              question.sampleAnswer = value;
              break;
            case "explanation":
              question.explanation = value;
              break;
            case "tags":
              question.tags = value ? value.split(";").map(t => t.trim()) : [];
              break;
            case "difficulty":
              question.difficulty = value || "Medium";
              break;
            case "industry":
              question.industry = value;
              break;
            case "ishighlighted":
            case "is_highlighted":
              question.isHighlighted = value.toLowerCase() === "true";
              break;
            case "isfeatured":
            case "is_featured":
              question.isFeatured = value.toLowerCase() === "true";
              break;
          }
        });
        
        return question;
      });

    bulkImportMutation.mutate({ questions });
  };

  const handleJsonImport = () => {
    try {
      const questions = JSON.parse(jsonData);
      if (!Array.isArray(questions)) {
        throw new Error("JSON must be an array of questions");
      }
      bulkImportMutation.mutate({ questions });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Invalid JSON format",
        variant: "destructive",
      });
    }
  };

  const toggleHighlight = (question: Question) => {
    updateQuestionMutation.mutate({
      id: question.id,
      data: { isHighlighted: !question.isHighlighted },
    });
  };

  const toggleFeatured = (question: Question) => {
    updateQuestionMutation.mutate({
      id: question.id,
      data: { isFeatured: !question.isFeatured },
    });
  };

  const toggleActive = (question: Question) => {
    updateQuestionMutation.mutate({
      id: question.id,
      data: { isHighlighted: !question.isHighlighted },
    });
  };

  const filteredQuestions = questions.filter((question: Question) => {
    const matchesSearch = question.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         question.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || question.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === "all" || question.difficulty === selectedDifficulty;
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Question Management</h1>
          <p className="text-muted-foreground">
            Add, edit, and manage interview questions for the database
          </p>
        </div>
      </div>

      <Tabs defaultValue="add-form" className="space-y-6">
        <TabsList>
          <TabsTrigger value="add-form">Add Question</TabsTrigger>
          <TabsTrigger value="bulk-import">Bulk Import</TabsTrigger>
          <TabsTrigger value="manage">Manage Questions</TabsTrigger>
        </TabsList>

        <TabsContent value="add-form">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Add New Question
              </CardTitle>
              <CardDescription>
                Create a new interview question for the database
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Behavioral, Technical" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="difficulty"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Difficulty</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select difficulty" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Easy">Easy</SelectItem>
                              <SelectItem value="Medium">Medium</SelectItem>
                              <SelectItem value="Hard">Hard</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="question"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Question</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter the interview question"
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="sampleAnswer"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sample Answer (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Provide a sample answer"
                            className="min-h-[120px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="explanation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Explanation (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Explain what makes a good answer"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Industry (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Technology, Finance" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-2">
                      <Label>Tags (comma-separated)</Label>
                      <Input 
                        placeholder="e.g., leadership, problem-solving"
                        onChange={(e) => {
                          const tags = e.target.value.split(",").map(tag => tag.trim());
                          form.setValue("tags", tags);
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex gap-6">
                    <FormField
                      control={form.control}
                      name="isHighlighted"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="flex items-center gap-2">
                            <Highlighter className="h-4 w-4" />
                            Highlight Question
                          </FormLabel>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="isFeatured"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="flex items-center gap-2">
                            <Star className="h-4 w-4" />
                            Feature Question
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={createQuestionMutation.isPending}
                  >
                    {createQuestionMutation.isPending ? "Creating..." : "Create Question"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk-import">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  CSV Import
                </CardTitle>
                <CardDescription>
                  Upload a CSV file with questions. Expected columns: category, question, sampleAnswer, explanation, tags, difficulty, industry, isHighlighted, isFeatured
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="csv-file">CSV File</Label>
                  <Input
                    id="csv-file"
                    type="file"
                    accept=".csv"
                    onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                  />
                </div>
                <Button 
                  onClick={handleCsvUpload}
                  disabled={!csvFile || bulkImportMutation.isPending}
                  className="w-full"
                >
                  {bulkImportMutation.isPending ? "Importing..." : "Import CSV"}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  JSON Import
                </CardTitle>
                <CardDescription>
                  Paste JSON array of questions with the required fields
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="json-data">JSON Data</Label>
                  <Textarea
                    id="json-data"
                    placeholder='[{"category": "Behavioral", "question": "Tell me about yourself", "difficulty": "Easy"}]'
                    value={jsonData}
                    onChange={(e) => setJsonData(e.target.value)}
                    className="min-h-[150px] font-mono text-sm"
                  />
                </div>
                <Button 
                  onClick={handleJsonImport}
                  disabled={!jsonData || bulkImportMutation.isPending}
                  className="w-full"
                >
                  {bulkImportMutation.isPending ? "Importing..." : "Import JSON"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="manage">
          <Card>
            <CardHeader>
              <CardTitle>Manage Questions</CardTitle>
              <CardDescription>
                View, edit, and manage existing questions in the database
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Search and Filters */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search questions..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category: any) => (
                      <SelectItem key={category.name} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="Easy">Easy</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Questions List */}
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center py-8">Loading questions...</div>
                ) : filteredQuestions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No questions found matching your criteria
                  </div>
                ) : (
                  filteredQuestions.map((question: Question) => (
                    <div key={question.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">{question.category}</Badge>
                            <Badge variant={
                              question.difficulty === "Easy" ? "default" :
                              question.difficulty === "Medium" ? "secondary" : "destructive"
                            }>
                              {question.difficulty}
                            </Badge>
                            {question.isHighlighted && (
                              <Badge className="bg-yellow-100 text-yellow-800">
                                <Highlighter className="h-3 w-3 mr-1" />
                                Highlighted
                              </Badge>
                            )}
                            {question.isFeatured && (
                              <Badge className="bg-blue-100 text-blue-800">
                                <Star className="h-3 w-3 mr-1" />
                                Featured
                              </Badge>
                            )}
                            {!question.isActive && (
                              <Badge variant="destructive">
                                <EyeOff className="h-3 w-3 mr-1" />
                                Hidden
                              </Badge>
                            )}
                          </div>
                          <p className="font-medium mb-2">{question.question}</p>
                          {question.industry && (
                            <p className="text-sm text-muted-foreground">
                              Industry: {question.industry}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleActive(question)}
                          >
                            {question.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleHighlight(question)}
                            className={question.isHighlighted ? "text-yellow-600" : ""}
                          >
                            <Highlighter className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleFeatured(question)}
                            className={question.isFeatured ? "text-blue-600" : ""}
                          >
                            <Star className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingQuestion(question)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteQuestionMutation.mutate(question.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}