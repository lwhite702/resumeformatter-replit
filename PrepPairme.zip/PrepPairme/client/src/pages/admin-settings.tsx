import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AdminNavigation } from "@/components/admin-navigation";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings, 
  Flag, 
  CreditCard, 
  Plus, 
  Edit, 
  Save, 
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  DollarSign
} from "lucide-react";

interface FeatureFlag {
  id: number;
  app: string;
  name: string;
  description: string;
  enabled: boolean;
  requiredPlan: string;
  createdAt: string;
  updatedAt: string;
}

interface BillingPlan {
  id: string;
  name: string;
  displayName: string;
  price: number;
  interval: string;
  features: string[];
  stripeProductId: string;
  stripePriceId: string;
  metadata: Record<string, any>;
  active: boolean;
}

export default function AdminSettings() {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newFlagOpen, setNewFlagOpen] = useState(false);
  const [newFlag, setNewFlag] = useState({
    name: "",
    description: "",
    enabled: false,
    requiredPlan: "free"
  });

  // Fetch feature flags
  const { data: featureFlags, isLoading: flagsLoading } = useQuery({
    queryKey: ['/api/admin/feature-flags'],
    queryFn: async () => {
      const response = await fetch('/api/admin/feature-flags');
      if (!response.ok) throw new Error('Failed to fetch feature flags');
      return response.json();
    }
  });

  // Fetch billing plans from Stripe
  const { data: billingPlans, isLoading: plansLoading } = useQuery({
    queryKey: ['/api/admin/billing-plans'],
    queryFn: async () => {
      const response = await fetch('/api/admin/billing-plans');
      if (!response.ok) throw new Error('Failed to fetch billing plans');
      return response.json();
    }
  });

  // Toggle feature flag mutation
  const toggleFlagMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => {
      const response = await fetch(`/api/admin/feature-flags/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled })
      });
      if (!response.ok) throw new Error('Failed to update feature flag');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/feature-flags'] });
      toast({
        title: "Feature flag updated",
        description: "Changes are now live across the application."
      });
    }
  });

  // Create feature flag mutation
  const createFlagMutation = useMutation({
    mutationFn: async (flagData: any) => {
      const response = await fetch('/api/admin/feature-flags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...flagData, app: 'PrepPair.me' })
      });
      if (!response.ok) throw new Error('Failed to create feature flag');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/feature-flags'] });
      setNewFlagOpen(false);
      setNewFlag({ name: "", description: "", enabled: false, requiredPlan: "free" });
      toast({
        title: "Feature flag created",
        description: "New feature flag is now available."
      });
    }
  });

  // Sync Stripe plans mutation
  const syncStripeDataMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/admin/sync-stripe', {
        method: 'POST'
      });
      if (!response.ok) throw new Error('Failed to sync Stripe data');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/billing-plans'] });
      toast({
        title: "Stripe data synced",
        description: "Latest pricing and plan data updated."
      });
    }
  });

  const handleToggleFlag = (id: number, enabled: boolean) => {
    toggleFlagMutation.mutate({ id, enabled });
  };

  const handleCreateFlag = () => {
    if (!newFlag.name || !newFlag.description) {
      toast({
        title: "Validation error",
        description: "Name and description are required.",
        variant: "destructive"
      });
      return;
    }
    createFlagMutation.mutate(newFlag);
  };

  if (!user?.publicMetadata?.role || user.publicMetadata.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Access Denied
            </CardTitle>
            <CardDescription>Admin privileges required.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <AdminNavigation currentPage="Settings" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Admin Settings
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Manage feature flags, billing plans, and system configuration
            </p>
          </div>

          <Tabs defaultValue="flags" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="flags" className="flex items-center gap-2">
                <Flag className="h-4 w-4" />
                Feature Flags
              </TabsTrigger>
              <TabsTrigger value="billing" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Billing Plans
              </TabsTrigger>
            </TabsList>

            {/* Feature Flags Tab */}
            <TabsContent value="flags" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Flag className="h-5 w-5" />
                        Feature Flags
                      </CardTitle>
                      <CardDescription>
                        Control app features and functionality in real-time
                      </CardDescription>
                    </div>
                    <Dialog open={newFlagOpen} onOpenChange={setNewFlagOpen}>
                      <DialogTrigger asChild>
                        <Button className="flex items-center gap-2">
                          <Plus className="h-4 w-4" />
                          Add Flag
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Create Feature Flag</DialogTitle>
                          <DialogDescription>
                            Add a new feature flag to control functionality
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="flag-name">Name</Label>
                            <Input
                              id="flag-name"
                              value={newFlag.name}
                              onChange={(e) => setNewFlag({...newFlag, name: e.target.value})}
                              placeholder="e.g., ai_resume_optimization"
                            />
                          </div>
                          <div>
                            <Label htmlFor="flag-description">Description</Label>
                            <Textarea
                              id="flag-description"
                              value={newFlag.description}
                              onChange={(e) => setNewFlag({...newFlag, description: e.target.value})}
                              placeholder="What does this feature do?"
                            />
                          </div>
                          <div>
                            <Label htmlFor="flag-plan">Required Plan</Label>
                            <Select 
                              value={newFlag.requiredPlan} 
                              onValueChange={(value) => setNewFlag({...newFlag, requiredPlan: value})}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="free">Free</SelectItem>
                                <SelectItem value="pro_monthly">Pro Monthly</SelectItem>
                                <SelectItem value="pro_quarterly">Pro Quarterly</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch
                              id="flag-enabled"
                              checked={newFlag.enabled}
                              onCheckedChange={(checked) => setNewFlag({...newFlag, enabled: checked})}
                            />
                            <Label htmlFor="flag-enabled">Enabled by default</Label>
                          </div>
                          <Button 
                            onClick={handleCreateFlag} 
                            disabled={createFlagMutation.isPending}
                            className="w-full"
                          >
                            {createFlagMutation.isPending ? "Creating..." : "Create Flag"}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  {flagsLoading ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-16 bg-gray-100 dark:bg-gray-800 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {featureFlags?.flags?.map((flag: FeatureFlag) => (
                        <div key={flag.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold">{flag.name}</h3>
                              <Badge variant={flag.requiredPlan === 'free' ? 'secondary' : 'default'}>
                                {flag.requiredPlan}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{flag.description}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              Updated: {new Date(flag.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-3">
                            <Switch
                              checked={flag.enabled}
                              onCheckedChange={(checked) => handleToggleFlag(flag.id, checked)}
                              disabled={toggleFlagMutation.isPending}
                            />
                            <Badge variant={flag.enabled ? 'default' : 'secondary'}>
                              {flag.enabled ? 'ON' : 'OFF'}
                            </Badge>
                          </div>
                        </div>
                      )) || (
                        <div className="text-center py-8 text-gray-500">
                          No feature flags configured yet
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Billing Plans Tab */}
            <TabsContent value="billing" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5" />
                        Billing Plans
                      </CardTitle>
                      <CardDescription>
                        Manage Stripe pricing and plan configurations
                      </CardDescription>
                    </div>
                    <Button 
                      onClick={() => syncStripeDataMutation.mutate()}
                      disabled={syncStripeDataMutation.isPending}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <RefreshCw className={`h-4 w-4 ${syncStripeDataMutation.isPending ? 'animate-spin' : ''}`} />
                      Sync Stripe
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {plansLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-48 bg-gray-100 dark:bg-gray-800 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {billingPlans?.plans?.map((plan: BillingPlan) => (
                        <Card key={plan.id} className={`${plan.name === 'pro_monthly' ? 'ring-2 ring-blue-500' : ''}`}>
                          <CardHeader>
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-lg">{plan.displayName}</CardTitle>
                              <Badge variant={plan.active ? 'default' : 'secondary'}>
                                {plan.active ? 'Active' : 'Inactive'}
                              </Badge>
                            </div>
                            <div className="text-2xl font-bold">
                              ${plan.price}
                              <span className="text-sm font-normal text-gray-500">
                                /{plan.interval}
                              </span>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <h4 className="font-semibold text-sm">Features:</h4>
                              <ul className="text-sm space-y-1">
                                {plan.features.map((feature, index) => (
                                  <li key={index} className="flex items-center gap-2">
                                    <CheckCircle className="h-3 w-3 text-green-500" />
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <div className="mt-4 pt-4 border-t text-xs text-gray-500">
                              <p>Stripe ID: {plan.stripePriceId}</p>
                              <p>Product: {plan.stripeProductId}</p>
                            </div>
                          </CardContent>
                        </Card>
                      )) || (
                        <div className="col-span-3 text-center py-8 text-gray-500">
                          No billing plans configured
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}