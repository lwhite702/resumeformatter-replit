import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Brain, Zap, Settings, TrendingUp, Plus, Target } from "lucide-react";
import { TooltipHelp, tooltips } from "@/components/tooltip-help";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AIFineTuning() {
  const [selectedIndustry, setSelectedIndustry] = useState("");
  const [trainingPrompt, setTrainingPrompt] = useState("");
  const [trainingCompletion, setTrainingCompletion] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: industries = [] } = useQuery({
    queryKey: ["/api/ai-tuning/industries"],
  });

  const { data: trainingData = [] } = useQuery({
    queryKey: ["/api/ai-tuning/training-data"],
  });

  const { data: metrics = {} } = useQuery({
    queryKey: ["/api/ai-tuning/metrics"],
  });

  const addTrainingMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/ai-tuning/training-examples", data);
    },
    onSuccess: () => {
      toast({
        title: "Training Example Added",
        description: "Your training example has been added to the dataset.",
      });
      setTrainingPrompt("");
      setTrainingCompletion("");
      queryClient.invalidateQueries({ queryKey: ["/api/ai-tuning/training-data"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add training example.",
        variant: "destructive",
      });
    },
  });

  const generateContentMutation = useMutation({
    mutationFn: async (industry: string) => {
      return await apiRequest("POST", "/api/ai-tuning/generate-content", { industry });
    },
    onSuccess: () => {
      toast({
        title: "Content Generated",
        description: "Industry-specific content has been generated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ai-tuning/training-data"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate industry content.",
        variant: "destructive",
      });
    },
  });

  const handleAddTrainingExample = () => {
    if (!selectedIndustry || !trainingPrompt || !trainingCompletion) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields before adding the training example.",
        variant: "destructive",
      });
      return;
    }

    addTrainingMutation.mutate({
      industry: selectedIndustry,
      prompt: trainingPrompt,
      completion: trainingCompletion,
      category: "custom"
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">AI Fine-tuning</h1>
          <div className="flex items-center gap-2 mt-2">
            <p className="text-muted-foreground">
              Customize AI responses for industry-specific interview preparation
            </p>
            <TooltipHelp content={tooltips.aiFineTuning} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Brain className="h-3 w-3" />
            {industries.length} Industries
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="training">Training Data</TabsTrigger>
          <TabsTrigger value="generate">Generate Content</TabsTrigger>
          <TabsTrigger value="settings">Model Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Training Examples</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{trainingData.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Industry-specific examples
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Model Accuracy</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics.accuracy || 85}%</div>
                <p className="text-xs text-muted-foreground">
                  Current performance score
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Industries</CardTitle>
                <Settings className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{industries.length || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Supported sectors
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Industry Performance</CardTitle>
              <CardDescription>
                Model performance across different industries
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {industries.slice(0, 5).map((industry: any) => (
                <div key={industry} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{industry}</span>
                    <span className="text-sm text-muted-foreground">
                      {Math.floor(Math.random() * 20) + 80}%
                    </span>
                  </div>
                  <Progress 
                    value={Math.floor(Math.random() * 20) + 80} 
                    className="h-2"
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Add Training Example</CardTitle>
              <CardDescription>
                Create custom training data to improve AI responses for specific industries
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Industry</label>
                  <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map((industry: string) => (
                        <SelectItem key={industry} value={industry}>
                          {industry}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Training Prompt</label>
                <Textarea
                  placeholder="Enter the question or scenario prompt..."
                  value={trainingPrompt}
                  onChange={(e) => setTrainingPrompt(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Expected Response</label>
                <Textarea
                  placeholder="Enter the ideal AI response for this prompt..."
                  value={trainingCompletion}
                  onChange={(e) => setTrainingCompletion(e.target.value)}
                  rows={4}
                />
              </div>

              <Button 
                onClick={handleAddTrainingExample}
                disabled={addTrainingMutation.isPending}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                {addTrainingMutation.isPending ? "Adding..." : "Add Training Example"}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Training Data</CardTitle>
              <CardDescription>
                Review and manage existing training examples
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {trainingData.length === 0 ? (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Training Data</h3>
                    <p className="text-muted-foreground">
                      Add training examples to customize AI responses for specific industries
                    </p>
                  </div>
                ) : (
                  trainingData.map((example: any, index: number) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline">{example.industry}</Badge>
                        <Badge variant="secondary">{example.category}</Badge>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <span className="text-sm font-medium">Prompt: </span>
                          <span className="text-sm">{example.prompt}</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Response: </span>
                          <span className="text-sm text-muted-foreground">{example.completion}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="generate" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Generate Industry Content</CardTitle>
              <CardDescription>
                Automatically generate training data and questions for specific industries
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {industries.map((industry: string) => (
                  <Card key={industry}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{industry}</h4>
                          <p className="text-sm text-muted-foreground">
                            Generate tailored content
                          </p>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => generateContentMutation.mutate(industry)}
                          disabled={generateContentMutation.isPending}
                        >
                          <Zap className="h-3 w-3 mr-1" />
                          Generate
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Model Configuration</CardTitle>
              <CardDescription>
                Adjust AI model parameters and behavior settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Response Temperature</label>
                  <Input type="number" placeholder="0.7" min="0" max="2" step="0.1" />
                  <p className="text-xs text-muted-foreground">
                    Controls randomness in responses (0 = deterministic, 2 = very creative)
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Max Tokens</label>
                  <Input type="number" placeholder="500" min="50" max="4000" />
                  <p className="text-xs text-muted-foreground">
                    Maximum length of AI responses
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Training Frequency</label>
                  <Select defaultValue="daily">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button className="w-full">
                <Settings className="h-4 w-4 mr-2" />
                Update Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}