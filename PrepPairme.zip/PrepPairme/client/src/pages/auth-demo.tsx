import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useApiClient } from '@/lib/apiClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

export default function AuthDemo() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [testResults, setTestResults] = useState<Record<string, any>>({});

  const userPlan = user?.publicMetadata?.plan || 'free';
  const userRole = user?.publicMetadata?.role || 'user';

  // Test API endpoints with different permission levels
  const testEndpoints = [
    { name: 'User Profile', endpoint: '/api/user/profile', method: 'GET', requiredPlan: 'free' },
    { name: 'Basic Interview Questions', endpoint: '/api/interview/questions/basic', method: 'GET', requiredPlan: 'free' },
    { name: 'Advanced Interview Questions', endpoint: '/api/interview/questions/advanced', method: 'GET', requiredPlan: 'pro' },
    { name: 'Resume Optimization', endpoint: '/api/resume/optimize', method: 'POST', requiredPlan: 'pro', body: { resumeText: 'Sample resume text' } },
    { name: 'Job Tracking', endpoint: '/api/jobs/tracking', method: 'GET', requiredPlan: 'pro' },
    { name: 'Video Sessions', endpoint: '/api/video/sessions', method: 'GET', requiredPlan: 'pro' },
    { name: 'AI Fine-tuning', endpoint: '/api/ai/fine-tune', method: 'POST', requiredPlan: 'career_coach', body: { industry: 'tech', jobRole: 'developer' } },
    { name: 'Career Visualization', endpoint: '/api/career/visualization', method: 'GET', requiredPlan: 'career_coach' },
    { name: 'Job Board Integrations', endpoint: '/api/integrations/job-boards', method: 'GET', requiredPlan: 'career_coach' },
    { name: 'Admin Dashboard', endpoint: '/api/admin/dashboard', method: 'GET', requiredRole: 'admin' },
    { name: 'Admin Users', endpoint: '/api/admin/users', method: 'GET', requiredRole: 'admin' },
  ];

  const { makeRequest } = useApiClient();

  const testEndpoint = async (endpoint: any) => {
    try {
      let result;
      if (endpoint.method === 'GET') {
        result = await makeRequest(endpoint.endpoint);
      } else {
        result = await makeRequest(endpoint.endpoint, {
          method: endpoint.method,
          body: JSON.stringify(endpoint.body),
        });
      }
      
      setTestResults(prev => ({
        ...prev,
        [endpoint.name]: { success: true, data: result, error: null }
      }));
      
      toast({
        title: "Success",
        description: `${endpoint.name} test passed`,
      });
    } catch (error: any) {
      setTestResults(prev => ({
        ...prev,
        [endpoint.name]: { success: false, data: null, error: error.message }
      }));
      
      toast({
        title: "Test Failed",
        description: `${endpoint.name}: ${error.message}`,
        variant: "destructive",
      });
    }
  };

  const testAllEndpoints = async () => {
    for (const endpoint of testEndpoints) {
      await testEndpoint(endpoint);
      // Add small delay between requests
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };

  const getExpectedResult = (endpoint: any) => {
    if (endpoint.requiredRole === 'admin' && userRole !== 'admin') {
      return 'Should fail - Admin required';
    }
    
    const planHierarchy = { 'free': 0, 'pro': 1, 'career_coach': 2 };
    const userPlanLevel = planHierarchy[userPlan as keyof typeof planHierarchy] || 0;
    const requiredPlanLevel = planHierarchy[endpoint.requiredPlan as keyof typeof planHierarchy] || 0;
    
    if (userPlanLevel < requiredPlanLevel) {
      return `Should fail - ${endpoint.requiredPlan} plan required`;
    }
    
    return 'Should succeed';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please sign in to test the authentication system</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = '/'} className="w-full">
              Go to Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">Authentication & Authorization Demo</h1>
        <p className="text-muted-foreground">
          Test various API endpoints to verify proper authentication and plan-based access control.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current User Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm font-medium">User ID</p>
              <p className="text-xs text-muted-foreground">{user?.id}</p>
            </div>
            <div>
              <p className="text-sm font-medium">Email</p>
              <p className="text-xs text-muted-foreground">{user?.emailAddresses?.[0]?.emailAddress || 'N/A'}</p>
            </div>
            <div>
              <p className="text-sm font-medium">Plan</p>
              <Badge variant={userPlan === 'free' ? 'secondary' : userPlan === 'pro' ? 'default' : 'destructive'}>
                {userPlan}
              </Badge>
            </div>
            <div>
              <p className="text-sm font-medium">Role</p>
              <Badge variant={userRole === 'admin' ? 'destructive' : 'outline'}>
                {userRole}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="endpoints" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="endpoints">API Endpoints Test</TabsTrigger>
          <TabsTrigger value="results">Test Results</TabsTrigger>
        </TabsList>
        
        <TabsContent value="endpoints" className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={testAllEndpoints}>Test All Endpoints</Button>
            <Button variant="outline" onClick={() => setTestResults({})}>Clear Results</Button>
          </div>
          
          <div className="grid gap-4">
            {testEndpoints.map((endpoint) => (
              <Card key={endpoint.name}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{endpoint.name}</CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="outline">{endpoint.method}</Badge>
                      {endpoint.requiredPlan && (
                        <Badge variant="secondary">{endpoint.requiredPlan}+</Badge>
                      )}
                      {endpoint.requiredRole && (
                        <Badge variant="destructive">{endpoint.requiredRole}</Badge>
                      )}
                    </div>
                  </div>
                  <CardDescription>
                    {endpoint.endpoint} • {getExpectedResult(endpoint)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() => testEndpoint(endpoint)}
                    size="sm"
                    disabled={Object.keys(testResults).length > 0 && !testResults[endpoint.name]}
                  >
                    Test Endpoint
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="results" className="space-y-4">
          {Object.keys(testResults).length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground">No test results yet. Run some endpoint tests to see results here.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {Object.entries(testResults).map(([name, result]) => (
                <Card key={name}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{name}</CardTitle>
                      <Badge variant={result.success ? 'default' : 'destructive'}>
                        {result.success ? 'Success' : 'Failed'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {result.success ? (
                      <div>
                        <p className="text-sm font-medium mb-2">Response Data:</p>
                        <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-40">
                          {JSON.stringify(result.data, null, 2)}
                        </pre>
                      </div>
                    ) : (
                      <div>
                        <p className="text-sm font-medium mb-2">Error:</p>
                        <p className="text-sm text-destructive bg-destructive/10 p-3 rounded">
                          {result.error}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}