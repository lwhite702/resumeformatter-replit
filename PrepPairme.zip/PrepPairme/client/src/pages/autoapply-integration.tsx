import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ExternalLink, CheckCircle, AlertCircle, RefreshCw, BarChart3, Bell } from 'lucide-react';
import { useApiClient } from '@/lib/apiClient';

interface AutoApplyApplication {
  externalId: string;
  jobTitle: string;
  company: string;
  location?: string;
  status: string;
  appliedDate: string;
  source: string;
  resumeUsed: string;
  coverLetter: string;
}

interface SyncResult {
  success: boolean;
  applicationsFound: number;
  prepPairSync: {
    success: boolean;
    message: string;
  };
  message: string;
  integration: string;
}

interface IntegrationStatus {
  enabled: boolean;
  plan: string;
  lastSync: string;
  applicationsCount: number;
  integrationActive: boolean;
  addonPrice?: string;
  regularPrice?: string;
  discount?: string;
}

export default function AutoApplyIntegration() {
  const { makeRequest } = useApiClient();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isEnabling, setIsEnabling] = useState(false);
  const [isLoadingAnalytics, setIsLoadingAnalytics] = useState(false);
  const [integrationStatus, setIntegrationStatus] = useState<IntegrationStatus | null>(null);
  const [syncResults, setSyncResults] = useState<SyncResult | null>(null);
  const [analytics, setAnalytics] = useState<any>(null);

  useEffect(() => {
    checkIntegrationStatus();
  }, []);

  const checkIntegrationStatus = async () => {
    setIsLoading(true);

    try {
      const response = await makeRequest('/api/integrations/autoapply/status');
      
      setIntegrationStatus(response);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to check integration status';
      toast({
        title: "Status Check Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const enableIntegration = async () => {
    setIsEnabling(true);

    try {
      const response = await makeRequest('/api/integrations/autoapply/enable', {
        method: 'POST',
      });

      if (response.success) {
        toast({
          title: "Integration Enabled",
          description: response.message,
        });
        await checkIntegrationStatus();
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to enable integration';
      toast({
        title: "Enable Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsEnabling(false);
    }
  };

  const syncApplications = async () => {
    setIsSyncing(true);
    setSyncResults(null);

    try {
      const response = await makeRequest('/api/integrations/autoapply/sync', {
        method: 'POST',
      });

      setSyncResults(response);
      
      if (response.success) {
        toast({
          title: "Sync Successful",
          description: response.message,
        });
        await checkIntegrationStatus();
      } else {
        toast({
          title: "Sync Failed",
          description: response.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Sync failed';
      toast({
        title: "Sync Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const loadAnalytics = async () => {
    setIsLoadingAnalytics(true);

    try {
      const response = await makeRequest('/api/analytics/preppair');
      setAnalytics(response);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to load analytics';
      toast({
        title: "Analytics Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoadingAnalytics(false);
    }
  };

  const createReminder = async () => {
    try {
      const response = await makeRequest('/api/reminders/create', {
        method: 'POST',
        body: JSON.stringify({
          type: 'follow_up',
          message: 'Follow up on recent job applications',
          scheduledFor: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours from now
        }),
      });

      if (response.success) {
        toast({
          title: "Reminder Created",
          description: "Follow-up reminder scheduled for tomorrow",
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create reminder';
      toast({
        title: "Reminder Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              ApplyCaptain Integration
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Premium job application automation from ApplyCaptain.com
            </p>
            <div className="mt-4">
              <Badge variant="secondary" className="text-sm px-3 py-1">
                Add-on Feature: $10/month for Pro Members (50% off regular price)
              </Badge>
            </div>
          </div>

          {/* Integration Status Card */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {integrationStatus?.integrationActive ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-yellow-500" />
                )}
                Integration Status
              </CardTitle>
              <CardDescription>
                ApplyCaptain integration - premium add-on feature for Pro members
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Checking integration status...</span>
                </div>
              ) : integrationStatus ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Status:</span>
                    <Badge variant={integrationStatus.enabled ? "default" : "secondary"}>
                      {integrationStatus.enabled ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Plan:</span>
                    <div className="flex gap-2">
                      <Badge variant="outline">{integrationStatus.plan}</Badge>
                      {integrationStatus.enabled && (
                        <Badge variant="default" className="bg-green-600">
                          ApplyCaptain Active
                        </Badge>
                      )}
                    </div>
                  </div>
                  {integrationStatus.addonPrice && (
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Add-on Price:</span>
                      <div className="text-right">
                        <span className="font-mono text-green-600">{integrationStatus.addonPrice}</span>
                        <div className="text-xs text-gray-500">
                          Regular: {integrationStatus.regularPrice}
                        </div>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Applications Tracked:</span>
                    <span className="font-mono">{integrationStatus.applicationsCount}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Last Sync:</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(integrationStatus.lastSync).toLocaleString()}
                    </span>
                  </div>
                </div>
              ) : (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Unable to load integration status. Please try again.
                  </AlertDescription>
                </Alert>
              )}

              <div className="flex gap-3 mt-6">
                <Button 
                  onClick={checkIntegrationStatus} 
                  disabled={isLoading}
                  variant="outline"
                >
                  {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Refresh Status
                </Button>
                
                {integrationStatus && !integrationStatus.enabled && (
                  <div className="space-y-3">
                    <div className="p-4 border border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800 rounded-lg">
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                        ApplyCaptain Add-on Required
                      </h4>
                      <p className="text-sm text-blue-700 dark:text-blue-200 mb-3">
                        Get premium job application automation for just $10/month (50% off the regular $20 price).
                      </p>
                      <div className="flex gap-2">
                        <Button 
                          onClick={enableIntegration} 
                          disabled={isEnabling}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          {isEnabling && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                          Upgrade to ApplyCaptain - $10/month
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => window.open('https://applycaptain.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Learn More
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="sync" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="sync">Sync Applications</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="reminders">Reminders</TabsTrigger>
            </TabsList>

            <TabsContent value="sync" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <RefreshCw className="w-5 h-5" />
                    Sync Applications
                  </CardTitle>
                  <CardDescription>
                    Synchronize your job applications from ApplyCaptain to PrepPair and external analytics.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button 
                      onClick={syncApplications} 
                      disabled={isSyncing || !integrationStatus?.enabled}
                      className="w-full"
                    >
                      {isSyncing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                      {isSyncing ? 'Synchronizing...' : 'Sync Now'}
                    </Button>

                    {syncResults && (
                      <Alert className={syncResults.success ? "border-green-200 bg-green-50 dark:bg-green-900/20" : "border-red-200 bg-red-50 dark:bg-red-900/20"}>
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertDescription>
                          <div className="space-y-2">
                            <p className="font-medium">{syncResults.message}</p>
                            <p className="text-sm">
                              Found {syncResults.applicationsFound} applications
                            </p>
                            <p className="text-sm">
                              PrepPair Sync: {syncResults.prepPairSync.success ? 'Success' : 'Failed'}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {syncResults.integration} integration
                            </Badge>
                          </div>
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    PrepPair Analytics
                  </CardTitle>
                  <CardDescription>
                    View your job application analytics and performance metrics.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button 
                      onClick={loadAnalytics} 
                      disabled={isLoadingAnalytics}
                      variant="outline"
                    >
                      {isLoadingAnalytics && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                      Load Analytics
                    </Button>

                    {analytics && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 border rounded-lg">
                          <h4 className="font-medium mb-2">Application Stats</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Analytics data will be displayed here when available.
                          </p>
                        </div>
                        <div className="p-4 border rounded-lg">
                          <h4 className="font-medium mb-2">Response Rate</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Performance metrics will be shown here.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reminders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    Application Reminders
                  </CardTitle>
                  <CardDescription>
                    Set up automated follow-up reminders for your job applications.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button 
                      onClick={createReminder}
                      variant="outline"
                    >
                      Create Follow-up Reminder
                    </Button>

                    <Alert>
                      <Bell className="h-4 w-4" />
                      <AlertDescription>
                        Reminders help you stay on top of your job applications. 
                        We'll notify you when it's time to follow up with employers.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center space-y-3">
                <div className="flex items-center justify-center gap-2">
                  <Badge variant="default" className="bg-gradient-to-r from-blue-600 to-purple-600">
                    Premium Add-on
                  </Badge>
                  <Badge variant="outline">
                    Pro Members: $10/month
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  ApplyCaptain integration provides automated job application services from ApplyCaptain.com
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-500">
                  Save 50% off the regular $20/month price • Secure server-side integration
                </p>
                <div className="pt-2">
                  <Button 
                    variant="link" 
                    className="text-xs"
                    onClick={() => window.open('https://applycaptain.com', '_blank')}
                  >
                    Visit ApplyCaptain.com <ExternalLink className="w-3 h-3 ml-1" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}