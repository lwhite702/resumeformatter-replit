import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { fetchBlogPost, stripHtmlTags, formatDate, type WordPressBlogPost } from "@/lib/wordpress-api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EnhancedBadge } from "@/components/ui/enhanced-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { NavigationHeader } from "@/components/navigation-header-new";
import { CTASection } from "@/components/ui/cta-section";
import { ArrowLeft, Calendar, Clock, User, Mail, Brain, BookOpen, List, Share2, Twitter, Facebook, Linkedin } from "lucide-react";

interface TableOfContentsItem {
  id: string;
  text: string;
  level: number;
}

export default function BlogPost() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/blog/:slug");
  const [tableOfContents, setTableOfContents] = useState<TableOfContentsItem[]>([]);
  const [activeSection, setActiveSection] = useState<string>("");

  const slug = params?.slug;

  // Fetch individual blog post
  const { data: post, isLoading, error } = useQuery({
    queryKey: ['/api/blog-post', slug],
    queryFn: () => fetchBlogPost(slug!),
    enabled: !!slug,
    retry: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Generate table of contents from post content
  useEffect(() => {
    if (post?.content?.rendered) {
      const content = post.content.rendered;
      const headingRegex = /<h([1-6])[^>]*>(.*?)<\/h[1-6]>/gi;
      const headings: TableOfContentsItem[] = [];
      let match;

      while ((match = headingRegex.exec(content)) !== null) {
        const level = parseInt(match[1]);
        const text = stripHtmlTags(match[2]);
        const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
        
        headings.push({ id, text, level });
      }

      setTableOfContents(headings);
    }
  }, [post]);

  // Handle scroll for active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = tableOfContents.map(item => document.getElementById(item.id)).filter(Boolean);
      
      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.getBoundingClientRect().top <= 100) {
          setActiveSection(section.id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [tableOfContents]);

  // Process content to add IDs to headings
  const processedContent = post?.content?.rendered?.replace(
    /<h([1-6])([^>]*)>(.*?)<\/h[1-6]>/gi,
    (match, level, attrs, text) => {
      const id = stripHtmlTags(text).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      return `<h${level}${attrs} id="${id}">${text}</h${level}>`;
    }
  ) || '';

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-3/4 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-8"></div>
            <div className="h-64 bg-gray-200 rounded mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Post Not Found</h1>
          <p className="text-gray-600 mb-8">The blog post you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/blog')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Blog
          </Button>
        </div>
      </div>
    );
  }

  const shareUrl = `${window.location.origin}/blog/${slug}`;
  const shareTitle = stripHtmlTags(post.title.rendered);

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />

      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <Button variant="ghost" onClick={() => setLocation('/blog')} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to The PrepBoard
          </Button>
          
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
            <Brain className="h-4 w-4 text-blue-600" />
            <span>The PrepBoard</span>
            <span>•</span>
            <Calendar className="h-3 w-3" />
            <span>{formatDate(post.date)}</span>
            <span>•</span>
            <Clock className="h-3 w-3" />
            <span>{Math.ceil(stripHtmlTags(post.content.rendered).length / 200)} min read</span>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {stripHtmlTags(post.title.rendered)}
          </h1>

          <div className="flex flex-wrap items-center gap-3 mb-6">
            <EnhancedBadge variant="purple-subtle" size="sm">
              Interview Tips
            </EnhancedBadge>
            <EnhancedBadge variant="blue-subtle" size="sm">
              AI Insights
            </EnhancedBadge>
          </div>

          {/* Share buttons */}
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-600">Share:</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`, '_blank')}
            >
              <Twitter className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <Facebook className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <Linkedin className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Table of Contents Sidebar */}
          {tableOfContents.length > 0 && (
            <div className="lg:col-span-1">
              <div className="sticky top-8">
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-4">
                    <List className="h-4 w-4 text-blue-600" />
                    <h3 className="font-semibold text-gray-900">Table of Contents</h3>
                  </div>
                  
                  <nav className="space-y-2">
                    {tableOfContents.map((item) => (
                      <a
                        key={item.id}
                        href={`#${item.id}`}
                        className={`block text-sm transition-colors hover:text-blue-600 ${
                          activeSection === item.id ? 'text-blue-600 font-medium' : 'text-gray-600'
                        }`}
                        style={{ paddingLeft: `${(item.level - 1) * 12}px` }}
                        onClick={(e) => {
                          e.preventDefault();
                          document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                        }}
                      >
                        {item.text}
                      </a>
                    ))}
                  </nav>
                </Card>
              </div>
            </div>
          )}

          {/* Main Content */}
          <div className={`${tableOfContents.length > 0 ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
            {/* Featured Image */}
            {post.featured_media_url && (
              <div className="mb-8">
                <img 
                  src={post.featured_media_url} 
                  alt={stripHtmlTags(post.title.rendered)}
                  className="w-full h-64 md:h-96 object-cover rounded-lg shadow-lg"
                />
              </div>
            )}

            {/* Article Content */}
            <Card className="p-8">
              <div 
                className="prose prose-lg max-w-none prose-headings:text-gray-900 prose-p:text-gray-700 prose-a:text-blue-600 prose-strong:text-gray-900 prose-ul:text-gray-700 prose-ol:text-gray-700"
                dangerouslySetInnerHTML={{ __html: processedContent }}
              />
            </Card>

            {/* Newsletter Signup */}
            <Card className="mt-8 p-8 bg-gradient-to-br from-blue-50 to-purple-50">
              <div className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <Mail className="h-8 w-8 text-blue-600 mr-3" />
                  <h3 className="text-2xl font-bold text-gray-900">
                    📰 The Job Jumpstart Newsletter
                  </h3>
                </div>
                
                <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                  Get the latest interview tips, AI insights, and career strategies delivered to your inbox every week. Join thousands of job seekers who prep smarter with PrepPair.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                  <Input placeholder="Enter your email address" className="flex-1" />
                  <Button className="gradient-bg text-white whitespace-nowrap">
                    Subscribe Now
                  </Button>
                </div>
                
                <p className="text-xs text-gray-500 mt-3">
                  No spam. Unsubscribe anytime. Read our privacy policy.
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Related Articles CTA */}
      <CTASection
        badge={{ text: "Keep Reading" }}
        title="More from The PrepBoard"
        description="Discover more expert insights and AI-powered strategies to ace your interviews and advance your career."
        action={{
          text: "Browse All Articles",
          href: "/blog",
          variant: "default"
        }}
        className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-900 dark:via-purple-900 dark:to-pink-900"
      />
    </div>
  );
}