import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { fetchBlogPosts, stripHtmlTags, formatDate, type WordPressBlogPost } from "@/lib/wordpress-api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EnhancedBadge } from "@/components/ui/enhanced-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { CTASection } from "@/components/ui/cta-section";
import { ArrowRight, Calendar, Clock, User, Mail, Brain, Search, BookOpen, TrendingUp, Star } from "lucide-react";

export default function Blog() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Scroll to top when component mounts
  useScrollToTop();

  // Fetch blog posts
  const { data: blogData, isLoading: blogLoading, error: blogError } = useQuery({
    queryKey: ['/api/blog-posts'],
    queryFn: () => fetchBlogPosts('preppair-me', 10),
    retry: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const posts = blogData?.posts || [];
  
  // Filter posts based on search and category
  const filteredPosts = posts.filter(post => {
    const matchesSearch = searchTerm === "" || 
      post.title.rendered.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stripHtmlTags(post.content.rendered).toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesSearch;
  });

  // Extract categories for filtering
  const categories = ["Interview Tips", "Resume Optimization", "Career Strategy", "AI Insights", "Job Search"];

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-900 dark:via-purple-900 dark:to-pink-900 py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-6">
            <Brain className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">
              The PrepBoard
            </h1>
          </div>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Your go-to resource for smarter job prep. Get interview tips, AI insights, and career strategies from your supportive AI sidekick.
          </p>
          
          <div className="flex flex-wrap justify-center items-center gap-4 mb-8">
            <EnhancedBadge variant="blue-subtle" size="md" icon={<Star />}>
              Expert Insights
            </EnhancedBadge>
            <EnhancedBadge variant="purple-subtle" size="md" icon={<TrendingUp />}>
              AI-Powered Tactics
            </EnhancedBadge>
            <EnhancedBadge variant="green-subtle" size="md" icon={<BookOpen />}>
              Weekly Posts
            </EnhancedBadge>
          </div>

          {/* Newsletter Signup */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-md mx-auto shadow-lg">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
              📰 The Job Jumpstart Newsletter
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              New posts every week. Subscribe to stay sharp
            </p>
            <div className="flex gap-2">
              <Input placeholder="Your email address" className="flex-1" />
              <Button className="gradient-bg text-white">
                <Mail className="h-4 w-4 mr-2" />
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <EnhancedBadge
              variant={selectedCategory === "all" ? "blue" : "gray-subtle"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
              className="cursor-pointer"
            >
              All Posts
            </EnhancedBadge>
            {categories.map(category => (
              <EnhancedBadge
                key={category}
                variant={selectedCategory === category ? "blue" : "gray-subtle"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="cursor-pointer"
              >
                {category}
              </EnhancedBadge>
            ))}
          </div>
        </div>

        {/* Blog Posts Grid */}
        {blogLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-20 bg-gray-200 rounded mb-4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : blogError ? (
          <div className="text-center py-12">
            <p className="text-gray-500 mb-4">Unable to load blog posts</p>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No posts found matching your search</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post: WordPressBlogPost, index: number) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow cursor-pointer group" onClick={() => setLocation(`/blog/${post.slug}`)}>
                {post.featured_media_url && (
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img 
                      src={post.featured_media_url} 
                      alt={post.title.rendered}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 right-3">
                      <EnhancedBadge variant="blue" size="sm">
                        {index === 0 ? 'Latest' : 'Featured'}
                      </EnhancedBadge>
                    </div>
                  </div>
                )}
                
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                    <Calendar className="h-3 w-3" />
                    <span>{formatDate(post.date)}</span>
                    <Clock className="h-3 w-3 ml-2" />
                    <span>{Math.ceil(stripHtmlTags(post.content.rendered).length / 200)} min read</span>
                  </div>
                  
                  <CardTitle className="text-lg group-hover:text-blue-600 transition-colors line-clamp-2">
                    {stripHtmlTags(post.title.rendered)}
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <CardDescription className="line-clamp-3 mb-4">
                    {stripHtmlTags(post.excerpt.rendered) || stripHtmlTags(post.content.rendered).substring(0, 150) + '...'}
                  </CardDescription>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-blue-600 group-hover:text-blue-700">
                      <span>Read more</span>
                      <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                    
                    <div className="flex gap-2">
                      <EnhancedBadge variant="purple-subtle" size="sm">
                        Interview Tips
                      </EnhancedBadge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Newsletter CTA Section */}
      <CTASection
        badge={{ text: "Stay Updated" }}
        title="Never Miss a Beat"
        description="Get the latest interview tips, AI insights, and career strategies delivered to your inbox every week."
        action={{
          text: "Subscribe to The Job Jumpstart",
          href: "/newsletter",
          variant: "default"
        }}
        className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-blue-900 dark:via-purple-900 dark:to-pink-900"
      />
      
      <Footer />
    </div>
  );
}