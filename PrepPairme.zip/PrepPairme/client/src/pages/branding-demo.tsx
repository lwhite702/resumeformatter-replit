import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RefreshCw, Copy, Check } from "lucide-react";
import { PrepSlogan, getAllSlogans, getRandomSlogan, getRandomMetaDescription, SOCIAL_ALT, META_DESCRIPTIONS } from "@/components/branding/PrepSlogan";
import { DynamicCTA } from "@/components/branding/DynamicCTA";
import { BRAND_CONSTANTS, getRandomCTA } from "@/lib/branding";

export default function BrandingDemo() {
  const [currentSlogan, setCurrentSlogan] = useState("");
  const [currentCTA, setCurrentCTA] = useState("");
  const [currentMeta, setCurrentMeta] = useState("");
  const [copied, setCopied] = useState("");

  useEffect(() => {
    refreshContent();
  }, []);

  const refreshContent = () => {
    setCurrentSlogan(getRandomSlogan());
    setCurrentCTA(getRandomCTA());
    setCurrentMeta(getRandomMetaDescription());
  };

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(type);
      setTimeout(() => setCopied(""), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const allSlogans = getAllSlogans();

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
          PrepPair.me Brand Components
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Dynamic slogan rotation and brand messaging system
        </p>
      </div>

      {/* Dynamic Components Demo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Live Component Demo
            <Button variant="outline" size="sm" onClick={refreshContent}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </CardTitle>
          <CardDescription>
            See how components display random brand messaging
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-4">
              <h3 className="font-semibold mb-3">PrepSlogan Component (Primary)</h3>
              <PrepSlogan variant="primary" className="text-center text-lg" />
            </Card>
            
            <Card className="p-4">
              <h3 className="font-semibold mb-3">PrepSlogan Component (Random)</h3>
              <PrepSlogan variant="random" className="text-center text-lg" />
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 text-center">
              <h3 className="font-semibold mb-3">Dynamic CTA - Primary</h3>
              <DynamicCTA variant="primary" size="md" href="#" showSlogan={false} />
            </Card>
            
            <Card className="p-4 text-center">
              <h3 className="font-semibold mb-3">Dynamic CTA - Gradient</h3>
              <DynamicCTA variant="gradient" size="md" href="#" showSlogan={false} />
            </Card>
            
            <Card className="p-4 text-center">
              <h3 className="font-semibold mb-3">Dynamic CTA with Slogan</h3>
              <DynamicCTA variant="primary" size="lg" href="#" showSlogan={true} />
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Brand Constants Tabs */}
      <Tabs defaultValue="slogans" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="slogans">Slogans</TabsTrigger>
          <TabsTrigger value="meta">Meta Descriptions</TabsTrigger>
          <TabsTrigger value="features">Feature Messaging</TabsTrigger>
          <TabsTrigger value="ctas">CTAs</TabsTrigger>
        </TabsList>

        <TabsContent value="slogans" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Brand Slogans</CardTitle>
              <CardDescription>
                Primary and alternate slogans with randomized rotation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-blue-900 dark:text-blue-100">Primary Slogan</h3>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => copyToClipboard(allSlogans.primary, 'primary')}
                    >
                      {copied === 'primary' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                  <p className="text-lg font-medium text-blue-800 dark:text-blue-200">
                    "{allSlogans.primary}"
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Alternate Slogans</h3>
                  <div className="grid gap-2">
                    {allSlogans.alternate.map((slogan, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <span className="text-sm">{slogan}</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(slogan, `alt-${index}`)}
                        >
                          {copied === `alt-${index}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="meta" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SEO Meta Descriptions</CardTitle>
              <CardDescription>
                Dynamic meta descriptions for better search engine optimization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-green-900 dark:text-green-100">Social Alt Text</h3>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => copyToClipboard(SOCIAL_ALT, 'social')}
                    >
                      {copied === 'social' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                  <p className="text-sm text-green-800 dark:text-green-200">
                    {SOCIAL_ALT}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Meta Description Variations</h3>
                  <div className="grid gap-3">
                    {META_DESCRIPTIONS.map((description, index) => (
                      <div key={index} className="flex items-start justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <span className="text-sm flex-1 mr-2">{description}</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(description, `meta-${index}`)}
                        >
                          {copied === `meta-${index}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Feature Messaging</CardTitle>
              <CardDescription>
                Consistent messaging for key platform features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {Object.entries(BRAND_CONSTANTS.FEATURES).map(([key, feature]) => (
                  <div key={key} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{feature.headline}</h3>
                      <Badge variant="secondary">{key.replace('_', ' ')}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ctas" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Call-to-Action Variations</CardTitle>
              <CardDescription>
                Dynamic CTA text for improved conversion rates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2">
                {BRAND_CONSTANTS.CTA_VARIATIONS.map((cta, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <span className="text-sm font-medium">{cta}</span>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => copyToClipboard(cta, `cta-${index}`)}
                    >
                      {copied === `cta-${index}` ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Usage Examples */}
      <Card>
        <CardHeader>
          <CardTitle>Implementation Status</CardTitle>
          <CardDescription>
            Component integration across PrepPair.me
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">PrepSlogan Component</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">DynamicCTA Component</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Brand Constants</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Meta Descriptions</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Slogan JSON File</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">SEO Utilities</span>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
              Integration Summary
            </h4>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>• Brand-specific slogans with randomized rotation via useMemo</li>
              <li>• Dynamic meta descriptions for improved SEO</li>
              <li>• Social media alt text constants exported</li>
              <li>• CTA variations for enhanced conversion rates</li>
              <li>• Components integrated across landing, features, and pricing pages</li>
              <li>• JSON file created at /public/slogans/preppair_slogans.json</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}