import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { NavigationHeader } from "@/components/navigation-header-new";
import { FloatingHelp } from "@/components/floating-help";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  Heart, 
  Smile, 
  Frown, 
  Meh, 
  Calendar,
  Tag,
  MapPin,
  Cloud,
  Sun,
  CloudRain,
  Zap,
  Target,
  BookOpen,
  TrendingUp,
  Filter,
  Search,
  Eye,
  Edit,
  Trash2,
  Star,
  Coffee,
  Lightbulb,
  Award,
  Users,
  Building,
  Clock,
  ArrowRight,
  Sparkles
} from "lucide-react";

// Mood mapping with emojis and colors
const moodConfig = {
  excited: { emoji: "🚀", color: "bg-orange-500 hover:bg-orange-600 active:bg-orange-700", text: "Excited" },
  confident: { emoji: "💪", color: "bg-blue-500 hover:bg-blue-600 active:bg-blue-700", text: "Confident" },
  nervous: { emoji: "😰", color: "bg-yellow-500 hover:bg-yellow-600 active:bg-yellow-700", text: "Nervous" },
  frustrated: { emoji: "😤", color: "bg-red-500 hover:bg-red-600 active:bg-red-700", text: "Frustrated" },
  hopeful: { emoji: "🌟", color: "bg-green-500 hover:bg-green-600 active:bg-green-700", text: "Hopeful" },
  overwhelmed: { emoji: "🌊", color: "bg-purple-500 hover:bg-purple-600 active:bg-purple-700", text: "Overwhelmed" },
  motivated: { emoji: "🔥", color: "bg-pink-500 hover:bg-pink-600 active:bg-pink-700", text: "Motivated" },
  exhausted: { emoji: "😴", color: "bg-gray-500 hover:bg-gray-600 active:bg-gray-700", text: "Exhausted" },
  optimistic: { emoji: "☀️", color: "bg-yellow-400 hover:bg-yellow-500 active:bg-yellow-600", text: "Optimistic" },
  anxious: { emoji: "😟", color: "bg-indigo-500 hover:bg-indigo-600 active:bg-indigo-700", text: "Anxious" }
};

const categoryConfig = {
  application: { icon: Building, color: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200", text: "Application" },
  interview: { icon: Users, color: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200", text: "Interview" },
  networking: { icon: Coffee, color: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-200", text: "Networking" },
  learning: { icon: BookOpen, color: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-200", text: "Learning" },
  milestone: { icon: Award, color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200", text: "Milestone" },
  setback: { icon: Target, color: "bg-red-100 text-red-800", text: "Setback" }
};

const weatherMoods = [
  { value: "sunny", emoji: "☀️", text: "Sunny" },
  { value: "cloudy", emoji: "☁️", text: "Cloudy" },
  { value: "rainy", emoji: "🌧️", text: "Rainy" },
  { value: "stormy", emoji: "⛈️", text: "Stormy" },
  { value: "rainbow", emoji: "🌈", text: "Rainbow" }
];

interface MoodEntry {
  id: number;
  mood: string;
  emoji: string;
  title: string;
  description?: string;
  category: string;
  tags?: string[];
  intensity: number;
  location?: string;
  weatherMood?: string;
  goals?: string[];
  gratitude?: string;
  learnings?: string;
  tomorrowFocus?: string;
  createdAt: string;
}

export default function CareerMoodBoard() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedMood, setSelectedMood] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [intensity, setIntensity] = useState<number[]>([5]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const [location, setMoodLocation] = useState("");
  const [weatherMood, setWeatherMood] = useState("");
  const [gratitude, setGratitude] = useState("");
  const [learnings, setLearnings] = useState("");
  const [tomorrowFocus, setTomorrowFocus] = useState("");
  const [goals, setGoals] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterMood, setFilterMood] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "timeline">("grid");

  // Fetch mood entries
  const { data: moodEntries = [], isLoading } = useQuery<MoodEntry[]>({
    queryKey: ['/api/mood-entries'],
    enabled: !!user,
  });

  // Create mood entry mutation
  const createMoodEntry = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch('/api/mood-entries', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error('Failed to create mood entry');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood-entries'] });
      setIsDialogOpen(false);
      resetForm();
      toast({
        title: "Mood entry added!",
        description: "Your career journey moment has been captured.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add mood entry",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setSelectedMood("");
    setSelectedCategory("");
    setIntensity([5]);
    setTitle("");
    setDescription("");
    setTags("");
    setMoodLocation("");
    setWeatherMood("");
    setGratitude("");
    setLearnings("");
    setTomorrowFocus("");
    setGoals("");
  };

  const handleSubmit = () => {
    if (!selectedMood || !selectedCategory || !title) {
      toast({
        title: "Missing information",
        description: "Please fill in mood, category, and title.",
        variant: "destructive",
      });
      return;
    }

    const moodData = {
      mood: selectedMood,
      emoji: moodConfig[selectedMood as keyof typeof moodConfig]?.emoji || "😊",
      title,
      description,
      category: selectedCategory,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      intensity: intensity[0],
      location,
      weatherMood,
      goals: goals.split(',').map(g => g.trim()).filter(Boolean),
      gratitude,
      learnings,
      tomorrowFocus,
    };

    createMoodEntry.mutate(moodData);
  };

  // Filter entries
  const filteredEntries = moodEntries.filter((entry: MoodEntry) => {
    const matchesMood = !filterMood || entry.mood === filterMood;
    const matchesCategory = !filterCategory || entry.category === filterCategory;
    const matchesSearch = !searchTerm || 
      entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesMood && matchesCategory && matchesSearch;
  });

  // Get mood statistics
  const moodStats = Object.keys(moodConfig).map(mood => ({
    mood,
    count: moodEntries.filter((entry: MoodEntry) => entry.mood === mood).length,
    ...moodConfig[mood as keyof typeof moodConfig]
  }));

  const averageIntensity = moodEntries.length > 0 
    ? Math.round(moodEntries.reduce((sum: number, entry: MoodEntry) => sum + entry.intensity, 0) / moodEntries.length)
    : 0;

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
        <NavigationHeader />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Career Journey Mood Board</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Please sign in to track your career journey emotions and milestones.
          </p>
          <Button onClick={() => window.location.href = '/api/login'}>
            Sign In to Continue
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <NavigationHeader />
      <FloatingHelp />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Career Journey Mood Board
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Track your emotional journey through job searching, interviews, and career milestones. 
            Capture the highs, lows, and everything in between with our interactive mood board.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center">
                <Sparkles className="h-8 w-8 text-purple-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Entries</p>
                  <p className="text-2xl font-bold text-gray-900">{moodEntries.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-green-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Intensity</p>
                  <p className="text-2xl font-bold text-gray-900">{averageIntensity}/10</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center">
                <Heart className="h-8 w-8 text-red-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Most Common</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {moodStats.sort((a, b) => b.count - a.count)[0]?.emoji || "😊"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600">This Week</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {moodEntries.filter((entry: MoodEntry) => 
                      new Date(entry.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
                    ).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Mood Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Capture Your Career Journey Moment</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Mood Selection */}
                <div>
                  <Label>How are you feeling?</Label>
                  <div className="grid grid-cols-5 gap-2 mt-2">
                    {Object.entries(moodConfig).map(([mood, config]) => (
                      <Button
                        key={mood}
                        variant={selectedMood === mood ? "default" : "outline"}
                        className="h-16 flex flex-col gap-1"
                        onClick={() => setSelectedMood(mood)}
                      >
                        <span className="text-2xl">{config.emoji}</span>
                        <span className="text-xs">{config.text}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Category Selection */}
                <div>
                  <Label>Category</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryConfig).map(([category, config]) => (
                        <SelectItem key={category} value={category}>
                          <div className="flex items-center gap-2">
                            <config.icon className="h-4 w-4" />
                            {config.text}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Title */}
                <div>
                  <Label>Title</Label>
                  <Input
                    placeholder="e.g., Got the interview!"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                {/* Intensity */}
                <div>
                  <Label>Intensity ({intensity[0]}/10)</Label>
                  <Slider
                    value={intensity}
                    onValueChange={setIntensity}
                    max={10}
                    min={1}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <Tabs defaultValue="details" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="reflection">Reflection</TabsTrigger>
                    <TabsTrigger value="context">Context</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="details" className="space-y-4">
                    <div>
                      <Label>Description</Label>
                      <Textarea
                        placeholder="What happened? How did it make you feel?"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label>Tags (comma-separated)</Label>
                      <Input
                        placeholder="e.g., tech startup, remote work, first interview"
                        value={tags}
                        onChange={(e) => setTags(e.target.value)}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="reflection" className="space-y-4">
                    <div>
                      <Label>What are you grateful for today?</Label>
                      <Textarea
                        placeholder="Reflect on the positive aspects..."
                        value={gratitude}
                        onChange={(e) => setGratitude(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label>What did you learn?</Label>
                      <Textarea
                        placeholder="Any insights or lessons from this experience?"
                        value={learnings}
                        onChange={(e) => setLearnings(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label>Tomorrow's focus</Label>
                      <Textarea
                        placeholder="What do you want to focus on tomorrow?"
                        value={tomorrowFocus}
                        onChange={(e) => setTomorrowFocus(e.target.value)}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="context" className="space-y-4">
                    <div>
                      <Label>Location</Label>
                      <Input
                        placeholder="Where were you? (e.g., home office, coffee shop)"
                        value={location}
                        onChange={(e) => setMoodLocation(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label>Weather Mood</Label>
                      <div className="grid grid-cols-5 gap-2 mt-2">
                        {weatherMoods.map((weather) => (
                          <Button
                            key={weather.value}
                            variant={weatherMood === weather.value ? "default" : "outline"}
                            className="h-12 flex flex-col gap-1"
                            onClick={() => setWeatherMood(weather.value)}
                          >
                            <span className="text-lg">{weather.emoji}</span>
                            <span className="text-xs">{weather.text}</span>
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <Label>Goals (comma-separated)</Label>
                      <Input
                        placeholder="e.g., prepare for next interview, update resume"
                        value={goals}
                        onChange={(e) => setGoals(e.target.value)}
                      />
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSubmit} disabled={createMoodEntry.isPending}>
                    {createMoodEntry.isPending ? "Saving..." : "Save Entry"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Filters and Search */}
          <div className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search entries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterMood} onValueChange={setFilterMood}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter mood" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All moods</SelectItem>
                {Object.entries(moodConfig).map(([mood, config]) => (
                  <SelectItem key={mood} value={mood}>
                    {config.emoji} {config.text}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All categories</SelectItem>
                {Object.entries(categoryConfig).map(([category, config]) => (
                  <SelectItem key={category} value={category}>
                    {config.text}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Mood Entries Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="h-64 bg-white/80 backdrop-blur-sm border-0 shadow-lg animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredEntries.length === 0 ? (
          <Card className="text-center py-16 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent>
              <Smile className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No mood entries yet</h3>
              <p className="text-gray-600 mb-6">
                Start your career journey tracking by adding your first mood entry!
              </p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Entry
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEntries.map((entry: MoodEntry) => {
              const moodInfo = moodConfig[entry.mood as keyof typeof moodConfig];
              const categoryInfo = categoryConfig[entry.category as keyof typeof categoryConfig];
              
              return (
                <Card key={entry.id} className="group hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${moodInfo?.color} text-white`}>
                          <span className="text-xl">{entry.emoji}</span>
                        </div>
                        <div>
                          <CardTitle className="text-lg">{entry.title}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={categoryInfo?.color}>
                              {categoryInfo?.text}
                            </Badge>
                            <span className="text-sm text-gray-500">
                              Intensity: {entry.intensity}/10
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    {entry.description && (
                      <p className="text-gray-600 mb-3 line-clamp-3">{entry.description}</p>
                    )}
                    
                    {entry.tags && entry.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {entry.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                        {entry.tags.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{entry.tags.length - 3} more
                          </Badge>
                        )}
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center gap-2">
                        {entry.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            <span>{entry.location}</span>
                          </div>
                        )}
                        {entry.weatherMood && (
                          <span>
                            {weatherMoods.find(w => w.value === entry.weatherMood)?.emoji}
                          </span>
                        )}
                      </div>
                      <span>{new Date(entry.createdAt).toLocaleDateString()}</span>
                    </div>
                    
                    {(entry.gratitude || entry.learnings) && (
                      <div className="mt-3 pt-3 border-t border-gray-100">
                        {entry.gratitude && (
                          <p className="text-xs text-gray-600 mb-1">
                            <strong>Grateful:</strong> {entry.gratitude.substring(0, 50)}...
                          </p>
                        )}
                        {entry.learnings && (
                          <p className="text-xs text-gray-600">
                            <strong>Learned:</strong> {entry.learnings.substring(0, 50)}...
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}