import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { BlurredContent } from "@/components/ui/blurred-content";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { GlowCard } from "@/components/ui/spotlight-card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { 
  Network, 
  TrendingUp, 
  Target, 
  MapPin, 
  DollarSign, 
  Clock, 
  Users, 
  BarChart3,
  LineChart,
  Plus,
  Edit,
  Trash2,
  Eye,
  ArrowRight,
  Play,
  CheckCircle2,
  Layers,
  Zap,
  Compass,
  TrendingDown,
  AlertCircle,
  Calendar,
  ChevronRight,
  Maximize,
  Move,
  RotateCcw
} from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

interface CareerPath {
  id: number;
  title: string;
  description?: string;
  industry: string;
  isPublic: boolean;
  isTemplate: boolean;
  templateId?: number;
  createdAt: string;
  updatedAt: string;
  nodes?: CareerPathNode[];
  connections?: CareerPathConnection[];
}

interface CareerPathNode {
  id: number;
  pathId: number;
  title: string;
  description?: string;
  level: string;
  salaryRange?: string;
  requiredSkills?: string[];
  timeToReach?: number;
  positionX: number;
  positionY: number;
  nodeType: string;
  isCompleted: boolean;
  completedAt?: string;
  marketDemand?: number;
  growthRate?: number;
}

interface CareerPathConnection {
  id: number;
  pathId: number;
  fromNodeId: number;
  toNodeId: number;
  connectionType: string;
  description?: string;
  probability?: number;
  timeRequired?: number;
  difficulty?: string;
}

interface IndustryTrend {
  id: number;
  industry: string;
  position: string;
  metric: string;
  value: number;
  period: string;
  source: string;
  lastUpdated: string;
  metadata?: any;
  trend: 'up' | 'down' | 'stable';
  confidence: number;
}

interface VisualizationState {
  zoom: number;
  panX: number;
  panY: number;
  showTrends: boolean;
  selectedNodeId?: number;
  hoveredNodeId?: number;
  showSalaryData: boolean;
  showTimeEstimates: boolean;
  filterByCompletion: 'all' | 'completed' | 'pending';
}

export default function CareerVisualization() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Component State
  const [selectedPath, setSelectedPath] = useState<CareerPath | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showNodeDialog, setShowNodeDialog] = useState(false);
  const [selectedIndustry, setSelectedIndustry] = useState<string>("technology");
  const [activeTab, setActiveTab] = useState("explore");
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  
  // Visualization State
  const [vizState, setVizState] = useState<VisualizationState>({
    zoom: 1,
    panX: 0,
    panY: 0,
    showTrends: true,
    showSalaryData: true,
    showTimeEstimates: true,
    filterByCompletion: 'all'
  });

  // Form State
  const [newPath, setNewPath] = useState({
    title: "",
    description: "",
    industry: "technology",
    isPublic: false
  });

  const [newNode, setNewNode] = useState({
    title: "",
    description: "",
    level: "entry",
    salaryRange: "",
    requiredSkills: "",
    timeToReach: 1,
    nodeType: "role"
  });

  // Authentication check
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch career paths
  const { data: careerPaths, isLoading: pathsLoading } = useQuery({
    queryKey: ["/api/career-paths"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Fetch industry trends
  const { data: industryTrends, isLoading: trendsLoading } = useQuery({
    queryKey: ["/api/industry-trends", selectedIndustry],
    enabled: isAuthenticated && !!selectedIndustry,
    retry: false,
  });

  // Fetch templates
  const { data: templates } = useQuery({
    queryKey: ["/api/career-templates", selectedIndustry],
    enabled: isAuthenticated,
    retry: false,
  });

  // Create career path mutation
  const createPathMutation = useMutation({
    mutationFn: async (pathData: any) => {
      const response = await apiRequest("POST", "/api/career-paths", pathData);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/career-paths"] });
      setShowCreateDialog(false);
      setNewPath({ title: "", description: "", industry: "technology", isPublic: false });
      toast({
        title: "Success",
        description: "Career path created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create career path. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Canvas drawing functions
  const drawCareerPath = useCallback((ctx: CanvasRenderingContext2D, path: CareerPath) => {
    if (!path.nodes || !path.connections) return;

    const { zoom, panX, panY, showTrends, selectedNodeId, hoveredNodeId } = vizState;
    
    // Apply transformations
    ctx.save();
    ctx.scale(zoom, zoom);
    ctx.translate(panX, panY);

    // Draw connections first
    path.connections.forEach(connection => {
      const fromNode = path.nodes?.find(n => n.id === connection.fromNodeId);
      const toNode = path.nodes?.find(n => n.id === connection.toNodeId);
      
      if (fromNode && toNode) {
        drawConnection(ctx, fromNode, toNode, connection);
      }
    });

    // Draw nodes
    path.nodes.forEach(node => {
      const isSelected = node.id === selectedNodeId;
      const isHovered = node.id === hoveredNodeId;
      drawNode(ctx, node, isSelected, isHovered, showTrends);
    });

    ctx.restore();
  }, [vizState]);

  const drawNode = (ctx: CanvasRenderingContext2D, node: CareerPathNode, isSelected: boolean, isHovered: boolean, showTrends: boolean) => {
    const x = node.positionX;
    const y = node.positionY;
    const radius = isSelected ? 35 : isHovered ? 30 : 25;

    // Node background
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, 2 * Math.PI);
    
    // Color based on completion and type
    if (node.isCompleted) {
      ctx.fillStyle = '#22c55e'; // Green for completed
    } else if (node.nodeType === 'role') {
      ctx.fillStyle = '#3b82f6'; // Blue for roles
    } else if (node.nodeType === 'milestone') {
      ctx.fillStyle = '#f59e0b'; // Amber for milestones
    } else {
      ctx.fillStyle = '#6b7280'; // Gray for others
    }
    
    ctx.fill();

    // Border
    ctx.strokeStyle = isSelected ? '#1f2937' : '#ffffff';
    ctx.lineWidth = isSelected ? 3 : 2;
    ctx.stroke();

    // Trend indicator if enabled
    if (showTrends && node.growthRate !== undefined) {
      const trendRadius = radius + 8;
      ctx.beginPath();
      ctx.arc(x + trendRadius, y - trendRadius, 6, 0, 2 * Math.PI);
      ctx.fillStyle = node.growthRate > 0 ? '#10b981' : node.growthRate < 0 ? '#ef4444' : '#6b7280';
      ctx.fill();
    }

    // Node text
    ctx.fillStyle = '#ffffff';
    ctx.font = '12px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Truncate text if too long
    const maxLength = 12;
    const displayText = node.title.length > maxLength ? 
      node.title.substring(0, maxLength) + '...' : 
      node.title;
    
    ctx.fillText(displayText, x, y);

    // Completion indicator
    if (node.isCompleted) {
      ctx.beginPath();
      ctx.arc(x + radius - 5, y - radius + 5, 8, 0, 2 * Math.PI);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.strokeStyle = '#22c55e';
      ctx.stroke();
      
      // Checkmark
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + radius - 8, y - radius + 5);
      ctx.lineTo(x + radius - 5, y - radius + 8);
      ctx.lineTo(x + radius - 2, y - radius + 2);
      ctx.stroke();
    }
  };

  const drawConnection = (ctx: CanvasRenderingContext2D, fromNode: CareerPathNode, toNode: CareerPathNode, connection: CareerPathConnection) => {
    const fromX = fromNode.positionX;
    const fromY = fromNode.positionY;
    const toX = toNode.positionX;
    const toY = toNode.positionY;

    // Calculate arrow position
    const angle = Math.atan2(toY - fromY, toX - fromX);
    const nodeRadius = 25;
    const startX = fromX + Math.cos(angle) * nodeRadius;
    const startY = fromY + Math.sin(angle) * nodeRadius;
    const endX = toX - Math.cos(angle) * nodeRadius;
    const endY = toY - Math.sin(angle) * nodeRadius;

    // Connection line
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    
    // Style based on connection type
    if (connection.connectionType === 'direct') {
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
    } else if (connection.connectionType === 'alternative') {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
    } else {
      ctx.strokeStyle = '#6b7280';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
    }
    
    ctx.stroke();
    ctx.setLineDash([]);

    // Arrow head
    const arrowLength = 10;
    const arrowAngle = 0.5;
    
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(
      endX - arrowLength * Math.cos(angle - arrowAngle),
      endY - arrowLength * Math.sin(angle - arrowAngle)
    );
    ctx.moveTo(endX, endY);
    ctx.lineTo(
      endX - arrowLength * Math.cos(angle + arrowAngle),
      endY - arrowLength * Math.sin(angle + arrowAngle)
    );
    ctx.stroke();

    // Probability indicator
    if (connection.probability && connection.probability < 0.8) {
      const midX = (startX + endX) / 2;
      const midY = (startY + endY) / 2;
      
      ctx.beginPath();
      ctx.arc(midX, midY, 4, 0, 2 * Math.PI);
      ctx.fillStyle = connection.probability > 0.5 ? '#f59e0b' : '#ef4444';
      ctx.fill();
    }
  };

  // Canvas event handlers
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setIsDragging(true);
    setDragStart({ x: x - vizState.panX, y: y - vizState.panY });
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isDragging) {
      setVizState(prev => ({
        ...prev,
        panX: x - dragStart.x,
        panY: y - dragStart.y
      }));
    } else {
      // Check for node hover
      if (selectedPath?.nodes) {
        const hoveredNode = selectedPath.nodes.find(node => {
          const nodeX = (node.positionX * vizState.zoom) + vizState.panX;
          const nodeY = (node.positionY * vizState.zoom) + vizState.panY;
          const distance = Math.sqrt((x - nodeX) ** 2 + (y - nodeY) ** 2);
          return distance <= 25 * vizState.zoom;
        });
        
        setVizState(prev => ({
          ...prev,
          hoveredNodeId: hoveredNode?.id
        }));
      }
    }
  };

  const handleCanvasMouseUp = () => {
    setIsDragging(false);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return;

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Check for node click
    if (selectedPath?.nodes) {
      const clickedNode = selectedPath.nodes.find(node => {
        const nodeX = (node.positionX * vizState.zoom) + vizState.panX;
        const nodeY = (node.positionY * vizState.zoom) + vizState.panY;
        const distance = Math.sqrt((x - nodeX) ** 2 + (y - nodeY) ** 2);
        return distance <= 25 * vizState.zoom;
      });
      
      if (clickedNode) {
        setVizState(prev => ({
          ...prev,
          selectedNodeId: clickedNode.id
        }));
      }
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.max(0.1, Math.min(3, vizState.zoom * zoomFactor));
    
    setVizState(prev => ({
      ...prev,
      zoom: newZoom
    }));
  };

  // Draw canvas when data changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedPath) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set canvas size
    const container = containerRef.current;
    if (container) {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    }

    // Draw background grid
    drawGrid(ctx, canvas.width, canvas.height);
    
    // Draw career path
    drawCareerPath(ctx, selectedPath);
  }, [selectedPath, vizState, drawCareerPath]);

  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const { zoom, panX, panY } = vizState;
    const gridSize = 50 * zoom;
    
    ctx.strokeStyle = '#f3f4f6';
    ctx.lineWidth = 1;
    
    // Vertical lines
    for (let x = (panX % gridSize); x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    
    // Horizontal lines
    for (let y = (panY % gridSize); y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  };

  // Helper functions
  const resetView = () => {
    setVizState(prev => ({
      ...prev,
      zoom: 1,
      panX: 0,
      panY: 0
    }));
  };

  const formatSalary = (range: string) => {
    if (!range) return "Not specified";
    return range.includes('-') ? range : `$${range}`;
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      default:
        return <BarChart3 className="h-4 w-4 text-gray-500" />;
    }
  };

  const getSelectedNode = () => {
    if (!selectedPath?.nodes || !vizState.selectedNodeId) return null;
    return selectedPath.nodes.find(node => node.id === vizState.selectedNodeId);
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-purple-900">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Career Path Visualization
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Explore interactive career paths with real-time industry trends and insights
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="explore">Explore Paths</TabsTrigger>
            <TabsTrigger value="create">Create Path</TabsTrigger>
            <TabsTrigger value="trends">Industry Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="explore" className="space-y-6">
            <div className="grid lg:grid-cols-4 gap-6">
              {/* Control Panel */}
              <div className="lg:col-span-1 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Layers className="h-5 w-5 mr-2" />
                      Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Industry Selection */}
                    <div>
                      <Label>Industry</Label>
                      <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="healthcare">Healthcare</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="marketing">Marketing</SelectItem>
                          <SelectItem value="design">Design</SelectItem>
                          <SelectItem value="sales">Sales</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* View Options */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-trends">Industry Trends</Label>
                        <Switch
                          id="show-trends"
                          checked={vizState.showTrends}
                          onCheckedChange={(checked) => 
                            setVizState(prev => ({ ...prev, showTrends: checked }))
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-salary">Salary Data</Label>
                        <Switch
                          id="show-salary"
                          checked={vizState.showSalaryData}
                          onCheckedChange={(checked) => 
                            setVizState(prev => ({ ...prev, showSalaryData: checked }))
                          }
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show-time">Time Estimates</Label>
                        <Switch
                          id="show-time"
                          checked={vizState.showTimeEstimates}
                          onCheckedChange={(checked) => 
                            setVizState(prev => ({ ...prev, showTimeEstimates: checked }))
                          }
                        />
                      </div>
                    </div>

                    {/* Zoom Control */}
                    <div>
                      <Label>Zoom: {Math.round(vizState.zoom * 100)}%</Label>
                      <Slider
                        value={[vizState.zoom]}
                        onValueChange={([zoom]) => 
                          setVizState(prev => ({ ...prev, zoom }))
                        }
                        min={0.1}
                        max={3}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>

                    <Button onClick={resetView} variant="outline" className="w-full">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset View
                    </Button>
                  </CardContent>
                </Card>

                {/* Path Selection */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Career Paths</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pathsLoading ? (
                      <div className="space-y-2">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="h-12 bg-gray-200 dark:bg-gray-700 rounded animate-pulse" />
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {careerPaths?.map((path: CareerPath) => (
                          <Button
                            key={path.id}
                            variant={selectedPath?.id === path.id ? "default" : "outline"}
                            className="w-full justify-start text-left"
                            onClick={() => setSelectedPath(path)}
                          >
                            <div className="truncate">
                              <div className="font-medium">{path.title}</div>
                              <div className="text-xs opacity-70">{path.industry}</div>
                            </div>
                          </Button>
                        )) || (
                          <p className="text-gray-500 dark:text-gray-400 text-sm">
                            No career paths found. Create your first path!
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Node Details */}
                {getSelectedNode() && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Node Details</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {(() => {
                        const node = getSelectedNode()!;
                        return (
                          <div className="space-y-3">
                            <div>
                              <h4 className="font-semibold">{node.title}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {node.description || "No description"}
                              </p>
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm">Level:</span>
                                <Badge variant="outline">{node.level}</Badge>
                              </div>
                              
                              {vizState.showSalaryData && node.salaryRange && (
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">Salary:</span>
                                  <span className="text-sm font-medium">
                                    {formatSalary(node.salaryRange)}
                                  </span>
                                </div>
                              )}
                              
                              {vizState.showTimeEstimates && node.timeToReach && (
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">Time to reach:</span>
                                  <span className="text-sm font-medium">
                                    {node.timeToReach} years
                                  </span>
                                </div>
                              )}
                              
                              {node.marketDemand && (
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">Market demand:</span>
                                  <div className="flex items-center">
                                    <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                      <div
                                        className="bg-blue-600 h-2 rounded-full"
                                        style={{ width: `${node.marketDemand}%` }}
                                      />
                                    </div>
                                    <span className="text-sm">{node.marketDemand}%</span>
                                  </div>
                                </div>
                              )}
                            </div>
                            
                            {node.requiredSkills && node.requiredSkills.length > 0 && (
                              <div>
                                <span className="text-sm font-medium">Required Skills:</span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {node.requiredSkills.map((skill, index) => (
                                    <Badge key={index} variant="secondary" className="text-xs">
                                      {skill}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between pt-2">
                              <span className="text-sm">Status:</span>
                              <Badge variant={node.isCompleted ? "default" : "secondary"}>
                                {node.isCompleted ? "Completed" : "In Progress"}
                              </Badge>
                            </div>
                          </div>
                        );
                      })()}
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Visualization Canvas */}
              <div className="lg:col-span-3">
                <Card className="h-[600px]">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <Network className="h-5 w-5 mr-2" />
                        {selectedPath ? selectedPath.title : "Select a Career Path"}
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="outline">
                          <Maximize className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="h-full p-0">
                    <div ref={containerRef} className="w-full h-full relative">
                      {selectedPath ? (
                        <canvas
                          ref={canvasRef}
                          className="w-full h-full cursor-grab active:cursor-grabbing"
                          onMouseDown={handleCanvasMouseDown}
                          onMouseMove={handleCanvasMouseMove}
                          onMouseUp={handleCanvasMouseUp}
                          onClick={handleCanvasClick}
                          onWheel={handleWheel}
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <div className="text-center">
                            <Network className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">
                              No Career Path Selected
                            </h3>
                            <p className="text-gray-500 dark:text-gray-500">
                              Choose a career path from the sidebar to begin visualization
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create New Career Path</CardTitle>
                <CardDescription>
                  Design a custom career path with interactive nodes and connections
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Path Title</Label>
                      <Input
                        id="title"
                        value={newPath.title}
                        onChange={(e) => setNewPath(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="e.g., Software Engineer Career Path"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newPath.description}
                        onChange={(e) => setNewPath(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Describe this career path..."
                        rows={3}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="industry">Industry</Label>
                      <Select 
                        value={newPath.industry} 
                        onValueChange={(value) => setNewPath(prev => ({ ...prev, industry: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="technology">Technology</SelectItem>
                          <SelectItem value="healthcare">Healthcare</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="marketing">Marketing</SelectItem>
                          <SelectItem value="design">Design</SelectItem>
                          <SelectItem value="sales">Sales</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="public"
                        checked={newPath.isPublic}
                        onCheckedChange={(checked) => setNewPath(prev => ({ ...prev, isPublic: checked }))}
                      />
                      <Label htmlFor="public">Make this path public</Label>
                    </div>
                    
                    <Button 
                      onClick={() => createPathMutation.mutate(newPath)}
                      disabled={createPathMutation.isPending || !newPath.title}
                      className="w-full"
                    >
                      {createPathMutation.isPending ? (
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                      ) : (
                        <Plus className="h-4 w-4 mr-2" />
                      )}
                      Create Career Path
                    </Button>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-3">Templates</h3>
                    <div className="space-y-2">
                      {templates?.map((template: CareerPath) => (
                        <Card key={template.id} className="p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">{template.title}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">{template.industry}</p>
                            </div>
                            <Button size="sm" variant="outline">
                              Use Template
                            </Button>
                          </div>
                        </Card>
                      )) || (
                        <p className="text-gray-500 dark:text-gray-400 text-sm">
                          No templates available for {selectedIndustry}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trendsLoading ? (
                [...Array(6)].map((_, i) => (
                  <GlowCard key={i} glowColor="blue" customSize={true} className="w-full h-48">
                    <div className="animate-pulse space-y-3 text-white">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded" />
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
                    </div>
                  </GlowCard>
                ))
              ) : (
                industryTrends?.map((trend: IndustryTrend) => (
                  <GlowCard 
                    key={trend.id} 
                    glowColor={trend.trend === 'up' ? 'green' : trend.trend === 'down' ? 'red' : 'blue'} 
                    customSize={true} 
                    className="w-full h-48"
                  >
                    <div className="text-white h-full flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-white">{trend.position}</h3>
                          {getTrendIcon(trend.trend)}
                        </div>
                        
                        <div className="text-2xl font-bold mb-1 text-white">
                          {trend.metric === 'salary' ? `$${trend.value.toLocaleString()}` :
                           trend.metric === 'growth' ? `${trend.value}%` :
                           trend.metric === 'demand' ? `${trend.value}/10` :
                           trend.value.toString()}
                        </div>
                        
                        <p className="text-sm text-gray-300 mb-3">
                          {trend.metric.charAt(0).toUpperCase() + trend.metric.slice(1)} trend
                        </p>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                          <span>{trend.source}</span>
                          <span>{new Date(trend.lastUpdated).toLocaleDateString()}</span>
                        </div>
                        
                        <div className="bg-gray-700 rounded-full h-2 mb-1">
                          <div
                            className={`h-2 rounded-full ${
                              trend.trend === 'up' ? 'bg-green-400' : 
                              trend.trend === 'down' ? 'bg-red-400' : 'bg-blue-400'
                            }`}
                            style={{ width: `${trend.confidence}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-400">
                          {trend.confidence}% confidence
                        </p>
                      </div>
                    </div>
                  </GlowCard>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}