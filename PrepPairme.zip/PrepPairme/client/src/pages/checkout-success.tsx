"use client"

import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Crown, Users, ArrowRight, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import confetti from "canvas-confetti";

export default function CheckoutSuccess() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [planType, setPlanType] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Parse URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const plan = urlParams.get('plan') || 'pro_monthly';
    setPlanType(plan);
    
    // Trigger confetti celebration
    const timer = setTimeout(() => {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const getPlanDetails = () => {
    switch (planType) {
      case 'pro_monthly':
        return {
          name: 'Pro Monthly',
          price: '$19/month',
          icon: <Crown className="w-8 h-8 text-purple-600" />,
          features: [
            'Unlimited AI-powered interview guides',
            'Advanced resume optimization',
            'Priority support',
            'All premium features'
          ]
        };
      case 'pro_quarterly':
        return {
          name: 'Pro Quarterly',
          price: '$14.25/month (billed quarterly)',
          icon: <Crown className="w-8 h-8 text-purple-600" />,
          features: [
            'Unlimited AI-powered interview guides',
            'Advanced resume optimization',
            'Priority support',
            'All premium features',
            '25% savings vs monthly'
          ]
        };
      case 'career_coach':
        return {
          name: 'Career Coach',
          price: '$39/user/month',
          icon: <Users className="w-8 h-8 text-purple-600" />,
          features: [
            'Team management dashboard',
            'Multi-user access',
            'Advanced analytics',
            'Priority support',
            'Custom onboarding'
          ]
        };
      default:
        return {
          name: 'Pro',
          price: 'Subscription active',
          icon: <Crown className="w-8 h-8 text-purple-600" />,
          features: ['All premium features unlocked']
        };
    }
  };

  const planDetails = getPlanDetails();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-4" />
          <p className="text-gray-600">Processing your subscription...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <CheckCircle className="w-16 h-16 text-green-600" />
              <div className="absolute -top-1 -right-1">
                {planDetails.icon}
              </div>
            </div>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Welcome to {planDetails.name}!
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-6">
            Your subscription is now active and ready to use.
          </p>

          {planType === 'pro_quarterly' && (
            <Badge variant="secondary" className="bg-green-100 text-green-800 mb-6">
              You saved 25% with quarterly billing!
            </Badge>
          )}
        </div>

        <Card className="shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Subscription Details</span>
              <Badge variant="outline" className="text-green-600 border-green-600">
                Active
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">Plan:</span>
              <span>{planDetails.name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">Price:</span>
              <span>{planDetails.price}</span>
            </div>
            {user?.email && (
              <div className="flex justify-between items-center">
                <span className="font-medium">Account:</span>
                <span>{user.email}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg mb-8">
          <CardHeader>
            <CardTitle>What's Included</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {planDetails.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div className="text-center space-y-4">
          <Button 
            onClick={() => setLocation('/dashboard')} 
            className="w-full sm:w-auto"
            size="lg"
          >
            Go to Dashboard
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          
          <p className="text-sm text-gray-500">
            Need help getting started? Check out our{" "}
            <button 
              onClick={() => setLocation('/features')}
              className="text-purple-600 hover:underline"
            >
              feature guide
            </button>{" "}
            or contact support.
          </p>
        </div>

        <div className="mt-12 bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 text-center">
          <h3 className="text-lg font-semibold text-purple-900 dark:text-purple-100 mb-2">
            🎉 Thank you for choosing PrepPair!
          </h3>
          <p className="text-purple-700 dark:text-purple-300">
            You're now equipped with AI-powered tools to accelerate your career growth.
            Let's help you land your dream job!
          </p>
        </div>
      </div>
    </div>
  );
}