"use client"

import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { ArrowLeft, Crown, Users, Loader2, CheckCircle } from "lucide-react";

// Initialize Stripe
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  planType: 'pro_monthly' | 'pro_quarterly' | 'career_coach';
  billingCycle?: 'monthly' | 'quarterly';
  teamUsers?: number;
}

const CheckoutForm = ({ planType, billingCycle, teamUsers }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/checkout/success?plan=${planType}`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Payment Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getPlanDetails = () => {
    switch (planType) {
      case 'pro_monthly':
        return {
          name: 'Pro Monthly',
          price: '$19',
          period: 'per month',
          description: 'Monthly billing, cancel anytime'
        };
      case 'pro_quarterly':
        return {
          name: 'Pro Quarterly',
          price: '$14.25',
          period: 'per month',
          description: 'Billed quarterly, save 25%'
        };
      case 'career_coach':
        return {
          name: 'Career Coach',
          price: '$39',
          period: `per user/month`,
          description: `Team plan for ${teamUsers || 3}+ users`
        };
      default:
        return { name: '', price: '', period: '', description: '' };
    }
  };

  const planDetails = getPlanDetails();

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold text-lg">{planDetails.name}</h3>
          {planType === 'pro_quarterly' && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Save 25%
            </Badge>
          )}
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold">{planDetails.price}</span>
          <span className="text-gray-600">{planDetails.period}</span>
        </div>
        <p className="text-sm text-gray-600 mt-1">{planDetails.description}</p>
        {planType === 'career_coach' && (
          <p className="text-sm text-purple-600 mt-2">
            Minimum 3 users • Quarterly billing • ${(teamUsers || 3) * 39 * 3} total
          </p>
        )}
      </div>

      <PaymentElement />

      <Button 
        type="submit" 
        className="w-full h-12" 
        disabled={!stripe || !elements || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin mr-2" />
            Processing...
          </>
        ) : (
          `Subscribe to ${planDetails.name}`
        )}
      </Button>

      <p className="text-xs text-gray-500 text-center">
        By subscribing, you agree to our Terms of Service and Privacy Policy.
        You can cancel your subscription at any time.
      </p>
    </form>
  );
};

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [planType, setPlanType] = useState<'pro_monthly' | 'pro_quarterly' | 'career_coach'>('pro_monthly');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'quarterly'>('monthly');
  const [teamUsers, setTeamUsers] = useState(3);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access checkout.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
      return;
    }

    if (!user) return;

    // Parse URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const plan = urlParams.get('plan') as 'pro_monthly' | 'pro_quarterly' | 'career_coach';
    const cycle = urlParams.get('cycle') as 'monthly' | 'quarterly';
    const users = parseInt(urlParams.get('users') || '3');

    if (plan) setPlanType(plan);
    if (cycle) setBillingCycle(cycle);
    if (users) setTeamUsers(users);

    initializePayment(plan || 'pro_monthly', cycle, users);
  }, [user, isLoading, toast]);

  const initializePayment = async (plan: string, cycle?: string, users?: number) => {
    try {
      setIsInitializing(true);
      let response;

      if (plan === 'career_coach') {
        response = await apiRequest("POST", "/api/create-team-subscription", {
          teamName: `${user?.firstName || 'My'} Team`,
          teamDescription: "Career coaching team",
          initialUsers: users || 3
        });
      } else {
        response = await apiRequest("POST", "/api/create-pro-subscription", {
          billingCycle: cycle || (plan.includes('quarterly') ? 'quarterly' : 'monthly')
        });
      }

      const data = await response.json();
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      } else {
        throw new Error('No client secret received');
      }
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }

      toast({
        title: "Error",
        description: error.message || "Failed to initialize payment",
        variant: "destructive",
      });
      setLocation('/subscribe');
    } finally {
      setIsInitializing(false);
    }
  };

  const appearance = {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#7c3aed',
    },
  };

  if (isLoading || isInitializing) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-4" />
          <p className="text-gray-600">Initializing checkout...</p>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Unable to initialize payment</p>
          <Button onClick={() => setLocation('/subscribe')}>
            Return to Plans
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation('/subscribe')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Plans
          </Button>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              {planType === 'career_coach' ? (
                <Users className="w-8 h-8 text-purple-600" />
              ) : (
                <Crown className="w-8 h-8 text-purple-600" />
              )}
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Complete Your Subscription
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Secure payment powered by Stripe
            </p>
          </div>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Payment Details
            </CardTitle>
            <CardDescription>
              Your subscription will be activated immediately after payment
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Elements stripe={stripePromise} options={{ clientSecret, appearance }}>
              <CheckoutForm 
                planType={planType} 
                billingCycle={billingCycle}
                teamUsers={teamUsers}
              />
            </Elements>
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>🔒 Your payment information is secure and encrypted</p>
        </div>
      </div>
    </div>
  );
}