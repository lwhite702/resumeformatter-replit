import {
  SignedIn,
  SignedOut,
  SignInButton,
  SignUpButton,
  UserButton,
} from "@clerk/clerk-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Star, 
  Users, 
  CheckCircle, 
  ArrowRight, 
  Briefcase, 
  VideoIcon, 
  FileText,
  Target,
  Zap
} from "lucide-react";
import logoWithText from "@assets/3_1749272880173.png";

export default function ClerkLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={logoWithText} alt="PrepPair.me" className="h-8" />
            </div>
            <div className="flex items-center gap-4">
              <SignedOut>
                <SignInButton mode="modal">
                  <Button variant="ghost">Sign In</Button>
                </SignInButton>
                <SignUpButton mode="modal">
                  <Button>Get Started</Button>
                </SignUpButton>
              </SignedOut>
              <SignedIn>
                <UserButton afterSignOutUrl="/" />
              </SignedIn>
            </div>
          </div>
        </div>
      </header>

      <SignedOut>
        {/* Hero Section */}
        <section className="container mx-auto px-6 py-16 text-center">
          <div className="max-w-4xl mx-auto space-y-8">
            <Badge variant="outline" className="mb-4">
              AI-Powered Career Development
            </Badge>
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white leading-tight">
              Master Your Next Interview with
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> AI Guidance</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              PrepPair transforms your job search with intelligent interview preparation, 
              resume optimization, and personalized career coaching powered by advanced AI.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <SignUpButton mode="modal">
                <Button size="lg" className="text-lg px-8 py-3">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </SignUpButton>
              <Button variant="outline" size="lg" className="text-lg px-8 py-3">
                Watch Demo
              </Button>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="container mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Everything You Need to Land Your Dream Job
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Comprehensive tools designed by career experts and powered by AI to give you the competitive edge.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <VideoIcon className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>AI Video Practice</CardTitle>
                <CardDescription>
                  Practice interviews with AI analysis of your body language, speech patterns, and content quality
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Resume Optimization</CardTitle>
                <CardDescription>
                  ATS-friendly resume analysis with keyword optimization and industry-specific recommendations
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>Job Tracking</CardTitle>
                <CardDescription>
                  Intelligent application tracking with automated follow-ups and interview scheduling
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle>Personalized Coaching</CardTitle>
                <CardDescription>
                  Custom interview guides based on your target role, company, and industry requirements
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-teal-600" />
                </div>
                <CardTitle>Skill Highlights</CardTitle>
                <CardDescription>
                  AI-powered skill extraction and verification from your experience and projects
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-red-600" />
                </div>
                <CardTitle>Real-time Feedback</CardTitle>
                <CardDescription>
                  Instant analysis and improvement suggestions with detailed performance metrics
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>

        {/* Social Proof */}
        <section className="container mx-auto px-6 py-16 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
              Trusted by Job Seekers Worldwide
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-blue-600">10,000+</div>
                <div className="text-gray-600 dark:text-gray-300">Successful Interviews</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-green-600">94%</div>
                <div className="text-gray-600 dark:text-gray-300">User Success Rate</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-purple-600">4.9/5</div>
                <div className="text-gray-600 dark:text-gray-300">Average Rating</div>
              </div>
            </div>
            
            {/* CTA */}
            <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-4">Ready to Transform Your Career?</h3>
                <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
                  Join thousands of professionals who have accelerated their careers with PrepPair's AI-powered platform.
                </p>
                <SignUpButton mode="modal">
                  <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
                    Start Your Free Trial
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </SignUpButton>
              </CardContent>
            </Card>
          </div>
        </section>
      </SignedOut>

      <SignedIn>
        {/* Signed In Dashboard Preview */}
        <section className="container mx-auto px-6 py-16">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              Welcome to PrepPair! 🎉
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              You're successfully authenticated with Clerk. Let's get started with your career development journey.
            </p>
            
            <Card className="text-left">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  Account Setup Complete
                </CardTitle>
                <CardDescription>
                  Your account has been created and you're ready to explore all PrepPair features.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Users className="h-5 w-5 text-blue-600" />
                    <span>Profile created and synced with Clerk</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Star className="h-5 w-5 text-purple-600" />
                    <span>Free trial activated (14 days)</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Zap className="h-5 w-5 text-orange-600" />
                    <span>AI features enabled and ready</span>
                  </div>
                </div>
                
                <div className="mt-6 flex gap-4">
                  <Button asChild>
                    <a href="/dashboard">
                      Go to Dashboard
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </a>
                  </Button>
                  <Button variant="outline" asChild>
                    <a href="/help">View Help Center</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </SignedIn>
    </div>
  );
}