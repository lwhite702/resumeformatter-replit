import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { Footer } from "@/components/ui/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NavigationHeader } from "@/components/navigation-header-new";
import { EnhancedTooltip, SimpleTooltip } from "@/components/ui/enhanced-tooltip";
import { SmartNotifications } from "@/components/smart-notifications";
import { ProgressiveDisclosure } from "@/components/progressive-disclosure";
import { useAuth } from "@/hooks/useAuth";
import { UserButton, SignedIn, SignedOut } from "@clerk/clerk-react";
import { PrepSlogan } from "@/components/branding/PrepSlogan";
import { DynamicCTA } from "@/components/branding/DynamicCTA";
import {
  FileText,
  Target,
  TrendingUp,
  Calendar,
  BookOpen,
  Star,
  Upload,
  Link2,
  HelpCircle,
  Sparkles,
  ArrowRight,
  X,
  BarChart3,
  PlusCircle,
  Clock,
  CheckCircle
} from "lucide-react";

export default function Dashboard() {
  useScrollToTop();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [showQuickTips, setShowQuickTips] = useState(true);

  // Early return for loading or unauthenticated states
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    setLocation('/');
    return null;
  }

  // Data queries - only run when user is authenticated
  const { data: guides } = useQuery({ 
    queryKey: ['/api/interview-guides'],
    enabled: !!user 
  });
  const { data: jobs } = useQuery({ 
    queryKey: ['/api/job-applications'],
    enabled: !!user 
  });
  const { data: resumes } = useQuery({ 
    queryKey: ['/api/resumes'],
    enabled: !!user 
  });
  const { data: analytics } = useQuery({ 
    queryKey: ['/api/analytics'],
    enabled: !!user 
  });

  const handleUpgradeClick = () => {
    setLocation('/subscribe');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      {/* Welcome Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="mb-8">
          <Card className="material-card">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row items-center">
                <div className="flex-1 lg:mr-6">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">
                    Welcome back, {(user as any)?.firstName || 'there'}! 👋
                  </h2>
                  <p className="text-gray-600 text-lg mb-4">
                    Ready to ace your next interview? Let's continue preparing for your upcoming opportunities.
                  </p>
                  
                  {/* Quick Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="flex items-center">
                        <BookOpen className="w-5 h-5 text-purple-600 mr-2" />
                        <span className="text-sm font-medium text-purple-600">Interview Guides</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 mt-1">{Array.isArray(guides) ? guides.length : 0}</p>
                    </div>
                    
                    <div className="bg-teal-50 p-4 rounded-lg">
                      <div className="flex items-center">
                        <Target className="w-5 h-5 text-teal-600 mr-2" />
                        <span className="text-sm font-medium text-teal-600">Job Applications</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 mt-1">{Array.isArray(jobs) ? jobs.length : 0}</p>
                    </div>
                    
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <div className="flex items-center">
                        <TrendingUp className="w-5 h-5 text-orange-600 mr-2" />
                        <span className="text-sm font-medium text-orange-600">ATS Score</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 mt-1">{(analytics as any)?.avgAtsScore || 0}%</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                    <Button 
                      onClick={() => setLocation('/interview-guide')} 
                      className="flex items-center"
                    >
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Create Interview Guide
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setLocation('/resume-optimizer')}
                      className="flex items-center"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Resume
                    </Button>
                  </div>
                </div>
                
                <div className="flex-shrink-0 mt-6 lg:mt-0 flex items-center gap-4">
                  <SignedIn>
                    <UserButton 
                      appearance={{
                        elements: {
                          avatarBox: "w-12 h-12",
                          userButtonPopoverCard: "shadow-lg border border-gray-200 dark:border-gray-700",
                          userButtonPopoverActions: "bg-white dark:bg-gray-800",
                          userButtonPopoverActionButton: "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700",
                          userButtonPopoverActionButtonText: "font-medium"
                        }
                      }}
                      afterSignOutUrl="/"
                    />
                  </SignedIn>
                  <SignedOut>
                    <Button onClick={() => setLocation('/sign-in')}>
                      Sign In
                    </Button>
                  </SignedOut>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions */}
        <section className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <h3 className="text-xl font-bold text-gray-900">Quick Actions</h3>
            <EnhancedTooltip
              tips={[
                {
                  title: "Getting Started",
                  description: "Use these quick actions to jump-start your interview preparation journey."
                },
                {
                  title: "Resume Analysis",
                  description: "Upload your resume to get ATS optimization suggestions and keyword analysis."
                },
                {
                  title: "Interview Guides",
                  description: "Generate personalized interview guides based on specific job postings or roles."
                },
                {
                  title: "Job Tracking",
                  description: "Import job postings to track your applications and prepare targeted responses."
                }
              ]}
              maxWidth="320px"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <SimpleTooltip
              content="Upload your resume in PDF or Word format to get ATS optimization, keyword analysis, and improvement suggestions"
              title="Resume Upload & Analysis"
              trigger={
                <Card className="material-card cursor-pointer" onClick={() => setLocation('/resume-optimizer')}>
                  <CardContent className="p-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-3">
                      <Upload className="w-6 h-6 text-purple-600" />
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">Upload Resume</h4>
                    <p className="text-sm text-gray-600">Upload and optimize your resume for ATS systems</p>
                  </CardContent>
                </Card>
              }
            />
            
            <SimpleTooltip
              content="Import job postings by URL or description to generate targeted interview guides and track applications"
              title="Job Import & Tracking"
              trigger={
                <Card className="material-card cursor-pointer" onClick={() => setLocation('/job-tracker')}>
                  <CardContent className="p-4">
                    <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-3">
                      <Link2 className="w-6 h-6 text-teal-600" />
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">Import Job Posting</h4>
                    <p className="text-sm text-gray-600">Paste URL or job description to analyze</p>
                  </CardContent>
                </Card>
              }
            />
            
            <SimpleTooltip
              content="Access 100+ curated interview questions organized by category with sample answers and tips"
              title="Practice Questions"
              trigger={
                <Card className="material-card cursor-pointer" onClick={handleUpgradeClick}>
                  <CardContent className="p-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-3">
                      <HelpCircle className="w-6 h-6 text-indigo-600" />
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">Practice Questions</h4>
                    <p className="text-sm text-gray-600">Browse 100+ interview questions by category</p>
                  </CardContent>
                </Card>
              }
            />
            
            <SimpleTooltip
              content="AI analyzes your resume to extract and highlight key skills relevant to your target roles"
              title="AI Skill Analysis"
              trigger={
                <Card className="material-card cursor-pointer" onClick={() => setLocation('/skill-highlights')}>
                  <CardContent className="p-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg flex items-center justify-center mb-3">
                      <Sparkles className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">AI Skill Highlights</h4>
                    <p className="text-sm text-gray-600">One-click intelligent skill extraction from resume</p>
                  </CardContent>
                </Card>
              }
            />

            <SimpleTooltip
              content="Access comprehensive guides, FAQs, and support resources for all PrepPair features"
              title="Help Center"
              trigger={
                <Card className="material-card cursor-pointer" onClick={() => setLocation('/help')}>
                  <CardContent className="p-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg flex items-center justify-center mb-3">
                      <BookOpen className="w-6 h-6 text-green-600" />
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">Help Center</h4>
                    <p className="text-sm text-gray-600">Guides, FAQs, and comprehensive support</p>
                  </CardContent>
                </Card>
              }
            />
          </div>
        </section>

        {/* Content Tabs */}
        <section>
          <Card className="material-card">
            <Tabs defaultValue="guides" className="w-full">
              <div className="border-b border-gray-200">
                <TabsList className="w-full justify-start bg-transparent h-auto p-0">
                  <TabsTrigger 
                    value="guides" 
                    className="data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent"
                  >
                    Interview Guides
                  </TabsTrigger>
                  <TabsTrigger 
                    value="resumes"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent"
                  >
                    Resumes
                  </TabsTrigger>
                  <TabsTrigger 
                    value="jobs"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent"
                  >
                    Job Applications
                  </TabsTrigger>
                  <TabsTrigger 
                    value="analytics"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-purple-600 data-[state=active]:text-purple-600 rounded-none bg-transparent"
                  >
                    Analytics
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="guides" className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">Your Interview Guides</h3>
                    {(user as any)?.isPro ? (
                      <Button onClick={() => setLocation('/interview-guide')}>
                        <PlusCircle className="w-4 h-4 mr-2" />
                        Create New Guide
                      </Button>
                    ) : (
                      <Button variant="outline" onClick={handleUpgradeClick}>
                        Upgrade to Create More
                      </Button>
                    )}
                  </div>
                  
                  {Array.isArray(guides) && guides.length > 0 ? (
                    <div className="grid gap-4">
                      {guides.map((guide: any) => (
                        <Card key={guide.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900 mb-1">{guide.title}</h4>
                                <p className="text-sm text-gray-600 mb-2">
                                  Created {new Date(guide.createdAt).toLocaleDateString()} • {guide.views || 0} views
                                </p>
                                <Badge variant="secondary">{guide.type || 'General'}</Badge>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => setLocation(`/interview-guide/${guide.id}`)}
                              >
                                View
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h4 className="text-lg font-medium text-gray-900 mb-2">No interview guides yet</h4>
                      <p className="text-gray-600 mb-4">
                        Create your first interview guide to get started with AI-powered preparation.
                      </p>
                      <Button onClick={() => setLocation('/interview-guide')}>
                        Create Your First Guide
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="resumes" className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">Your Resumes</h3>
                    <Button onClick={() => setLocation('/resume-optimizer')}>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload New Resume
                    </Button>
                  </div>
                  
                  {Array.isArray(resumes) && resumes.length > 0 ? (
                    <div className="grid gap-4">
                      {resumes.map((resume: any) => (
                        <Card key={resume.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900 mb-1">{resume.title}</h4>
                                <p className="text-sm text-gray-600 mb-2">
                                  Uploaded {new Date(resume.uploadedAt).toLocaleDateString()}
                                </p>
                                <Badge variant={resume.atsScore > 75 ? "default" : "secondary"}>
                                  ATS Score: {resume.atsScore || 0}%
                                </Badge>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => setLocation(`/resume-optimizer/${resume.id}`)}
                              >
                                Optimize
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h4 className="text-lg font-medium text-gray-900 mb-2">No resumes uploaded</h4>
                      <p className="text-gray-600 mb-4">
                        Upload your resume to get ATS optimization and improvement suggestions.
                      </p>
                      <Button onClick={() => setLocation('/resume-optimizer')}>
                        Upload Your First Resume
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="jobs" className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold">Job Applications</h3>
                    <Button onClick={() => setLocation('/job-tracker')}>
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Add Job Application
                    </Button>
                  </div>
                  
                  {Array.isArray(jobs) && jobs.length > 0 ? (
                    <div className="grid gap-4">
                      {jobs.map((job: any) => (
                        <Card key={job.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900 mb-1">{job.title}</h4>
                                <p className="text-sm text-gray-600 mb-2">{job.company}</p>
                                <Badge variant="outline">{job.status}</Badge>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => setLocation(`/job-tracker/${job.id}`)}
                              >
                                View Details
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h4 className="text-lg font-medium text-gray-900 mb-2">No job applications tracked</h4>
                      <p className="text-gray-600 mb-4">
                        Start tracking your job applications to stay organized and prepared.
                      </p>
                      <Button onClick={() => setLocation('/job-tracker')}>
                        Add Your First Application
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="p-6">
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold">Your Progress Analytics</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Interview Success Rate</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-gray-900">{(analytics as any)?.successRate || 0}%</div>
                        <p className="text-xs text-gray-600 mt-1">
                          Based on tracked applications
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Average Response Time</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-gray-900">{(analytics as any)?.avgResponseTime || 0} days</div>
                        <p className="text-xs text-gray-600 mt-1">
                          From application to response
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">ATS Score Improvement</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-gray-900">
                          {(analytics as any)?.currentScore || 0}%
                        </div>
                        {(analytics as any)?.beforeScore && (analytics as any).currentScore > (analytics as any).beforeScore && (
                          <div className="bg-green-100 text-green-800 px-3 py-2 rounded-lg text-sm text-center">
                            +{((analytics as any).currentScore - (analytics as any).beforeScore)} point improvement!
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </section>

        {/* Progressive Disclosure Section */}
        <section className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-purple-600" />
                <span>Your Learning Path</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProgressiveDisclosure 
                userProgress={{
                  onboardingCompleted: true,
                  resumeUploaded: true,
                  firstPracticeCompleted: false,
                  jobApplicationsAdded: false,
                  videoSessionCompleted: false,
                  analyticsViewed: false,
                  isPro: false
                }}
              />
            </CardContent>
          </Card>
        </section>

        {/* Upgrade Prompt */}
        <section className="mt-8 gradient-bg rounded-lg p-6 text-white">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="flex-1 lg:mr-6">
              <h3 className="text-2xl font-bold mb-2">Unlock Your Full Potential</h3>
              <p className="text-lg opacity-90 mb-4">
                Get unlimited interview guides, resume optimizations, and advanced AI features with PrepPair Pro.
              </p>
              <ul className="space-y-1 mb-4 text-sm">
                <li className="flex items-center">
                  <Target className="w-4 h-4 mr-2" />
                  Unlimited interview guides and STAR stories
                </li>
                <li className="flex items-center">
                  <Target className="w-4 h-4 mr-2" />
                  Advanced resume optimization with detailed feedback
                </li>
                <li className="flex items-center">
                  <Target className="w-4 h-4 mr-2" />
                  Priority AI processing and customer support
                </li>
              </ul>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                <Button 
                  onClick={() => setLocation('/subscribe')} 
                  className="bg-white text-purple-600 hover:bg-gray-100"
                >
                  Upgrade to Pro - $19/month
                </Button>
                <Button 
                  variant="outline" 
                  onClick={handleUpgradeClick}
                  className="border-white border-opacity-30 text-white hover:bg-white hover:bg-opacity-10"
                >
                  Buy Credits Instead
                </Button>
              </div>
            </div>
            <div className="flex-shrink-0 mt-4 lg:mt-0">
              <img 
                src="https://images.unsplash.com/photo-1551836022-deb4988cc6c0?ixlib=rb-4.0.3&w=300&h=200&fit=crop" 
                alt="Confident professional" 
                className="rounded-lg w-full max-w-xs"
              />
            </div>
          </div>
        </section>
      </main>

      {/* Quick Tips Card */}
      {showQuickTips && (
        <div className="fixed bottom-6 left-6 bg-white rounded-lg shadow-lg p-4 max-w-sm z-30">
          <div className="flex items-start">
            <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
              <HelpCircle className="w-4 h-4 text-teal-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-medium text-gray-900 mb-1">Quick Tip</h4>
              <p className="text-sm text-gray-600 mb-2">
                Start by uploading your resume to get personalized optimization suggestions and track your ATS score improvements.
              </p>
              <div className="flex space-x-2">
                <Button size="sm" onClick={() => setLocation('/resume-optimizer')}>
                  Upload Resume
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => setShowQuickTips(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Smart Notifications */}
      <SmartNotifications 
        userActivity={{
          lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
          completedOnboarding: true,
          hasResume: true,
          hasJobApplications: false,
          practiceSessionsCount: 2,
          isPro: false
        }}
      />
      
      {/* Footer */}
      <Footer />
    </div>
  );
}