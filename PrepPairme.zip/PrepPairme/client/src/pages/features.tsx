import { Header1 } from "@/components/ui/header";
import { Footer } from "@/components/ui/footer";
import { Features } from "@/components/blocks/features-11";
import { PrepSlogan } from "@/components/branding/PrepSlogan";
import { useScrollToTop } from "@/hooks/useScrollToTop";

export default function FeaturesPage() {
  useScrollToTop();
  
  return (
    <div className="min-h-screen bg-background">
      <Header1 />
      <main className="pt-16 lg:pt-20">
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Powerful Features for Interview Success
          </h1>
          <PrepSlogan variant="random" className="text-xl text-muted-foreground mb-12" />
        </div>
        <Features />
      </main>
      <Footer />
    </div>
  );
}