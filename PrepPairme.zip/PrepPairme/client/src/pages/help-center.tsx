import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { NavigationHeader } from "@/components/navigation-header-new";
import {
  Search,
  BookOpen,
  MessageCircleQuestion,
  FolderOpen,
  Star,
  Clock,
  ThumbsUp,
  Eye,
  ArrowRight,
  HelpCircle,
  FileText,
  Users,
  Lightbulb
} from "lucide-react";

interface Article {
  id: number;
  title: string;
  content: string;
  excerpt: string;
  slug: string;
  category: string;
  tags: string[] | null;
  status: string;
  author_name: string;
  created_at: string;
  view_count: number;
  helpful_count: number;
}

interface FAQ {
  id: number;
  question: string;
  answer: string;
  category_id: number | null;
  is_active: boolean;
  view_count: number;
  helpful_count: number;
  tags: string[] | null;
  created_at: string;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  color: string;
  icon: string;
  isActive: boolean;
}

interface SearchResults {
  articles: Article[];
  faqs: FAQ[];
}

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResults>({ articles: [], faqs: [] });
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/knowledge/categories'],
  });

  // Fetch featured articles
  const { data: featuredArticles = [] } = useQuery<Article[]>({
    queryKey: ['/api/knowledge/featured', 'articles'],
    queryFn: () => fetch('/api/knowledge/featured?type=articles&limit=6').then(res => res.json()),
  });

  // Fetch popular FAQs
  const { data: popularFAQs = [] } = useQuery<FAQ[]>({
    queryKey: ['/api/knowledge/faqs'],
    queryFn: () => fetch('/api/knowledge/faqs?limit=8').then(res => res.json()),
  });

  // Fetch articles by category
  const { data: categoryArticles = [] } = useQuery<Article[]>({
    queryKey: ['/api/knowledge/articles', selectedCategory],
    queryFn: () => {
      const url = selectedCategory 
        ? `/api/knowledge/articles?category_id=${selectedCategory}&limit=20`
        : '/api/knowledge/articles?limit=20';
      return fetch(url).then(res => res.json());
    },
    enabled: selectedCategory !== null,
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/knowledge/search?q=${encodeURIComponent(searchQuery)}&limit=20`);
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  const getCategoryIcon = (iconName: string) => {
    const icons: { [key: string]: any } = {
      'mic': MessageCircleQuestion,
      'file-text': FileText,
      'trending-up': Star,
      'search': Search,
      'users': Users,
      'lightbulb': Lightbulb,
    };
    const IconComponent = icons[iconName] || HelpCircle;
    return <IconComponent className="h-5 w-5" />;
  };

  return (
    <div className="min-h-screen bg-background">
      <NavigationHeader />
      
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
            Help Center
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Find answers, guides, and support for your career development journey
          </p>
        </div>

        {/* Search Section */}
        <Card>
          <CardContent className="p-6">
            <div className="flex gap-2 mb-4">
              <Input
                placeholder="Search articles, guides, and FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={loading}>
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>

            {/* Search Results */}
            {(searchResults.articles.length > 0 || searchResults.faqs.length > 0) && (
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Search Results</h3>
                
                {searchResults.articles.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2 text-blue-600 dark:text-blue-400">
                      Articles ({searchResults.articles.length})
                    </h4>
                    <div className="grid gap-3">
                      {searchResults.articles.map((article) => (
                        <div key={article.id} className="p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h5 className="font-medium text-sm">{article.title}</h5>
                              <p className="text-xs text-muted-foreground mt-1">
                                {truncateText(article.excerpt, 120)}
                              </p>
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Eye className="h-3 w-3" />
                                  {article.view_count}
                                </span>
                                <span className="flex items-center gap-1">
                                  <ThumbsUp className="h-3 w-3" />
                                  {article.helpful_count}
                                </span>
                                <Badge variant="outline" className="text-xs">
                                  {article.category}
                                </Badge>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm">
                              <ArrowRight className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {searchResults.faqs.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2 text-green-600 dark:text-green-400">
                      FAQs ({searchResults.faqs.length})
                    </h4>
                    <div className="grid gap-3">
                      {searchResults.faqs.map((faq) => (
                        <div key={faq.id} className="p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50">
                          <h5 className="font-medium text-sm mb-2">{faq.question}</h5>
                          <p className="text-xs text-muted-foreground">
                            {truncateText(faq.answer, 150)}
                          </p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {faq.view_count}
                            </span>
                            <span className="flex items-center gap-1">
                              <ThumbsUp className="h-3 w-3" />
                              {faq.helpful_count}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse">Browse by Category</TabsTrigger>
            <TabsTrigger value="featured">Featured Articles</TabsTrigger>
            <TabsTrigger value="faqs">Popular FAQs</TabsTrigger>
            <TabsTrigger value="guides">Quick Guides</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((category) => (
                <Card 
                  key={category.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-3 text-base">
                      <div className="p-2 rounded-lg" style={{ backgroundColor: `${category.color}20` }}>
                        <div style={{ color: category.color }}>
                          {getCategoryIcon(category.icon)}
                        </div>
                      </div>
                      {category.name}
                    </CardTitle>
                    <CardDescription className="text-sm">
                      {category.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">
                        View articles
                      </span>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Category Articles */}
            {selectedCategory && categoryArticles.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FolderOpen className="h-5 w-5" />
                    Category Articles
                  </CardTitle>
                  <CardDescription>
                    Articles in {categories.find(c => c.id === selectedCategory)?.name}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    {categoryArticles.map((article) => (
                      <div key={article.id} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium mb-2">{article.title}</h4>
                            <p className="text-sm text-muted-foreground mb-3">
                              {truncateText(article.excerpt, 200)}
                            </p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Eye className="h-3 w-3" />
                                {article.view_count} views
                              </span>
                              <span className="flex items-center gap-1">
                                <ThumbsUp className="h-3 w-3" />
                                {article.helpful_count} helpful
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {formatDate(article.created_at)}
                              </span>
                              <span>By {article.author_name}</span>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            Read More
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="featured" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Featured Articles
                </CardTitle>
                <CardDescription>
                  Most popular and helpful articles from our knowledge base
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {featuredArticles.map((article) => (
                    <div key={article.id} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium mb-2">{article.title}</h4>
                          <p className="text-sm text-muted-foreground mb-3">
                            {truncateText(article.excerpt, 200)}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {article.view_count} views
                            </span>
                            <span className="flex items-center gap-1">
                              <ThumbsUp className="h-3 w-3" />
                              {article.helpful_count} helpful
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {article.category}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Read Article
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="faqs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircleQuestion className="h-5 w-5" />
                  Frequently Asked Questions
                </CardTitle>
                <CardDescription>
                  Quick answers to common questions about PrepPair
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {popularFAQs.map((faq) => (
                    <div key={faq.id} className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2 text-gray-900 dark:text-white">
                        {faq.question}
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {faq.answer}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {faq.view_count} views
                          </span>
                          <span className="flex items-center gap-1">
                            <ThumbsUp className="h-3 w-3" />
                            {faq.helpful_count} helpful
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <ThumbsUp className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="guides" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BookOpen className="h-5 w-5 text-blue-500" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Account setup and profile creation
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      First interview preparation session
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Resume upload and optimization
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Video practice setup guide
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Lightbulb className="h-5 w-5 text-yellow-500" />
                    Pro Tips
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Maximizing AI feedback effectiveness
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Advanced resume optimization techniques
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Video interview best practices
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      Career tracking and goal setting
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Contact Support */}
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                Need More Help?
              </h3>
              <p className="text-muted-foreground">
                Can't find what you're looking for? Our support team is here to help.
              </p>
              <div className="flex justify-center gap-4">
                <Button variant="outline">
                  <MessageCircleQuestion className="h-4 w-4 mr-2" />
                  Contact Support
                </Button>
                <Button>
                  <BookOpen className="h-4 w-4 mr-2" />
                  Browse All Articles
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}