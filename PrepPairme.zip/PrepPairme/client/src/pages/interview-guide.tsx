import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Header1 } from "@/components/ui/header";
import { Footer } from "@/components/ui/footer";
import { FloatingHelp } from "@/components/floating-help";
import { UpgradeModal } from "@/components/upgrade-modal";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  FileText, 
  Upload, 
  Link2, 
  Brain, 
  Download, 
  Eye, 
  Star,
  ArrowLeft,
  Loader2,
  CheckCircle,
  AlertCircle,
  Mail,
  Copy
} from "lucide-react";
import { format } from "date-fns";

interface InterviewGuideContent {
  title: string;
  summary: string;
  keySkills: string[];
  questions: Array<{
    question: string;
    answer: string;
    category: string;
  }>;
  starStories: Array<{
    situation: string;
    task: string;
    action: string;
    result: string;
    question: string;
  }>;
  talkingPoints: string[];
  followUpEmail: string;
}

export default function InterviewGuide() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [jobDescription, setJobDescription] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [resumeContent, setResumeContent] = useState("");
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const [selectedJobId, setSelectedJobId] = useState<string>("");
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch existing guide if ID provided
  const { data: guide, isLoading: guideLoading } = useQuery({
    queryKey: [`/api/interview-guides/${id}`],
    enabled: !!id,
  });

  // Fetch user's resumes
  const { data: resumes = [] } = useQuery({
    queryKey: ['/api/resumes'],
  });

  // Fetch user's jobs
  const { data: jobs = [] } = useQuery({
    queryKey: ['/api/jobs'],
  });

  const generateGuideMutation = useMutation({
    mutationFn: async (data: {
      jobDescription: string;
      resumeContent: string;
      jobPostingId?: number;
      resumeId?: number;
    }) => {
      const response = await apiRequest("POST", "/api/interview-guides", data);
      return response.json();
    },
    onSuccess: (newGuide) => {
      toast({
        title: "Interview Guide Created!",
        description: "Your personalized interview guide has been generated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/interview-guides'] });
      setLocation(`/interview-guide/${newGuide.id}`);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      if (error.message.includes("Insufficient credits")) {
        setShowUpgradeModal(true);
        return;
      }
      
      toast({
        title: "Error",
        description: error.message || "Failed to generate interview guide",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (guide) {
      // Pre-populate form if viewing existing guide
      setJobDescription(guide.content?.summary || "");
    }
  }, [guide]);

  const handleResumeSelect = (resumeId: string) => {
    setSelectedResumeId(resumeId);
    const resume = resumes.find((r: any) => r.id.toString() === resumeId);
    if (resume) {
      setResumeContent(resume.content);
    }
  };

  const handleJobSelect = (jobId: string) => {
    setSelectedJobId(jobId);
    const job = jobs.find((j: any) => j.id.toString() === jobId);
    if (job) {
      setJobDescription(job.description);
    }
  };

  const handleGenerateGuide = () => {
    if (!jobDescription.trim() || !resumeContent.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide both job description and resume content.",
        variant: "destructive",
      });
      return;
    }

    if (!user?.isPro && (user?.credits || 0) < 1) {
      setShowUpgradeModal(true);
      return;
    }

    setIsGenerating(true);
    generateGuideMutation.mutate({
      jobDescription,
      resumeContent,
      jobPostingId: selectedJobId ? parseInt(selectedJobId) : undefined,
      resumeId: selectedResumeId ? parseInt(selectedResumeId) : undefined,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Content copied to clipboard",
    });
  };

  const exportGuide = () => {
    if (!guide) return;
    
    const content = `
# ${guide.content.title}

## Summary
${guide.content.summary}

## Key Skills Required
${guide.content.keySkills.map((skill: string) => `• ${skill}`).join('\n')}

## Interview Questions & Answers
${guide.content.questions.map((q: any, i: number) => `
### Question ${i + 1}: ${q.question}
**Category:** ${q.category}
**Answer:** ${q.answer}
`).join('\n')}

## STAR Stories
${guide.content.starStories.map((story: any, i: number) => `
### STAR Story ${i + 1} - ${story.question}
**Situation:** ${story.situation}
**Task:** ${story.task}
**Action:** ${story.action}
**Result:** ${story.result}
`).join('\n')}

## Key Talking Points
${guide.content.talkingPoints.map((point: string) => `• ${point}`).join('\n')}

## Follow-up Email Template
${guide.content.followUpEmail}
    `.trim();

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${guide.content.title.replace(/[^a-z0-9]/gi, '_')}_interview_guide.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (id && guideLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header1 />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header1 />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {guide ? guide.content.title : 'Create Interview Guide'}
              </h1>
              {guide && (
                <p className="text-sm text-gray-600">
                  Created {format(new Date(guide.createdAt), 'MMM d, yyyy')} • {guide.views} views
                </p>
              )}
            </div>
          </div>
          {guide && (
            <div className="flex items-center space-x-2">
              <Button variant="outline" onClick={exportGuide}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Badge variant={user?.isPro ? "default" : "secondary"}>
                {user?.isPro ? 'Pro Guide' : 'Free Preview'}
              </Badge>
            </div>
          )}
        </div>

        {/* Content */}
        {guide ? (
          // Display existing guide
          <div className="space-y-6">
            {/* Summary Card */}
            <Card className="material-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-600" />
                  Interview Guide Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">{guide.content.summary}</p>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Key Skills Required:</h4>
                  <div className="flex flex-wrap gap-2">
                    {guide.content.keySkills.map((skill: string, index: number) => (
                      <Badge key={index} variant="outline">{skill}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tabbed Content */}
            <Card className="material-card">
              <Tabs defaultValue="questions" className="w-full">
                <CardHeader>
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="questions">Questions & Answers</TabsTrigger>
                    <TabsTrigger value="star">STAR Stories</TabsTrigger>
                    <TabsTrigger value="points">Talking Points</TabsTrigger>
                    <TabsTrigger value="email">Follow-up Email</TabsTrigger>
                  </TabsList>
                </CardHeader>
                
                <CardContent>
                  <TabsContent value="questions" className="mt-0">
                    <div className="space-y-6">
                      {guide.content.questions.map((q: any, index: number) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <Badge variant="outline" className="text-xs">
                              {q.category}
                            </Badge>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => copyToClipboard(`Q: ${q.question}\nA: ${q.answer}`)}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                          <h4 className="font-medium text-gray-900 mb-2">
                            Q{index + 1}: {q.question}
                          </h4>
                          <p className="text-gray-700 whitespace-pre-wrap">{q.answer}</p>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="star" className="mt-0">
                    {!user?.isPro && guide.content.starStories.length > 1 ? (
                      <div className="text-center py-8">
                        <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                          Upgrade to Access All STAR Stories
                        </h3>
                        <p className="text-gray-600 mb-4">
                          Pro users get detailed STAR methodology examples for behavioral questions.
                        </p>
                        <Button onClick={() => setShowUpgradeModal(true)} className="gradient-bg text-white">
                          Upgrade to Pro
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {guide.content.starStories.slice(0, user?.isPro ? undefined : 1).map((story: any, index: number) => (
                          <div key={index} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex justify-between items-start mb-3">
                              <h4 className="font-medium text-gray-900">{story.question}</h4>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(`${story.situation}\n${story.task}\n${story.action}\n${story.result}`)}
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div>
                                <h5 className="font-medium text-purple-600 mb-1">Situation</h5>
                                <p className="text-sm text-gray-700 mb-3">{story.situation}</p>
                                <h5 className="font-medium text-teal-600 mb-1">Task</h5>
                                <p className="text-sm text-gray-700">{story.task}</p>
                              </div>
                              <div>
                                <h5 className="font-medium text-blue-600 mb-1">Action</h5>
                                <p className="text-sm text-gray-700 mb-3">{story.action}</p>
                                <h5 className="font-medium text-green-600 mb-1">Result</h5>
                                <p className="text-sm text-gray-700">{story.result}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="points" className="mt-0">
                    <div className="space-y-3">
                      {guide.content.talkingPoints.map((point: string, index: number) => (
                        <div key={index} className="flex items-start p-3 bg-gray-50 rounded-lg">
                          <Star className="w-4 h-4 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                          <p className="text-gray-700">{point}</p>
                        </div>
                      ))}
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => copyToClipboard(guide.content.talkingPoints.join('\n• '))}
                      className="mt-4"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy All Points
                    </Button>
                  </TabsContent>

                  <TabsContent value="email" className="mt-0">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="font-medium text-gray-900 flex items-center">
                          <Mail className="w-4 h-4 mr-2" />
                          Follow-up Email Template
                        </h4>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => copyToClipboard(guide.content.followUpEmail)}
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                      </div>
                      <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
                        {guide.content.followUpEmail}
                      </pre>
                    </div>
                  </TabsContent>
                </CardContent>
              </Tabs>
            </Card>
          </div>
        ) : (
          // Create new guide form
          <div className="space-y-6">
            {/* Input Form */}
            <Card className="material-card">
              <CardHeader>
                <CardTitle>Create Your Interview Guide</CardTitle>
                <CardDescription>
                  Upload your resume and job description to generate a personalized interview guide with AI-powered insights.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Resume Section */}
                <div>
                  <Label className="text-sm font-medium">Resume</Label>
                  <div className="grid md:grid-cols-2 gap-4 mt-2">
                    <div>
                      <Select value={selectedResumeId} onValueChange={handleResumeSelect}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select existing resume" />
                        </SelectTrigger>
                        <SelectContent>
                          {resumes.map((resume: any) => (
                            <SelectItem key={resume.id} value={resume.id.toString()}>
                              {resume.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => setLocation('/resume-optimizer')}
                      className="w-full"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload New Resume
                    </Button>
                  </div>
                  <Textarea
                    placeholder="Or paste your resume content here..."
                    value={resumeContent}
                    onChange={(e) => setResumeContent(e.target.value)}
                    className="mt-3"
                    rows={6}
                  />
                </div>

                <Separator />

                {/* Job Description Section */}
                <div>
                  <Label className="text-sm font-medium">Job Description</Label>
                  <div className="grid md:grid-cols-2 gap-4 mt-2">
                    <div>
                      <Select value={selectedJobId} onValueChange={handleJobSelect}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select tracked job" />
                        </SelectTrigger>
                        <SelectContent>
                          {jobs.map((job: any) => (
                            <SelectItem key={job.id} value={job.id.toString()}>
                              {job.title} at {job.company}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Job posting URL"
                        value={jobUrl}
                        onChange={(e) => setJobUrl(e.target.value)}
                      />
                      <Button variant="outline" disabled>
                        <Link2 className="w-4 h-4 mr-2" />
                        Import
                      </Button>
                    </div>
                  </div>
                  <Textarea
                    placeholder="Paste the full job description here..."
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    className="mt-3"
                    rows={8}
                  />
                </div>

                {/* Credits Warning */}
                {!user?.isPro && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center">
                      <AlertCircle className="w-5 h-5 text-blue-600 mr-2" />
                      <div>
                        <p className="text-sm font-medium text-blue-900">
                          Credits Required: 1 credit
                        </p>
                        <p className="text-sm text-blue-700">
                          You have {user?.credits || 0} credits remaining. 
                          {(user?.credits || 0) === 0 && (
                            <span className="ml-1">
                              <Button 
                                variant="link" 
                                size="sm" 
                                onClick={() => setShowUpgradeModal(true)}
                                className="p-0 h-auto text-blue-600"
                              >
                                Upgrade for unlimited guides
                              </Button>
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Generate Button */}
                <Button 
                  onClick={handleGenerateGuide}
                  disabled={!jobDescription.trim() || !resumeContent.trim() || isGenerating}
                  className="w-full gradient-bg text-white hover:opacity-90"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating Your Guide...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-2" />
                      Generate Interview Guide
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Quick Start Preview */}
            <Card className="material-card">
              <CardHeader>
                <CardTitle className="text-lg">What You'll Get</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">Personalized Questions</h4>
                        <p className="text-sm text-gray-600">8-10 targeted interview questions based on the job requirements</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">STAR Method Answers</h4>
                        <p className="text-sm text-gray-600">Detailed behavioral responses using your background</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">Key Talking Points</h4>
                        <p className="text-sm text-gray-600">Strategic points to highlight your relevant experience</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">Follow-up Email</h4>
                        <p className="text-sm text-gray-600">Professional thank-you email template</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">Skills Analysis</h4>
                        <p className="text-sm text-gray-600">Key skills to emphasize for this specific role</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">Export Options</h4>
                        <p className="text-sm text-gray-600">Download as PDF or text for offline review</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      <FloatingHelp />
      <UpgradeModal open={showUpgradeModal} onOpenChange={setShowUpgradeModal} />
      <Footer />
    </div>
  );
}
