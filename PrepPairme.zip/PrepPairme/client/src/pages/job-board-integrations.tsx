import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { 
  ExternalLink, 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  Linkedin,
  Globe,
  Calendar,
  MapPin,
  Building,
  DollarSign,
  FileText,
  Trash2,
  Settings,
  Upload,
  Download
} from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

interface JobBoard {
  id: string;
  name: string;
  description: string;
  available: boolean;
}

interface JobBoardIntegration {
  id: number;
  userId: string;
  jobBoard: string;
  isActive: boolean;
  lastSyncAt: string | null;
  syncStatus: string;
  errorMessage: string | null;
  settings: any;
  createdAt: string;
  updatedAt: string;
}

interface ExternalApplication {
  id: number;
  externalId: string;
  jobBoard: string;
  jobTitle: string;
  company: string;
  location?: string;
  jobUrl?: string;
  description?: string;
  salaryRange?: string;
  jobType?: string;
  applicationStatus: string;
  appliedAt: string;
  lastUpdatedAt?: string;
  notes?: string;
  syncedAt: string;
}

interface ApplicationEvent {
  id: number;
  eventType: string;
  eventData: any;
  eventDate: string;
  description: string;
  isAutomated: boolean;
}

export default function JobBoardIntegrations() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [selectedApplication, setSelectedApplication] = useState<ExternalApplication | null>(null);
  const [showApplicationDetails, setShowApplicationDetails] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [showEmailParser, setShowEmailParser] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: jobBoards = [], isLoading: jobBoardsLoading } = useQuery<JobBoard[]>({
    queryKey: ["/api/job-boards"],
    enabled: isAuthenticated,
  });

  const { data: integrations = [], isLoading: integrationsLoading } = useQuery<JobBoardIntegration[]>({
    queryKey: ["/api/job-board-integrations"],
    enabled: isAuthenticated,
  });

  const { data: externalApplications = [], isLoading: applicationsLoading } = useQuery<ExternalApplication[]>({
    queryKey: ["/api/external-applications"],
    enabled: isAuthenticated,
  });

  const { data: applicationEvents = [] } = useQuery<ApplicationEvent[]>({
    queryKey: [`/api/external-applications/${selectedApplication?.id}/events`],
    enabled: !!selectedApplication,
  });

  const syncMutation = useMutation({
    mutationFn: async (integrationId: number) => {
      return await apiRequest("POST", `/api/job-board-integrations/${integrationId}/sync`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-board-integrations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/external-applications"] });
      toast({
        title: "Sync Started",
        description: "Your job applications are being synced from the job board.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleIntegrationMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      return await apiRequest("PUT", `/api/job-board-integrations/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-board-integrations"] });
      toast({
        title: "Integration Updated",
        description: "Integration status has been updated.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteIntegrationMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/job-board-integrations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-board-integrations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/external-applications"] });
      toast({
        title: "Integration Deleted",
        description: "Job board integration has been removed.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const csvImportMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/external-applications/import", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Import failed");
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/external-applications"] });
      setShowCsvImport(false);
      
      if (result.errors > 0) {
        toast({
          title: "Import Completed with Warnings",
          description: `Imported ${result.imported} applications. ${result.errors} rows had errors.`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Import Successful",
          description: `Successfully imported ${result.imported} applications.`,
        });
      }
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Import Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const emailParseMutation = useMutation({
    mutationFn: async (emailData: { subject: string; body: string; sender: string; receivedAt?: string }) => {
      return await apiRequest("POST", "/api/external-applications/parse-email", emailData);
    },
    onSuccess: (result) => {
      if (result.success) {
        queryClient.invalidateQueries({ queryKey: ["/api/external-applications"] });
        setShowEmailParser(false);
        toast({
          title: "Email Parsed Successfully",
          description: `Job application extracted with ${result.confidence}% confidence.`,
        });
      } else {
        toast({
          title: "No Job Application Found",
          description: result.reasoning || "This email doesn't appear to contain job application information.",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Parsing Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleConnectLinkedIn = () => {
    // Note: This would require LinkedIn app credentials to be configured
    toast({
      title: "LinkedIn Integration",
      description: "LinkedIn API credentials need to be configured. Please contact support.",
      variant: "destructive",
    });
  };

  const handleCsvUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Invalid File",
        description: "Please select a CSV file.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('csvFile', file);
    csvImportMutation.mutate(formData);
  };

  const downloadCsvTemplate = () => {
    const csvContent = `job_title,company,application_status,applied_at,location,job_url,description,salary_range,job_type,notes
Software Engineer,Tech Corp,applied,2024-01-15,New York NY,https://example.com/job,Full stack development role,80000-120000,full-time,Excited about this opportunity
Product Manager,StartupCo,interview,2024-01-10,San Francisco CA,https://example.com/job2,Lead product strategy,90000-130000,full-time,Second round interview scheduled`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'job_applications_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const EmailParserForm = ({ 
    onParseEmail,
    isLoading
  }: { 
    onParseEmail: (emailData: { subject: string; body: string; sender: string; receivedAt?: string }) => void;
    isLoading: boolean;
  }) => {
    const [emailSubject, setEmailSubject] = useState("");
    const [emailBody, setEmailBody] = useState("");
    const [emailSender, setEmailSender] = useState("");
    const [emailDate, setEmailDate] = useState("");

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!emailSubject.trim() || !emailBody.trim() || !emailSender.trim()) {
        return;
      }

      onParseEmail({
        subject: emailSubject.trim(),
        body: emailBody.trim(),
        sender: emailSender.trim(),
        receivedAt: emailDate || new Date().toISOString(),
      });
    };

    const clearForm = () => {
      setEmailSubject("");
      setEmailBody("");
      setEmailSender("");
      setEmailDate("");
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email-sender">Email Sender</Label>
          <Input
            id="email-sender"
            type="email"
            placeholder="noreply@company.com or recruiter@company.com"
            value={emailSender}
            onChange={(e) => setEmailSender(e.target.value)}
            disabled={isLoading}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email-subject">Email Subject</Label>
          <Input
            id="email-subject"
            placeholder="Application received: Software Engineer position"
            value={emailSubject}
            onChange={(e) => setEmailSubject(e.target.value)}
            disabled={isLoading}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email-date">Email Date (Optional)</Label>
          <Input
            id="email-date"
            type="datetime-local"
            value={emailDate}
            onChange={(e) => setEmailDate(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email-body">Email Content</Label>
          <Textarea
            id="email-body"
            placeholder="Thank you for your application to the Software Engineer position at TechCorp. We have received your application and will review it shortly..."
            value={emailBody}
            onChange={(e) => setEmailBody(e.target.value)}
            disabled={isLoading}
            rows={8}
            required
          />
        </div>

        <div className="flex space-x-3">
          <Button 
            type="submit" 
            disabled={isLoading || !emailSubject.trim() || !emailBody.trim() || !emailSender.trim()}
            className="flex items-center space-x-2"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Parsing...</span>
              </>
            ) : (
              <>
                <FileText className="h-4 w-4" />
                <span>Parse Email</span>
              </>
            )}
          </Button>
          
          <Button 
            type="button" 
            variant="outline" 
            onClick={clearForm}
            disabled={isLoading}
          >
            Clear
          </Button>
        </div>

        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Privacy:</strong> Email content is processed securely and only job-related information is extracted.
            <br />
            <strong>Accuracy:</strong> AI parsing works best with confirmation emails from job boards and companies.
          </AlertDescription>
        </Alert>
      </form>
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'syncing':
        return <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied':
        return 'bg-blue-100 text-blue-800';
      case 'viewed':
        return 'bg-yellow-100 text-yellow-800';
      case 'interview':
        return 'bg-purple-100 text-purple-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'offer':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getJobBoardIcon = (jobBoard: string) => {
    switch (jobBoard) {
      case 'linkedin':
        return <Linkedin className="h-4 w-4" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Job Board Integrations</h1>
          <p className="text-muted-foreground">
            Connect your job board accounts to automatically track your applications
          </p>
        </div>
      </div>

      <Tabs defaultValue="integrations" className="space-y-6">
        <TabsList>
          <TabsTrigger value="integrations">My Integrations</TabsTrigger>
          <TabsTrigger value="applications">Tracked Applications</TabsTrigger>
          <TabsTrigger value="connect">Connect New</TabsTrigger>
          <TabsTrigger value="import">Import CSV</TabsTrigger>
          <TabsTrigger value="email">Parse Email</TabsTrigger>
        </TabsList>

        <TabsContent value="integrations" className="space-y-6">
          <IntegrationsList 
            integrations={integrations}
            isLoading={integrationsLoading}
            onSync={(id) => syncMutation.mutate(id)}
            onToggle={(id, isActive) => toggleIntegrationMutation.mutate({ id, isActive })}
            onDelete={(id) => deleteIntegrationMutation.mutate(id)}
            isSyncing={syncMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="applications" className="space-y-6">
          <ApplicationsList 
            applications={externalApplications}
            isLoading={applicationsLoading}
            onSelectApplication={(app) => {
              setSelectedApplication(app);
              setShowApplicationDetails(true);
            }}
          />
        </TabsContent>

        <TabsContent value="connect" className="space-y-6">
          <ConnectJobBoards 
            jobBoards={jobBoards}
            isLoading={jobBoardsLoading}
            onConnectLinkedIn={handleConnectLinkedIn}
          />
        </TabsContent>

        <TabsContent value="import" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Upload className="h-5 w-5" />
                <span>Import Job Applications</span>
              </CardTitle>
              <CardDescription>
                Upload a CSV file with your job application data to automatically track your applications.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Required CSV Format</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Your CSV file must include these columns (in any order):
                  </p>
                  <div className="bg-muted p-3 rounded-lg text-sm font-mono">
                    job_title, company, application_status, applied_at
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Optional columns: location, job_url, description, salary_range, job_type, notes
                  </p>
                </div>

                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    onClick={downloadCsvTemplate}
                    className="flex items-center space-x-2"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download CSV Template</span>
                  </Button>
                  
                  <div>
                    <Input
                      ref={fileInputRef}
                      type="file"
                      accept=".csv"
                      onChange={handleCsvUpload}
                      disabled={csvImportMutation.isPending}
                    />
                  </div>
                  
                  {csvImportMutation.isPending && (
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>Importing applications...</span>
                    </div>
                  )}
                </div>

                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Date Format:</strong> Use YYYY-MM-DD format for the applied_at column (e.g., 2024-01-15).
                    <br />
                    <strong>Status Values:</strong> Use lowercase values like "applied", "interview", "rejected", "offer", etc.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Parse Job Application Email</span>
              </CardTitle>
              <CardDescription>
                Paste job application emails to automatically extract and track application data using AI.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EmailParserForm 
                onParseEmail={(emailData) => emailParseMutation.mutate(emailData)}
                isLoading={emailParseMutation.isPending}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Application Details Dialog */}
      <Dialog open={showApplicationDetails} onOpenChange={setShowApplicationDetails}>
        <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {selectedApplication && getJobBoardIcon(selectedApplication.jobBoard)}
              <span>{selectedApplication?.jobTitle}</span>
            </DialogTitle>
            <DialogDescription>
              Application details and timeline
            </DialogDescription>
          </DialogHeader>
          {selectedApplication && (
            <ApplicationDetails 
              application={selectedApplication}
              events={applicationEvents}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function IntegrationsList({ 
  integrations, 
  isLoading, 
  onSync, 
  onToggle, 
  onDelete,
  isSyncing 
}: { 
  integrations: JobBoardIntegration[];
  isLoading: boolean;
  onSync: (id: number) => void;
  onToggle: (id: number, isActive: boolean) => void;
  onDelete: (id: number) => void;
  isSyncing: boolean;
}) {
  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (integrations.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Globe className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Integrations</h3>
          <p className="text-muted-foreground text-center mb-4">
            Connect your job board accounts to start tracking applications automatically
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {integrations.map((integration) => (
        <Card key={integration.id}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {integration.jobBoard === 'linkedin' ? 
                  <Linkedin className="h-5 w-5 text-blue-600" /> : 
                  <Globe className="h-5 w-5" />
                }
                <CardTitle className="capitalize">{integration.jobBoard}</CardTitle>
              </div>
              <div className="flex items-center space-x-2">
                {getStatusIcon(integration.syncStatus)}
                <Switch
                  checked={integration.isActive}
                  onCheckedChange={(checked) => onToggle(integration.id, checked)}
                />
              </div>
            </div>
            <CardDescription>
              {integration.lastSyncAt ? 
                `Last synced: ${new Date(integration.lastSyncAt).toLocaleDateString()}` :
                'Never synced'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="capitalize">
                {integration.syncStatus}
              </Badge>
              <span className="text-sm text-muted-foreground">
                Connected {new Date(integration.createdAt).toLocaleDateString()}
              </span>
            </div>

            {integration.errorMessage && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {integration.errorMessage}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onSync(integration.id)}
                disabled={!integration.isActive || isSyncing}
              >
                <RefreshCw className={`mr-1 h-3 w-3 ${isSyncing ? 'animate-spin' : ''}`} />
                Sync Now
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onDelete(integration.id)}
              >
                <Trash2 className="mr-1 h-3 w-3" />
                Remove
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ApplicationsList({ 
  applications, 
  isLoading, 
  onSelectApplication 
}: { 
  applications: ExternalApplication[];
  isLoading: boolean;
  onSelectApplication: (app: ExternalApplication) => void;
}) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-muted rounded w-1/2 mb-4"></div>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (applications.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <FileText className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Applications Found</h3>
          <p className="text-muted-foreground text-center">
            Connect your job board accounts to start tracking applications
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {applications.map((application) => (
        <Card 
          key={application.id} 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => onSelectApplication(application)}
        >
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  {getJobBoardIcon(application.jobBoard)}
                  <h3 className="text-lg font-semibold">{application.jobTitle}</h3>
                  <Badge className={getStatusColor(application.applicationStatus)}>
                    {application.applicationStatus}
                  </Badge>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-2">
                  <div className="flex items-center space-x-1">
                    <Building className="h-3 w-3" />
                    <span>{application.company}</span>
                  </div>
                  {application.location && (
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-3 w-3" />
                      <span>{application.location}</span>
                    </div>
                  )}
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>Applied {new Date(application.appliedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              {application.jobUrl && (
                <Button size="sm" variant="outline" asChild>
                  <a href={application.jobUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </Button>
              )}
            </div>

            {application.salaryRange && (
              <div className="flex items-center space-x-1 text-sm text-green-600 mb-2">
                <DollarSign className="h-3 w-3" />
                <span>{application.salaryRange}</span>
              </div>
            )}

            {application.description && (
              <p className="text-sm text-muted-foreground line-clamp-2">
                {application.description}
              </p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ConnectJobBoards({ 
  jobBoards, 
  isLoading, 
  onConnectLinkedIn 
}: { 
  jobBoards: JobBoard[];
  isLoading: boolean;
  onConnectLinkedIn: () => void;
}) {
  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
            </CardHeader>
            <CardContent>
              <div className="h-10 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {jobBoards.map((jobBoard) => (
        <Card key={jobBoard.id}>
          <CardHeader>
            <div className="flex items-center space-x-2">
              {jobBoard.id === 'linkedin' ? 
                <Linkedin className="h-5 w-5 text-blue-600" /> : 
                <Globe className="h-5 w-5" />
              }
              <CardTitle>{jobBoard.name}</CardTitle>
              {!jobBoard.available && (
                <Badge variant="secondary">Coming Soon</Badge>
              )}
            </div>
            <CardDescription>{jobBoard.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              className="w-full"
              disabled={!jobBoard.available}
              onClick={() => {
                if (jobBoard.id === 'linkedin') {
                  onConnectLinkedIn();
                }
              }}
            >
              {jobBoard.available ? `Connect ${jobBoard.name}` : 'Coming Soon'}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function ApplicationDetails({ 
  application, 
  events 
}: { 
  application: ExternalApplication;
  events: ApplicationEvent[];
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied':
        return 'bg-blue-100 text-blue-800';
      case 'viewed':
        return 'bg-yellow-100 text-yellow-800';
      case 'interview':
        return 'bg-purple-100 text-purple-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'offer':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getJobBoardIcon = (jobBoard: string) => {
    switch (jobBoard) {
      case 'linkedin':
        return <Linkedin className="h-4 w-4" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Application Overview */}
      <div className="space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <Badge className={getStatusColor(application.applicationStatus)}>
                {application.applicationStatus}
              </Badge>
              <span className="text-sm text-muted-foreground">
                Applied {new Date(application.appliedAt).toLocaleDateString()}
              </span>
            </div>
            <div className="space-y-1">
              <div className="flex items-center space-x-1">
                <Building className="h-3 w-3" />
                <span className="text-sm">{application.company}</span>
              </div>
              {application.location && (
                <div className="flex items-center space-x-1">
                  <MapPin className="h-3 w-3" />
                  <span className="text-sm">{application.location}</span>
                </div>
              )}
              {application.jobType && (
                <div className="flex items-center space-x-1">
                  <FileText className="h-3 w-3" />
                  <span className="text-sm capitalize">{application.jobType}</span>
                </div>
              )}
              {application.salaryRange && (
                <div className="flex items-center space-x-1">
                  <DollarSign className="h-3 w-3" />
                  <span className="text-sm">{application.salaryRange}</span>
                </div>
              )}
            </div>
          </div>
          {application.jobUrl && (
            <Button size="sm" variant="outline" asChild>
              <a href={application.jobUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-1 h-3 w-3" />
                View Job
              </a>
            </Button>
          )}
        </div>

        {application.description && (
          <div>
            <h4 className="font-medium mb-2">Job Description</h4>
            <p className="text-sm text-muted-foreground">
              {application.description}
            </p>
          </div>
        )}
      </div>

      {/* Application Timeline */}
      <div>
        <h4 className="font-medium mb-3">Application Timeline</h4>
        <div className="space-y-3">
          {events.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events recorded</p>
          ) : (
            events.map((event) => (
              <div key={event.id} className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                <div className="flex-shrink-0 mt-1">
                  {event.isAutomated ? (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  ) : (
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{event.description}</p>
                    <span className="text-xs text-muted-foreground">
                      {new Date(event.eventDate).toLocaleDateString()}
                    </span>
                  </div>
                  {event.eventData && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {JSON.stringify(event.eventData)}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}