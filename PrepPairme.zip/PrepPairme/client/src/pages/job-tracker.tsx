import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { NavigationHeader } from "@/components/navigation-header-new";
import { FloatingHelp } from "@/components/floating-help";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Plus, 
  Building, 
  MapPin, 
  DollarSign, 
  Calendar, 
  Clock,
  FileText,
  Edit,
  Trash2,
  ArrowLeft,
  Briefcase,
  Target,
  TrendingUp,
  Filter
} from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";

const statusOptions = [
  { value: "active", label: "Active", color: "bg-gray-100 text-gray-800" },
  { value: "applied", label: "Applied", color: "bg-blue-100 text-blue-800" },
  { value: "interview", label: "Interview", color: "bg-yellow-100 text-yellow-800" },
  { value: "offer", label: "Offer", color: "bg-green-100 text-green-800" },
  { value: "rejected", label: "Rejected", color: "bg-red-100 text-red-800" },
  { value: "archived", label: "Archived", color: "bg-gray-100 text-gray-600" },
];

const typeOptions = [
  { value: "full-time", label: "Full-time" },
  { value: "part-time", label: "Part-time" },
  { value: "contract", label: "Contract" },
  { value: "internship", label: "Internship" },
  { value: "freelance", label: "Freelance" },
];

export default function JobTracker() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [filterStatus, setFilterStatus] = useState("all");
  const [editingJob, setEditingJob] = useState<any>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    title: "",
    company: "",
    description: "",
    url: "",
    location: "",
    salary: "",
    type: "full-time",
    status: "active",
    notes: "",
    appliedAt: "",
    interviewDate: "",
  });

  // Fetch jobs
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ['/api/jobs'],
  });

  const addJobMutation = useMutation({
    mutationFn: async (jobData: any) => {
      const response = await apiRequest("POST", "/api/jobs", jobData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Job Added!",
        description: "Job has been added to your tracker.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
      setShowAddDialog(false);
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to add job",
        variant: "destructive",
      });
    },
  });

  const updateJobMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest("PUT", `/api/jobs/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Job Updated!",
        description: "Job information has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
      setEditingJob(null);
      resetForm();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update job",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      company: "",
      description: "",
      url: "",
      location: "",
      salary: "",
      type: "full-time",
      status: "active",
      notes: "",
      appliedAt: "",
      interviewDate: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.company.trim() || !formData.description.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in the title, company, and description.",
        variant: "destructive",
      });
      return;
    }

    const submitData = {
      ...formData,
      appliedAt: formData.appliedAt ? new Date(formData.appliedAt).toISOString() : null,
      interviewDate: formData.interviewDate ? new Date(formData.interviewDate).toISOString() : null,
    };

    if (editingJob) {
      updateJobMutation.mutate({ id: editingJob.id, data: submitData });
    } else {
      addJobMutation.mutate(submitData);
    }
  };

  const handleEdit = (job: any) => {
    setEditingJob(job);
    setFormData({
      title: job.title,
      company: job.company,
      description: job.description,
      url: job.url || "",
      location: job.location || "",
      salary: job.salary || "",
      type: job.type || "full-time",
      status: job.status,
      notes: job.notes || "",
      appliedAt: job.appliedAt ? format(new Date(job.appliedAt), 'yyyy-MM-dd') : "",
      interviewDate: job.interviewDate ? format(new Date(job.interviewDate), "yyyy-MM-dd'T'HH:mm") : "",
    });
    setShowAddDialog(true);
  };

  const handleCreateGuide = (job: any) => {
    // Navigate to interview guide creation with pre-filled job info
    setLocation(`/interview-guide?jobId=${job.id}`);
  };

  const filteredJobs = filterStatus === "all" 
    ? jobs 
    : jobs.filter((job: any) => job.status === filterStatus);

  const getStatusColor = (status: string) => {
    const statusOption = statusOptions.find(opt => opt.value === status);
    return statusOption?.color || "bg-gray-100 text-gray-800";
  };

  const getStatusCounts = () => {
    const counts = statusOptions.reduce((acc, status) => {
      acc[status.value] = jobs.filter((job: any) => job.status === status.value).length;
      return acc;
    }, {} as Record<string, number>);
    counts.all = jobs.length;
    return counts;
  };

  const statusCounts = getStatusCounts();

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Job Application Tracker</h1>
              <p className="text-gray-600">Manage your job applications and interview pipeline</p>
            </div>
          </div>
          <Button 
            onClick={() => {
              resetForm();
              setEditingJob(null);
              setShowAddDialog(true);
            }}
            className="bg-teal-600 text-white hover:bg-teal-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Job
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="material-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Briefcase className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <div className="text-2xl font-bold">{jobs.length}</div>
                  <div className="text-sm text-gray-600">Total Applications</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="material-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Calendar className="w-8 h-8 text-yellow-600 mr-3" />
                <div>
                  <div className="text-2xl font-bold">{statusCounts.interview || 0}</div>
                  <div className="text-sm text-gray-600">Interviews Scheduled</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="material-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Target className="w-8 h-8 text-green-600 mr-3" />
                <div>
                  <div className="text-2xl font-bold">{statusCounts.offer || 0}</div>
                  <div className="text-sm text-gray-600">Offers Received</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="material-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-purple-600 mr-3" />
                <div>
                  <div className="text-2xl font-bold">
                    {jobs.length > 0 ? Math.round(((statusCounts.interview || 0) + (statusCounts.offer || 0)) / jobs.length * 100) : 0}%
                  </div>
                  <div className="text-sm text-gray-600">Success Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="material-card mb-6">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 overflow-x-auto">
              <Filter className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <Button
                variant={filterStatus === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterStatus("all")}
                className="whitespace-nowrap"
              >
                All ({statusCounts.all})
              </Button>
              {statusOptions.map((status) => (
                <Button
                  key={status.value}
                  variant={filterStatus === status.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterStatus(status.value)}
                  className="whitespace-nowrap"
                >
                  {status.label} ({statusCounts[status.value] || 0})
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Jobs List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">Loading jobs...</div>
          ) : filteredJobs.length === 0 ? (
            <Card className="material-card">
              <CardContent className="text-center py-12">
                <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {filterStatus === "all" ? "No jobs tracked yet" : `No ${filterStatus} applications`}
                </h3>
                <p className="text-gray-600 mb-4">
                  {filterStatus === "all" 
                    ? "Start tracking your job applications to manage your interview pipeline."
                    : `You don't have any applications with ${filterStatus} status.`
                  }
                </p>
                {filterStatus === "all" && (
                  <Button 
                    onClick={() => {
                      resetForm();
                      setEditingJob(null);
                      setShowAddDialog(true);
                    }}
                    className="bg-teal-600 text-white hover:bg-teal-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Job
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            filteredJobs.map((job: any) => (
              <Card key={job.id} className="material-card hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center mb-3">
                        <img 
                          src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&w=48&h=48&fit=crop" 
                          alt="Company" 
                          className="w-12 h-12 rounded-lg object-cover mr-4"
                        />
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{job.title}</h3>
                          <p className="text-gray-600 flex items-center">
                            <Building className="w-4 h-4 mr-1" />
                            {job.company}
                            {job.location && (
                              <>
                                <MapPin className="w-4 h-4 ml-3 mr-1" />
                                {job.location}
                              </>
                            )}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-6 text-sm text-gray-600 mb-3">
                        {job.salary && (
                          <span className="flex items-center">
                            <DollarSign className="w-4 h-4 mr-1" />
                            {job.salary}
                          </span>
                        )}
                        <span className="capitalize">{job.type}</span>
                        {job.appliedAt && (
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            Applied {format(new Date(job.appliedAt), 'MMM d, yyyy')}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-4 mb-3">
                        <Badge className={getStatusColor(job.status)}>
                          {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                        </Badge>
                        {job.interviewDate && (
                          <span className="text-sm text-gray-600 flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            Interview: {format(new Date(job.interviewDate), 'MMM d, h:mm a')}
                          </span>
                        )}
                      </div>
                      
                      {job.notes && (
                        <p className="text-sm text-gray-700 bg-gray-50 p-2 rounded mt-2">
                          {job.notes}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleCreateGuide(job)}
                        title="Create Interview Guide"
                      >
                        <FileText className="w-4 h-4 text-purple-600" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEdit(job)}
                        title="Edit Job"
                      >
                        <Edit className="w-4 h-4 text-gray-600" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Add/Edit Job Dialog */}
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingJob ? 'Edit Job Application' : 'Add New Job Application'}
              </DialogTitle>
              <DialogDescription>
                {editingJob 
                  ? 'Update the job application details.'
                  : 'Track a new job application in your pipeline.'
                }
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Job Title *</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    placeholder="e.g., Senior Software Engineer"
                    required
                  />
                </div>
                <div>
                  <Label>Company *</Label>
                  <Input
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                    placeholder="e.g., Tech Corp"
                    required
                  />
                </div>
              </div>

              <div>
                <Label>Job Description *</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Paste the full job description here..."
                  rows={6}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Job URL</Label>
                  <Input
                    value={formData.url}
                    onChange={(e) => setFormData({...formData, url: e.target.value})}
                    placeholder="https://..."
                    type="url"
                  />
                </div>
                <div>
                  <Label>Location</Label>
                  <Input
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    placeholder="e.g., San Francisco, CA"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Salary Range</Label>
                  <Input
                    value={formData.salary}
                    onChange={(e) => setFormData({...formData, salary: e.target.value})}
                    placeholder="e.g., $120k - $140k"
                  />
                </div>
                <div>
                  <Label>Job Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {typeOptions.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Status</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {statusOptions.map((status) => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Applied Date</Label>
                  <Input
                    type="date"
                    value={formData.appliedAt}
                    onChange={(e) => setFormData({...formData, appliedAt: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <Label>Interview Date & Time</Label>
                <Input
                  type="datetime-local"
                  value={formData.interviewDate}
                  onChange={(e) => setFormData({...formData, interviewDate: e.target.value})}
                />
              </div>

              <div>
                <Label>Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  placeholder="Any additional notes about this application..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={addJobMutation.isPending || updateJobMutation.isPending}
                  className="bg-teal-600 text-white hover:bg-teal-700"
                >
                  {editingJob ? 'Update Job' : 'Add Job'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </main>

      <FloatingHelp />
    </div>
  );
}
