import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Building, MapPin, Calendar, ExternalLink } from "lucide-react";
import { TooltipHelp, tooltips } from "@/components/tooltip-help";
import { Header1 } from "@/components/ui/header";
import JobFilters, { JobFilter, JobFilterType } from "@/components/ui/job-filters";
import { JobFilterCombobox } from "@/components/ui/job-filter-combobox";

interface JobApplication {
  id: number;
  jobTitle: string;
  company: string;
  location: string;
  status: string;
  appliedAt: string;
  jobUrl?: string;
  salaryRange?: string;
  jobType: string;
  lastUpdated: string;
  priority: string;
}

export default function JobTracking() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState<JobFilter[]>([]);

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ["/api/job-applications"],
  });

  const filteredApplications = applications.filter((app: JobApplication) => {
    const matchesSearch = app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'applied':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'interview':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'offer':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'rejected':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'low':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const statusCounts = {
    total: filteredApplications.length,
    applied: filteredApplications.filter((app: JobApplication) => app.status === 'applied').length,
    interview: filteredApplications.filter((app: JobApplication) => app.status === 'interview').length,
    offer: filteredApplications.filter((app: JobApplication) => app.status === 'offer').length,
    rejected: filteredApplications.filter((app: JobApplication) => app.status === 'rejected').length,
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header1 />
      <div className="pt-20 container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Job Application Tracking</h1>
            <div className="flex items-center gap-2 mt-2">
              <p className="text-muted-foreground">
                Track and manage your job applications with advanced filtering
              </p>
              <TooltipHelp content={tooltips.jobTracking} />
            </div>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Application
          </Button>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Applications</CardDescription>
              <CardTitle className="text-2xl">{statusCounts.total}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Applied</CardDescription>
              <CardTitle className="text-2xl text-blue-600">{statusCounts.applied}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Interviews</CardDescription>
              <CardTitle className="text-2xl text-yellow-600">{statusCounts.interview}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Offers</CardDescription>
              <CardTitle className="text-2xl text-green-600">{statusCounts.offer}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Rejected</CardDescription>
              <CardTitle className="text-2xl text-red-600">{statusCounts.rejected}</CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Search and Advanced Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search by job title, company, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex items-center gap-2">
            <JobFilterCombobox filters={filters} setFilters={setFilters} />
            <JobFilters filters={filters} setFilters={setFilters} />
          </div>
        </div>

        {/* Applications List */}
        <Tabs defaultValue="list" className="w-full">
          <TabsList>
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="kanban">Kanban Board</TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="space-y-4">
            {filteredApplications.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">No job applications found</p>
                  <Button className="mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Application
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredApplications.map((app: JobApplication) => (
                <Card key={app.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-semibold">{app.jobTitle}</h3>
                          {app.jobUrl && (
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Building className="h-3 w-3" />
                            {app.company}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {app.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Applied {new Date(app.appliedAt).toLocaleDateString()}
                          </div>
                        </div>
                        {app.salaryRange && (
                          <p className="text-sm font-medium text-green-600">{app.salaryRange}</p>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <div className="flex gap-2">
                          <Badge className={getStatusColor(app.status)}>
                            {app.status}
                          </Badge>
                          <Badge className={getPriorityColor(app.priority)}>
                            {app.priority}
                          </Badge>
                        </div>
                        <Badge variant="outline">
                          {app.jobType}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="kanban" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {['applied', 'interview', 'offer', 'rejected'].map((status) => (
                <div key={status} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold capitalize">{status}</h3>
                    <Badge variant="secondary">
                      {filteredApplications.filter((app: JobApplication) => app.status === status).length}
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    {filteredApplications
                      .filter((app: JobApplication) => app.status === status)
                      .map((app: JobApplication) => (
                        <Card key={app.id} className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <h4 className="font-medium text-sm">{app.jobTitle}</h4>
                            <p className="text-xs text-muted-foreground mt-1">{app.company}</p>
                            <div className="flex items-center justify-between mt-2">
                              <Badge variant="outline" className="text-xs">
                                {app.jobType}
                              </Badge>
                              <Badge className={getPriorityColor(app.priority)}>
                                {app.priority}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}