import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { 
  BookOpen, 
  Search, 
  FolderOpen, 
  MessageCircleQuestion, 
  Star, 
  BarChart3, 
  Database,
  Globe,
  Shield,
  Clock,
  Users,
  CheckCircle,
  ArrowRight,
  Copy,
  ExternalLink
} from "lucide-react";

export default function KnowledgeBaseGuide() {
  const endpoints = [
    {
      name: "Articles Search",
      method: "GET",
      path: "/api/knowledge/articles",
      description: "Search and filter knowledge base articles with category, status, and tag filtering",
      params: "category_id, search, status, limit, offset, tags",
      example: "/api/knowledge/articles?search=resume&limit=20"
    },
    {
      name: "Categories",
      method: "GET", 
      path: "/api/knowledge/categories",
      description: "Get all knowledge base categories with hierarchical structure",
      params: "parent_id, include_inactive",
      example: "/api/knowledge/categories"
    },
    {
      name: "FAQ Items",
      method: "GET",
      path: "/api/knowledge/faqs",
      description: "Retrieve frequently asked questions with category filtering",
      params: "category_id, search, limit",
      example: "/api/knowledge/faqs?limit=10"
    },
    {
      name: "Universal Search",
      method: "GET",
      path: "/api/knowledge/search",
      description: "Cross-platform search across all content types with intelligent ranking",
      params: "q (required), type, limit",
      example: "/api/knowledge/search?q=interview&limit=15"
    },
    {
      name: "Featured Content",
      method: "GET",
      path: "/api/knowledge/featured",
      description: "Get popular and featured content for homepage display",
      params: "type, limit",
      example: "/api/knowledge/featured?type=articles&limit=5"
    },
    {
      name: "Analytics Stats",
      method: "GET",
      path: "/api/knowledge/stats",
      description: "Comprehensive analytics and statistics (admin required)",
      params: "None",
      example: "/api/knowledge/stats"
    }
  ];

  const platforms = [
    {
      name: "ResumeFormatter.io",
      description: "Professional resume optimization and formatting platform",
      color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      features: ["Resume parsing", "ATS optimization", "Template library", "Export formats"]
    },
    {
      name: "PrepPair.me", 
      description: "AI-powered interview preparation and career development",
      color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      features: ["Interview practice", "Video analysis", "Career guidance", "Skill assessment"]
    },
    {
      name: "NameDrop.cv",
      description: "Professional networking and career opportunity platform",
      color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200", 
      features: ["Network building", "Opportunity matching", "Profile optimization", "Connection tracking"]
    }
  ];

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
          Unified Support System Documentation
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Comprehensive knowledge base API for Wrelik.com cross-platform integration
        </p>
        <div className="flex justify-center gap-2">
          <Badge variant="outline" className="text-green-600 border-green-300">
            <CheckCircle className="h-3 w-3 mr-1" />
            All Systems Operational
          </Badge>
          <Badge variant="outline" className="text-blue-600 border-blue-300">
            <Database className="h-3 w-3 mr-1" />
            6 Core Endpoints
          </Badge>
          <Badge variant="outline" className="text-purple-600 border-purple-300">
            <Users className="h-3 w-3 mr-1" />
            3 Platform Integration
          </Badge>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500 rounded-lg">
                <Globe className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900 dark:text-blue-100">Test API Endpoints</h3>
                <p className="text-sm text-blue-700 dark:text-blue-300">Interactive testing interface</p>
              </div>
              <Button variant="outline" size="sm" asChild className="ml-auto">
                <a href="/support-api-test">
                  Test API <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500 rounded-lg">
                <BarChart3 className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-green-900 dark:text-green-100">Real-time Analytics</h3>
                <p className="text-sm text-green-700 dark:text-green-300">Cross-platform metrics</p>
              </div>
              <Button variant="outline" size="sm" asChild className="ml-auto">
                <a href="/admin-dashboard">
                  View Stats <ArrowRight className="h-3 w-3 ml-1" />
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="endpoints" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="endpoints">API Endpoints</TabsTrigger>
          <TabsTrigger value="platforms">Platform Integration</TabsTrigger>
          <TabsTrigger value="authentication">Security</TabsTrigger>
          <TabsTrigger value="examples">Usage Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="endpoints" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Knowledge Base API Endpoints
              </CardTitle>
              <CardDescription>
                6 fully operational endpoints supporting ResumeFormatter.io, PrepPair.me, and NameDrop.cv
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {endpoints.map((endpoint, index) => (
                  <div key={index} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="font-mono">
                          {endpoint.method}
                        </Badge>
                        <h3 className="font-semibold">{endpoint.name}</h3>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => copyToClipboard(endpoint.example)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{endpoint.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-gray-500">Path:</span>
                        <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                          {endpoint.path}
                        </code>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-gray-500">Parameters:</span>
                        <span className="text-xs text-gray-600 dark:text-gray-400">{endpoint.params}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-gray-500">Example:</span>
                        <code className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 px-2 py-1 rounded">
                          {endpoint.example}
                        </code>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Cross-Platform Integration
              </CardTitle>
              <CardDescription>
                Unified support system serving three professional development platforms
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                {platforms.map((platform, index) => (
                  <div key={index} className="p-6 border rounded-lg">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{platform.name}</h3>
                        <p className="text-sm text-muted-foreground">{platform.description}</p>
                      </div>
                      <Badge className={platform.color}>
                        Active
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {platform.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="authentication" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security & Authentication
              </CardTitle>
              <CardDescription>
                JWT-based authentication with platform-specific validation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">JWT Token Requirements</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <code className="bg-amber-100 dark:bg-amber-800/50 px-2 py-1 rounded text-xs">aud</code>
                    <span className="text-amber-800 dark:text-amber-200">preppair.me</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="bg-amber-100 dark:bg-amber-800/50 px-2 py-1 rounded text-xs">iss</code>
                    <span className="text-amber-800 dark:text-amber-200">resumeformatter.io</span>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Public Endpoints
                  </h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Knowledge base search</li>
                    <li>• Article retrieval</li>
                    <li>• Category listings</li>
                    <li>• FAQ access</li>
                  </ul>
                </div>

                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    Protected Endpoints
                  </h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Admin statistics</li>
                    <li>• Content management</li>
                    <li>• Analytics data</li>
                    <li>• Bulk operations</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="examples" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Implementation Examples
              </CardTitle>
              <CardDescription>
                Real-world usage patterns for Wrelik.com integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-6">
                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Basic Article Search</h4>
                    <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
{`// Search for resume-related articles
fetch('/api/knowledge/articles?search=resume&limit=10')
  .then(response => response.json())
  .then(articles => {
    console.log('Found articles:', articles.length);
    articles.forEach(article => {
      console.log(article.title, article.category);
    });
  });`}
                    </pre>
                  </div>

                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Cross-Platform Search</h4>
                    <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
{`// Universal search across all content types
fetch('/api/knowledge/search?q=interview%20preparation&limit=15')
  .then(response => response.json())
  .then(results => {
    console.log('Articles found:', results.articles.length);
    console.log('FAQs found:', results.faqs.length);
  });`}
                    </pre>
                  </div>

                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Category-Filtered Content</h4>
                    <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
{`// Get articles in specific category
fetch('/api/knowledge/articles?category_id=1&status=published')
  .then(response => response.json())
  .then(articles => {
    articles.forEach(article => {
      console.log(article.title, article.view_count);
    });
  });`}
                    </pre>
                  </div>

                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <h4 className="font-semibold mb-2">Featured Content for Homepage</h4>
                    <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded overflow-x-auto">
{`// Get featured articles for homepage display
fetch('/api/knowledge/featured?type=articles&limit=5')
  .then(response => response.json())
  .then(featured => {
    featured.forEach(article => {
      console.log(article.title, article.helpful_count);
    });
  });`}
                    </pre>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* System Status */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500 rounded-full">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  System Status: Fully Operational
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  All 6 knowledge base endpoints tested and verified • Cross-platform integration active
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Clock className="h-4 w-4" />
                Last verified: {new Date().toLocaleString()}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}