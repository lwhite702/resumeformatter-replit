import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CheckCircle, Target, Zap, Shield, Clock, Award, ArrowRight, Star } from "lucide-react";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";

export default function AdsLanding() {
  const [email, setEmail] = useState("");
  const [, setLocation] = useLocation();

  const handleGetStarted = () => {
    setLocation("/sign-up?utm_source=ads&utm_campaign=landing");
  };

  const benefits = [
    {
      icon: Target,
      title: "3x Higher Interview Rate",
      description: "Our AI optimization increases your chances of getting interviews",
      metric: "300%"
    },
    {
      icon: Zap,
      title: "Land Job in 30 Days",
      description: "Average time to job offer for PrepPair users",
      metric: "30 days"
    },
    {
      icon: Award,
      title: "95% Success Rate",
      description: "Users who complete our program get job offers",
      metric: "95%"
    }
  ];

  const features = [
    "AI-powered resume optimization with ATS scoring",
    "Mock interviews with real-time feedback",
    "Job application tracking and analytics",
    "Industry-specific question databases",
    "Salary negotiation guidance",
    "Career path planning and visualization"
  ];

  const urgencyFeatures = [
    {
      icon: Clock,
      title: "Limited Time Offer",
      description: "50% off premium features - expires soon!"
    },
    {
      icon: Shield,
      title: "Risk-Free Trial",
      description: "7-day money-back guarantee"
    },
    {
      icon: Star,
      title: "Join 50,000+ Users",
      description: "Don't miss out on career success"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-pink-100 dark:from-gray-900 dark:via-orange-900 dark:to-red-900">
      <NavigationHeader />
      
      {/* Hero Section with Urgency */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="destructive" className="mb-6 bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 animate-pulse">
              🔥 Limited Time: 50% OFF Premium Features
            </Badge>
            
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Get Your Dream Job
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600">
                3X Faster
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              AI-powered career platform that guarantees results. Join 50,000+ professionals who transformed their careers.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <Button 
                size="lg" 
                onClick={handleGetStarted}
                className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white px-8 py-4 text-lg font-semibold"
              >
                Claim 50% Discount Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>

            <p className="text-sm text-gray-500 dark:text-gray-400">
              ⏰ Offer expires in 24 hours • No credit card required
            </p>
          </div>

          {/* Key Benefits */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-xl text-center">
                  <CardContent className="pt-8">
                    <Icon className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                    <div className="text-3xl font-bold text-orange-600 mb-2">{benefit.metric}</div>
                    <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400">{benefit.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Social Proof & Testimonials */}
      <section className="py-16 px-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Proven Results That Speak for Themselves
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Real success stories from professionals like you
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                    JD
                  </div>
                  <div>
                    <div className="font-semibold">John Davis</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Software Engineer → Meta</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  "Landed a $180k offer at Meta in just 3 weeks. The interview prep was incredible!"
                </p>
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                    AL
                  </div>
                  <div>
                    <div className="font-semibold">Amanda Lee</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Marketing → Google</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  "Went from 0 interviews to 5 offers. PrepPair changed my entire career trajectory."
                </p>
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                    MR
                  </div>
                  <div>
                    <div className="font-semibold">Mike Rodriguez</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Data Scientist → Netflix</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  "40% salary increase and dream job at Netflix. Best investment I ever made!"
                </p>
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features List */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Everything You Need to Land Your Dream Job
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Comprehensive career tools in one powerful platform
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3 p-4 bg-white/60 dark:bg-gray-800/60 rounded-lg backdrop-blur-sm">
                <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                <span className="text-gray-700 dark:text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Urgency Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-100 to-red-100 dark:from-orange-900/20 dark:to-red-900/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Don't Miss This Opportunity
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Join thousands of professionals who transformed their careers
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {urgencyFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg text-center">
                  <CardContent className="pt-8">
                    <Icon className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Transform Your Career?
          </h2>
          <p className="text-orange-100 mb-8 text-xl">
            Join 50,000+ professionals who chose success. Limited time offer expires soon!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto mb-6">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/90 border-0"
            />
            <Button 
              onClick={handleGetStarted}
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 font-semibold"
            >
              Claim 50% OFF
            </Button>
          </div>
          
          <div className="text-orange-200 text-sm">
            <p>✅ 7-day money-back guarantee</p>
            <p>✅ No credit card required for trial</p>
            <p>✅ Cancel anytime</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}