import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMarketingAnalytics } from "@/hooks/useMarketingAnalytics";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CheckCircle, Star, Users, TrendingUp, Play, ArrowRight } from "lucide-react";
import { SiLinkedin, SiX, SiFacebook, SiInstagram } from "react-icons/si";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";

export default function SocialLanding() {
  const [email, setEmail] = useState("");
  const [, setLocation] = useLocation();
  const { trackLandingPageView, trackCTAClick, trackSignupStart } = useMarketingAnalytics();

  useEffect(() => {
    trackLandingPageView();
  }, []);

  const handleGetStarted = () => {
    trackCTAClick("hero", "Start Free Trial");
    trackSignupStart();
    setLocation("/sign-up?utm_source=social&utm_campaign=landing");
  };

  const handleWatchDemo = () => {
    trackCTAClick("hero", "Watch Demo");
  };

  const handleEmailSignup = () => {
    if (email) {
      trackCTAClick("cta_section", "Get Started Free");
      trackSignupStart();
      setLocation("/sign-up?utm_source=social&utm_campaign=landing&email=" + encodeURIComponent(email));
    }
  };

  const socialProof = [
    { platform: "LinkedIn", icon: SiLinkedin, users: "50K+", color: "text-blue-600" },
    { platform: "X (Twitter)", icon: SiX, users: "25K+", color: "text-sky-500" },
    { platform: "Instagram", icon: SiInstagram, users: "15K+", color: "text-pink-500" },
    { platform: "Facebook", icon: SiFacebook, users: "30K+", color: "text-blue-700" }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Software Engineer",
      avatar: "SC",
      content: "PrepPair helped me land my dream job at Google! The AI interview prep was game-changing.",
      platform: "LinkedIn"
    },
    {
      name: "Marcus Rodriguez",
      role: "Product Manager",
      avatar: "MR", 
      content: "The video practice sessions gave me the confidence I needed. Got 3 offers in 2 weeks!",
      platform: "X (Twitter)"
    },
    {
      name: "Emily Watson",
      role: "Data Scientist",
      avatar: "EW",
      content: "Resume optimization increased my interview rate by 300%. This platform works!",
      platform: "Instagram"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900">
      <NavigationHeader />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge variant="secondary" className="mb-6 bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300">
            🚀 Trending on Social Media
          </Badge>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Land Your Dream Job
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600">
              Like 50,000+ Others
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Join the career transformation movement that's taking social media by storm. 
            AI-powered interview prep that actually works.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              size="lg" 
              onClick={handleGetStarted}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 text-lg"
            >
              Start Free Trial
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-3 text-lg" onClick={handleWatchDemo}>
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>

          {/* Social Proof */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {socialProof.map((social) => {
              const Icon = social.icon;
              return (
                <Card key={social.platform} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="pt-6 text-center">
                    <Icon className={`h-8 w-8 mx-auto mb-2 ${social.color}`} />
                    <div className="font-bold text-2xl">{social.users}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">followers</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Social Testimonials */}
      <section className="py-16 px-4 bg-white/40 dark:bg-gray-800/40 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              What People Are Saying
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Real success stories from our social media community
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">{testimonial.role}</div>
                    </div>
                    <Badge variant="outline" className="ml-auto">
                      {testimonial.platform}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 dark:text-gray-300 italic">
                    "{testimonial.content}"
                  </p>
                  <div className="flex text-yellow-400 mt-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features for Social Users */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Why Social Media Loves PrepPair
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Features designed for the modern job seeker
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <TrendingUp className="h-8 w-8 text-purple-600 mb-2" />
                <CardTitle>Viral Success Stories</CardTitle>
                <CardDescription>
                  Share your career wins and inspire others in the community
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <Users className="h-8 w-8 text-blue-600 mb-2" />
                <CardTitle>Community Support</CardTitle>
                <CardDescription>
                  Connect with thousands of job seekers and share experiences
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <Play className="h-8 w-8 text-green-600 mb-2" />
                <CardTitle>Shareable Content</CardTitle>
                <CardDescription>
                  Create practice videos and progress updates to share online
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Join the Movement?
          </h2>
          <p className="text-purple-100 mb-8 text-lg">
            Start your free trial today and see why everyone's talking about PrepPair
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/90 border-0"
            />
            <Button 
              onClick={handleEmailSignup}
              className="bg-white text-purple-600 hover:bg-gray-100 px-8"
            >
              Get Started Free
            </Button>
          </div>
          
          <p className="text-purple-200 text-sm mt-4">
            No credit card required • 7-day free trial • Cancel anytime
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}