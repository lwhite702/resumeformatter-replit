import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CheckCircle, Building, Users, Briefcase, ArrowRight, Star, Award, Zap } from "lucide-react";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";

export default function WrelikLanding() {
  const [email, setEmail] = useState("");
  const [, setLocation] = useLocation();

  const handleGetStarted = () => {
    setLocation("/sign-up?utm_source=wrelik&utm_campaign=ecosystem");
  };

  const wrelikApps = [
    {
      name: "ResumeFormatter.io",
      description: "Professional resume formatting and design",
      users: "100K+",
      icon: Briefcase,
      color: "text-blue-600"
    },
    {
      name: "AutoApply Captain",
      description: "Automated job application management",
      users: "75K+", 
      icon: Zap,
      color: "text-green-600"
    },
    {
      name: "CareerMentor AI",
      description: "AI-powered career guidance and coaching",
      users: "50K+",
      icon: Award,
      color: "text-purple-600"
    }
  ];

  const ecosystemBenefits = [
    {
      title: "Seamless Integration",
      description: "Your data syncs automatically across all Wrelik Brands apps",
      icon: Building
    },
    {
      title: "Unified Dashboard",
      description: "Manage your entire career toolkit from one central location",
      icon: Users
    },
    {
      title: "Premium Perks",
      description: "Exclusive features and discounts across the ecosystem",
      icon: Star
    }
  ];

  const successStories = [
    {
      name: "David Park",
      role: "Senior Developer",
      company: "Microsoft",
      story: "Used ResumeFormatter.io, then PrepPair for interviews. Landed my dream job in 6 weeks!",
      avatar: "DP"
    },
    {
      name: "Lisa Chen", 
      role: "Product Manager",
      company: "Amazon",
      story: "The Wrelik ecosystem streamlined my entire job search. All tools work perfectly together.",
      avatar: "LC"
    },
    {
      name: "Alex Thompson",
      role: "Data Scientist", 
      company: "Netflix",
      story: "From resume to interview prep to job applications - everything in one place. Incredible!",
      avatar: "AT"
    }
  ];

  const features = [
    "Cross-platform data synchronization",
    "Unified career analytics and insights", 
    "Priority customer support",
    "Early access to new features",
    "Ecosystem-wide premium benefits",
    "Consolidated billing and management"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-100 dark:from-gray-900 dark:via-indigo-900 dark:to-purple-900">
      <NavigationHeader />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge variant="secondary" className="mb-6 bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300">
            <Building className="w-4 h-4 mr-2" />
            Welcome from the Wrelik Brands Ecosystem
          </Badge>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Complete Your
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              Career Transformation
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            You're already part of the Wrelik family. Now add PrepPair's AI-powered interview preparation 
            to complete your career success toolkit.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              size="lg" 
              onClick={handleGetStarted}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 text-lg"
            >
              Continue with Wrelik Account
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>

          <p className="text-sm text-gray-500 dark:text-gray-400">
            Your existing Wrelik account works seamlessly • Instant data sync
          </p>
        </div>
      </section>

      {/* Wrelik Ecosystem Apps */}
      <section className="py-16 px-4 bg-white/40 dark:bg-gray-800/40 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              You're Already in the Wrelik Family
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Join 225,000+ professionals using Wrelik Brands career tools
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {wrelikApps.map((app, index) => {
              const Icon = app.icon;
              return (
                <Card key={index} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-0 shadow-lg text-center">
                  <CardContent className="pt-8">
                    <Icon className={`h-12 w-12 mx-auto mb-4 ${app.color}`} />
                    <h3 className="text-xl font-semibold mb-2">{app.name}</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-3">{app.description}</p>
                    <div className="text-2xl font-bold text-indigo-600">{app.users}</div>
                    <div className="text-sm text-gray-500">active users</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="text-center">
            <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-0 shadow-xl max-w-2xl mx-auto">
              <CardContent className="pt-8">
                <h3 className="text-2xl font-bold mb-4">Now Add PrepPair</h3>
                <p className="text-indigo-100 mb-6">
                  Complete your career toolkit with AI-powered interview preparation. 
                  Seamlessly integrated with your existing Wrelik tools.
                </p>
                <Button 
                  onClick={handleGetStarted}
                  className="bg-white text-indigo-600 hover:bg-gray-100 px-8 py-3 font-semibold"
                >
                  Get Started Now
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Ecosystem Benefits */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Ecosystem Advantages
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Why the Wrelik Brands ecosystem is more powerful together
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {ecosystemBenefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <Icon className="h-8 w-8 text-indigo-600 mb-2" />
                    <CardTitle>{benefit.title}</CardTitle>
                    <CardDescription>{benefit.description}</CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 px-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Ecosystem Success Stories
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Real results from professionals using multiple Wrelik tools
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {successStories.map((story, index) => (
              <Card key={index} className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                      {story.avatar}
                    </div>
                    <div>
                      <div className="font-semibold">{story.name}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">{story.role} at {story.company}</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 dark:text-gray-300 mb-3 italic">
                    "{story.story}"
                  </p>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              What You Get with PrepPair
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Enhanced features when used within the Wrelik ecosystem
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3 p-4 bg-white/60 dark:bg-gray-800/60 rounded-lg backdrop-blur-sm">
                <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                <span className="text-gray-700 dark:text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 px-4 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Complete Your Toolkit?
          </h2>
          <p className="text-indigo-100 mb-8 text-xl">
            Your Wrelik account is ready. Add PrepPair in seconds and start acing interviews.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto mb-6">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/90 border-0"
            />
            <Button 
              onClick={handleGetStarted}
              className="bg-white text-indigo-600 hover:bg-gray-100 px-8 font-semibold"
            >
              Continue
            </Button>
          </div>
          
          <div className="text-indigo-200 text-sm">
            <p>Already a Wrelik user? Your data syncs automatically</p>
            <p>New to Wrelik? We'll set everything up for you</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}