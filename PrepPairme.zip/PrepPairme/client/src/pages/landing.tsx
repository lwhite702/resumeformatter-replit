import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { fetchBlogPosts, stripHtmlTags, formatDate, type WordPressBlogPost } from "@/lib/wordpress-api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, CheckCircle, Star, Users, Target, TrendingUp, Zap, Shield, Clock, Award, Brain, FileText, Video, BarChart3, Play, Upload, Sparkles, MessageSquare, Calendar, Globe, Check, X } from "lucide-react";
import { GlowCard } from "@/components/ui/spotlight-card";
import { ContainerScroll } from "@/components/ui/container-scroll-animation";
import { CTASection } from "@/components/ui/cta-section";
import { AuroraBackground } from "@/components/ui/aurora-background";
import { EnhancedBadge } from "@/components/ui/enhanced-badge";
import { Header1 } from "@/components/ui/header";
import { Footer } from "@/components/ui/footer";
import { ModalPricing } from "@/components/ui/modal-pricing";
import { Features } from "@/components/blocks/features-6";
import { BentoFeatures } from "@/components/blocks/bento-features";
import { PrepPairBlog } from "@/components/blocks/preppair-blog";
import { Cta13 } from "@/components/ui/cta-13";
import { Faq5 } from "@/components/ui/faq-5";
import PricingSectionNew from "@/components/blocks/pricing-section-new";
import { OnboardingWizard } from "@/components/onboarding-wizard";
import { NewsletterSignup } from "@/components/newsletter-signup";
import { SignedIn, SignedOut, SignInButton, SignUpButton } from "@clerk/clerk-react";
import { PrepSlogan } from "@/components/branding/PrepSlogan";

export default function Landing() {
  useScrollToTop();
  
  const [, setLocation] = useLocation();
  const [activeDemo, setActiveDemo] = useState("resume");
  const [showPricing, setShowPricing] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Fetch blog posts
  const { data: blogData, isLoading: blogLoading, error: blogError } = useQuery({
    queryKey: ['/api/blog-posts'],
    queryFn: () => fetchBlogPosts('preppair-me', 3),
    retry: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Header */}
      <Header1 />

      {/* Hero Section with Aurora Background and Container Scroll */}
      <div className="relative pt-20">
        <AuroraBackground className="h-auto min-h-screen bg-transparent">
          <ContainerScroll
          titleComponent={
            <div className="text-center max-w-4xl mx-auto">
              <div className="mb-8">
                <EnhancedBadge variant="trial" size="lg" icon={<Sparkles />}>
                  Your AI Interview Partner
                </EnhancedBadge>
              </div>
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight text-center">
                <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                  PrepPair.me
                </span>
              </h1>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                Transform Your Career Journey
              </h2>
              <PrepSlogan variant="primary" className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 mb-4 max-w-3xl mx-auto leading-relaxed text-center font-medium" />
              <p className="text-base sm:text-lg text-gray-500 dark:text-gray-400 mb-8 max-w-3xl mx-auto leading-relaxed text-center">
                Practice with AI, optimize your resume, track applications, and land your dream job with confidence. 
                We're your personal interview partner every step of the way.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-lg px-8 py-6 shadow-lg transform hover:scale-105 transition-all duration-200" asChild>
                  <a href="/api/login">
                    Start Your Journey <ArrowRight className="ml-2 h-5 w-5" />
                  </a>
                </Button>
                <Button variant="outline" size="lg" className="border-2 border-purple-600 text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900 text-lg px-8 py-6 transform hover:scale-105 transition-all duration-200" onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}>
                  <Play className="mr-2 h-5 w-5" />
                  Explore Features
                </Button>
              </div>
            <div className="flex flex-wrap items-center justify-center gap-6">
              <div className="flex items-center bg-green-50 dark:bg-green-900/20 px-4 py-2 rounded-full shadow-sm">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span className="text-green-700 dark:text-green-300 font-medium">Free trial available</span>
              </div>
              <div className="flex items-center bg-blue-50 dark:bg-blue-900/20 px-4 py-2 rounded-full shadow-sm">
                <Users className="h-5 w-5 text-blue-500 mr-2" />
                <span className="text-blue-700 dark:text-blue-300 font-medium">10,000+ users</span>
              </div>
              <div className="flex items-center bg-yellow-50 dark:bg-yellow-900/20 px-4 py-2 rounded-full shadow-sm">
                <Star className="h-5 w-5 text-yellow-500 mr-2" />
                <span className="text-yellow-700 dark:text-yellow-300 font-medium">4.9/5 rating</span>
              </div>
            </div>
          </div>
        }
      >
        <div className="bg-gradient-to-br from-blue-100 via-purple-50 to-pink-100 dark:from-blue-900 dark:via-purple-900 dark:to-pink-900 rounded-2xl p-6 h-full flex flex-col">
          {/* Feature Icons */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md text-center">
              <Brain className="h-6 w-6 text-purple-600 mx-auto mb-1" />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">AI Practice</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md text-center">
              <FileText className="h-6 w-6 text-blue-600 mx-auto mb-1" />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Resume Optimizer</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md text-center">
              <Video className="h-6 w-6 text-green-600 mx-auto mb-1" />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Video Practice</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-md text-center">
              <BarChart3 className="h-6 w-6 text-orange-600 mx-auto mb-1" />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Job Tracking</span>
            </div>
          </div>

          {/* Interactive Demo */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg flex-1">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">Try Our AI Interview Assistant</h3>
              <EnhancedBadge variant="purple-subtle" size="sm">Live Demo</EnhancedBadge>
            </div>
            
            <Tabs value={activeDemo} onValueChange={setActiveDemo} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="resume" className="text-xs">Resume</TabsTrigger>
                <TabsTrigger value="interview" className="text-xs">Interview</TabsTrigger>
                <TabsTrigger value="tracking" className="text-xs">Tracking</TabsTrigger>
              </TabsList>
              
              <TabsContent value="resume" className="space-y-3 mt-4">
                <div className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Upload your resume for instant ATS analysis
                </div>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                  <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-xs text-gray-500 dark:text-gray-400">Click to upload or drag & drop</p>
                </div>
                <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium text-green-800 dark:text-green-300">ATS Score: 85%</span>
                  </div>
                  <p className="text-xs text-green-700 dark:text-green-400">Strong keyword match for Software Engineer roles</p>
                </div>
              </TabsContent>
              
              <TabsContent value="interview" className="space-y-3 mt-4">
                <div className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Practice with AI-generated questions
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
                    "Tell me about a challenging project you worked on."
                  </p>
                  <Button size="sm" className="w-full text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Generate STAR Response
                  </Button>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <Clock className="h-3 w-3" />
                  <span>Practice time: 2-5 minutes</span>
                </div>
              </TabsContent>
              
              <TabsContent value="tracking" className="space-y-3 mt-4">
                <div className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Track your application pipeline
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                    <span className="text-xs font-medium">Google - SWE</span>
                    <Badge variant="outline" className="text-xs">Interview</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded">
                    <span className="text-xs font-medium">Meta - Frontend</span>
                    <Badge variant="outline" className="text-xs">Applied</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                    <span className="text-xs font-medium">Microsoft - PM</span>
                    <Badge variant="outline" className="text-xs">Screening</Badge>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <SignedIn>
              <Button className="w-full mt-4 text-sm" onClick={() => setLocation('/dashboard')}>
                Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </SignedIn>
            <SignedOut>
              <SignUpButton>
                <Button className="w-full mt-4 text-sm">
                  Try Full Platform <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </SignUpButton>
            </SignedOut>
          </div>
        </div>
          </ContainerScroll>
        </AuroraBackground>
      </div>

      {/* New Features Section */}
      <Features />

      {/* Bento Grid Features */}
      <BentoFeatures />

      {/* Pricing Section */}
      <PricingSectionNew />

      {/* Spotlight Features Section */}
      <section id="features" className="py-20 bg-gradient-to-b from-white to-blue-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <EnhancedBadge variant="turbo" size="lg" icon={<Sparkles />}>
              Your Complete Career Partner
            </EnhancedBadge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6 text-center">
              <span className="bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Everything You Need
              </span>
              <br />
              <span className="text-gray-900 dark:text-white">
                to Land Your Dream Job
              </span>
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed text-center">
              Your AI interview partner covers every aspect of your career journey with intelligent tools and guidance
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-8">
            
            {/* AI Resume Optimization */}
            <GlowCard customSize>
              <div className="p-8 text-center">
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 w-fit mx-auto mb-6 shadow-lg">
                  <FileText className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">AI Resume Optimization</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg leading-relaxed max-w-2xl mx-auto">
                  Get instant ATS compatibility scoring, keyword optimization, and personalized improvement suggestions that actually work.
                </p>
                <div className="flex flex-wrap gap-3 justify-center">
                  <div className="flex items-center bg-blue-50 dark:bg-blue-900/20 px-4 py-2 rounded-full">
                    <Zap className="h-4 w-4 mr-2 text-blue-500" />
                    <span className="text-blue-700 dark:text-blue-300 font-medium">Instant Analysis</span>
                  </div>
                  <div className="flex items-center bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2 rounded-full">
                    <Target className="h-4 w-4 mr-2 text-emerald-500" />
                    <span className="text-emerald-700 dark:text-emerald-300 font-medium">ATS Optimized</span>
                  </div>
                  <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 px-4 py-2 rounded-full">
                    <TrendingUp className="h-4 w-4 mr-2 text-purple-500" />
                    <span className="text-purple-700 dark:text-purple-300 font-medium">Score Tracking</span>
                  </div>
                </div>
              </div>
            </GlowCard>

            {/* AI Interview Practice */}
            <GlowCard customSize>
              <div className="p-8 text-center">
                <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-4 w-fit mx-auto mb-6 shadow-lg">
                  <MessageSquare className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">AI Interview Practice</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg leading-relaxed max-w-2xl mx-auto">
                  Practice with AI-generated questions, get STAR method guidance, and receive personalized feedback to ace any interview.
                </p>
                <div className="flex flex-wrap gap-3 justify-center">
                  <div className="flex items-center bg-purple-50 dark:bg-purple-900/20 px-4 py-2 rounded-full">
                    <Brain className="h-4 w-4 mr-2 text-purple-500" />
                    <span className="text-purple-700 dark:text-purple-300 font-medium">AI Questions</span>
                  </div>
                  <div className="flex items-center bg-pink-50 dark:bg-pink-900/20 px-4 py-2 rounded-full">
                    <Star className="h-4 w-4 mr-2 text-pink-500" />
                    <span className="text-pink-700 dark:text-pink-300 font-medium">STAR Method</span>
                  </div>
                  <div className="flex items-center bg-indigo-50 dark:bg-indigo-900/20 px-4 py-2 rounded-full">
                    <Video className="h-4 w-4 mr-2 text-indigo-500" />
                    <span className="text-indigo-700 dark:text-indigo-300 font-medium">Video Practice</span>
                  </div>
                </div>
              </div>
            </GlowCard>

            {/* Smart Job Tracking */}
            <GlowCard customSize>
              <div className="p-8 text-center">
                <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 w-fit mx-auto mb-6 shadow-lg">
                  <BarChart3 className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">Smart Job Tracking</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg leading-relaxed max-w-2xl mx-auto">
                  Centralize your job applications with automated status updates, progress analytics, and intelligent insights.
                </p>
                <div className="flex flex-wrap gap-3 justify-center">
                  <div className="flex items-center bg-green-50 dark:bg-green-900/20 px-4 py-2 rounded-full">
                    <Calendar className="h-4 w-4 mr-2 text-green-500" />
                    <span className="text-green-700 dark:text-green-300 font-medium">Auto Updates</span>
                  </div>
                  <div className="flex items-center bg-teal-50 dark:bg-teal-900/20 px-4 py-2 rounded-full">
                    <TrendingUp className="h-4 w-4 mr-2 text-teal-500" />
                    <span className="text-teal-700 dark:text-teal-300 font-medium">Analytics</span>
                  </div>
                  <div className="flex items-center bg-cyan-50 dark:bg-cyan-900/20 px-4 py-2 rounded-full">
                    <Globe className="h-4 w-4 mr-2 text-cyan-500" />
                    <span className="text-cyan-700 dark:text-cyan-300 font-medium">Multi-Platform</span>
                  </div>
                </div>
              </div>
            </GlowCard>
          </div>
        </div>
      </section>

      {/* Pricing Modal */}
      <Dialog open={showPricing} onOpenChange={setShowPricing}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">Choose Your Plan</DialogTitle>
            <DialogDescription className="text-center">
              Start free and upgrade as you grow your career
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <Card className="relative">
              <CardHeader>
                <CardTitle>Free</CardTitle>
                <CardDescription>Perfect for getting started</CardDescription>
                <div className="text-3xl font-bold">$0<span className="text-base font-normal">/month</span></div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">5 resume analyses</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">10 interview questions</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Basic job tracking</span>
                  </div>
                </div>
                <Button className="w-full" asChild>
                  <a href="/api/login">Get Started Free</a>
                </Button>
              </CardContent>
            </Card>

            <Card className="relative border-purple-200 dark:border-purple-800">
              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-purple-600 text-white">Most Popular</Badge>
              </div>
              <CardHeader>
                <CardTitle>Pro</CardTitle>
                <CardDescription>For serious job seekers</CardDescription>
                <div className="text-3xl font-bold">$19<span className="text-base font-normal">/month</span></div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Unlimited resume analyses</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Unlimited AI questions</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Video interview practice</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Advanced job tracking</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Priority support</span>
                  </div>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700" asChild>
                  <a href="/api/login">Start Pro Trial</a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* Blog Preview Section */}
      <PrepPairBlog 
        posts={blogData?.posts ? blogData.posts.slice(0, 3).map((post: WordPressBlogPost) => ({
          id: post.id.toString(),
          title: stripHtmlTags(post.title.rendered),
          summary: stripHtmlTags(post.excerpt.rendered),
          label: "Career Tips",
          author: "PrepPair Team",
          published: formatDate(post.date),
          url: post.link,
          image: post._embedded?.['wp:featuredmedia']?.[0]?.source_url || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&h=450&fit=crop"
        })) : undefined}
        isLoading={blogLoading}
        hasError={!!blogError}
      />

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white dark:from-gray-800 dark:to-gray-900">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <NewsletterSignup variant="landing" className="mx-auto" />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <Faq5 />

      {/* Newsletter CTA */}
      <Cta13 />

      {/* Call to Action Section */}
      <section className="py-20 bg-gradient-to-b from-purple-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-6 text-center">
          <EnhancedBadge
            variant="blue-subtle"
            size="md"
            className="mb-8"
          >
            Get Started Today
          </EnhancedBadge>
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
            Ready to Land Your Dream Job?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who've transformed their careers with PrepPair.me
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button 
              size="lg" 
              onClick={() => setShowOnboarding(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Get Personalized Plan
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="/api/login">Start Free Trial</a>
            </Button>
            <ModalPricing />
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            No credit card required • 7-day free trial
          </p>
        </div>
      </section>

      {/* Footer */}
      <Footer />

      {/* Onboarding Wizard */}
      <OnboardingWizard
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
        onComplete={() => {
          setShowOnboarding(false);
          // User will be redirected to dashboard via the wizard
        }}
      />
    </div>
  );
}