import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Shield, FileText, Cookie, Clock, Mail } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface LegalDocument {
  id: string;
  title: string;
  content: string;
  lastUpdated: string;
  icon: any;
  description: string;
}

export default function Legal() {
  useScrollToTop();
  const [activeSection, setActiveSection] = useState<string>("privacy-policy");

  // Fetch legal pages from WordPress CMS with variable substitution
  const { data: legalData, isLoading, error } = useQuery({
    queryKey: ['/api/legal-pages'],
    queryFn: async () => {
      const response = await fetch('/api/legal-pages');
      if (!response.ok) {
        throw new Error('Failed to fetch legal pages');
      }
      return response.json();
    },
    retry: 1,
  });

  // Map WordPress pages to legal documents structure
  const getPageBySlug = (slug: string) => {
    return legalData?.pages?.find((page: any) => page.slug === slug);
  };

  const legalDocuments: LegalDocument[] = [
    {
      id: "privacy-policy",
      title: "Privacy Policy",
      content: getPageBySlug("privacy-policy")?.content || "Loading privacy policy from WordPress...",
      lastUpdated: getPageBySlug("privacy-policy")?.lastModified ? new Date(getPageBySlug("privacy-policy").lastModified).toLocaleDateString() : "June 18, 2025",
      icon: Shield,
      description: "How we collect, use, and protect your personal information"
    },
    {
      id: "terms-of-service",
      title: "Terms of Service",
      content: getPageBySlug("terms-of-service")?.content || "Loading terms of service from WordPress...",
      lastUpdated: getPageBySlug("terms-of-service")?.lastModified ? new Date(getPageBySlug("terms-of-service").lastModified).toLocaleDateString() : "June 18, 2025",
      icon: FileText,
      description: "The rules and regulations for using our platform"
    },
    {
      id: "cookie-policy",
      title: "Cookie Policy",
      content: getPageBySlug("cookie-policy")?.content || "Loading cookie policy from WordPress...",
      lastUpdated: getPageBySlug("cookie-policy")?.lastModified ? new Date(getPageBySlug("cookie-policy").lastModified).toLocaleDateString() : "June 18, 2025",
      icon: Cookie,
      description: "How we use cookies and tracking technologies"
    },
    {
      id: "gdpr-compliance",
      title: "GDPR Compliance",
      content: getPageBySlug("gdpr-compliance")?.content || "Loading GDPR compliance from WordPress...",
      lastUpdated: getPageBySlug("gdpr-compliance")?.lastModified ? new Date(getPageBySlug("gdpr-compliance").lastModified).toLocaleDateString() : "June 18, 2025",
      icon: Clock,
      description: "How we comply with GDPR and data protection regulations"
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
        <NavigationHeader />
        <div className="container mx-auto px-4 pt-24 pb-16">
          <div className="max-w-4xl mx-auto">
            <Skeleton className="h-12 w-64 mb-4" />
            <Skeleton className="h-6 w-96 mb-8" />
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <NavigationHeader />
      
      <div className="container mx-auto px-4 pt-24 pb-16">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Legal Information
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
              Our commitment to transparency and your rights
            </p>
            <Badge variant="outline" className="bg-white/50 dark:bg-gray-800/50">
              Last updated: June 18, 2025
            </Badge>
          </div>

          {/* Quick Contact */}
          <Card className="mb-8 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-blue-600" />
                Have Questions?
              </CardTitle>
              <CardDescription>
                Contact our privacy team at privacy@preppair.me for any questions about these policies.
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Legal Documents Accordion */}
          <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Legal Documents</CardTitle>
              <CardDescription>
                Click on any section below to read the full details
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible value={activeSection} onValueChange={setActiveSection}>
                {legalDocuments.map((doc) => {
                  const Icon = doc.icon;
                  return (
                    <AccordionItem key={doc.id} value={doc.id}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center gap-3 text-left">
                          <Icon className="h-5 w-5 text-blue-600 flex-shrink-0" />
                          <div>
                            <div className="font-semibold">{doc.title}</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {doc.description}
                            </div>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pt-4 pb-2">
                          <div className="prose prose-gray dark:prose-invert max-w-none">
                            <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-lg">
                              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                                Last updated: {doc.lastUpdated}
                              </div>
                              <div 
                                className="whitespace-pre-wrap leading-relaxed prose prose-gray dark:prose-invert max-w-none"
                                dangerouslySetInnerHTML={{ __html: doc.content }}
                              />
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  );
                })}
              </Accordion>
            </CardContent>
          </Card>

          {/* Footer Note */}
          <div className="text-center mt-12 text-sm text-gray-500 dark:text-gray-400">
            <p>
              These policies are part of the Wrelik Brands ecosystem and are regularly updated to reflect 
              current practices and regulations. For the most current version, please visit this page.
            </p>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}