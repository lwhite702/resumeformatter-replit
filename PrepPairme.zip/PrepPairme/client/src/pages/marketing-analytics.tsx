import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, Users, MousePointerClick, DollarSign, Target, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function MarketingAnalytics() {
  const [dateRange, setDateRange] = useState("30");
  const [selectedChannel, setSelectedChannel] = useState("all");

  // Fetch marketing analytics data
  const { data: analyticsData, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/marketing/analytics', { 
      startDate: new Date(Date.now() - parseInt(dateRange) * 24 * 60 * 60 * 1000).toISOString(),
      endDate: new Date().toISOString(),
      channel: selectedChannel === 'all' ? undefined : selectedChannel
    }],
    retry: 1,
  });

  // Fetch conversion funnel data
  const { data: funnelData, isLoading: funnelLoading } = useQuery({
    queryKey: ['/api/marketing/funnel', {
      startDate: new Date(Date.now() - parseInt(dateRange) * 24 * 60 * 60 * 1000).toISOString(),
      endDate: new Date().toISOString(),
      channel: selectedChannel === 'all' ? undefined : selectedChannel
    }],
    retry: 1,
  });

  // Fetch channel performance data
  const { data: channelsData, isLoading: channelsLoading } = useQuery({
    queryKey: ['/api/marketing/channels', {
      startDate: new Date(Date.now() - parseInt(dateRange) * 24 * 60 * 60 * 1000).toISOString(),
      endDate: new Date().toISOString()
    }],
    retry: 1,
  });

  const isLoading = analyticsLoading || funnelLoading || channelsLoading;

  // Mock data for development (replace with actual API data)
  const mockChannelData = [
    { channel: 'social', visitors: 12500, signups: 875, conversions: 156, revenue: 15600, color: '#8B5CF6' },
    { channel: 'ads', visitors: 8900, signups: 623, conversions: 134, revenue: 20100, color: '#F59E0B' },
    { channel: 'wrelik', visitors: 5600, signups: 392, conversions: 89, revenue: 13350, color: '#10B981' },
    { channel: 'organic', visitors: 3200, signups: 224, conversions: 67, revenue: 10050, color: '#3B82F6' },
    { channel: 'referral', visitors: 1800, signups: 126, conversions: 34, revenue: 5100, color: '#EF4444' }
  ];

  const mockFunnelData = [
    { step: 'Landing Page Views', count: 32000, percentage: 100, color: '#E5E7EB' },
    { step: 'Sign Up Started', count: 2240, percentage: 7.0, color: '#C3B5F7' },
    { step: 'Sign Up Completed', count: 1568, percentage: 4.9, color: '#A78BFA' },
    { step: 'Trial Started', count: 941, percentage: 2.9, color: '#8B5CF6' },
    { step: 'Purchased', count: 480, percentage: 1.5, color: '#7C3AED' }
  ];

  const mockTrendData = [
    { date: '2025-01-01', social: 120, ads: 89, wrelik: 56, organic: 32 },
    { date: '2025-01-02', social: 132, ads: 95, wrelik: 61, organic: 28 },
    { date: '2025-01-03', social: 125, ads: 101, wrelik: 58, organic: 35 },
    { date: '2025-01-04', social: 145, ads: 87, wrelik: 63, organic: 41 },
    { date: '2025-01-05', social: 156, ads: 112, wrelik: 67, organic: 38 },
    { date: '2025-01-06', social: 134, ads: 98, wrelik: 59, organic: 33 },
    { date: '2025-01-07', social: 167, ads: 125, wrelik: 72, organic: 45 }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
        <NavigationHeader />
        <div className="container mx-auto px-4 pt-24 pb-16">
          <div className="max-w-7xl mx-auto">
            <Skeleton className="h-12 w-96 mb-8" />
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </div>
            <Skeleton className="h-96 mb-8" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <NavigationHeader />
      
      <div className="container mx-auto px-4 pt-24 pb-16">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                Marketing Analytics
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-300">
                Track conversion performance across acquisition channels
              </p>
            </div>
            
            <div className="flex gap-4 mt-4 lg:mt-0">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={selectedChannel} onValueChange={setSelectedChannel}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Channels</SelectItem>
                  <SelectItem value="social">Social Media</SelectItem>
                  <SelectItem value="ads">Paid Ads</SelectItem>
                  <SelectItem value="wrelik">Wrelik Ecosystem</SelectItem>
                  <SelectItem value="organic">Organic Search</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Visitors</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {mockChannelData.reduce((sum, channel) => sum + channel.visitors, 0).toLocaleString()}
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    +12.5% vs last period
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Signups</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {mockChannelData.reduce((sum, channel) => sum + channel.signups, 0).toLocaleString()}
                    </p>
                  </div>
                  <MousePointerClick className="h-8 w-8 text-purple-600" />
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    +8.3% vs last period
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Conversions</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {mockChannelData.reduce((sum, channel) => sum + channel.conversions, 0).toLocaleString()}
                    </p>
                  </div>
                  <Target className="h-8 w-8 text-green-600" />
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    +15.7% vs last period
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Revenue</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      ${mockChannelData.reduce((sum, channel) => sum + channel.revenue, 0).toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-yellow-600" />
                </div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    +22.1% vs last period
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analytics Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 lg:w-96">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="channels">Channels</TabsTrigger>
              <TabsTrigger value="funnel">Funnel</TabsTrigger>
              <TabsTrigger value="trends">Trends</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Channel Performance */}
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Channel Performance Overview</CardTitle>
                  <CardDescription>
                    Compare performance metrics across all acquisition channels
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={mockChannelData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="channel" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="visitors" fill="#8B5CF6" name="Visitors" />
                        <Bar dataKey="signups" fill="#10B981" name="Signups" />
                        <Bar dataKey="conversions" fill="#F59E0B" name="Conversions" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="channels" className="space-y-6">
              {/* Channel Details */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {mockChannelData.map((channel) => (
                  <Card key={channel.channel} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span className="capitalize">{channel.channel}</span>
                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: channel.color }} />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Visitors</span>
                          <span className="font-semibold">{channel.visitors.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Signups</span>
                          <span className="font-semibold">{channel.signups.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Conversions</span>
                          <span className="font-semibold">{channel.conversions.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Revenue</span>
                          <span className="font-semibold">${channel.revenue.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Conversion Rate</span>
                          <span className="font-semibold">
                            {((channel.conversions / channel.visitors) * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="funnel" className="space-y-6">
              {/* Conversion Funnel */}
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Conversion Funnel</CardTitle>
                  <CardDescription>
                    Track user journey from landing page to purchase
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockFunnelData.map((step, index) => (
                      <div key={step.step} className="relative">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{step.step}</span>
                          <div className="flex items-center gap-4">
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {step.count.toLocaleString()} ({step.percentage}%)
                            </span>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-6">
                          <div 
                            className="h-6 rounded-full transition-all duration-500"
                            style={{ 
                              width: `${step.percentage}%`,
                              backgroundColor: step.color
                            }}
                          />
                        </div>
                        {index < mockFunnelData.length - 1 && (
                          <div className="text-center text-sm text-gray-500 mt-2">
                            {(((mockFunnelData[index + 1].count / step.count) * 100)).toFixed(1)}% continue
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="trends" className="space-y-6">
              {/* Trends Chart */}
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Channel Trends</CardTitle>
                  <CardDescription>
                    Daily conversion trends across channels
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={mockTrendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" tickFormatter={(date) => new Date(date).toLocaleDateString()} />
                        <YAxis />
                        <Tooltip labelFormatter={(date) => new Date(date).toLocaleDateString()} />
                        <Line type="monotone" dataKey="social" stroke="#8B5CF6" strokeWidth={2} name="Social" />
                        <Line type="monotone" dataKey="ads" stroke="#F59E0B" strokeWidth={2} name="Ads" />
                        <Line type="monotone" dataKey="wrelik" stroke="#10B981" strokeWidth={2} name="Wrelik" />
                        <Line type="monotone" dataKey="organic" stroke="#3B82F6" strokeWidth={2} name="Organic" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Footer />
    </div>
  );
}