import { useScrollToTop } from "@/hooks/useScrollToTop";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { NewsletterSignup } from "@/components/newsletter-signup";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Mail, Brain, Target, Users, TrendingUp, Star, CheckCircle, Clock, Zap } from "lucide-react";

export default function Newsletter() {
  // Scroll to top when component mounts
  useScrollToTop();

  const benefits = [
    {
      icon: Brain,
      title: "AI-Powered Insights",
      description: "Get smart interview strategies and talking points generated specifically for trending job roles."
    },
    {
      icon: Target,
      title: "Expert Interview Tips",
      description: "Learn proven techniques from career coaches and hiring managers that actually work."
    },
    {
      icon: Users,
      title: "Community Success Stories",
      description: "Read real stories from job seekers who landed their dream roles using our strategies."
    },
    {
      icon: TrendingUp,
      title: "Industry Trends",
      description: "Stay ahead with the latest hiring trends, salary insights, and in-demand skills."
    },
    {
      icon: CheckCircle,
      title: "Ready-to-Use Templates",
      description: "Download thank-you note templates, resume formats, and follow-up email scripts."
    },
    {
      icon: Zap,
      title: "Quick Wins",
      description: "Get actionable tips you can implement immediately to improve your interview performance."
    }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Software Engineer",
      quote: "The AI interview tips helped me land a senior role at a top tech company. The strategies actually work!",
      rating: 5
    },
    {
      name: "Marcus Rodriguez",
      role: "Product Manager",
      quote: "The weekly newsletter keeps me motivated and the templates saved me hours of preparation time.",
      rating: 5
    },
    {
      name: "Emily Johnson",
      role: "Marketing Director",
      quote: "I love the real success stories and industry insights. It's like having a career coach in my inbox.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-purple-900 dark:via-blue-900 dark:to-pink-900 py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-purple-100 dark:bg-purple-900/30 rounded-full p-4">
              <Mail className="h-12 w-12 text-purple-600" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            📬 The Job Jumpstart
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Smart interview prep in your inbox — tips, templates, and encouragement from your friendly AI sidekick.
          </p>
          
          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 mb-12">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">12,000+</div>
              <div className="text-gray-600 dark:text-gray-300">Subscribers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">89%</div>
              <div className="text-gray-600 dark:text-gray-300">Read Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">Weekly</div>
              <div className="text-gray-600 dark:text-gray-300">Delivery</div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <NewsletterSignup variant="landing" className="mb-12" />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              What You'll Get Every Week
            </h2>
            <p className="text-gray-600 dark:text-gray-300 text-lg max-w-2xl mx-auto">
              Join thousands of job seekers who are leveling up their interview game with our weekly insights.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg p-2">
                      <benefit.icon className="h-6 w-6 text-purple-600" />
                    </div>
                    <CardTitle className="text-lg">{benefit.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    {benefit.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              What Our Subscribers Say
            </h2>
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              Real feedback from job seekers who've transformed their careers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="h-full">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <blockquote className="text-gray-600 dark:text-gray-300 mb-4">
                    "{testimonial.quote}"
                  </blockquote>
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {testimonial.role}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-gradient-to-br from-purple-600 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Level Up Your Interview Game?
          </h2>
          <p className="text-purple-100 text-lg mb-8 max-w-2xl mx-auto">
            Join 12,000+ job seekers who get our weekly newsletter with smart strategies, 
            templates, and the motivation to land their dream job.
          </p>
          <div className="max-w-md mx-auto">
            <NewsletterSignup variant="popup" className="mb-6" />
          </div>
          <div className="flex flex-wrap justify-center gap-6 text-purple-100 text-sm">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              <span>5-minute read</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              <span>Actionable tips</span>
            </div>
            <div className="flex items-center">
              <Mail className="h-4 w-4 mr-2" />
              <span>Unsubscribe anytime</span>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}