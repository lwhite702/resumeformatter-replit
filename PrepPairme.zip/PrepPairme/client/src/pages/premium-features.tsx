import { NavigationHeader } from "@/components/navigation-header-new";
import { PrepSlogan } from "@/components/branding/PrepSlogan";
import { Footer } from "@/components/ui/footer";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BlurredContent } from "@/components/ui/blurred-content";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Brain, 
  Camera, 
  FileText, 
  Target, 
  TrendingUp,
  Users,
  Zap
} from "lucide-react";
import { FEATURE_SLUGS } from "@/hooks/useFeatureAccess";

export default function PremiumFeatures() {
  useScrollToTop();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />
      
      <main className="pt-16 lg:pt-20">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <PrepSlogan />
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Premium Features
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Experience advanced AI-powered career development tools. Preview features below to see what's available with our premium plans.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            
            {/* AI Interview Guides */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.AI_INTERVIEW_GUIDES}
              featureName="AI Interview Guides"
              requiredPlan="Professional Plan"
              className="h-full"
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Brain className="w-8 h-8 text-purple-600" />
                    <div>
                      <CardTitle>AI Interview Guides</CardTitle>
                      <Badge variant="secondary">Professional</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Get personalized interview preparation guides powered by AI for any job role.
                  </CardDescription>
                  <div className="space-y-3">
                    <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                      <h4 className="font-semibold text-sm">Common Questions</h4>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        Tell me about yourself, Why do you want this job?, What are your strengths?
                      </p>
                    </div>
                    <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                      <h4 className="font-semibold text-sm">STAR Method Examples</h4>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        Situation: When I led a team project...
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

            {/* Resume Optimization */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.RESUME_OPTIMIZATION}
              featureName="Resume Optimization"
              requiredPlan="Essential Plan"
              blurIntensity="heavy"
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <FileText className="w-8 h-8 text-blue-600" />
                    <div>
                      <CardTitle>Resume Optimization</CardTitle>
                      <Badge variant="outline">Essential</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Advanced ATS optimization with real-time scoring and improvement suggestions.
                  </CardDescription>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <span className="text-sm font-semibold">ATS Score</span>
                      <Badge className="bg-green-600">94%</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        ✓ Keyword optimization
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        ✓ Format compatibility
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">
                        ✓ Content enhancement
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

            {/* Video Practice */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.AI_FEEDBACK_VIDEO_PRACTICE}
              featureName="AI Video Practice"
              requiredPlan="Professional Plan"
              showPreview={false}
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Camera className="w-8 h-8 text-red-600" />
                    <div>
                      <CardTitle>AI Video Practice</CardTitle>
                      <Badge className="bg-red-600">Professional</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Practice interviews with AI-powered feedback on your body language, speech, and content.
                  </CardDescription>
                  <div className="aspect-video bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <Camera className="w-12 h-12 text-gray-400" />
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

            {/* Advanced Analytics */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.ADVANCED_CAREER_ANALYTICS}
              featureName="Career Analytics"
              requiredPlan="Enterprise Plan"
              blurIntensity="light"
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <BarChart3 className="w-8 h-8 text-orange-600" />
                    <div>
                      <CardTitle>Advanced Analytics</CardTitle>
                      <Badge className="bg-orange-600">Enterprise</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Deep insights into your career progression and market positioning.
                  </CardDescription>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-orange-50 dark:bg-orange-900/20 p-2 rounded text-center">
                        <TrendingUp className="w-4 h-4 mx-auto mb-1 text-orange-600" />
                        <div className="text-xs font-semibold">Career Growth</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">+23%</div>
                      </div>
                      <div className="bg-orange-50 dark:bg-orange-900/20 p-2 rounded text-center">
                        <Target className="w-4 h-4 mx-auto mb-1 text-orange-600" />
                        <div className="text-xs font-semibold">Goal Progress</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">87%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

            {/* Job Tracking */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.JOB_APPLICATION_TRACKING}
              featureName="Application Tracking"
              requiredPlan="Essential Plan"
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Target className="w-8 h-8 text-green-600" />
                    <div>
                      <CardTitle>Application Tracking</CardTitle>
                      <Badge variant="secondary">Essential</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Track your job applications with automated status updates and insights.
                  </CardDescription>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                      <span className="text-xs">Applied</span>
                      <Badge variant="outline" className="text-xs">12</Badge>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                      <span className="text-xs">Interviews</span>
                      <Badge variant="outline" className="text-xs">3</Badge>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-green-50 dark:bg-green-900/20 rounded">
                      <span className="text-xs">Offers</span>
                      <Badge variant="outline" className="text-xs">1</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

            {/* Team Management */}
            <BlurredContent
              featureSlug={FEATURE_SLUGS.TEAM_MANAGEMENT}
              featureName="Team Management"
              requiredPlan="Enterprise Plan"
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Users className="w-8 h-8 text-indigo-600" />
                    <div>
                      <CardTitle>Team Management</CardTitle>
                      <Badge className="bg-indigo-600">Enterprise</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Manage team members, track progress, and provide organizational insights.
                  </CardDescription>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded">
                      <div className="w-6 h-6 bg-indigo-200 rounded-full"></div>
                      <span className="text-xs">Team Member 1</span>
                      <Badge variant="outline" className="ml-auto text-xs">Active</Badge>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded">
                      <div className="w-6 h-6 bg-indigo-200 rounded-full"></div>
                      <span className="text-xs">Team Member 2</span>
                      <Badge variant="outline" className="ml-auto text-xs">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </BlurredContent>

          </div>

          {/* Call to Action */}
          <div className="mt-16 text-center">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center justify-center gap-2">
                  <Zap className="w-6 h-6 text-yellow-500" />
                  Ready to Unlock These Features?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Choose a plan that fits your career development needs and start accessing advanced AI-powered tools today.
                </p>
                <div className="flex gap-4 justify-center">
                  <button 
                    onClick={() => window.location.href = '/pricing'}
                    className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    View Pricing Plans
                  </button>
                  <button 
                    onClick={() => window.location.href = '/sign-in'}
                    className="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    Sign In
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}