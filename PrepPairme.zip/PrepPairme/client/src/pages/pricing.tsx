import { PricingComponent } from "@runonatlas/react";
import { NavigationHeader } from "@/components/navigation-header-new";
import { PrepSlogan } from "@/components/branding/PrepSlogan";
import { Footer } from "@/components/ui/footer";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Star, Zap, Crown, Users } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "@clerk/clerk-react";

// Features that will be configured in Clerk Dashboard
const features = {
  // Free tier features
  basic_interview_prep: "Basic interview question database",
  basic_resume_review: "Basic resume analysis",
  community_access: "Access to community forums",
  
  // Pro tier features
  advanced_interview_prep: "AI-powered interview preparation",
  resume_optimization: "Advanced resume optimization with ATS scoring",
  video_practice: "Video interview practice with feedback",
  skill_extraction: "AI skill highlighting and analysis",
  job_tracking: "Advanced job application tracking",
  career_visualization: "Interactive career path planning",
  priority_support: "Priority customer support",
  unlimited_access: "Unlimited access to all features"
};

interface AtlasPlan {
  id: string;
  name: string;
  description: string;
  price: { price: number };
  entitlements: Array<{
    id: string;
    included: boolean;
    limit?: number;
  }>;
}

interface AtlasEntitlement {
  id: string;
  name: string;
  slug: string;
}

export default function Pricing() {
  useScrollToTop();
  const { isSignedIn } = useAuth();
  const [atlasData, setAtlasData] = useState<{ plans: AtlasPlan[]; entitlements: AtlasEntitlement[] } | null>(null);
  const [atlasError, setAtlasError] = useState(false);

  useEffect(() => {
    // Fetch Atlas pricing data directly
    fetch('/api/atlas/atlas-api/pricing-model')
      .then(res => res.json())
      .then(data => setAtlasData(data))
      .catch(() => setAtlasError(true));
  }, []);

  const handleUpgrade = (planId: string) => {
    if (!isSignedIn) {
      window.location.href = '/sign-in';
      return;
    }
    // Redirect to Atlas checkout or subscription flow
    window.location.href = `/api/atlas/checkout?plan=${planId}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />
      
      <main className="pt-16 lg:pt-20">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <PrepSlogan />
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Choose Your Career Growth Plan
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Unlock your career potential with AI-powered tools and personalized guidance. 
              Start free and upgrade when you're ready to accelerate your success.
            </p>
          </div>

          {/* Atlas Pricing Plans */}
          <div className="max-w-5xl mx-auto mb-16">
            <Card className="p-8">
              <CardHeader className="text-center mb-8">
                <CardTitle className="text-2xl font-bold mb-2">
                  Professional Plans
                </CardTitle>
                <CardDescription className="text-lg">
                  Choose the plan that fits your career development needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                {atlasData ? (
                  <div className="grid md:grid-cols-3 gap-6">
                    {atlasData.plans
                      .sort((a, b) => a.price.price - b.price.price)
                      .map((plan) => {
                        const isPopular = plan.name === "Professional Plan";
                        const entitlementNames = plan.entitlements
                          .filter(e => e.included)
                          .map(e => {
                            const entitlement = atlasData.entitlements.find(ent => ent.id === e.id);
                            return entitlement ? entitlement.name : null;
                          })
                          .filter(Boolean);

                        return (
                          <Card key={plan.id} className={`relative ${isPopular ? 'border-purple-500 border-2' : ''}`}>
                            {isPopular && (
                              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                                <Badge className="bg-purple-500 text-white">Most Popular</Badge>
                              </div>
                            )}
                            <CardHeader className="text-center">
                              <CardTitle className="text-xl">{plan.name}</CardTitle>
                              <CardDescription className="text-sm">{plan.description}</CardDescription>
                              <div className="mt-4">
                                <span className="text-3xl font-bold">${plan.price.price}</span>
                                <span className="text-gray-600 dark:text-gray-400">/month</span>
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              {entitlementNames.slice(0, 6).map((name, idx) => (
                                <div key={idx} className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                                  <span className="text-sm">{name}</span>
                                </div>
                              ))}
                              {entitlementNames.length > 6 && (
                                <div className="text-sm text-gray-600 dark:text-gray-400">
                                  +{entitlementNames.length - 6} more features
                                </div>
                              )}
                              <Button 
                                className="w-full mt-6" 
                                variant={isPopular ? "default" : "outline"}
                                onClick={() => handleUpgrade(plan.id)}
                              >
                                Get Started
                              </Button>
                            </CardContent>
                          </Card>
                        );
                      })}
                  </div>
                ) : atlasError ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Unable to load pricing information. Please try again later.
                    </p>
                    <Button onClick={() => window.location.reload()}>
                      Retry
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-600 dark:text-gray-400">Loading pricing information...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Feature Comparison */}
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">
              What's Included
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Free Features */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    Free Tier Features
                  </CardTitle>
                  <CardDescription>
                    Get started with essential career tools
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Basic Interview Prep</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Access to essential interview questions and tips</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Basic Resume Review</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Limited resume analysis and basic suggestions</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Community Access</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Join our career development community</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Pro Features */}
              <Card className="border-purple-200 dark:border-purple-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-purple-600" />
                    Pro Tier Features
                    <Badge variant="secondary" className="ml-2">Popular</Badge>
                  </CardTitle>
                  <CardDescription>
                    Advanced AI-powered career acceleration tools
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Advanced Interview Prep</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">AI-powered practice with personalized feedback</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Resume Optimization</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Advanced ATS scoring and optimization</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Video Practice</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">AI-powered video interview analysis</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Skill Extraction</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">AI skill highlighting and gap analysis</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Job Tracking</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Advanced application tracking and insights</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Career Visualization</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Interactive career path planning</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Zap className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Priority Support</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Get help when you need it most</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="max-w-3xl mx-auto mt-16">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-8">
              Frequently Asked Questions
            </h2>
            
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">Can I cancel my subscription anytime?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Yes, you can cancel your subscription at any time. You'll continue to have access to Pro features until the end of your billing period.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">What payment methods do you accept?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    We accept all major credit cards through our secure payment processor. All transactions are encrypted and secure.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">Is there a free trial?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Our free tier gives you access to essential features. You can upgrade to Pro at any time to unlock advanced AI-powered tools.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-2">How does the AI-powered feedback work?</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Our AI analyzes your resume, interview responses, and video practice sessions to provide personalized, actionable feedback to improve your career prospects.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}