import { useState } from "react";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Search, Lock, Star, BookOpen, Brain, Target, Zap, Crown } from "lucide-react";
import { useLocation } from "wouter";

interface Question {
  id: number;
  question: string;
  category: string;
  difficulty: "Easy" | "Medium" | "Hard";
  industry: string;
  sampleAnswer: string;
  tips: string[];
  isPremium: boolean;
}

const sampleQuestions: Question[] = [
  {
    id: 1,
    question: "Tell me about yourself",
    category: "General",
    difficulty: "Easy",
    industry: "All",
    sampleAnswer: "I'm a passionate software developer with 3 years of experience building scalable web applications. I specialize in React and Node.js, and I'm particularly excited about creating user-centered solutions that solve real problems.",
    tips: [
      "Keep it concise - aim for 60-90 seconds",
      "Focus on relevant professional experience",
      "End with why you're interested in this role"
    ],
    isPremium: false
  },
  {
    id: 2,
    question: "Why do you want to work here?",
    category: "Company Research",
    difficulty: "Medium",
    industry: "All",
    sampleAnswer: "I'm drawn to your company's mission of democratizing financial services. Your recent expansion into AI-powered investment tools aligns perfectly with my background in fintech and machine learning.",
    tips: [
      "Research the company's recent news and developments",
      "Connect your values with the company's mission",
      "Mention specific products or initiatives"
    ],
    isPremium: false
  },
  {
    id: 3,
    question: "Describe a challenging project you worked on",
    category: "Behavioral",
    difficulty: "Hard",
    industry: "Technology",
    sampleAnswer: "Premium content - upgrade to access detailed STAR method examples and industry-specific variations.",
    tips: [
      "Use the STAR method (Situation, Task, Action, Result)",
      "Quantify your impact with specific metrics",
      "Choose a project relevant to the target role"
    ],
    isPremium: true
  },
  {
    id: 4,
    question: "How do you handle conflict in a team?",
    category: "Behavioral",
    difficulty: "Medium",
    industry: "All",
    sampleAnswer: "Premium content - access 500+ behavioral questions with detailed frameworks.",
    tips: [
      "Show emotional intelligence and communication skills",
      "Provide a specific example",
      "Focus on resolution and learning"
    ],
    isPremium: true
  },
  {
    id: 5,
    question: "What's your greatest weakness?",
    category: "Self-Assessment",
    difficulty: "Hard",
    industry: "All",
    sampleAnswer: "Premium content - learn the advanced framework for turning weaknesses into strengths.",
    tips: [
      "Choose a real weakness, not a disguised strength",
      "Explain steps you're taking to improve",
      "Show self-awareness and growth mindset"
    ],
    isPremium: true
  }
];

export default function QuestionsDatabase() {
  useScrollToTop();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const categories = ["All", "General", "Behavioral", "Technical", "Company Research", "Self-Assessment"];
  
  const filteredQuestions = sampleQuestions.filter(question => {
    const matchesSearch = searchTerm === "" || 
      question.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      question.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || question.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleQuestionClick = (question: Question) => {
    if (question.isPremium) {
      setShowUpgradeModal(true);
    } else {
      setSelectedQuestion(question);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />
      
      <main className="pt-16 lg:pt-20">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Interview Questions Database
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Access our comprehensive collection of interview questions with expert answers, 
              tips, and industry-specific variations.
            </p>
            
            {/* Free vs Premium Info */}
            <div className="flex justify-center gap-4 mb-8">
              <div className="flex items-center bg-green-100 text-green-800 px-4 py-2 rounded-full">
                <BookOpen className="w-4 h-4 mr-2" />
                <span className="text-sm font-medium">5 Free Questions</span>
              </div>
              <div className="flex items-center bg-purple-100 text-purple-800 px-4 py-2 rounded-full">
                <Crown className="w-4 h-4 mr-2" />
                <span className="text-sm font-medium">500+ Premium Questions</span>
              </div>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search questions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex gap-2 flex-wrap">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Questions Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredQuestions.map((question) => (
              <Card 
                key={question.id} 
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  question.isPremium ? 'relative overflow-hidden' : ''
                }`}
                onClick={() => handleQuestionClick(question)}
              >
                {question.isPremium && (
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-blue-500/10 backdrop-blur-sm z-10 flex items-center justify-center">
                    <div className="text-center">
                      <Lock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-purple-600">Premium Content</p>
                    </div>
                  </div>
                )}
                
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg leading-tight">{question.question}</CardTitle>
                    {question.isPremium && (
                      <Crown className="w-5 h-5 text-purple-600 flex-shrink-0" />
                    )}
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="secondary">{question.category}</Badge>
                    <Badge 
                      variant={question.difficulty === "Easy" ? "default" : 
                              question.difficulty === "Medium" ? "secondary" : "destructive"}
                    >
                      {question.difficulty}
                    </Badge>
                    {question.industry !== "All" && (
                      <Badge variant="outline">{question.industry}</Badge>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent>
                  <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-3">
                    {question.isPremium 
                      ? "Premium content with detailed STAR method examples, industry variations, and expert insights..."
                      : question.sampleAnswer
                    }
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Upgrade CTA */}
          <div className="mt-16 text-center">
            <Card className="max-w-4xl mx-auto bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0">
              <CardContent className="p-8">
                <h3 className="text-3xl font-bold mb-4">Unlock the Full Database</h3>
                <p className="text-lg mb-6 opacity-90">
                  Get access to 500+ premium questions with detailed answers, industry variations, 
                  and expert tips from hiring managers.
                </p>
                
                <div className="grid md:grid-cols-3 gap-6 mb-8 text-center">
                  <div>
                    <Brain className="w-8 h-8 mx-auto mb-2 opacity-90" />
                    <h4 className="font-semibold mb-1">AI-Powered Answers</h4>
                    <p className="text-sm opacity-80">Personalized responses based on your background</p>
                  </div>
                  <div>
                    <Target className="w-8 h-8 mx-auto mb-2 opacity-90" />
                    <h4 className="font-semibold mb-1">Industry-Specific</h4>
                    <p className="text-sm opacity-80">Tailored questions for your target industry</p>
                  </div>
                  <div>
                    <Zap className="w-8 h-8 mx-auto mb-2 opacity-90" />
                    <h4 className="font-semibold mb-1">Instant Access</h4>
                    <p className="text-sm opacity-80">Download, practice, and ace your interviews</p>
                  </div>
                </div>
                
                <Button 
                  size="lg" 
                  className="bg-white text-purple-600 hover:bg-gray-100"
                  onClick={() => setLocation('/subscribe')}
                >
                  Upgrade to Pro - $19/month
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Question Detail Modal */}
      <Dialog open={!!selectedQuestion} onOpenChange={() => setSelectedQuestion(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {selectedQuestion && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selectedQuestion.question}</DialogTitle>
                <DialogDescription>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="secondary">{selectedQuestion.category}</Badge>
                    <Badge variant="outline">{selectedQuestion.difficulty}</Badge>
                  </div>
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-2">Sample Answer:</h4>
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                    {selectedQuestion.sampleAnswer}
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Expert Tips:</h4>
                  <ul className="space-y-2">
                    {selectedQuestion.tips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <Star className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Upgrade Modal */}
      <Dialog open={showUpgradeModal} onOpenChange={setShowUpgradeModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-purple-600" />
              Premium Content
            </DialogTitle>
            <DialogDescription>
              This question requires a Pro subscription to access the full answer and expert insights.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <p className="text-sm text-purple-700 dark:text-purple-300">
                Unlock 500+ premium questions with detailed STAR method examples, 
                industry variations, and hiring manager insights.
              </p>
            </div>
            
            <div className="flex gap-3">
              <Button 
                className="flex-1"
                onClick={() => {
                  setShowUpgradeModal(false);
                  setLocation('/subscribe');
                }}
              >
                Upgrade to Pro
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowUpgradeModal(false)}
              >
                Maybe Later
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}