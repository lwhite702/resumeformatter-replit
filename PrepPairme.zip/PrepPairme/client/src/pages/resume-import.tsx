import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Upload, ExternalLink, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ImportSource {
  id: string;
  name: string;
  description: string;
  requiresApiKey: boolean;
  endpoint: string;
}

export default function ResumeImport() {
  const { toast } = useToast();
  const [selectedSource, setSelectedSource] = useState<string>("");
  const [apiKey, setApiKey] = useState("");
  const [resumeData, setResumeData] = useState("");
  const [isApiKeyValid, setIsApiKeyValid] = useState<boolean | null>(null);

  // Fetch available import sources
  const { data: sources, isLoading: sourcesLoading } = useQuery<ImportSource[]>({
    queryKey: ['/api/resume/import/sources'],
  });

  // Validate API key mutation
  const validateKeyMutation = useMutation({
    mutationFn: async ({ apiKey, source }: { apiKey: string; source: string }) => {
      return await apiRequest("POST", "/api/resume/import/validate-key", { apiKey, source });
    },
    onSuccess: (data) => {
      setIsApiKeyValid(data.valid);
      toast({
        title: data.valid ? "API Key Valid" : "Invalid API Key",
        description: data.message,
        variant: data.valid ? "default" : "destructive",
      });
    },
    onError: () => {
      setIsApiKeyValid(false);
      toast({
        title: "Validation Failed",
        description: "Unable to validate API key",
        variant: "destructive",
      });
    },
  });

  // Import resume mutation
  const importMutation = useMutation({
    mutationFn: async (importData: any) => {
      if (selectedSource === 'resumeformatter.io') {
        return await apiRequest("POST", "/api/resume/import/resumeformatter", {
          resumeformatterData: JSON.parse(resumeData),
          apiKey
        });
      } else {
        return await apiRequest("POST", "/api/resume/import/external", {
          resumeData: JSON.parse(resumeData),
          source: selectedSource,
          apiKey
        });
      }
    },
    onSuccess: (data) => {
      toast({
        title: "Import Successful",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/resumes'] });
      // Reset form
      setResumeData("");
      setApiKey("");
      setSelectedSource("");
      setIsApiKeyValid(null);
    },
    onError: (error: any) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import resume",
        variant: "destructive",
      });
    },
  });

  const handleValidateKey = () => {
    if (!apiKey || !selectedSource) {
      toast({
        title: "Missing Information",
        description: "Please select a source and enter an API key",
        variant: "destructive",
      });
      return;
    }
    validateKeyMutation.mutate({ apiKey, source: selectedSource });
  };

  const handleImport = () => {
    if (!resumeData || !apiKey || !selectedSource) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      JSON.parse(resumeData);
    } catch {
      toast({
        title: "Invalid JSON",
        description: "Please enter valid JSON data",
        variant: "destructive",
      });
      return;
    }

    importMutation.mutate({});
  };

  if (sourcesLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Resume Import
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Import resumes from external services and third-party platforms
          </p>
        </div>

        <div className="grid gap-6">
          {/* Source Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ExternalLink className="h-5 w-5" />
                Select Import Source
              </CardTitle>
              <CardDescription>
                Choose the external service you want to import from
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="source">Import Source</Label>
                <Select value={selectedSource} onValueChange={setSelectedSource}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an import source" />
                  </SelectTrigger>
                  <SelectContent>
                    {sources?.map((source) => (
                      <SelectItem key={source.id} value={source.id}>
                        {source.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedSource && sources && (
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  {(() => {
                    const source = sources.find(s => s.id === selectedSource);
                    return (
                      <div>
                        <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                          {source?.name}
                        </h4>
                        <p className="text-blue-800 dark:text-blue-200 text-sm mb-3">
                          {source?.description}
                        </p>
                        {source?.requiresApiKey && (
                          <Badge variant="secondary">
                            API Key Required
                          </Badge>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}
            </CardContent>
          </Card>

          {/* API Key Configuration */}
          {selectedSource && sources?.find(s => s.id === selectedSource)?.requiresApiKey && (
            <Card>
              <CardHeader>
                <CardTitle>API Key Configuration</CardTitle>
                <CardDescription>
                  Enter your API key for {sources.find(s => s.id === selectedSource)?.name}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="apiKey">API Key</Label>
                  <div className="flex gap-2">
                    <Input
                      id="apiKey"
                      type="password"
                      placeholder="Enter your API key"
                      value={apiKey}
                      onChange={(e) => {
                        setApiKey(e.target.value);
                        setIsApiKeyValid(null);
                      }}
                    />
                    <Button
                      onClick={handleValidateKey}
                      disabled={!apiKey || validateKeyMutation.isPending}
                      variant="outline"
                    >
                      {validateKeyMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        "Validate"
                      )}
                    </Button>
                  </div>
                  {isApiKeyValid !== null && (
                    <div className={`flex items-center gap-2 text-sm ${
                      isApiKeyValid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                    }`}>
                      {isApiKeyValid ? (
                        <>
                          <Check className="h-4 w-4" />
                          API key is valid
                        </>
                      ) : (
                        <>
                          <X className="h-4 w-4" />
                          Invalid API key
                        </>
                      )}
                    </div>
                  )}
                </div>

                {selectedSource === 'resumeformatter.io' && (
                  <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                    <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
                      ResumeFormatter.io Setup
                    </h4>
                    <p className="text-amber-800 dark:text-amber-200 text-sm">
                      To get your API key:
                    </p>
                    <ol className="list-decimal list-inside text-amber-800 dark:text-amber-200 text-sm mt-2 space-y-1">
                      <li>Visit resumeformatter.io and create an account</li>
                      <li>Go to your API settings in the dashboard</li>
                      <li>Generate a new API key</li>
                      <li>Copy and paste it above</li>
                    </ol>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Resume Data Input */}
          {selectedSource && isApiKeyValid && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Resume Data
                </CardTitle>
                <CardDescription>
                  Paste the JSON data from your external source
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="resumeData">JSON Data</Label>
                  <Textarea
                    id="resumeData"
                    placeholder="Paste your resume JSON data here..."
                    value={resumeData}
                    onChange={(e) => setResumeData(e.target.value)}
                    rows={10}
                    className="font-mono text-sm"
                  />
                </div>

                {selectedSource === 'resumeformatter.io' && (
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h4 className="font-semibold text-green-900 dark:text-green-100 mb-2">
                      Expected Format
                    </h4>
                    <pre className="text-green-800 dark:text-green-200 text-xs overflow-x-auto">
{`{
  "filename": "resume.pdf",
  "formatted_content": "...",
  "extracted_text": "...",
  "skills": ["skill1", "skill2"],
  "work_experience": [...],
  "education": [...],
  "summary": "...",
  "ats_score": 85,
  "improvement_suggestions": [...]
}`}
                    </pre>
                  </div>
                )}

                <Button
                  onClick={handleImport}
                  disabled={!resumeData || importMutation.isPending}
                  className="w-full"
                >
                  {importMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Importing Resume...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      Import Resume
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}