import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { BlurredContent } from "@/components/ui/blurred-content";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Upload, 
  FileText, 
  Target, 
  TrendingUp, 
  Download,
  ArrowLeft,
  Loader2,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Copy,
  Zap
} from "lucide-react";
import { useLocation } from "wouter";

interface ResumeAnalysis {
  atsScore: number;
  keywordMatches: number;
  totalKeywords: number;
  suggestions: string[];
  bulletImprovements: Array<{
    original: string;
    improved: string;
    reasoning: string;
  }>;
}

export default function ResumeOptimizer() {
  useScrollToTop();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [resumeName, setResumeName] = useState("");
  const [resumeContent, setResumeContent] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedResumeId, setSelectedResumeId] = useState<number | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [improvingBullets, setImprovingBullets] = useState<Set<number>>(new Set());

  // Fetch user's resumes
  const { data: resumes = [] } = useQuery({
    queryKey: ['/api/resumes'],
  });

  const uploadResumeMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest("POST", "/api/resumes", formData);
      return response.json();
    },
    onSuccess: (newResume) => {
      toast({
        title: "Resume Uploaded!",
        description: "Your resume has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/resumes'] });
      setSelectedResumeId(newResume.id);
      setResumeContent(newResume.content);
      setResumeName(newResume.name);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload resume",
        variant: "destructive",
      });
    },
  });

  const analyzeResumeMutation = useMutation({
    mutationFn: async ({ resumeId, jobDescription }: { resumeId: number; jobDescription: string }) => {
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/analyze`, { jobDescription });
      return response.json();
    },
    onSuccess: (analysisResult) => {
      setAnalysis(analysisResult);
      toast({
        title: "Analysis Complete!",
        description: `Your resume scored ${analysisResult.atsScore}% for ATS compatibility.`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze resume",
        variant: "destructive",
      });
    },
  });

  const improveBulletMutation = useMutation({
    mutationFn: async ({ originalBullet, jobDescription }: { originalBullet: string; jobDescription: string }) => {
      const response = await apiRequest("POST", "/api/improve-bullet", { 
        originalBullet, 
        jobDescription,
        context: resumeContent.slice(0, 500)
      });
      return response.json();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      if (error.message.includes("Insufficient credits")) {
        setShowUpgradeModal(true);
        return;
      }
      
      toast({
        title: "Improvement Failed",
        description: error.message || "Failed to improve bullet point",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setResumeName(file.name);
      
      // For text files, read content immediately
      if (file.type === 'text/plain') {
        const reader = new FileReader();
        reader.onload = (e) => {
          setResumeContent(e.target?.result as string || '');
        };
        reader.readAsText(file);
      }
    }
  };

  const handleUpload = () => {
    if (!selectedFile && !resumeContent.trim()) {
      toast({
        title: "Missing Content",
        description: "Please select a file or paste resume content.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    if (selectedFile) {
      formData.append('file', selectedFile);
    }
    formData.append('name', resumeName || 'Untitled Resume');
    formData.append('content', resumeContent);

    uploadResumeMutation.mutate(formData);
  };

  const handleAnalyze = () => {
    if (!selectedResumeId) {
      toast({
        title: "No Resume Selected",
        description: "Please upload or select a resume first.",
        variant: "destructive",
      });
      return;
    }

    if (!jobDescription.trim()) {
      toast({
        title: "Missing Job Description",
        description: "Please provide a job description for analysis.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    analyzeResumeMutation.mutate({ resumeId: selectedResumeId, jobDescription });
  };

  const handleImproveBullet = async (bulletIndex: number, originalBullet: string) => {
    if (!user?.isPro && (user?.credits || 0) < 1) {
      setShowUpgradeModal(true);
      return;
    }

    setImprovingBullets(prev => new Set(prev).add(bulletIndex));
    
    try {
      const result = await improveBulletMutation.mutateAsync({ originalBullet, jobDescription });
      
      // Update the analysis with the improved bullet
      if (analysis) {
        const updatedImprovements = [...analysis.bulletImprovements];
        updatedImprovements[bulletIndex] = {
          ...updatedImprovements[bulletIndex],
          improved: result.improved
        };
        setAnalysis({
          ...analysis,
          bulletImprovements: updatedImprovements
        });
      }
      
      toast({
        title: "Bullet Point Improved!",
        description: "Your bullet point has been optimized for better impact.",
      });
    } finally {
      setImprovingBullets(prev => {
        const next = new Set(prev);
        next.delete(bulletIndex);
        return next;
      });
    }
  };

  const handleResumeSelect = (resume: any) => {
    setSelectedResumeId(resume.id);
    setResumeContent(resume.content);
    setResumeName(resume.name);
    setAnalysis(null); // Clear previous analysis
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 90) return "bg-green-50 border-green-200";
    if (score >= 80) return "bg-blue-50 border-blue-200";
    if (score >= 70) return "bg-yellow-50 border-yellow-200";
    return "bg-red-50 border-red-200";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Resume Optimizer</h1>
              <p className="text-gray-600">Analyze and optimize your resume for ATS systems</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left Column - Input */}
          <div className="space-y-6 mobile-card-stack lg:space-y-6 lg:px-0">
            {/* Existing Resumes */}
            {resumes.length > 0 && (
              <Card className="material-card">
                <CardHeader>
                  <CardTitle className="text-lg">Your Resumes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {resumes.map((resume: any) => (
                      <div 
                        key={resume.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors touch-manipulation min-h-[60px] ${
                          selectedResumeId === resume.id 
                            ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/20' 
                            : 'border-gray-200 hover:border-gray-300 active:bg-gray-50 dark:active:bg-gray-800'
                        }`}
                        onClick={() => handleResumeSelect(resume)}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium text-gray-900">{resume.name}</h4>
                            <p className="text-sm text-gray-600">
                              {resume.atsScore ? `${resume.atsScore}% ATS Score` : 'Not analyzed'}
                            </p>
                          </div>
                          {resume.atsScore && (
                            <Progress value={resume.atsScore} className="w-16" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Upload New Resume */}
            <Card className="material-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="w-5 h-5 mr-2 text-purple-600" />
                  Upload Resume
                </CardTitle>
                <CardDescription>
                  Upload your resume in PDF, DOCX, or text format for ATS optimization
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Resume Name</Label>
                  <Input
                    value={resumeName}
                    onChange={(e) => setResumeName(e.target.value)}
                    placeholder="e.g., Software Engineer Resume v2"
                  />
                </div>

                <div>
                  <Label>Upload File</Label>
                  <Input
                    type="file"
                    accept=".pdf,.docx,.txt"
                    onChange={handleFileUpload}
                    className="cursor-pointer"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Supported formats: PDF, DOCX, TXT (max 10MB)
                  </p>
                </div>

                <div>
                  <Label>Or Paste Resume Content</Label>
                  <Textarea
                    value={resumeContent}
                    onChange={(e) => setResumeContent(e.target.value)}
                    placeholder="Paste your complete resume text here..."
                    rows={8}
                  />
                </div>

                <Button 
                  onClick={handleUpload}
                  disabled={(!selectedFile && !resumeContent.trim()) || uploadResumeMutation.isPending}
                  className="w-full gradient-bg text-white hover:opacity-90"
                >
                  {uploadResumeMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Save Resume
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Job Description */}
            <Card className="material-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2 text-teal-600" />
                  Job Description
                </CardTitle>
                <CardDescription>
                  Paste the job description to analyze ATS compatibility
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Paste the complete job description here..."
                  rows={8}
                />
                <Button 
                  onClick={handleAnalyze}
                  disabled={!selectedResumeId || !jobDescription.trim() || isAnalyzing}
                  className="w-full mt-4 bg-teal-600 text-white hover:bg-teal-700"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Analyze Resume
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Analysis Results */}
          <div className="space-y-6">
            {analysis ? (
              <>
                {/* ATS Score */}
                <Card className="material-card">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center">
                        <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
                        ATS Score
                      </span>
                      <Badge className={`${getScoreBgColor(analysis.atsScore)} ${getScoreColor(analysis.atsScore)}`}>
                        {analysis.atsScore}%
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">ATS Compatibility</span>
                          <span className={`text-sm font-medium ${getScoreColor(analysis.atsScore)}`}>
                            {analysis.atsScore}%
                          </span>
                        </div>
                        <Progress value={analysis.atsScore} className="w-full" />
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-2xl font-bold text-green-600">{analysis.keywordMatches}</div>
                          <div className="text-sm text-gray-600">Keywords Matched</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-2xl font-bold text-blue-600">{analysis.totalKeywords}</div>
                          <div className="text-sm text-gray-600">Total Keywords</div>
                        </div>
                      </div>

                      <div className="text-center">
                        <p className="text-sm text-gray-600">
                          Match Rate: {Math.round((analysis.keywordMatches / analysis.totalKeywords) * 100)}%
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Analysis Results Tabs */}
                <Card className="material-card">
                  <Tabs defaultValue="suggestions" className="w-full">
                    <CardHeader>
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                        <TabsTrigger value="improvements">Bullet Improvements</TabsTrigger>
                      </TabsList>
                    </CardHeader>
                    
                    <CardContent>
                      <TabsContent value="suggestions" className="mt-0">
                        <div className="space-y-3">
                          {analysis.suggestions.map((suggestion, index) => (
                            <div key={index} className="flex items-start p-3 bg-blue-50 rounded-lg">
                              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
                              <p className="text-sm text-gray-700">{suggestion}</p>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="improvements" className="mt-0">
                        <div className="space-y-4">
                          {analysis.bulletImprovements.length > 0 ? (
                            analysis.bulletImprovements.map((improvement, index) => (
                              <div key={index} className="border border-gray-200 rounded-lg p-4">
                                <div className="space-y-3">
                                  <div>
                                    <Label className="text-sm font-medium text-red-600">Original:</Label>
                                    <p className="text-sm text-gray-700 mt-1">{improvement.original}</p>
                                  </div>
                                  
                                  <div>
                                    <div className="flex justify-between items-center mb-1">
                                      <Label className="text-sm font-medium text-green-600">Improved:</Label>
                                      <div className="flex space-x-2">
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => navigator.clipboard.writeText(improvement.improved)}
                                        >
                                          <Copy className="w-3 h-3" />
                                        </Button>
                                        {!user?.isPro && (
                                          <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => handleImproveBullet(index, improvement.original)}
                                            disabled={improvingBullets.has(index)}
                                          >
                                            {improvingBullets.has(index) ? (
                                              <Loader2 className="w-3 h-3 animate-spin" />
                                            ) : (
                                              <RefreshCw className="w-3 h-3" />
                                            )}
                                          </Button>
                                        )}
                                      </div>
                                    </div>
                                    <p className="text-sm text-gray-700 bg-green-50 p-2 rounded">
                                      {improvement.improved}
                                    </p>
                                  </div>
                                  
                                  <div>
                                    <Label className="text-sm font-medium text-blue-600">Why this is better:</Label>
                                    <p className="text-sm text-gray-600 mt-1">{improvement.reasoning}</p>
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-center py-8 text-gray-500">
                              No bullet point improvements found. Your resume content is already well-optimized!
                            </div>
                          )}
                        </div>
                      </TabsContent>
                    </CardContent>
                  </Tabs>
                </Card>

                {/* Pro Upgrade Prompt */}
                {!user?.isPro && (
                  <Card className="material-card border-purple-200 bg-purple-50">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <Zap className="w-5 h-5 text-purple-600 mr-2" />
                        <div className="flex-1">
                          <h4 className="font-medium text-purple-900">Unlock Advanced Features</h4>
                          <p className="text-sm text-purple-700">
                            Get unlimited bullet improvements, detailed ATS analysis, and priority processing.
                          </p>
                        </div>
                        <Button 
                          onClick={() => setShowUpgradeModal(true)}
                          className="gradient-bg text-white"
                        >
                          Upgrade
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              /* Getting Started Guide */
              <Card className="material-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="w-5 h-5 mr-2 text-gray-600" />
                    How to Optimize Your Resume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-sm font-bold text-purple-600">1</span>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Upload Your Resume</h4>
                        <p className="text-sm text-gray-600">
                          Upload your resume file or paste the content directly
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-6 h-6 bg-teal-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-sm font-bold text-teal-600">2</span>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Add Job Description</h4>
                        <p className="text-sm text-gray-600">
                          Paste the full job description for targeted analysis
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-sm font-bold text-blue-600">3</span>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Get AI Analysis</h4>
                        <p className="text-sm text-gray-600">
                          Receive ATS score, keyword analysis, and improvement suggestions
                        </p>
                      </div>
                    </div>

                    <Separator />

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-medium text-blue-900 mb-2">What You'll Get:</h4>
                      <ul className="text-sm text-blue-800 space-y-1">
                        <li>• ATS compatibility score (0-100%)</li>
                        <li>• Keyword matching analysis</li>
                        <li>• Specific improvement suggestions</li>
                        <li>• Bullet point optimizations</li>
                        <li>• Export optimized resume</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
