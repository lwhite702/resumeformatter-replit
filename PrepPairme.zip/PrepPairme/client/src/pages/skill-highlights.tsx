import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Sparkles, 
  Brain, 
  Code, 
  Users, 
  Building, 
  Award, 
  Globe, 
  CheckCircle,
  XCircle,
  RefreshCw,
  TrendingUp,
  Star,
  Zap
} from "lucide-react";

interface ExtractedSkill {
  skillName: string;
  category: 'technical' | 'soft' | 'industry' | 'certification' | 'language';
  proficiencyLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  yearsOfExperience: number | null;
  contextualExamples: string[];
  relevanceScore: number;
  extractedFrom: string;
}

interface SkillExtractionResult {
  extractedSkills: ExtractedSkill[];
  summary: {
    totalSkillsFound: number;
    technicalSkills: number;
    softSkills: number;
    industrySkills: number;
    certifications: number;
    languages: number;
  };
  recommendations: string[];
}

const categoryConfig = {
  technical: { icon: Code, color: "bg-blue-500", label: "Technical Skills" },
  soft: { icon: Users, color: "bg-green-500", label: "Soft Skills" },
  industry: { icon: Building, color: "bg-orange-500", label: "Industry Knowledge" },
  certification: { icon: Award, color: "bg-purple-500", label: "Certifications" },
  language: { icon: Globe, color: "bg-red-500", label: "Languages" },
};

const proficiencyColors = {
  beginner: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
  intermediate: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200",
  advanced: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200",
  expert: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-200",
};

export default function SkillHighlights() {
  const { isAuthenticated, isLoading: authLoading, user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedResumeId, setSelectedResumeId] = useState<number | null>(null);
  const [skillAnalysis, setSkillAnalysis] = useState<SkillExtractionResult | null>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch user's resumes
  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Generate skill highlights mutation
  const generateSkillsMutation = useMutation({
    mutationFn: async (resumeId: number) => {
      return await apiRequest("POST", `/api/resumes/${resumeId}/skill-highlights`);
    },
    onSuccess: (data) => {
      setSkillAnalysis(data);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Success",
        description: "Skill highlights generated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to generate skill highlights",
        variant: "destructive",
      });
    },
  });

  // Fetch existing skill highlights
  const { data: existingSkills } = useQuery({
    queryKey: [`/api/resumes/${selectedResumeId}/skill-highlights`],
    enabled: !!selectedResumeId,
    retry: false,
  });

  const handleGenerateSkills = () => {
    if (!selectedResumeId) return;
    generateSkillsMutation.mutate(selectedResumeId);
  };

  const renderSkillCard = (skill: ExtractedSkill, index: number) => {
    const CategoryIcon = categoryConfig[skill.category].icon;
    
    return (
      <Card key={index} className="hover:shadow-md transition-shadow">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-lg ${categoryConfig[skill.category].color} text-white`}>
                <CategoryIcon className="h-4 w-4" />
              </div>
              <div>
                <CardTitle className="text-lg">{skill.skillName}</CardTitle>
                <p className="text-sm text-gray-500">{categoryConfig[skill.category].label}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={proficiencyColors[skill.proficiencyLevel]}>
                {skill.proficiencyLevel}
              </Badge>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500" />
                <span className="text-sm font-medium">{skill.relevanceScore}/100</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {skill.yearsOfExperience && (
              <div className="text-sm">
                <span className="font-medium">Experience:</span> {skill.yearsOfExperience} years
              </div>
            )}
            
            <div>
              <p className="text-sm font-medium mb-2">Context Examples:</p>
              <div className="space-y-1">
                {skill.contextualExamples.map((example, idx) => (
                  <p key={idx} className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                    "{example}"
                  </p>
                ))}
              </div>
            </div>
            
            <div className="text-xs text-gray-500">
              Extracted from: {skill.extractedFrom}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (authLoading || resumesLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                AI Skill Highlights Generator
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                One-click intelligent skill extraction and analysis from your resume
              </p>
            </div>
          </div>
        </div>

        {/* Resume Selection */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Select Resume for Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {resumes && resumes.length > 0 ? (
                <div className="grid gap-3">
                  {resumes.map((resume: any) => (
                    <div
                      key={resume.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedResumeId === resume.id
                          ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setSelectedResumeId(resume.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">{resume.title}</h3>
                          <p className="text-sm text-gray-500">
                            Uploaded: {new Date(resume.uploadedAt).toLocaleDateString()}
                          </p>
                          {resume.lastSkillAnalysisAt && (
                            <p className="text-sm text-green-600">
                              Last analyzed: {new Date(resume.lastSkillAnalysisAt).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {resume.atsScore && (
                            <Badge variant="outline">ATS: {resume.atsScore}%</Badge>
                          )}
                          {selectedResumeId === resume.id && (
                            <CheckCircle className="h-5 w-5 text-blue-500" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">No resumes found. Upload a resume to get started.</p>
                  <Button variant="outline">Upload Resume</Button>
                </div>
              )}

              {selectedResumeId && (
                <div className="flex items-center gap-4 pt-4 border-t">
                  <Button 
                    onClick={handleGenerateSkills}
                    disabled={generateSkillsMutation.isPending}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    {generateSkillsMutation.isPending ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Analyzing Skills...
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        Generate Skill Highlights
                      </>
                    )}
                  </Button>
                  <div className="text-sm text-gray-500">
                    Cost: {user?.isPro ? "Free (Pro)" : "2 credits"}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Skill Analysis Results */}
        {(skillAnalysis || existingSkills?.skills) && (
          <div className="space-y-8">
            {skillAnalysis && (
              <>
                {/* Summary Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Analysis Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {skillAnalysis.summary.totalSkillsFound}
                        </div>
                        <div className="text-sm text-gray-500">Total Skills</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {skillAnalysis.summary.technicalSkills}
                        </div>
                        <div className="text-sm text-gray-500">Technical</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {skillAnalysis.summary.softSkills}
                        </div>
                        <div className="text-sm text-gray-500">Soft Skills</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {skillAnalysis.summary.certifications}
                        </div>
                        <div className="text-sm text-gray-500">Certifications</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-red-600">
                          {skillAnalysis.summary.languages}
                        </div>
                        <div className="text-sm text-gray-500">Languages</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Recommendations */}
                {skillAnalysis.recommendations.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="h-5 w-5" />
                        AI Recommendations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {skillAnalysis.recommendations.map((rec, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <Sparkles className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                            <p className="text-sm">{rec}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}

            {/* Skills Grid */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Extracted Skills</h2>
              <div className="grid gap-4 md:grid-cols-2">
                {(skillAnalysis?.extractedSkills || existingSkills?.skills || []).map((skill, index) => 
                  renderSkillCard(skill, index)
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}