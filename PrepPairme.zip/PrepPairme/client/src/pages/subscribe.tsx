import { useEffect, useState } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { NavigationHeader } from "@/components/navigation-header-new";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { 
  Crown, 
  Check, 
  Loader2,
  ArrowLeft,
  Calendar,
  DollarSign
} from "lucide-react";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = ({ billingCycle }: { billingCycle: 'monthly' | 'quarterly' }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/?payment=success',
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Successful",
          description: "Welcome to PrepPair Pro!",
        });
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <PaymentElement />
      </div>
      
      <Button 
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full bg-purple-600 hover:bg-purple-700 text-white h-12 text-base"
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Processing Payment...
          </>
        ) : (
          <>
            <Crown className="w-5 h-5 mr-2" />
            Subscribe to Pro {billingCycle === 'monthly' ? 'Monthly' : 'Quarterly'}
          </>
        )}
      </Button>
    </form>
  );
};

const PlanCard = ({ 
  billingCycle, 
  onSelect, 
  isSelected 
}: { 
  billingCycle: 'monthly' | 'quarterly'; 
  onSelect: () => void;
  isSelected: boolean;
}) => {
  const isMonthly = billingCycle === 'monthly';
  const price = isMonthly ? 19 : 49;
  const period = isMonthly ? '/month' : '/quarter';
  const savings = isMonthly ? '' : 'Save 18%';

  const features = [
    "Unlimited AI interview guides",
    "Advanced resume optimization",
    "Video interview practice",
    "Skill extraction & highlighting",
    "Job application tracking",
    "Priority customer support",
    "Industry-specific insights",
    "Thank you note generation"
  ];

  return (
    <Card 
      className={`cursor-pointer transition-all duration-200 ${
        isSelected 
          ? 'ring-2 ring-purple-600 bg-purple-50 shadow-lg' 
          : 'hover:shadow-md border-gray-200'
      } ${!isMonthly ? 'border-2 border-purple-200' : ''}`}
      onClick={onSelect}
    >
      <CardHeader className="relative">
        {!isMonthly && (
          <Badge className="absolute -top-2 right-4 bg-green-600 text-white">
            Best Value
          </Badge>
        )}
        {isMonthly && (
          <Badge className="absolute -top-2 right-4 bg-purple-600 text-white">
            Most Popular
          </Badge>
        )}
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {isMonthly ? (
              <Calendar className="w-6 h-6 text-purple-600 mr-2" />
            ) : (
              <DollarSign className="w-6 h-6 text-green-600 mr-2" />
            )}
            <div>
              <CardTitle className="text-xl">
                Pro {isMonthly ? 'Monthly' : 'Quarterly'}
              </CardTitle>
              <CardDescription>
                {isMonthly ? 'Perfect for getting started' : 'Best value for serious job seekers'}
              </CardDescription>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-gray-900">${price}</div>
            <div className="text-sm text-gray-600">{period}</div>
            {savings && <div className="text-xs text-green-600 font-medium">{savings}</div>}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <ul className="space-y-3">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className="w-4 h-4 text-green-600 mr-3 flex-shrink-0" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        {!isMonthly && (
          <div className="mt-4 p-3 bg-green-50 rounded-lg">
            <p className="text-sm text-green-800 font-medium">
              Save $8 compared to monthly billing (equivalent to $16.33/month)
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'quarterly' | null>('monthly');
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  // Check URL parameters for plan selection
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const plan = urlParams.get('plan');
    
    if (plan === 'monthly' || plan === 'quarterly') {
      setSelectedPlan(plan);
    }
    
    if (urlParams.get('payment') === 'success') {
      toast({
        title: "Payment Successful!",
        description: "Your subscription has been activated.",
      });
      setLocation('/dashboard');
    }
  }, [toast, setLocation]);

  const handlePlanSelect = async (plan: 'monthly' | 'quarterly') => {
    setSelectedPlan(plan);
    setIsLoading(true);
    setShowPayment(false);

    try {
      const response = await apiRequest("POST", "/api/create-pro-subscription", {
        billingCycle: plan
      });
      
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPayment(true);
    } catch (error: any) {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Please log in",
          description: "You need to be logged in to subscribe.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      
      toast({
        title: "Error",
        description: error?.message || "Failed to initialize payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-4" />
            <p>Loading user information...</p>
          </div>
        </div>
      </div>
    );
  }

  const appearance = {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#7c3aed',
      colorBackground: '#ffffff',
      colorText: '#1f2937',
    },
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <Button 
            variant="ghost" 
            onClick={() => setLocation('/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Choose Your Pro Plan
          </h1>
          <p className="text-lg text-gray-600">
            Unlock all AI-powered career tools and accelerate your job search
          </p>
        </div>

        {!showPayment ? (
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <PlanCard
              billingCycle="monthly"
              onSelect={() => handlePlanSelect('monthly')}
              isSelected={selectedPlan === 'monthly'}
            />
            <PlanCard
              billingCycle="quarterly"
              onSelect={() => handlePlanSelect('quarterly')}
              isSelected={selectedPlan === 'quarterly'}
            />
          </div>
        ) : (
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-center">Complete Your Subscription</CardTitle>
                <CardDescription className="text-center">
                  Subscribe to PrepPair Pro {selectedPlan === 'monthly' ? 'Monthly ($19/month)' : 'Quarterly ($49/quarter)'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {clientSecret && (
                  <Elements 
                    stripe={stripePromise} 
                    options={{ clientSecret, appearance }}
                  >
                    <SubscribeForm billingCycle={selectedPlan!} />
                  </Elements>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {isLoading && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg">
              <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-4" />
              <p>Setting up your subscription...</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}