import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, BookOpen, MessageCircleQuestion, FolderOpen, Star, Clock } from "lucide-react";

interface Article {
  id: number;
  title: string;
  content: string;
  excerpt: string;
  slug: string;
  category: string;
  tags: string[] | null;
  status: string;
  author_name: string;
  created_at: string;
  view_count: number;
  helpful_count: number;
}

interface FAQ {
  id: number;
  question: string;
  answer: string;
  category_id: number | null;
  is_active: boolean;
  view_count: number;
  helpful_count: number;
  tags: string[] | null;
  created_at: string;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  color: string;
  icon: string;
  isActive: boolean;
}

interface SearchResults {
  articles: Article[];
  faqs: FAQ[];
}

export default function SupportApiTest() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResults>({ articles: [], faqs: [] });
  const [articles, setArticles] = useState<Article[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredArticles, setFeaturedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);

  // Load initial data
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      // Load categories
      const categoriesRes = await fetch('/api/knowledge/categories');
      const categoriesData = await categoriesRes.json();
      setCategories(categoriesData);

      // Load articles
      const articlesRes = await fetch('/api/knowledge/articles?limit=10');
      const articlesData = await articlesRes.json();
      setArticles(articlesData);

      // Load FAQs
      const faqsRes = await fetch('/api/knowledge/faqs?limit=10');
      const faqsData = await faqsRes.json();
      setFaqs(faqsData);

      // Load featured articles
      const featuredRes = await fetch('/api/knowledge/featured?type=articles&limit=5');
      const featuredData = await featuredRes.json();
      setFeaturedArticles(featuredData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/knowledge/search?q=${encodeURIComponent(searchQuery)}&limit=10`);
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
          Wrelik.com Knowledge Base API
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Comprehensive support system integration with 6 core endpoints
        </p>
      </div>

      {/* Search Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Universal Search API
          </CardTitle>
          <CardDescription>
            Search across articles and FAQs with intelligent ranking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input
              placeholder="Search knowledge base..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={loading}>
              Search
            </Button>
          </div>

          {searchResults.articles.length > 0 || searchResults.faqs.length > 0 ? (
            <div className="space-y-4">
              {searchResults.articles.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Articles ({searchResults.articles.length})</h3>
                  <div className="space-y-2">
                    {searchResults.articles.map((article) => (
                      <Card key={article.id} className="p-3">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium">{article.title}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                              {truncateText(article.excerpt || '', 150)}
                            </p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                              <span>Category: {article.category}</span>
                              <span>Views: {article.view_count}</span>
                              <span>Helpful: {article.helpful_count}</span>
                            </div>
                          </div>
                          <Badge variant="secondary">{article.category}</Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {searchResults.faqs.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">FAQs ({searchResults.faqs.length})</h3>
                  <div className="space-y-2">
                    {searchResults.faqs.map((faq) => (
                      <Card key={faq.id} className="p-3">
                        <div>
                          <h4 className="font-medium">{faq.question}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {truncateText(faq.answer, 200)}
                          </p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                            <span>Views: {faq.view_count}</span>
                            <span>Helpful: {faq.helpful_count}</span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : searchQuery && !loading && (
            <p className="text-gray-500 text-center py-4">No results found for "{searchQuery}"</p>
          )}
        </CardContent>
      </Card>

      {/* API Endpoints Tabs */}
      <Tabs defaultValue="articles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="articles" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Articles
          </TabsTrigger>
          <TabsTrigger value="faqs" className="flex items-center gap-2">
            <MessageCircleQuestion className="h-4 w-4" />
            FAQs
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center gap-2">
            <FolderOpen className="h-4 w-4" />
            Categories
          </TabsTrigger>
          <TabsTrigger value="featured" className="flex items-center gap-2">
            <Star className="h-4 w-4" />
            Featured
          </TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Base Articles</CardTitle>
              <CardDescription>
                Published articles from /api/knowledge/articles endpoint
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  {articles.map((article) => (
                    <Card key={article.id} className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold">{article.title}</h3>
                        <Badge variant="outline">{article.category}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        {article.excerpt}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>By {article.author_name}</span>
                        <span className="flex items-center gap-4">
                          <span>Views: {article.view_count}</span>
                          <span>Helpful: {article.helpful_count}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatDate(article.created_at)}
                          </span>
                        </span>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faqs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>
                Active FAQs from /api/knowledge/faqs endpoint
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  {faqs.map((faq) => (
                    <Card key={faq.id} className="p-4">
                      <h3 className="font-semibold mb-2">{faq.question}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        {faq.answer}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex gap-2">
                          {faq.tags && faq.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <span className="flex items-center gap-4">
                          <span>Views: {faq.view_count}</span>
                          <span>Helpful: {faq.helpful_count}</span>
                        </span>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Base Categories</CardTitle>
              <CardDescription>
                Organized categories from /api/knowledge/categories endpoint
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((category) => (
                  <Card key={category.id} className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div 
                        className="w-4 h-4 rounded" 
                        style={{ backgroundColor: category.color }}
                      />
                      <h3 className="font-semibold">{category.name}</h3>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {category.description}
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <Badge variant={category.isActive ? "default" : "secondary"}>
                        {category.isActive ? "Active" : "Inactive"}
                      </Badge>
                      <span>/{category.slug}</span>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="featured" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Featured Content</CardTitle>
              <CardDescription>
                Top-performing content from /api/knowledge/featured endpoint
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {featuredArticles.map((article, index) => (
                  <Card key={article.id} className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex items-center justify-center w-8 h-8 bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-400 rounded-full text-sm font-semibold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold">{article.title}</h3>
                          <Badge variant="outline">{article.category}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          {article.excerpt}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>By {article.author_name}</span>
                          <span className="flex items-center gap-4">
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              {article.helpful_count} helpful
                            </span>
                            <span>{article.view_count} views</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* API Status */}
      <Card>
        <CardHeader>
          <CardTitle>API Integration Status</CardTitle>
          <CardDescription>
            Complete Wrelik.com unified support desk integration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Articles API</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Search API</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Categories API</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">FAQs API</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">Featured API</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-sm font-medium">JWT Security</span>
            </div>
          </div>
          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
              Integration Details
            </h4>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>• 6 core API endpoints fully operational</li>
              <li>• Real-time search across articles and FAQs</li>
              <li>• JWT-based authentication with aud=preppair.me</li>
              <li>• Comprehensive analytics and engagement tracking</li>
              <li>• Support ticket management system</li>
              <li>• Bulk content import/export capabilities</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}