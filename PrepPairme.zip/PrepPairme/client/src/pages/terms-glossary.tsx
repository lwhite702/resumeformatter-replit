import { useState } from "react";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, BookOpen, Briefcase, Users, Target } from "lucide-react";

interface GlossaryTerm {
  id: number;
  term: string;
  definition: string;
  category: string;
  relatedTerms: string[];
  usage: string;
}

const glossaryTerms: GlossaryTerm[] = [
  {
    id: 1,
    term: "ATS (Applicant Tracking System)",
    definition:
      "Software used by employers to collect, sort, scan, and rank job applications. ATS systems filter resumes based on keywords, skills, and other criteria before human recruiters review them.",
    category: "Technology",
    relatedTerms: ["Resume Optimization", "Keywords", "Screening"],
    usage:
      "Make sure your resume is ATS-friendly by using standard formatting and including relevant keywords from the job description.",
  },
  {
    id: 2,
    term: "STAR Method",
    definition:
      "A structured approach to answering behavioral interview questions by describing the Situation, Task, Action, and Result of a specific experience.",
    category: "Interview Technique",
    relatedTerms: ["Behavioral Questions", "Storytelling", "Examples"],
    usage:
      "When asked 'Tell me about a time when...', use STAR to structure your response with concrete examples.",
  },
  {
    id: 3,
    term: "Behavioral Interview",
    definition:
      "An interview technique that focuses on how you handled past situations to predict future performance. Questions typically start with 'Tell me about a time when...'",
    category: "Interview Types",
    relatedTerms: ["STAR Method", "Competency-Based", "Past Experience"],
    usage:
      "Prepare 5-7 specific examples from your experience that demonstrate key competencies like leadership, problem-solving, and teamwork.",
  },
  {
    id: 4,
    term: "Technical Interview",
    definition:
      "An interview focused on assessing technical skills through coding challenges, system design questions, or domain-specific problems.",
    category: "Interview Types",
    relatedTerms: ["Coding Challenge", "System Design", "Problem Solving"],
    usage:
      "Practice coding problems on platforms like LeetCode and be ready to explain your thought process while solving problems.",
  },
  {
    id: 5,
    term: "Culture Fit",
    definition:
      "How well a candidate's values, work style, and personality align with the company's culture and team dynamics.",
    category: "Evaluation Criteria",
    relatedTerms: ["Values Alignment", "Team Dynamics", "Company Culture"],
    usage:
      "Research the company's values and mission to demonstrate alignment during interviews and in your application materials.",
  },
  {
    id: 6,
    term: "Elevator Pitch",
    definition:
      "A brief, compelling summary of your professional background and value proposition, typically 30-60 seconds long.",
    category: "Communication",
    relatedTerms: ["Personal Branding", "Introduction", "Value Proposition"],
    usage:
      "Prepare a concise elevator pitch for networking events, interviews, and when answering 'Tell me about yourself.'",
  },
  {
    id: 7,
    term: "Soft Skills",
    definition:
      "Non-technical abilities like communication, teamwork, leadership, and emotional intelligence that are essential for workplace success.",
    category: "Skills",
    relatedTerms: [
      "Interpersonal Skills",
      "Emotional Intelligence",
      "Communication",
    ],
    usage:
      "Highlight soft skills in interviews with specific examples of how you've demonstrated leadership, collaboration, or adaptability.",
  },
  {
    id: 8,
    term: "Hard Skills",
    definition:
      "Technical, measurable abilities and knowledge that can be taught and quantified, such as programming languages, certifications, or software proficiency.",
    category: "Skills",
    relatedTerms: ["Technical Skills", "Certifications", "Competencies"],
    usage:
      "List relevant hard skills prominently on your resume and be prepared to demonstrate them during technical interviews.",
  },
  {
    id: 9,
    term: "Competency-Based Interview",
    definition:
      "An interview approach that evaluates specific competencies or skills required for the role through targeted questions and scenarios.",
    category: "Interview Types",
    relatedTerms: [
      "Behavioral Questions",
      "Skills Assessment",
      "Performance Indicators",
    ],
    usage:
      "Review the job description to identify key competencies and prepare examples demonstrating each one.",
  },
  {
    id: 10,
    term: "Onboarding",
    definition:
      "The process of integrating new employees into an organization, including orientation, training, and cultural assimilation.",
    category: "Process",
    relatedTerms: ["Orientation", "Training", "Integration"],
    usage:
      "During interviews, ask about the company's onboarding process to show interest in successful integration.",
  },
];

export default function TermsGlossary() {
  useScrollToTop();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = [
    "All",
    "Technology",
    "Interview Technique",
    "Interview Types",
    "Evaluation Criteria",
    "Communication",
    "Skills",
    "Process",
  ];

  const filteredTerms = glossaryTerms.filter((term) => {
    const matchesSearch =
      searchTerm === "" ||
      term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
      term.definition.toLowerCase().includes(searchTerm.toLowerCase()) ||
      term.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "All" || term.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Technology":
        return Target;
      case "Interview Technique":
        return BookOpen;
      case "Interview Types":
        return Users;
      case "Skills":
        return Briefcase;
      default:
        return BookOpen;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Technology":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "Interview Technique":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "Interview Types":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "Evaluation Criteria":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      case "Communication":
        return "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200";
      case "Skills":
        return "bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200";
      case "Process":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />

      <main className="pt-16 lg:pt-20">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Career Terms Glossary
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Master the essential terminology for job searching, interviews,
              and career development. Build your professional vocabulary with
              clear definitions and practical usage examples.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search terms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <div className="flex gap-2 flex-wrap">
                {categories.map((category) => (
                  <Badge
                    key={category}
                    variant={
                      selectedCategory === category ? "default" : "outline"
                    }
                    className="cursor-pointer px-3 py-1"
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Terms Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredTerms.map((term) => {
              const IconComponent = getCategoryIcon(term.category);
              return (
                <Card
                  key={term.id}
                  className="hover:shadow-lg transition-shadow"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <CardTitle className="text-lg leading-tight">
                        {term.term}
                      </CardTitle>
                      <IconComponent className="w-5 h-5 text-gray-500 flex-shrink-0" />
                    </div>
                    <Badge
                      className={`w-fit ${getCategoryColor(term.category)}`}
                    >
                      {term.category}
                    </Badge>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                      {term.definition}
                    </p>

                    <div>
                      <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">
                        How to Use:
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 italic">
                        {term.usage}
                      </p>
                    </div>

                    {term.relatedTerms.length > 0 && (
                      <div>
                        <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">
                          Related Terms:
                        </h4>
                        <div className="flex gap-1 flex-wrap">
                          {term.relatedTerms.map((relatedTerm, index) => (
                            <Badge
                              key={index}
                              variant="outline"
                              className="text-xs"
                            >
                              {relatedTerm}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredTerms.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                No terms found
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Try adjusting your search criteria or category filter.
              </p>
            </div>
          )}

          {/* Additional Resources */}
          <div className="mt-16">
            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200 dark:border-blue-700">
              <CardContent className="p-8 text-center">
                <BookOpen className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Expand Your Career Vocabulary
                </h3>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                  Understanding these terms will help you communicate more
                  effectively in interviews, networking events, and professional
                  conversations. Keep this glossary handy as you navigate your
                  career journey.
                </p>
                <div className="flex justify-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <span>• {glossaryTerms.length} Essential Terms</span>
                  <span>• Practical Usage Examples</span>
                  <span>• Related Concepts</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
