import { useState } from "react";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import { NavigationHeader } from "@/components/navigation-header-new";
import { Footer } from "@/components/ui/footer";
import { BlurredContent } from "@/components/ui/blurred-content";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  VideoIcon, 
  Camera, 
  Mic, 
  Play, 
  Pause, 
  Square, 
  Timer, 
  Eye,
  BarChart3,
  TrendingUp,
  Star,
  Target,
  Brain,
  Users,
  Crown
} from "lucide-react";

interface VideoSession {
  id: number;
  title: string;
  duration: number;
  feedback: {
    overallScore: number;
    confidenceScore: number;
    clarityScore: number;
    eyeContact: string;
    speakingPace: string;
    strengths: string[];
    improvements: string[];
  };
  isPremium: boolean;
}

const sampleSessions: VideoSession[] = [
  {
    id: 1,
    title: "Basic Introduction Practice",
    duration: 120,
    feedback: {
      overallScore: 78,
      confidenceScore: 80,
      clarityScore: 75,
      eyeContact: "Good",
      speakingPace: "Moderate",
      strengths: ["Clear articulation", "Good posture"],
      improvements: ["More eye contact", "Reduce filler words"]
    },
    isPremium: false
  },
  {
    id: 2,
    title: "Advanced Behavioral Questions",
    duration: 300,
    feedback: {
      overallScore: 0,
      confidenceScore: 0,
      clarityScore: 0,
      eyeContact: "Premium analysis",
      speakingPace: "Premium analysis",
      strengths: ["Premium insights available"],
      improvements: ["Upgrade to access detailed feedback"]
    },
    isPremium: true
  }
];

const practiceQuestions = [
  { id: 1, question: "Tell me about yourself", category: "Introduction", difficulty: "Easy", isPremium: false },
  { id: 2, question: "Why do you want this position?", category: "Motivation", difficulty: "Medium", isPremium: false },
  { id: 3, question: "Describe a challenging situation you overcame", category: "Behavioral", difficulty: "Hard", isPremium: true },
  { id: 4, question: "How do you handle conflict with teammates?", category: "Behavioral", difficulty: "Hard", isPremium: true },
  { id: 5, question: "What are your salary expectations?", category: "Negotiation", difficulty: "Hard", isPremium: true }
];

export default function VideoPracticeEnhanced() {
  useScrollToTop();
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [selectedQuestion, setSelectedQuestion] = useState(practiceQuestions[0]);
  const [activeTab, setActiveTab] = useState("practice");

  const mockFeedbackData = {
    overallScore: 85,
    scores: {
      confidence: 88,
      clarity: 82,
      pace: 80,
      engagement: 90
    },
    insights: [
      "Strong opening and conclusion",
      "Good use of specific examples",
      "Maintained good eye contact",
      "Speaking pace was appropriate"
    ],
    improvements: [
      "Reduce filler words (um, uh)",
      "Use more hand gestures for emphasis",
      "Pause between key points",
      "Practice stronger closing statements"
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavigationHeader />
      
      <main className="pt-16 lg:pt-20">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Video Interview Practice
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Practice your interview skills with AI-powered feedback and analysis. 
              Record yourself answering questions and get detailed insights to improve your performance.
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="practice">Practice Session</TabsTrigger>
              <TabsTrigger value="sessions">My Sessions</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            {/* Practice Tab */}
            <TabsContent value="practice" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Video Recording Area */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="w-5 h-5" />
                      Recording Studio
                    </CardTitle>
                    <CardDescription>
                      Set up your camera and microphone to start practicing
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Camera Preview */}
                    <div className="aspect-video bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-600">
                      <div className="text-center">
                        <VideoIcon className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-500 dark:text-gray-400">Camera preview will appear here</p>
                      </div>
                    </div>

                    {/* Recording Controls */}
                    <div className="flex items-center justify-center gap-4">
                      <Button
                        onClick={() => setIsRecording(!isRecording)}
                        className={isRecording ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
                      >
                        {isRecording ? (
                          <>
                            <Square className="w-4 h-4 mr-2" />
                            Stop Recording
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Start Recording
                          </>
                        )}
                      </Button>
                      
                      {isRecording && (
                        <div className="flex items-center gap-2 text-red-600">
                          <div className="w-3 h-3 bg-red-600 rounded-full animate-pulse" />
                          <Timer className="w-4 h-4" />
                          <span className="font-mono">{Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}</span>
                        </div>
                      )}
                    </div>

                    {/* Audio/Video Settings */}
                    <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                      <div className="flex items-center gap-2">
                        <Camera className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Camera: Ready</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mic className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600 dark:text-gray-400">Microphone: Ready</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Question Selection */}
                <Card>
                  <CardHeader>
                    <CardTitle>Practice Questions</CardTitle>
                    <CardDescription>
                      Choose a question to practice or use our AI-generated questions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      {practiceQuestions.map((question) => (
                        <div
                          key={question.id}
                          className={`p-4 border rounded-lg cursor-pointer transition-all ${
                            selectedQuestion.id === question.id
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 dark:border-gray-700 hover:border-primary/50"
                          } ${question.isPremium ? "relative overflow-hidden" : ""}`}
                          onClick={() => !question.isPremium && setSelectedQuestion(question)}
                        >
                          {question.isPremium && (
                            <div className="absolute top-2 right-2">
                              <Crown className="w-4 h-4 text-purple-600" />
                            </div>
                          )}
                          
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <p className={`font-medium ${question.isPremium ? "text-gray-500" : "text-gray-900 dark:text-white"}`}>
                                {question.question}
                              </p>
                              <div className="flex gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  {question.category}
                                </Badge>
                                <Badge variant={question.difficulty === "Easy" ? "default" : question.difficulty === "Medium" ? "secondary" : "destructive"} className="text-xs">
                                  {question.difficulty}
                                </Badge>
                                {question.isPremium && (
                                  <Badge variant="outline" className="text-xs text-purple-600 border-purple-600">
                                    Premium
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Selected Question Display */}
                    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-2">
                        Current Question:
                      </h4>
                      <p className="text-blue-800 dark:text-blue-300">
                        {selectedQuestion.question}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Sessions Tab */}
            <TabsContent value="sessions" className="space-y-6">
              <div className="grid gap-6">
                {sampleSessions.map((session) => (
                  <BlurredContent
                    key={session.id}
                    requiredFeature={session.isPremium ? "video_practice" : undefined}
                    featureName="Advanced Video Analysis"
                    description="Get detailed AI-powered feedback on your interview performance including confidence scoring, speaking pace analysis, and personalized improvement recommendations."
                  >
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              <VideoIcon className="w-5 h-5" />
                              {session.title}
                            </CardTitle>
                            <CardDescription>
                              Duration: {Math.floor(session.duration / 60)}:{(session.duration % 60).toString().padStart(2, '0')}
                            </CardDescription>
                          </div>
                          {session.isPremium && (
                            <Crown className="w-6 h-6 text-purple-600" />
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                          {/* Scores */}
                          <div className="space-y-4">
                            <h4 className="font-semibold">Performance Scores</h4>
                            
                            <div className="space-y-3">
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Overall Score</span>
                                  <span>{session.feedback.overallScore}%</span>
                                </div>
                                <Progress value={session.feedback.overallScore} className="h-2" />
                              </div>
                              
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Confidence</span>
                                  <span>{session.feedback.confidenceScore}%</span>
                                </div>
                                <Progress value={session.feedback.confidenceScore} className="h-2" />
                              </div>
                              
                              <div>
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Clarity</span>
                                  <span>{session.feedback.clarityScore}%</span>
                                </div>
                                <Progress value={session.feedback.clarityScore} className="h-2" />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-gray-600 dark:text-gray-400">Eye Contact:</span>
                                <p className="font-medium">{session.feedback.eyeContact}</p>
                              </div>
                              <div>
                                <span className="text-gray-600 dark:text-gray-400">Speaking Pace:</span>
                                <p className="font-medium">{session.feedback.speakingPace}</p>
                              </div>
                            </div>
                          </div>

                          {/* Feedback */}
                          <div className="space-y-4">
                            <div>
                              <h4 className="font-semibold text-green-700 dark:text-green-400 mb-2">Strengths</h4>
                              <ul className="space-y-1">
                                {session.feedback.strengths.map((strength, index) => (
                                  <li key={index} className="text-sm flex items-start gap-2">
                                    <Star className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                                    {strength}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div>
                              <h4 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">Areas for Improvement</h4>
                              <ul className="space-y-1">
                                {session.feedback.improvements.map((improvement, index) => (
                                  <li key={index} className="text-sm flex items-start gap-2">
                                    <Target className="w-3 h-3 text-blue-500 mt-0.5 flex-shrink-0" />
                                    {improvement}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </BlurredContent>
                ))}
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <BlurredContent
                requiredFeature="video_practice"
                featureName="Performance Analytics"
                description="Track your progress over time with detailed analytics, trend analysis, and personalized coaching recommendations based on your video practice sessions."
              >
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <BarChart3 className="w-8 h-8 text-blue-600" />
                        <div>
                          <p className="text-2xl font-bold">{mockFeedbackData.overallScore}%</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Overall Score</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <TrendingUp className="w-8 h-8 text-green-600" />
                        <div>
                          <p className="text-2xl font-bold">+12%</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Improvement</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <Eye className="w-8 h-8 text-purple-600" />
                        <div>
                          <p className="text-2xl font-bold">24</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Sessions</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <Brain className="w-8 h-8 text-orange-600" />
                        <div>
                          <p className="text-2xl font-bold">89%</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Confidence</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Detailed Analytics Charts */}
                <div className="grid lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Trends</CardTitle>
                      <CardDescription>Your interview skills progress over time</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <div className="text-center">
                          <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-500">Performance chart would appear here</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Skill Breakdown</CardTitle>
                      <CardDescription>Areas of strength and improvement</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {Object.entries(mockFeedbackData.scores).map(([skill, score]) => (
                          <div key={skill}>
                            <div className="flex justify-between text-sm mb-1">
                              <span className="capitalize">{skill}</span>
                              <span>{score}%</span>
                            </div>
                            <Progress value={score} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* AI Insights */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="w-5 h-5" />
                      AI-Powered Insights
                    </CardTitle>
                    <CardDescription>
                      Personalized recommendations based on your performance data
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-green-700 dark:text-green-400 mb-3">Key Strengths</h4>
                        <ul className="space-y-2">
                          {mockFeedbackData.insights.map((insight, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Star className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{insight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-blue-700 dark:text-blue-400 mb-3">Recommended Focus Areas</h4>
                        <ul className="space-y-2">
                          {mockFeedbackData.improvements.map((improvement, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Target className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{improvement}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </BlurredContent>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}