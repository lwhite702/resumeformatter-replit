import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { VideoIcon, MicIcon, Square, PlayIcon, BarChart3, ClockIcon, CheckCircleIcon, XCircleIcon } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

interface VideoPracticeSession {
  id: number;
  title: string;
  description?: string;
  questionId?: number;
  customQuestion?: string;
  videoUrl?: string;
  transcription?: string;
  duration?: number;
  status: string;
  createdAt: string;
}

interface VideoFeedback {
  id: number;
  sessionId: number;
  overallScore: number;
  contentScore: number;
  deliveryScore: number;
  clarityScore: number;
  confidenceScore: number;
  strengths: string[];
  improvements: string[];
  keyInsights: string[];
  speakingPace: string;
  fillerWords: number;
  eyeContact: string;
  bodyLanguage: string;
  practiceAreas: string[];
  suggestedQuestions: string[];
}

interface Question {
  id: number;
  question: string;
  category: string;
}

export default function VideoPractice() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);
  const [selectedSession, setSelectedSession] = useState<VideoPracticeSession | null>(null);
  const [showNewSession, setShowNewSession] = useState(false);
  const [transcriptionText, setTranscriptionText] = useState("");

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: sessions = [], isLoading: sessionsLoading } = useQuery<VideoPracticeSession[]>({
    queryKey: ["/api/video-practice"],
    enabled: isAuthenticated,
  });

  const { data: questions = [] } = useQuery<Question[]>({
    queryKey: ["/api/questions"],
    enabled: isAuthenticated,
  });

  const createSessionMutation = useMutation({
    mutationFn: async (data: { title: string; description?: string; questionId?: number; customQuestion?: string }) => {
      return await apiRequest("POST", "/api/video-practice", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/video-practice"] });
      setShowNewSession(false);
      toast({
        title: "Success",
        description: "Practice session created successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const analyzeVideoMutation = useMutation({
    mutationFn: async ({ sessionId, transcription }: { sessionId: number; transcription: string }) => {
      return await apiRequest("POST", `/api/video-practice/${sessionId}/analyze`, { transcription });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/video-practice"] });
      toast({
        title: "Success",
        description: "Video analyzed successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setRecordedBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (error) {
      toast({
        title: "Error",
        description: "Could not access camera and microphone",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }

      if (selectedSession) {
        // Update session with duration
        apiRequest("PUT", `/api/video-practice/${selectedSession.id}`, {
          duration: recordingTime
        });
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnalyze = () => {
    if (!selectedSession || !transcriptionText.trim()) {
      toast({
        title: "Error",
        description: "Please provide a transcription of your response",
        variant: "destructive",
      });
      return;
    }

    analyzeVideoMutation.mutate({
      sessionId: selectedSession.id,
      transcription: transcriptionText
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreBadgeVariant = (score: number) => {
    if (score >= 80) return "default";
    if (score >= 60) return "secondary";
    return "destructive";
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Video Interview Practice</h1>
          <p className="text-muted-foreground">
            Practice your interview skills with AI-powered feedback
          </p>
        </div>
        <Dialog open={showNewSession} onOpenChange={setShowNewSession}>
          <DialogTrigger asChild>
            <Button>
              <VideoIcon className="mr-2 h-4 w-4" />
              New Practice Session
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Create New Practice Session</DialogTitle>
              <DialogDescription>
                Set up a new video interview practice session
              </DialogDescription>
            </DialogHeader>
            <NewSessionForm 
              questions={questions}
              onSubmit={(data) => createSessionMutation.mutate(data)}
              isLoading={createSessionMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="sessions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="sessions">My Sessions</TabsTrigger>
          <TabsTrigger value="practice">Practice Now</TabsTrigger>
        </TabsList>

        <TabsContent value="sessions" className="space-y-6">
          <SessionsList 
            sessions={sessions}
            isLoading={sessionsLoading}
            onSelectSession={setSelectedSession}
          />
        </TabsContent>

        <TabsContent value="practice" className="space-y-6">
          {selectedSession ? (
            <PracticeInterface
              session={selectedSession}
              isRecording={isRecording}
              recordingTime={recordingTime}
              recordedBlob={recordedBlob}
              transcriptionText={transcriptionText}
              videoRef={videoRef}
              onStartRecording={startRecording}
              onStopRecording={stopRecording}
              onTranscriptionChange={setTranscriptionText}
              onAnalyze={handleAnalyze}
              isAnalyzing={analyzeVideoMutation.isPending}
            />
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <VideoIcon className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Session Selected</h3>
                <p className="text-muted-foreground mb-4">
                  Create or select a practice session to begin
                </p>
                <Button onClick={() => setShowNewSession(true)}>
                  Create New Session
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function NewSessionForm({ 
  questions, 
  onSubmit, 
  isLoading 
}: { 
  questions: Question[];
  onSubmit: (data: any) => void;
  isLoading: boolean;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [questionType, setQuestionType] = useState<"preset" | "custom">("preset");
  const [selectedQuestionId, setSelectedQuestionId] = useState<string>("");
  const [customQuestion, setCustomQuestion] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      return;
    }

    const data: any = {
      title: title.trim(),
      description: description.trim() || undefined,
    };

    if (questionType === "preset" && selectedQuestionId) {
      data.questionId = parseInt(selectedQuestionId);
    } else if (questionType === "custom" && customQuestion.trim()) {
      data.customQuestion = customQuestion.trim();
    }

    onSubmit(data);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Session Title</Label>
        <Input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g., Software Engineer Interview Practice"
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description (Optional)</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of this practice session"
          rows={3}
        />
      </div>

      <div>
        <Label>Interview Question</Label>
        <Tabs value={questionType} onValueChange={(value) => setQuestionType(value as "preset" | "custom")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="preset">Preset Question</TabsTrigger>
            <TabsTrigger value="custom">Custom Question</TabsTrigger>
          </TabsList>
          
          <TabsContent value="preset" className="mt-4">
            <Select value={selectedQuestionId} onValueChange={setSelectedQuestionId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a question" />
              </SelectTrigger>
              <SelectContent>
                {questions.map((question) => (
                  <SelectItem key={question.id} value={question.id.toString()}>
                    {question.question}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </TabsContent>
          
          <TabsContent value="custom" className="mt-4">
            <Textarea
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              placeholder="Enter your custom interview question"
              rows={3}
            />
          </TabsContent>
        </Tabs>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Creating..." : "Create Session"}
        </Button>
      </div>
    </form>
  );
}

function SessionsList({ 
  sessions, 
  isLoading, 
  onSelectSession 
}: { 
  sessions: VideoPracticeSession[];
  isLoading: boolean;
  onSelectSession: (session: VideoPracticeSession) => void;
}) {
  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (sessions.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <VideoIcon className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Practice Sessions</h3>
          <p className="text-muted-foreground">
            Create your first video practice session to get started
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {sessions.map((session) => (
        <SessionCard 
          key={session.id} 
          session={session} 
          onSelect={() => onSelectSession(session)}
        />
      ))}
    </div>
  );
}

function SessionCard({ 
  session, 
  onSelect 
}: { 
  session: VideoPracticeSession;
  onSelect: () => void;
}) {
  const getStatusIcon = () => {
    switch (session.status) {
      case "completed":
        return <CheckCircleIcon className="h-4 w-4 text-green-600" />;
      case "processing":
        return <ClockIcon className="h-4 w-4 text-yellow-600" />;
      default:
        return <VideoIcon className="h-4 w-4 text-blue-600" />;
    }
  };

  const getStatusText = () => {
    switch (session.status) {
      case "completed":
        return "Analyzed";
      case "processing":
        return "Processing";
      case "recording":
        return "Ready to Record";
      default:
        return "New";
    }
  };

  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={onSelect}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg line-clamp-2">{session.title}</CardTitle>
          <div className="flex items-center space-x-1">
            {getStatusIcon()}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <CardDescription className="text-sm">
            {new Date(session.createdAt).toLocaleDateString()}
          </CardDescription>
          <Badge variant="outline" className="text-xs">
            {getStatusText()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {session.description && (
          <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
            {session.description}
          </p>
        )}
        {session.duration && (
          <div className="flex items-center text-sm text-muted-foreground">
            <ClockIcon className="h-3 w-3 mr-1" />
            {Math.floor(session.duration / 60)}m {session.duration % 60}s
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PracticeInterface({
  session,
  isRecording,
  recordingTime,
  recordedBlob,
  transcriptionText,
  videoRef,
  onStartRecording,
  onStopRecording,
  onTranscriptionChange,
  onAnalyze,
  isAnalyzing
}: {
  session: VideoPracticeSession;
  isRecording: boolean;
  recordingTime: number;
  recordedBlob: Blob | null;
  transcriptionText: string;
  videoRef: React.RefObject<HTMLVideoElement>;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onTranscriptionChange: (text: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}) {
  const { data: feedback } = useQuery<VideoFeedback>({
    queryKey: [`/api/video-practice/${session.id}/feedback`],
    enabled: session.status === "completed",
  });

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{session.title}</CardTitle>
          {session.description && (
            <CardDescription>{session.description}</CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {(session.customQuestion || session.questionId) && (
            <Alert>
              <AlertDescription className="font-medium">
                Interview Question: {session.customQuestion || "Loading question..."}
              </AlertDescription>
            </Alert>
          )}

          <div className="relative">
            <video
              ref={videoRef}
              autoPlay
              muted
              className="w-full h-64 bg-gray-900 rounded-lg"
            />
            
            {isRecording && (
              <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                {formatTime(recordingTime)}
              </div>
            )}
          </div>

          <div className="flex justify-center space-x-4">
            {!isRecording ? (
              <Button onClick={onStartRecording} size="lg">
                <VideoIcon className="mr-2 h-4 w-4" />
                Start Recording
              </Button>
            ) : (
              <Button onClick={onStopRecording} variant="destructive" size="lg">
                <Square className="mr-2 h-4 w-4" />
                Stop Recording
              </Button>
            )}
          </div>

          {recordedBlob && (
            <div className="space-y-4">
              <Alert>
                <CheckCircleIcon className="h-4 w-4" />
                <AlertDescription>
                  Recording completed! Please provide a transcription of your response below.
                </AlertDescription>
              </Alert>

              <div>
                <Label htmlFor="transcription">Your Response Transcription</Label>
                <Textarea
                  id="transcription"
                  value={transcriptionText}
                  onChange={(e) => onTranscriptionChange(e.target.value)}
                  placeholder="Type what you said in your response here..."
                  rows={6}
                  className="mt-2"
                />
              </div>

              <Button 
                onClick={onAnalyze} 
                disabled={!transcriptionText.trim() || isAnalyzing}
                className="w-full"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Analyzing Response...
                  </>
                ) : (
                  <>
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Get AI Feedback
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {feedback && (
        <FeedbackDisplay feedback={feedback} />
      )}
    </div>
  );
}

function FeedbackDisplay({ feedback }: { feedback: VideoFeedback }) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreBadgeVariant = (score: number) => {
    if (score >= 80) return "default";
    if (score >= 60) return "secondary";
    return "destructive";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart3 className="mr-2 h-5 w-5" />
          AI Feedback Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Score */}
        <div className="text-center">
          <div className={`text-4xl font-bold ${getScoreColor(feedback.overallScore)}`}>
            {feedback.overallScore}/100
          </div>
          <p className="text-muted-foreground">Overall Score</p>
        </div>

        {/* Score Breakdown */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <Badge variant={getScoreBadgeVariant(feedback.contentScore)} className="mb-2">
              {feedback.contentScore}/100
            </Badge>
            <p className="text-sm">Content</p>
          </div>
          <div className="text-center">
            <Badge variant={getScoreBadgeVariant(feedback.deliveryScore)} className="mb-2">
              {feedback.deliveryScore}/100
            </Badge>
            <p className="text-sm">Delivery</p>
          </div>
          <div className="text-center">
            <Badge variant={getScoreBadgeVariant(feedback.clarityScore)} className="mb-2">
              {feedback.clarityScore}/100
            </Badge>
            <p className="text-sm">Clarity</p>
          </div>
          <div className="text-center">
            <Badge variant={getScoreBadgeVariant(feedback.confidenceScore)} className="mb-2">
              {feedback.confidenceScore}/100
            </Badge>
            <p className="text-sm">Confidence</p>
          </div>
        </div>

        {/* Strengths */}
        <div>
          <h4 className="font-semibold text-green-600 mb-2">Strengths</h4>
          <ul className="space-y-1">
            {feedback.strengths.map((strength, index) => (
              <li key={index} className="flex items-start">
                <CheckCircleIcon className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-sm">{strength}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Areas for Improvement */}
        <div>
          <h4 className="font-semibold text-orange-600 mb-2">Areas for Improvement</h4>
          <ul className="space-y-1">
            {feedback.improvements.map((improvement, index) => (
              <li key={index} className="flex items-start">
                <XCircleIcon className="h-4 w-4 text-orange-600 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-sm">{improvement}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Key Insights */}
        <div>
          <h4 className="font-semibold text-blue-600 mb-2">Key Insights</h4>
          <ul className="space-y-1">
            {feedback.keyInsights.map((insight, index) => (
              <li key={index} className="flex items-start">
                <div className="h-4 w-4 bg-blue-600 rounded-full mr-2 mt-0.5 flex-shrink-0"></div>
                <span className="text-sm">{insight}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Speech Analysis */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Speaking Pace</p>
            <p className="font-medium capitalize">{feedback.speakingPace}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Filler Words</p>
            <p className="font-medium">{feedback.fillerWords}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Eye Contact</p>
            <p className="font-medium capitalize">{feedback.eyeContact}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Body Language</p>
            <p className="font-medium capitalize">{feedback.bodyLanguage}</p>
          </div>
        </div>

        {/* Recommended Practice Areas */}
        <div>
          <h4 className="font-semibold mb-2">Recommended Practice Areas</h4>
          <div className="flex flex-wrap gap-2">
            {feedback.practiceAreas.map((area, index) => (
              <Badge key={index} variant="outline">
                {area}
              </Badge>
            ))}
          </div>
        </div>

        {/* Suggested Questions */}
        <div>
          <h4 className="font-semibold mb-2">Suggested Questions for Next Practice</h4>
          <ul className="space-y-1">
            {feedback.suggestedQuestions.map((question, index) => (
              <li key={index} className="text-sm text-muted-foreground">
                • {question}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}