# Getting Started with PrepPair.me

## Overview
PrepPair.me is your AI-powered interview preparation and career development platform. In just 3 clicks, you can create personalized interview guides, optimize your resume, and track your job search progress.

## Quick Start Guide

### Step 1: Create Your Account
1. Click "Start Your Journey" on the homepage
2. Sign in using your preferred OAuth provider
3. You'll be redirected to your personalized dashboard

### Step 2: Upload Your Resume
1. Navigate to the Resume Optimizer section
2. Upload your resume (PDF, DOCX, or text format supported)
3. Or paste your resume content directly into the text area
4. Your resume will be automatically parsed and analyzed

### Step 3: Generate Your First Interview Guide
1. Go to the Interview Guide section
2. Paste a job description from any job posting
3. Click "Generate Interview Guide"
4. Review your personalized questions, answers, and STAR stories

## Key Features at a Glance

### Free Features
- **Resume Upload & Analysis**: Get ATS scores and basic optimization tips
- **Interview Guide Generator**: Create guides with AI-powered questions and answers
- **Job Tracking**: Organize your applications and interview pipeline
- **Career Mood Board**: Track your emotional journey through job searching
- **Question Database**: Access 100+ common interview questions

### Pro Features
- **Unlimited Guides**: Create as many interview guides as you need
- **Advanced STAR Stories**: Get detailed behavioral question responses
- **Resume Optimization**: Detailed keyword analysis and improvement suggestions
- **Priority Support**: Get help faster with dedicated assistance
- **Video Practice**: Record and analyze your interview performance

## Navigation Overview

### Dashboard
Your central hub showing:
- Recent interview guides
- Resume analysis results
- Job application tracking
- Quick action buttons for common tasks

### Main Features
- **Interview Guide**: AI-powered interview preparation
- **Resume Optimizer**: ATS optimization and improvement
- **Job Tracker**: Application management and pipeline tracking
- **Career Mood Board**: Emotional journey tracking
- **Video Practice**: Interview recording and feedback
- **Questions Database**: Comprehensive question library

## Credit System

### How Credits Work
- Free users receive 2 credits to start
- Each AI action (guide generation, optimization) uses 1 credit
- Credits never expire and carry over
- Pro users get unlimited access to all features

### Managing Credits
- View your current credit balance in the dashboard
- Purchase additional credits as needed
- Upgrade to Pro for unlimited access

## Getting Help

### In-App Support
- Click the help button (bottom right) for comprehensive guides
- Access step-by-step tutorials for each feature
- Find answers to frequently asked questions

### Contact Support
- Email: support@preppair.me
- Response time: 24 hours (4 hours for Pro users)
- Live chat available during business hours

## Pro vs Free Comparison

| Feature | Free | Pro |
|---------|------|-----|
| Interview Guides | 2 credits | Unlimited |
| Resume Optimization | Basic | Advanced |
| STAR Stories | Limited | Detailed |
| Video Practice | Not included | Full access |
| Support | Standard | Priority |
| Monthly Price | $0 | $19 |

## Next Steps

1. **Upload Your Resume**: Start with resume analysis to understand your baseline ATS score
2. **Create Your First Guide**: Generate an interview guide for a specific job
3. **Track Applications**: Add jobs you're applying to for organized tracking
4. **Explore Features**: Try the mood board and video practice tools
5. **Consider Pro**: Upgrade for unlimited access to all features

## Troubleshooting

### Common Issues
- **Resume not parsing correctly**: Try pasting content directly instead of uploading
- **Job description not recognized**: Ensure you're pasting the full job posting text
- **Credits not updating**: Refresh the page or contact support
- **Features not loading**: Clear browser cache and cookies

### File Format Support
- **Resume Upload**: PDF, DOCX, TXT files
- **Maximum file size**: 10MB
- **Alternative**: Copy and paste resume text directly

Need more help? Use the floating help button or contact our support team.