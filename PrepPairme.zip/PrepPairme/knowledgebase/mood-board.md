# Career Mood Board

## Overview
The Career Mood Board is an interactive emotional tracking system that helps you log and reflect on your job search journey. Track your feelings, celebrate wins, process setbacks, and maintain emotional awareness throughout your career development.

## How to Access
- **Navigation**: Click "Mood Board" in the main menu
- **Dashboard**: Select mood board quick action
- **Route**: `/career-mood-board`

## Step-by-Step Instructions

### Creating Your First Mood Entry

1. **Select Your Mood**
   - Choose from 10 emotion options with emoji representations
   - Options: excited, confident, nervous, frustrated, hopeful, overwhelmed, motivated, exhausted, optimistic, anxious

2. **Set Intensity Level**
   - Use slider to rate intensity from 1-10
   - 1 = barely noticeable, 10 = extremely intense
   - Helps track emotional patterns over time

3. **Choose Category**
   - **Application**: Job application activities
   - **Interview**: Interview preparation and experiences
   - **Networking**: Professional relationship building
   - **Learning**: Skill development and education
   - **Milestone**: Career achievements and progress
   - **Setback**: Challenges and disappointments

4. **Add Details**
   - **Title**: Brief description of the event
   - **Description**: Detailed context and circumstances
   - **Location**: Where you were during this experience
   - **Weather Mood**: Optional atmospheric context

5. **Reflection Prompts**
   - **Gratitude**: What are you thankful for today
   - **Learnings**: Insights gained from this experience
   - **Tomorrow's Focus**: What you want to prioritize next

### Advanced Features

**Linking to Applications:**
- Connect mood entries to specific job applications
- Track emotional patterns for different companies
- Analyze which opportunities create positive feelings

**Goal Setting:**
- Add personal goals related to the mood entry
- Track progress toward career objectives
- Celebrate goal achievements

**Tag System:**
- Add custom tags for better organization
- Filter entries by tags
- Create personal tracking categories

## Understanding Your Data

### Mood Patterns
- View emotional trends over time
- Identify triggers for specific moods
- Recognize patterns in job search journey

### Category Analysis
- See which activities generate positive emotions
- Understand sources of stress or anxiety
- Balance different types of career activities

### Intensity Tracking
- Monitor emotional intensity changes
- Notice if certain activities consistently rate high or low
- Adjust strategies based on emotional impact

## Privacy and Security

**Entry Privacy:**
- Mark entries as private for personal reflection
- Private entries visible only to you
- Public entries can be shared with career coaches

**Data Control:**
- Edit or delete entries anytime
- Export your mood data
- Complete control over shared information

## Benefits of Mood Tracking

### Self-Awareness
- Understand emotional responses to career activities
- Recognize stress patterns and triggers
- Celebrate progress and achievements

### Strategic Planning
- Make decisions based on emotional data
- Choose opportunities that align with well-being
- Avoid patterns that consistently cause stress

### Interview Preparation
- Process anxiety before important interviews
- Build confidence through reflection
- Develop emotional regulation strategies

## Integration with Other Features

**Job Tracker Connection:**
- Link mood entries to specific applications
- Track emotional journey for each opportunity
- Analyze which companies feel like good fits

**Interview Guide Enhancement:**
- Use positive mood entries for confidence building
- Address anxiety patterns in interview preparation
- Reflect on past successes for STAR stories

**Video Practice Correlation:**
- Track confidence levels during practice sessions
- Notice improvement in comfort over time
- Celebrate progress in communication skills

## Best Practices

### Regular Check-ins
- Log moods at consistent times
- Capture both positive and negative experiences
- Include context for better understanding

### Honest Reflection
- Be authentic about emotional experiences
- Don't judge your feelings as right or wrong
- Use entries for growth and learning

### Pattern Recognition
- Review entries weekly or monthly
- Look for trends and recurring themes
- Adjust job search strategy based on insights

## Troubleshooting

### Common Questions

**How often should I log moods?**
- Daily during active job searching
- After significant career events
- Whenever you notice strong emotions

**What if I'm not sure about my mood?**
- Choose the closest match available
- Use the description field for nuance
- Focus on the dominant feeling

**Can I change entries later?**
- Yes, all entries are editable
- Update insights as you gain perspective
- Delete entries if needed

### Technical Issues

**Entries not saving:**
- Check internet connection
- Refresh page and try again
- Contact support if problems persist

**Can't find specific mood:**
- Use description field for specific emotions
- Choose closest available option
- Suggest new moods to support team

## Templates and Prompts

### Daily Reflection Template
- What was the highlight of my job search today?
- What challenged me the most?
- How did I handle difficult emotions?
- What am I grateful for in this process?

### Weekly Review Questions
- What patterns do I notice in my mood entries?
- Which activities consistently bring joy or stress?
- How has my emotional relationship with job searching changed?
- What adjustments should I make next week?

### Goal Setting Framework
- What career milestone am I working toward?
- How does this mood entry relate to my goals?
- What action can I take to move closer to my objectives?
- How will I celebrate progress along the way?

## Support and Community

**Getting Help:**
- Use floating help button for guidance
- Email support for technical issues
- Share feedback for feature improvements

**Privacy Commitment:**
- Your emotional data is completely private
- No sharing without explicit permission
- Secure storage and handling of sensitive information

**Professional Resources:**
- Consider career coaching for deeper support
- Mental health resources for significant distress
- Professional development programs for skill building