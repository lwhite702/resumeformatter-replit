import OpenAI from "openai";
import { db } from "./db";
import { industryModels, trainingData, questions } from "@shared/schema";
import { eq, and } from "drizzle-orm";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export interface IndustrySpecificPrompt {
  industry: string;
  jobRole: string;
  context: string;
  requirements: string[];
}

export interface FineTuningTrainingExample {
  prompt: string;
  completion: string;
  industry: string;
  category: string;
}

export class AIFineTuningService {
  private readonly supportedIndustries = [
    "healthcare",
    "technology", 
    "finance",
    "education",
    "manufacturing",
    "retail",
    "consulting",
    "legal",
    "marketing",
    "engineering"
  ];

  async generateIndustrySpecificContent(
    prompt: string,
    industry: string,
    jobRole: string,
    category: "question" | "answer" | "guide" = "question"
  ): Promise<string> {
    // Get industry-specific model if available
    const industryModel = await this.getIndustryModel(industry);
    
    // Create industry-specific prompt with context
    const enhancedPrompt = await this.enhancePromptWithIndustryContext(
      prompt,
      industry,
      jobRole,
      category
    );

    try {
      const response = await openai.chat.completions.create({
        model: industryModel?.modelId || "gpt-4o",
        messages: [
          {
            role: "system",
            content: this.getIndustrySystemPrompt(industry, jobRole, category)
          },
          {
            role: "user",
            content: enhancedPrompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1500,
        response_format: { type: "json_object" }
      });

      return response.choices[0].message.content || "";
    } catch (error) {
      console.error("Error generating industry-specific content:", error);
      throw new Error("Failed to generate industry-specific content");
    }
  }

  async createFineTunedModel(industry: string): Promise<string> {
    // Collect training data for the industry
    const trainingExamples = await this.collectTrainingData(industry);
    
    if (trainingExamples.length < 10) {
      throw new Error(`Insufficient training data for ${industry}. Need at least 10 examples.`);
    }

    // Format training data for OpenAI fine-tuning
    const formattedData = trainingExamples.map(example => ({
      messages: [
        {
          role: "system",
          content: this.getIndustrySystemPrompt(industry, "general", "question")
        },
        {
          role: "user",
          content: example.prompt
        },
        {
          role: "assistant",
          content: example.completion
        }
      ]
    }));

    try {
      // Create training file
      const trainingFileContent = formattedData.map(item => JSON.stringify(item)).join('\n');
      const trainingFile = await openai.files.create({
        file: new Blob([trainingFileContent]),
        purpose: "fine-tune"
      });

      // Create fine-tuning job
      const fineTuningJob = await openai.fineTuning.jobs.create({
        training_file: trainingFile.id,
        model: "gpt-3.5-turbo",
        suffix: `${industry}-interview-model`
      });

      // Store model information in database
      await db.insert(industryModels).values({
        industry,
        modelId: fineTuningJob.id,
        trainingData: {
          fileId: trainingFile.id,
          exampleCount: trainingExamples.length,
          jobId: fineTuningJob.id
        },
        isActive: false, // Will be activated when training completes
        version: "1.0"
      });

      return fineTuningJob.id;
    } catch (error) {
      console.error("Error creating fine-tuned model:", error);
      throw new Error("Failed to create fine-tuned model");
    }
  }

  async addTrainingExample(example: FineTuningTrainingExample): Promise<void> {
    await db.insert(trainingData).values({
      industry: example.industry,
      jobRole: "general",
      prompt: example.prompt,
      completion: example.completion,
      category: example.category,
      quality: 5,
      isValidated: true
    });
  }

  async generateIndustryQuestions(
    industry: string,
    jobRole: string,
    count: number = 10
  ): Promise<Array<{
    question: string;
    answer: string;
    category: string;
    difficulty: string;
    tags: string[];
  }>> {
    const prompt = `Generate ${count} industry-specific interview questions for a ${jobRole} role in the ${industry} industry. Include behavioral, technical, and situational questions appropriate for the role level and industry requirements.`;

    const response = await this.generateIndustrySpecificContent(
      prompt,
      industry,
      jobRole,
      "question"
    );

    try {
      const parsed = JSON.parse(response);
      return parsed.questions || [];
    } catch (error) {
      console.error("Error parsing generated questions:", error);
      return [];
    }
  }

  async optimizeAnswerForIndustry(
    question: string,
    baseAnswer: string,
    industry: string,
    jobRole: string
  ): Promise<{
    optimizedAnswer: string;
    industryKeywords: string[];
    improvements: string[];
  }> {
    const prompt = `Optimize this interview answer for the ${industry} industry and ${jobRole} role:

Question: ${question}
Current Answer: ${baseAnswer}

Provide industry-specific keywords, terminology, and improvements to make the answer more relevant and compelling for this specific industry context.`;

    const response = await this.generateIndustrySpecificContent(
      prompt,
      industry,
      jobRole,
      "answer"
    );

    try {
      return JSON.parse(response);
    } catch (error) {
      console.error("Error parsing optimized answer:", error);
      return {
        optimizedAnswer: baseAnswer,
        industryKeywords: [],
        improvements: []
      };
    }
  }

  private async getIndustryModel(industry: string) {
    const [model] = await db
      .select()
      .from(industryModels)
      .where(and(
        eq(industryModels.industry, industry),
        eq(industryModels.isActive, true)
      ))
      .limit(1);

    return model;
  }

  private async collectTrainingData(industry: string) {
    return await db
      .select()
      .from(trainingData)
      .where(and(
        eq(trainingData.industry, industry),
        eq(trainingData.isValidated, true)
      ));
  }

  private getIndustrySystemPrompt(
    industry: string,
    jobRole: string,
    category: string
  ): string {
    const basePrompts: Record<string, string> = {
      question: `You are an expert interview coach specializing in the ${industry} industry. Generate professional, industry-specific interview questions that assess both technical competencies and cultural fit for ${jobRole} roles. Focus on real-world scenarios, industry challenges, and required skills.`,
      answer: `You are an expert career advisor specializing in the ${industry} industry. Provide compelling, industry-specific interview answers that demonstrate deep understanding of ${industry} practices, terminology, and challenges. Use the STAR method and include relevant industry examples.`,
      guide: `You are a senior ${industry} industry professional and interview coach. Create comprehensive interview guides that reflect current industry trends, required competencies, and effective preparation strategies for ${jobRole} positions.`
    };

    return basePrompts[category] || basePrompts.question;
  }

  private async enhancePromptWithIndustryContext(
    prompt: string,
    industry: string,
    jobRole: string,
    category: string
  ): Promise<string> {
    // Get industry-specific context from existing questions
    const existingQuestions = await db
      .select()
      .from(questions)
      .where(eq(questions.industry, industry))
      .limit(5);

    const industryContext = existingQuestions.length > 0 
      ? `Context from existing ${industry} questions: ${existingQuestions.map(q => q.question).join('; ')}`
      : '';

    return `${prompt}

Industry: ${industry}
Job Role: ${jobRole}
Category: ${category}
${industryContext}

Ensure the response is specifically tailored to ${industry} industry standards, terminology, and best practices.`;
  }

  getSupportedIndustries(): string[] {
    return this.supportedIndustries;
  }

  async getIndustryMetrics(industry: string) {
    const model = await this.getIndustryModel(industry);
    const trainingCount = await db
      .select()
      .from(trainingData)
      .where(eq(trainingData.industry, industry));

    return {
      hasCustomModel: !!model,
      modelVersion: model?.version || null,
      trainingExamples: trainingCount.length,
      isActive: model?.isActive || false,
      performanceMetrics: model?.performanceMetrics || null
    };
  }
}

export const aiFineTuningService = new AIFineTuningService();