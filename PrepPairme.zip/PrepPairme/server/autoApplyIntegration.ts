export interface AutoApplyApplication {
  externalId: string;
  jobTitle: string;
  company: string;
  status: "applied" | "viewed" | "interview" | "offer" | "rejected" | "withdrawn";
  appliedDate: string;
  source: string;
  resumeUsed: string;
  coverLetter: string;
}

export interface AutoApplyResponse {
  applications: AutoApplyApplication[];
}

export interface PrepPairSyncData {
  userId: string;
  source: string;
  applications: AutoApplyApplication[];
  syncedAt: string;
}

export class AutoApplyIntegrationService {
  private readonly autoApplyBaseUrl = 'https://autoapply.wrelik.com/api';
  private readonly prepPairBaseUrl = 'https://api.preppair.me';

  async testConnection(apiKey: string): Promise<{ success: boolean; message: string; count?: number }> {
    try {
      const response = await fetch(`${this.autoApplyBaseUrl}/applications`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'User-Agent': 'PrepPair/1.0'
        }
      });

      if (!response.ok) {
        throw new Error(`AutoApply API error: ${response.status} ${response.statusText}`);
      }

      const data: AutoApplyResponse = await response.json();
      return {
        success: true,
        message: 'Connection successful',
        count: data.applications?.length || 0
      };
    } catch (error: any) {
      console.error('AutoApply connection test failed:', error);
      return {
        success: false,
        message: `Connection failed: ${error.message}`
      };
    }
  }

  async fetchApplications(apiKey: string, since?: Date): Promise<AutoApplyResponse> {
    try {
      const url = new URL(`${this.autoApplyBaseUrl}/applications`);
      
      if (since) {
        url.searchParams.append('since', since.toISOString());
      }

      const response = await fetch(url.toString(), {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'User-Agent': 'PrepPair/1.0'
        }
      });

      if (!response.ok) {
        throw new Error(`AutoApply API error: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error: any) {
      console.error('Failed to fetch AutoApply applications:', error);
      throw new Error(`AutoApply API request failed: ${error.message}`);
    }
  }

  async syncToPrepPairApi(syncData: PrepPairSyncData): Promise<{ success: boolean; message: string }> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        console.warn('PrepPair API key not configured, skipping PrepPair sync');
        return { success: false, message: 'PrepPair API key not configured' };
      }

      const response = await fetch(`${this.prepPairBaseUrl}/v1/applications/sync`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json',
          'User-Agent': 'PrepPair-AutoApply-Integration/1.0'
        },
        body: JSON.stringify(syncData)
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      console.log('Successfully synced to PrepPair API:', result);
      
      return { success: true, message: 'Synced to PrepPair API successfully' };
    } catch (error: any) {
      console.error('PrepPair API sync failed:', error);
      return { success: false, message: `PrepPair sync failed: ${error.message}` };
    }
  }

  async getAnalytics(userId: string): Promise<{ success: boolean; data?: any; message?: string }> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        throw new Error('PrepPair API key not configured');
      }

      const response = await fetch(`${this.prepPairBaseUrl}/v1/analytics?userId=${userId}`, {
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const analytics = await response.json();
      return { success: true, data: analytics };
    } catch (error: any) {
      console.error('Failed to get analytics:', error);
      return { success: false, message: error.message };
    }
  }

  async createReminder(userId: string, reminderData: {
    applicationId: string;
    type: 'follow_up' | 'interview_prep' | 'thank_you';
    dueDate: string;
    message: string;
  }): Promise<{ success: boolean; data?: any; message?: string }> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        throw new Error('PrepPair API key not configured');
      }

      const response = await fetch(`${this.prepPairBaseUrl}/v1/reminders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          ...reminderData
        })
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const reminder = await response.json();
      return { success: true, data: reminder };
    } catch (error: any) {
      console.error('Failed to create reminder:', error);
      return { success: false, message: error.message };
    }
  }

  mapStatus(status: string): "applied" | "in_review" | "interviewed" | "offered" | "rejected" | "withdrawn" {
    const statusMap: Record<string, "applied" | "in_review" | "interviewed" | "offered" | "rejected" | "withdrawn"> = {
      'applied': 'applied',
      'viewed': 'in_review',
      'interview': 'interviewed',
      'offer': 'offered',
      'rejected': 'rejected',
      'withdrawn': 'withdrawn'
    };

    return statusMap[status] || 'applied';
  }
}

export const autoApplyService = new AutoApplyIntegrationService();