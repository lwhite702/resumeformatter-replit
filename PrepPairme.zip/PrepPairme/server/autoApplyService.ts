import { storage } from "./storage";

export interface AutoApplyApplication {
  externalId: string;
  jobTitle: string;
  company: string;
  status: "applied" | "viewed" | "interview" | "offer" | "rejected" | "withdrawn";
  appliedDate: string;
  source: string;
  resumeUsed: string;
  coverLetter: string;
}

export interface AutoApplyResponse {
  applications: AutoApplyApplication[];
}

export interface PrepPairApiResponse {
  success: boolean;
  data?: any;
  message?: string;
}

export class AutoApplyIntegrationService {
  private readonly autoApplyBaseUrl = 'https://autoapply.wrelik.com/api';
  private readonly prepPairBaseUrl = 'https://api.preppair.me';

  async connectUserAccount(userId: string, apiKey: string): Promise<{ success: boolean; message: string }> {
    try {
      // Test the AutoApply API connection
      const testResponse = await this.fetchAutoApplyApplications(apiKey);
      
      if (testResponse.applications) {
        // Store the integration configuration
        const integrationData = {
          userId,
          jobBoard: 'autoapply',
          accessToken: apiKey,
          isActive: true,
          lastSyncAt: new Date(),
          createdAt: new Date()
        };

        await storage.createJobBoardIntegration(integrationData);

        // Sync applications immediately after connection
        await this.syncUserApplications(userId);

        return {
          success: true,
          message: `Successfully connected to AutoApply. Found ${testResponse.applications.length} applications.`
        };
      }

      return {
        success: false,
        message: 'Failed to connect to AutoApply API. Please check your API key.'
      };
    } catch (error: any) {
      console.error('AutoApply connection error:', error);
      return {
        success: false,
        message: `Connection failed: ${error.message}`
      };
    }
  }

  async fetchAutoApplyApplications(apiKey: string, lastSyncDate?: Date): Promise<AutoApplyResponse> {
    try {
      const url = new URL(`${this.autoApplyBaseUrl}/applications`);
      
      if (lastSyncDate) {
        url.searchParams.append('since', lastSyncDate.toISOString());
      }

      const response = await fetch(url.toString(), {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'User-Agent': 'PrepPair/1.0'
        }
      });

      if (!response.ok) {
        throw new Error(`AutoApply API error: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error: any) {
      console.error('Failed to fetch AutoApply applications:', error);
      throw new Error(`AutoApply API request failed: ${error.message}`);
    }
  }

  async syncUserApplications(userId: string): Promise<{ 
    synced: number; 
    updated: number; 
    errors: string[]; 
  }> {
    try {
      const integration = await storage.getJobBoardIntegration(userId);
      
      if (!integration || !integration.isActive || !integration.accessToken) {
        throw new Error('AutoApply integration not found or inactive');
      }

      const applications = await this.fetchAutoApplyApplications(
        integration.accessToken, 
        integration.lastSyncAt || undefined
      );

      let synced = 0;
      let updated = 0;
      const errors: string[] = [];

      for (const app of applications.applications) {
        try {
          const existingApp = await storage.getExternalApplicationByExternalId(
            app.externalId, 
            'autoapply'
          );

          const applicationData = {
            userId,
            integrationId: integration.id,
            externalId: app.externalId,
            jobBoard: 'autoapply',
            jobTitle: app.jobTitle,
            company: app.company,
            applicationStatus: this.mapAutoApplyStatus(app.status),
            appliedAt: new Date(app.appliedDate),
            source: app.source,
            resumeUsed: app.resumeUsed,
            coverLetter: app.coverLetter,
            rawData: app,
            syncedAt: new Date()
          };

          if (existingApp) {
            await storage.updateExternalApplication(existingApp.id, applicationData);
            updated++;
          } else {
            await storage.createExternalApplication(applicationData);
            synced++;
          }
        } catch (error: any) {
          errors.push(`Failed to sync application ${app.externalId}: ${error.message}`);
        }
      }

      // Update last sync date
      await storage.updateJobBoardIntegration(integration.id, {
        lastSyncDate: new Date()
      });

      // Sync data to PrepPair API
      await this.syncToPrepPairApi(userId, applications.applications);

      return { synced, updated, errors };
    } catch (error: any) {
      console.error('AutoApply sync error:', error);
      throw new Error(`Sync failed: ${error.message}`);
    }
  }

  async syncToPrepPairApi(userId: string, applications: AutoApplyApplication[]): Promise<PrepPairApiResponse> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        console.warn('PrepPair API key not configured, skipping sync to PrepPair API');
        return { success: false, message: 'PrepPair API key not configured' };
      }

      const syncData = {
        userId,
        source: 'autoapply',
        applications: applications.map(app => ({
          externalId: app.externalId,
          jobTitle: app.jobTitle,
          company: app.company,
          status: app.status,
          appliedDate: app.appliedDate,
          source: app.source,
          resumeUsed: app.resumeUsed,
          coverLetter: app.coverLetter
        })),
        syncedAt: new Date().toISOString()
      };

      const response = await fetch(`${this.prepPairBaseUrl}/v1/applications/sync`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json',
          'User-Agent': 'PrepPair-AutoApply-Integration/1.0'
        },
        body: JSON.stringify(syncData)
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      console.log('Successfully synced applications to PrepPair API:', result);
      
      return { success: true, data: result };
    } catch (error: any) {
      console.error('Failed to sync to PrepPair API:', error);
      return { success: false, message: error.message };
    }
  }

  async getAnalytics(userId: string): Promise<PrepPairApiResponse> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        throw new Error('PrepPair API key not configured');
      }

      const response = await fetch(`${this.prepPairBaseUrl}/v1/analytics?userId=${userId}`, {
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const analytics = await response.json();
      return { success: true, data: analytics };
    } catch (error: any) {
      console.error('Failed to get analytics from PrepPair API:', error);
      return { success: false, message: error.message };
    }
  }

  async createReminder(userId: string, reminderData: {
    applicationId: string;
    type: 'follow_up' | 'interview_prep' | 'thank_you';
    dueDate: string;
    message: string;
  }): Promise<PrepPairApiResponse> {
    try {
      const prepPairApiKey = process.env.PREP_PAIR_API_KEY;
      
      if (!prepPairApiKey) {
        throw new Error('PrepPair API key not configured');
      }

      const response = await fetch(`${this.prepPairBaseUrl}/v1/reminders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${prepPairApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          ...reminderData
        })
      });

      if (!response.ok) {
        throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
      }

      const reminder = await response.json();
      return { success: true, data: reminder };
    } catch (error: any) {
      console.error('Failed to create reminder via PrepPair API:', error);
      return { success: false, message: error.message };
    }
  }

  async handleWebhook(payload: any): Promise<{ processed: boolean; message: string }> {
    try {
      const { event, data } = payload;
      
      if (!event || !data || !data.application) {
        return {
          processed: false,
          message: 'Invalid webhook payload'
        };
      }

      const app = data.application as AutoApplyApplication;
      
      // Find the integration by external ID
      const existingApp = await storage.getExternalApplicationByExternalId(
        app.externalId,
        'autoapply'
      );

      if (!existingApp) {
        return {
          processed: false,
          message: 'Application not found in system'
        };
      }

      // Update the application with new data
      await storage.updateExternalApplication(existingApp.id, {
        jobTitle: app.jobTitle,
        company: app.company,
        applicationStatus: this.mapAutoApplyStatus(app.status),
        appliedAt: new Date(app.appliedDate),
        source: app.source,
        resumeUsed: app.resumeUsed,
        coverLetter: app.coverLetter,
        rawData: app,
        syncedAt: new Date()
      });

      // Sync single application to PrepPair API
      await this.syncToPrepPairApi(existingApp.userId, [app]);

      return {
        processed: true,
        message: `Webhook processed for application ${app.externalId}`
      };
    } catch (error: any) {
      console.error('AutoApply webhook processing error:', error);
      return {
        processed: false,
        message: `Webhook processing failed: ${error.message}`
      };
    }
  }

  async getUserIntegrationStatus(userId: string): Promise<{
    connected: boolean;
    lastSync?: Date;
    applicationsCount?: number;
    webhookConfigured?: boolean;
  }> {
    try {
      const integration = await storage.getJobBoardIntegration(userId, 'autoapply');
      
      if (!integration || !integration.isActive) {
        return { connected: false };
      }

      const applicationsCount = await storage.getExternalApplicationsCount(
        userId,
        'autoapply'
      );

      return {
        connected: true,
        lastSync: integration.lastSyncDate,
        applicationsCount,
        webhookConfigured: !!integration.webhookUrl
      };
    } catch (error: any) {
      console.error('Failed to get AutoApply integration status:', error);
      return { connected: false };
    }
  }

  async disconnectUserAccount(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      const integration = await storage.getJobBoardIntegration(userId, 'autoapply');
      
      if (!integration) {
        return {
          success: true,
          message: 'No AutoApply integration found'
        };
      }

      // Deactivate the integration
      await storage.updateJobBoardIntegration(integration.id, {
        isActive: false,
        apiKey: null,
        webhookUrl: null,
        webhookId: null
      });

      return {
        success: true,
        message: 'AutoApply integration disconnected successfully'
      };
    } catch (error: any) {
      console.error('AutoApply disconnection error:', error);
      return {
        success: false,
        message: `Disconnection failed: ${error.message}`
      };
    }
  }

  private mapAutoApplyStatus(status: string): "applied" | "in_review" | "interviewed" | "offered" | "rejected" | "withdrawn" {
    const statusMap: Record<string, "applied" | "in_review" | "interviewed" | "offered" | "rejected" | "withdrawn"> = {
      'applied': 'applied',
      'viewed': 'in_review',
      'interview': 'interviewed',
      'offer': 'offered',
      'rejected': 'rejected',
      'withdrawn': 'withdrawn'
    };

    return statusMap[status] || 'applied';
  }
}

export const autoApplyIntegrationService = new AutoApplyIntegrationService();