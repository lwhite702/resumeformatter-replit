import { Router } from 'express';
import { requireAuth } from './middleware/clerkAuth';
import { createClerkClient } from '@clerk/backend';

const clerkClient = createClerkClient({
  secretKey: process.env.CLERK_SECRET_KEY!,
});

const router = Router();

// Create checkout session for subscription
router.post('/create-checkout', requireAuth, async (req, res) => {
  try {
    const { planId } = req.body;
    const userId = req.user!.id;

    if (!planId) {
      return res.status(400).json({ error: 'Plan ID is required' });
    }

    // Create checkout session through Clerk
    // This will be handled by Clerk's billing system automatically
    // The pricing table component will handle the checkout flow
    
    res.json({ 
      success: true,
      message: 'Checkout will be handled by Clerk PricingTable component',
      userId,
      planId
    });
  } catch (error) {
    console.error('Checkout creation error:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Manage subscription portal
router.post('/manage-subscription', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    // In a real implementation, this would redirect to Clerk's billing portal
    // For now, we'll return the user's current subscription info
    const user = await clerkClient.users.getUser(userId);
    
    res.json({
      success: true,
      subscription: user.publicMetadata?.subscription || null,
      plan: user.publicMetadata?.plan || 'free',
      features: user.publicMetadata?.features || {}
    });
  } catch (error) {
    console.error('Subscription management error:', error);
    res.status(500).json({ error: 'Failed to access subscription management' });
  }
});

// Get user's billing information
router.get('/subscription', requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const user = await clerkClient.users.getUser(userId);

    res.json({
      userId,
      plan: user.publicMetadata?.plan || 'free',
      features: user.publicMetadata?.features || {},
      subscription: user.publicMetadata?.subscription || null
    });
  } catch (error) {
    console.error('Get subscription error:', error);
    res.status(500).json({ error: 'Failed to get subscription information' });
  }
});

// Update user's subscription (webhook handler)
router.post('/webhook', async (req, res) => {
  try {
    // This would handle Clerk webhooks for subscription changes
    // Implementation depends on Clerk's specific webhook format
    const { type, data } = req.body;

    switch (type) {
      case 'subscription.created':
      case 'subscription.updated':
        // Update user metadata with new subscription info
        await clerkClient.users.updateUserMetadata(data.userId, {
          publicMetadata: {
            plan: data.plan,
            features: data.features,
            subscription: {
              id: data.subscriptionId,
              status: data.status,
              plan: data.plan,
              features: data.features
            }
          }
        });
        break;
      
      case 'subscription.deleted':
        // Revert user to free plan
        await clerkClient.users.updateUserMetadata(data.userId, {
          publicMetadata: {
            plan: 'free',
            features: {
              basic_interview_prep: true,
              basic_resume_review: true,
              community_access: true
            },
            subscription: null
          }
        });
        break;
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

export default router;