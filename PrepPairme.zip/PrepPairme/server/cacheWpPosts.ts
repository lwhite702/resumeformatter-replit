import { Pool } from 'pg';
import fetch from 'node-fetch';
import https from 'https';
import dotenv from 'dotenv';

dotenv.config();

interface WordPressPost {
  id: number;
  title: {
    rendered: string;
  };
  slug: string;
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  date: string;
}

class WordPressCacher {
  private pool: Pool;
  private readonly wpApiUrl: string;

  constructor(customUrl?: string) {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }
    
    // Use custom URL or fetch from The PrepBoard category (ID: 13) on WrelikBrands.com
    this.wpApiUrl = customUrl || process.env.WORDPRESS_API_URL || 'https://wrelikbrands.com/wp-json/wp/v2/posts?categories=13&per_page=20&_fields=id,title,slug,excerpt,content,date';
    
    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });
  }

  private cleanHtmlContent(html: string): string {
    if (!html) return '';
    
    // Remove HTML tags and decode entities
    return html
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/&nbsp;/g, ' ') // Replace non-breaking spaces
      .replace(/&amp;/g, '&') // Decode ampersands
      .replace(/&lt;/g, '<') // Decode less than
      .replace(/&gt;/g, '>') // Decode greater than
      .replace(/&quot;/g, '"') // Decode quotes
      .replace(/&#8217;/g, "'") // Replace curly apostrophes
      .replace(/&#8220;/g, '"') // Replace opening curly quotes
      .replace(/&#8221;/g, '"') // Replace closing curly quotes
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
  }

  private async ensureTableExists(): Promise<void> {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS cached_posts (
        id SERIAL PRIMARY KEY,
        wp_id INTEGER UNIQUE NOT NULL,
        title TEXT NOT NULL,
        slug TEXT NOT NULL,
        excerpt TEXT,
        content TEXT NOT NULL,
        published_at TIMESTAMP NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
      
      CREATE INDEX IF NOT EXISTS idx_cached_posts_wp_id ON cached_posts(wp_id);
      CREATE INDEX IF NOT EXISTS idx_cached_posts_published_at ON cached_posts(published_at DESC);
    `;

    try {
      await this.pool.query(createTableQuery);
    } catch (error) {
      console.error('Error creating cached_posts table:', error);
      throw error;
    }
  }

  private async upsertPost(post: WordPressPost): Promise<void> {
    const query = `
      INSERT INTO cached_posts (wp_id, title, slug, excerpt, content, published_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW())
      ON CONFLICT (wp_id) 
      DO UPDATE SET 
        title = EXCLUDED.title,
        slug = EXCLUDED.slug,
        excerpt = EXCLUDED.excerpt,
        content = EXCLUDED.content,
        published_at = EXCLUDED.published_at,
        updated_at = NOW()
    `;

    const values = [
      post.id,
      this.cleanHtmlContent(post.title.rendered),
      post.slug,
      post.excerpt ? this.cleanHtmlContent(post.excerpt.rendered) : null,
      this.cleanHtmlContent(post.content.rendered),
      new Date(post.date)
    ];

    try {
      await this.pool.query(query, values);
    } catch (error) {
      console.error(`Error upserting post ${post.id}:`, error);
      throw error;
    }
  }

  async fetchAndCachePosts(): Promise<void> {
    try {
      // Ensure table exists
      await this.ensureTableExists();
      
      // Create custom agent that ignores SSL cert issues for specific domains
      const agent = new https.Agent({
        rejectUnauthorized: false
      });
      
      // Fetch posts from WordPress
      console.log('Fetching posts from WordPress API...');
      console.log('API URL:', this.wpApiUrl);
      
      const response = await fetch(this.wpApiUrl, {
        agent: this.wpApiUrl.includes('wrelikbrands.com') ? agent : undefined,
        headers: {
          'User-Agent': 'PrepPair-WordPress-Cache/1.0'
        }
      });
      
      if (!response.ok) {
        throw new Error(`WordPress API returned ${response.status}: ${response.statusText}`);
      }

      const posts: WordPressPost[] = await response.json() as WordPressPost[];
      
      if (!Array.isArray(posts) || posts.length === 0) {
        console.log('No posts found from WordPress API');
        return;
      }

      // Cache each post
      console.log(`Processing ${posts.length} posts...`);
      
      for (const post of posts) {
        await this.upsertPost(post);
      }

      console.log(`✅ Cached ${posts.length} posts from WordPress.`);
      
    } catch (error) {
      console.error('Error caching WordPress posts:', error);
      throw error;
    }
  }

  async getRecentPosts(limit: number = 5): Promise<any[]> {
    const query = `
      SELECT wp_id, title, slug, excerpt, published_at, updated_at
      FROM cached_posts
      ORDER BY published_at DESC
      LIMIT $1
    `;

    try {
      const result = await this.pool.query(query, [limit]);
      return result.rows;
    } catch (error) {
      console.error('Error fetching recent posts:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

// Main execution function
async function main() {
  const cacher = new WordPressCacher();
  
  try {
    await cacher.fetchAndCachePosts();
    
    // Example: Show 5 most recent posts
    console.log('\nMost recent cached posts:');
    const recentPosts = await cacher.getRecentPosts(5);
    recentPosts.forEach((post, index) => {
      console.log(`${index + 1}. ${post.title} (${post.slug}) - ${new Date(post.published_at).toLocaleDateString()}`);
    });
    
  } catch (error) {
    console.error('Failed to cache WordPress posts:', error);
    process.exit(1);
  } finally {
    await cacher.close();
  }
}

// Run if called directly (ES module check)
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { WordPressCacher };