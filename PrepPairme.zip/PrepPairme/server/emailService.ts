import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface EmailApplicationData {
  jobTitle?: string;
  company?: string;
  location?: string;
  applicationStatus: string;
  appliedAt: Date;
  jobUrl?: string;
  contactEmail?: string;
  interviewDate?: Date;
  salaryRange?: string;
  jobType?: string;
  confidence: number; // 0-100
}

export interface ParsedEmailResult {
  isJobRelated: boolean;
  data?: EmailApplicationData;
  confidence: number;
  reasoning: string;
}

// Email patterns for different job boards and companies
const JOB_EMAIL_PATTERNS = [
  // Application confirmations
  /application.*received/i,
  /thank you.*applying/i,
  /we have received your application/i,
  /application.*submitted/i,
  
  // Interview invitations
  /interview.*scheduled/i,
  /would like to schedule/i,
  /interview invitation/i,
  /phone.*interview/i,
  /video.*interview/i,
  
  // Status updates
  /application.*status/i,
  /unfortunately.*not moving forward/i,
  /we regret to inform/i,
  /congratulations/i,
  /offer.*position/i,
  
  // Job board notifications
  /linkedin.*job/i,
  /indeed.*application/i,
  /glassdoor.*update/i,
  /monster.*jobs/i,
  /ziprecruiter.*applied/i,
];

const COMPANY_EMAIL_DOMAINS = [
  'linkedin.com',
  'indeed.com',
  'glassdoor.com',
  'monster.com',
  'ziprecruiter.com',
  'greenhouse.io',
  'workday.com',
  'lever.co',
  'bamboohr.com',
  'smartrecruiters.com',
];

export class EmailService {
  
  async parseJobApplicationEmail(
    subject: string,
    body: string,
    sender: string,
    receivedAt: Date
  ): Promise<ParsedEmailResult> {
    try {
      // Quick filter to avoid processing irrelevant emails
      if (!this.isLikelyJobEmail(subject, body, sender)) {
        return {
          isJobRelated: false,
          confidence: 0,
          reasoning: "Email does not match job-related patterns"
        };
      }

      const prompt = `
        Analyze this email to extract job application information. Determine if this is related to a job application and extract relevant data.

        Email Subject: ${subject}
        Email Sender: ${sender}
        Email Body: ${body.substring(0, 2000)} // Truncate for API limits
        Received At: ${receivedAt.toISOString()}

        Please analyze and return JSON with this structure:
        {
          "isJobRelated": boolean,
          "confidence": number (0-100),
          "reasoning": "Brief explanation",
          "data": {
            "jobTitle": "extracted job title",
            "company": "company name",
            "location": "job location if mentioned",
            "applicationStatus": "applied|interview|rejected|offer|other",
            "appliedAt": "ISO date string when application was submitted",
            "jobUrl": "job posting URL if found",
            "contactEmail": "recruiter/HR email if different from sender",
            "interviewDate": "ISO date string if interview is scheduled",
            "salaryRange": "salary information if mentioned",
            "jobType": "full-time|part-time|contract|internship"
          }
        }

        Status mapping:
        - "applied" for application confirmations
        - "interview" for interview invitations/schedules
        - "rejected" for rejection emails
        - "offer" for job offers
        - "other" for general updates

        Only include data fields that can be confidently extracted. Set confidence based on how certain you are about the job relation and data accuracy.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert at parsing job-related emails and extracting structured data. Be conservative with confidence scores and only extract data you're certain about."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1,
      });

      const result = JSON.parse(response.choices[0].message.content!);
      
      // Validate and sanitize the result
      return this.validateParsedResult(result, receivedAt);

    } catch (error: any) {
      console.error("Email parsing error:", error);
      return {
        isJobRelated: false,
        confidence: 0,
        reasoning: `Parsing failed: ${error.message}`
      };
    }
  }

  private isLikelyJobEmail(subject: string, body: string, sender: string): boolean {
    const text = `${subject} ${body}`.toLowerCase();
    
    // Check if sender is from known job board or recruiting platform
    const isFromJobBoard = COMPANY_EMAIL_DOMAINS.some(domain => 
      sender.toLowerCase().includes(domain)
    );
    
    // Check if content matches job-related patterns
    const hasJobPattern = JOB_EMAIL_PATTERNS.some(pattern => 
      pattern.test(text)
    );

    // Check for common job-related keywords
    const jobKeywords = [
      'application', 'interview', 'position', 'role', 'job', 'career',
      'recruitment', 'hiring', 'candidate', 'resume', 'cv'
    ];
    
    const hasJobKeywords = jobKeywords.some(keyword => 
      text.includes(keyword)
    );

    return isFromJobBoard || hasJobPattern || hasJobKeywords;
  }

  private validateParsedResult(result: any, receivedAt: Date): ParsedEmailResult {
    try {
      // Ensure required fields exist
      const validated: ParsedEmailResult = {
        isJobRelated: Boolean(result.isJobRelated),
        confidence: Math.max(0, Math.min(100, Number(result.confidence) || 0)),
        reasoning: String(result.reasoning || "")
      };

      if (validated.isJobRelated && result.data) {
        const data: EmailApplicationData = {
          applicationStatus: this.validateStatus(result.data.applicationStatus),
          appliedAt: this.parseDate(result.data.appliedAt) || receivedAt,
          confidence: validated.confidence
        };

        // Add optional fields if they exist and are valid
        if (result.data.jobTitle && typeof result.data.jobTitle === 'string') {
          data.jobTitle = result.data.jobTitle.trim();
        }
        
        if (result.data.company && typeof result.data.company === 'string') {
          data.company = result.data.company.trim();
        }
        
        if (result.data.location && typeof result.data.location === 'string') {
          data.location = result.data.location.trim();
        }
        
        if (result.data.jobUrl && this.isValidUrl(result.data.jobUrl)) {
          data.jobUrl = result.data.jobUrl;
        }
        
        if (result.data.contactEmail && this.isValidEmail(result.data.contactEmail)) {
          data.contactEmail = result.data.contactEmail;
        }
        
        if (result.data.interviewDate) {
          const interviewDate = this.parseDate(result.data.interviewDate);
          if (interviewDate && interviewDate > new Date()) {
            data.interviewDate = interviewDate;
          }
        }
        
        if (result.data.salaryRange && typeof result.data.salaryRange === 'string') {
          data.salaryRange = result.data.salaryRange.trim();
        }
        
        if (result.data.jobType && typeof result.data.jobType === 'string') {
          data.jobType = this.validateJobType(result.data.jobType);
        }

        validated.data = data;
      }

      return validated;

    } catch (error) {
      return {
        isJobRelated: false,
        confidence: 0,
        reasoning: "Failed to validate parsed data"
      };
    }
  }

  private validateStatus(status: string): string {
    const validStatuses = ['applied', 'interview', 'rejected', 'offer', 'other'];
    const normalizedStatus = String(status || '').toLowerCase();
    return validStatuses.includes(normalizedStatus) ? normalizedStatus : 'other';
  }

  private validateJobType(jobType: string): string {
    const validTypes = ['full-time', 'part-time', 'contract', 'internship'];
    const normalizedType = String(jobType || '').toLowerCase();
    return validTypes.includes(normalizedType) ? normalizedType : 'full-time';
  }

  private parseDate(dateString: string): Date | null {
    try {
      const date = new Date(dateString);
      return isNaN(date.getTime()) ? null : date;
    } catch {
      return null;
    }
  }

  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  private isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  // Gmail API integration methods
  async connectGmail(authCode: string, redirectUri: string): Promise<{
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
  }> {
    // Placeholder for Gmail OAuth integration
    throw new Error("Gmail integration requires OAuth credentials to be configured");
  }

  async syncGmailEmails(accessToken: string, lastSyncDate?: Date): Promise<any[]> {
    // Placeholder for Gmail API sync
    throw new Error("Gmail API integration not yet implemented");
  }

  // Outlook API integration methods
  async connectOutlook(authCode: string, redirectUri: string): Promise<{
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
  }> {
    // Placeholder for Outlook OAuth integration
    throw new Error("Outlook integration requires OAuth credentials to be configured");
  }

  async syncOutlookEmails(accessToken: string, lastSyncDate?: Date): Promise<any[]> {
    // Placeholder for Outlook API sync
    throw new Error("Outlook API integration not yet implemented");
  }
}

export const emailService = new EmailService();