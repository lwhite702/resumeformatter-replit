import express, { type Request, Response, NextFunction } from "express";
import { config } from "dotenv";
import { registerRoutes } from "./protected-routes";
import { setupVite, serveStatic, log } from "./vite";
import billingRoutes from "./billing";
import { AtlasExpressClient } from "@runonatlas/express";
import { verifyToken } from '@clerk/backend';
import { legalPagesService } from "./legalPagesService";

// Load environment variables
config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Initialize Atlas Express Client with Clerk authentication (optional)
let atlasExpress: any = null;
try {
  if (process.env.ATLAS_API_KEY) {
    atlasExpress = new AtlasExpressClient(
      (req) => {
        try {
          // Extract user ID from Clerk headers or auth middleware
          const user = (req as any).user;
          const clerkUserId = req.headers['x-clerk-user-id'] as string;
          return user?.id || clerkUserId || "";
        } catch (error) {
          console.error('Atlas user ID extraction error:', error);
          return "";
        }
      }
    );
  }
} catch (error) {
  console.warn('Atlas initialization failed, continuing without Atlas:', error instanceof Error ? error.message : 'Unknown error');
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Add Atlas router with /api prefix to avoid Vite conflicts
if (atlasExpress) {
  app.use("/api/atlas", atlasExpress.router);
}

// Add billing routes
app.use('/api/billing', billingRoutes);

(async () => {
  // Initialize legal pages system
  try {
    await legalPagesService.fetchAndCacheLegalPages();
    console.log('Legal pages initialized successfully');
  } catch (error) {
    console.warn('Legal pages initialization failed:', error instanceof Error ? error.message : String(error));
  }

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
