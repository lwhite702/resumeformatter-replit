import { storage } from "./storage";
import type { 
  JobBoardIntegration, 
  InsertJobBoardIntegration,
  ExternalApplication,
  InsertExternalApplication,
  ApplicationEvent,
  InsertApplicationEvent 
} from "@shared/schema";

// Job board service interfaces
export interface JobBoardAPI {
  authenticate(credentials: any): Promise<{ accessToken: string; refreshToken?: string; expiresAt?: Date }>;
  refreshToken(refreshToken: string): Promise<{ accessToken: string; expiresAt?: Date }>;
  getApplications(accessToken: string, lastSyncDate?: Date): Promise<ExternalApplicationData[]>;
  getApplication(accessToken: string, applicationId: string): Promise<ExternalApplicationData>;
}

export interface ExternalApplicationData {
  externalId: string;
  jobTitle: string;
  company: string;
  location?: string;
  jobUrl?: string;
  description?: string;
  requirements?: string;
  salaryRange?: string;
  jobType?: string;
  applicationStatus: string;
  appliedAt: Date;
  lastUpdatedAt?: Date;
  resumeUsed?: string;
  coverLetter?: string;
  rawData?: any;
}

// LinkedIn Jobs API implementation
export class LinkedInJobsAPI implements JobBoardAPI {
  private readonly baseUrl = 'https://api.linkedin.com/v2';

  async authenticate(credentials: { code: string; redirectUri: string }): Promise<{ accessToken: string; refreshToken?: string; expiresAt?: Date }> {
    // LinkedIn OAuth2 token exchange
    const response = await fetch('https://www.linkedin.com/oauth/v2/accessToken', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: credentials.code,
        redirect_uri: credentials.redirectUri,
        client_id: process.env.LINKEDIN_CLIENT_ID!,
        client_secret: process.env.LINKEDIN_CLIENT_SECRET!,
      }),
    });

    if (!response.ok) {
      throw new Error(`LinkedIn authentication failed: ${response.statusText}`);
    }

    const data = await response.json();
    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresAt: new Date(Date.now() + data.expires_in * 1000),
    };
  }

  async refreshToken(refreshToken: string): Promise<{ accessToken: string; expiresAt?: Date }> {
    const response = await fetch('https://www.linkedin.com/oauth/v2/accessToken', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: process.env.LINKEDIN_CLIENT_ID!,
        client_secret: process.env.LINKEDIN_CLIENT_SECRET!,
      }),
    });

    if (!response.ok) {
      throw new Error(`LinkedIn token refresh failed: ${response.statusText}`);
    }

    const data = await response.json();
    return {
      accessToken: data.access_token,
      expiresAt: new Date(Date.now() + data.expires_in * 1000),
    };
  }

  async getApplications(accessToken: string, lastSyncDate?: Date): Promise<ExternalApplicationData[]> {
    // Note: LinkedIn's API access is limited - this is a simplified implementation
    // In practice, you'd need to request access to LinkedIn's Partner Program
    const response = await fetch(`${this.baseUrl}/jobApplications`, {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });

    if (!response.ok) {
      throw new Error(`LinkedIn API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.elements.map((app: any) => this.transformApplication(app));
  }

  async getApplication(accessToken: string, applicationId: string): Promise<ExternalApplicationData> {
    const response = await fetch(`${this.baseUrl}/jobApplications/${applicationId}`, {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });

    if (!response.ok) {
      throw new Error(`LinkedIn API error: ${response.statusText}`);
    }

    const data = await response.json();
    return this.transformApplication(data);
  }

  private transformApplication(app: any): ExternalApplicationData {
    return {
      externalId: app.id,
      jobTitle: app.job?.title || 'Unknown Position',
      company: app.job?.company?.name || 'Unknown Company',
      location: app.job?.location?.name,
      jobUrl: app.job?.url,
      description: app.job?.description,
      applicationStatus: this.mapLinkedInStatus(app.state),
      appliedAt: new Date(app.submittedAt),
      lastUpdatedAt: new Date(app.lastModified),
      rawData: app,
    };
  }

  private mapLinkedInStatus(status: string): string {
    const statusMap: Record<string, string> = {
      'SUBMITTED': 'applied',
      'VIEWED': 'viewed',
      'REJECTED': 'rejected',
      'HIRED': 'offer',
    };
    return statusMap[status] || 'applied';
  }
}

// Indeed API implementation (mock - Indeed doesn't have public API)
export class IndeedAPI implements JobBoardAPI {
  async authenticate(credentials: any): Promise<{ accessToken: string; refreshToken?: string; expiresAt?: Date }> {
    // Indeed doesn't have a public API for job applications
    // This would require web scraping or other methods
    throw new Error('Indeed API integration not available - requires web scraping implementation');
  }

  async refreshToken(refreshToken: string): Promise<{ accessToken: string; expiresAt?: Date }> {
    throw new Error('Indeed API integration not available');
  }

  async getApplications(accessToken: string, lastSyncDate?: Date): Promise<ExternalApplicationData[]> {
    throw new Error('Indeed API integration not available');
  }

  async getApplication(accessToken: string, applicationId: string): Promise<ExternalApplicationData> {
    throw new Error('Indeed API integration not available');
  }
}

// Job board service manager
export class JobBoardService {
  private apis: Map<string, JobBoardAPI> = new Map();

  constructor() {
    this.apis.set('linkedin', new LinkedInJobsAPI());
    this.apis.set('indeed', new IndeedAPI());
  }

  getAPI(jobBoard: string): JobBoardAPI {
    const api = this.apis.get(jobBoard);
    if (!api) {
      throw new Error(`Unsupported job board: ${jobBoard}`);
    }
    return api;
  }

  async createIntegration(userId: string, jobBoard: string, credentials: any): Promise<JobBoardIntegration> {
    const api = this.getAPI(jobBoard);
    
    try {
      const authResult = await api.authenticate(credentials);
      
      const integration = await storage.createJobBoardIntegration({
        userId,
        jobBoard,
        accessToken: authResult.accessToken, // In production, encrypt this
        refreshToken: authResult.refreshToken,
        tokenExpiresAt: authResult.expiresAt,
        isActive: true,
        syncStatus: 'pending',
      });

      // Start initial sync
      this.syncApplications(integration.id).catch(console.error);

      return integration;
    } catch (error) {
      throw new Error(`Failed to create ${jobBoard} integration: ${error.message}`);
    }
  }

  async syncApplications(integrationId: number): Promise<void> {
    const integration = await storage.getJobBoardIntegration(integrationId);
    if (!integration || !integration.isActive) {
      return;
    }

    try {
      await storage.updateJobBoardIntegration(integrationId, { syncStatus: 'syncing' });

      const api = this.getAPI(integration.jobBoard);
      let accessToken = integration.accessToken;

      // Check if token needs refresh
      if (integration.tokenExpiresAt && new Date() >= integration.tokenExpiresAt) {
        if (integration.refreshToken) {
          const refreshResult = await api.refreshToken(integration.refreshToken);
          accessToken = refreshResult.accessToken;
          await storage.updateJobBoardIntegration(integrationId, {
            accessToken: refreshResult.accessToken,
            tokenExpiresAt: refreshResult.expiresAt,
          });
        } else {
          throw new Error('Token expired and no refresh token available');
        }
      }

      const applications = await api.getApplications(accessToken!, integration.lastSyncAt);
      
      for (const appData of applications) {
        await this.upsertApplication(integration.userId, integrationId, integration.jobBoard, appData);
      }

      await storage.updateJobBoardIntegration(integrationId, {
        syncStatus: 'completed',
        lastSyncAt: new Date(),
        errorMessage: null,
      });

    } catch (error) {
      await storage.updateJobBoardIntegration(integrationId, {
        syncStatus: 'error',
        errorMessage: error.message,
      });
      throw error;
    }
  }

  private async upsertApplication(
    userId: string, 
    integrationId: number, 
    jobBoard: string, 
    appData: ExternalApplicationData
  ): Promise<ExternalApplication> {
    // Check if application already exists
    const existing = await storage.getExternalApplicationByExternalId(appData.externalId, jobBoard);
    
    if (existing) {
      // Update existing application
      const updated = await storage.updateExternalApplication(existing.id, {
        applicationStatus: appData.applicationStatus,
        lastUpdatedAt: appData.lastUpdatedAt,
        description: appData.description,
        requirements: appData.requirements,
        salaryRange: appData.salaryRange,
        rawData: appData.rawData,
        syncedAt: new Date(),
      });

      // Create event for status change if different
      if (existing.applicationStatus !== appData.applicationStatus) {
        await storage.createApplicationEvent({
          applicationId: existing.id,
          eventType: 'status_change',
          eventData: {
            previousStatus: existing.applicationStatus,
            newStatus: appData.applicationStatus,
          },
          eventDate: appData.lastUpdatedAt || new Date(),
          description: `Status changed from ${existing.applicationStatus} to ${appData.applicationStatus}`,
          isAutomated: true,
        });
      }

      return updated;
    } else {
      // Create new application
      const newApp = await storage.createExternalApplication({
        userId,
        integrationId,
        externalId: appData.externalId,
        jobBoard,
        jobTitle: appData.jobTitle,
        company: appData.company,
        location: appData.location,
        jobUrl: appData.jobUrl,
        description: appData.description,
        requirements: appData.requirements,
        salaryRange: appData.salaryRange,
        jobType: appData.jobType,
        applicationStatus: appData.applicationStatus,
        appliedAt: appData.appliedAt,
        lastUpdatedAt: appData.lastUpdatedAt,
        resumeUsed: appData.resumeUsed,
        coverLetter: appData.coverLetter,
        rawData: appData.rawData,
        syncedAt: new Date(),
      });

      // Create initial application event
      await storage.createApplicationEvent({
        applicationId: newApp.id,
        eventType: 'application_created',
        eventData: { source: 'job_board_sync' },
        eventDate: appData.appliedAt,
        description: `Application imported from ${jobBoard}`,
        isAutomated: true,
      });

      return newApp;
    }
  }

  async syncAllUserIntegrations(userId: string): Promise<void> {
    const integrations = await storage.getUserJobBoardIntegrations(userId);
    const activesIntegrations = integrations.filter(i => i.isActive);

    const syncPromises = activesIntegrations.map(integration => 
      this.syncApplications(integration.id).catch(error => {
        console.error(`Sync failed for integration ${integration.id}:`, error);
      })
    );

    await Promise.all(syncPromises);
  }

  getSupportedJobBoards(): Array<{ id: string; name: string; description: string; available: boolean }> {
    return [
      {
        id: 'linkedin',
        name: 'LinkedIn',
        description: 'Connect your LinkedIn account to sync job applications',
        available: !!(process.env.LINKEDIN_CLIENT_ID && process.env.LINKEDIN_CLIENT_SECRET),
      },
      {
        id: 'indeed',
        name: 'Indeed',
        description: 'Indeed integration (coming soon)',
        available: false,
      },
      {
        id: 'glassdoor',
        name: 'Glassdoor',
        description: 'Glassdoor integration (coming soon)',
        available: false,
      },
      {
        id: 'ziprecruiter',
        name: 'ZipRecruiter',
        description: 'ZipRecruiter integration (coming soon)',
        available: false,
      },
    ];
  }
}

export const jobBoardService = new JobBoardService();