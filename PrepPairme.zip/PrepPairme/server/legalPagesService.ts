import { Pool } from 'pg';
import fetch from 'node-fetch';
import https from 'https';

interface WordPressPage {
  id: number;
  title: {
    rendered: string;
  };
  slug: string;
  content: {
    rendered: string;
  };
  date: string;
  modified: string;
}

interface LegalPageVariables {
  appName: string;
  appUrl: string;
  supportEmail: string;
  supportCenterUrl: string;
  knowledgeBaseUrl: string;
  appFeatures: string[];
  privacyRoute: string;
  termsRoute: string;
  cookiesRoute: string;
  gdprRoute: string;
}

export class LegalPagesService {
  private pool: Pool;
  private readonly wpApiUrl: string;
  private variables: LegalPageVariables;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is required');
    }
    
    this.wpApiUrl = 'https://wrelikbrands.com/wp-json/wp/v2/pages';
    
    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });

    // Define application variables for substitution
    this.variables = {
      appName: 'PrepPair',
      appUrl: 'https://preppair.me',
      supportEmail: 'help@preppair.com',
      supportCenterUrl: 'https://preppair.me/help-center',
      knowledgeBaseUrl: 'https://preppair.me/knowledge-base-guide',
      appFeatures: [
        'AI-powered interview preparation',
        'Resume optimization with ATS scoring',
        'Job application tracking and analytics',
        'Video practice sessions with feedback',
        'Career path visualization and planning',
        'Industry-specific question databases',
        'Automated job board integrations',
        'Real-time application status updates'
      ],
      privacyRoute: '/legal/privacy',
      termsRoute: '/legal/terms',
      cookiesRoute: '/legal/cookies',
      gdprRoute: '/legal/gdpr'
    };
  }

  private async ensureTableExists(): Promise<void> {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS legal_pages (
        id SERIAL PRIMARY KEY,
        wp_id INTEGER UNIQUE NOT NULL,
        slug VARCHAR(255) NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        raw_content TEXT NOT NULL,
        last_modified TIMESTAMP,
        cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(slug)
      );
      
      CREATE INDEX IF NOT EXISTS idx_legal_pages_slug ON legal_pages(slug);
      CREATE INDEX IF NOT EXISTS idx_legal_pages_wp_id ON legal_pages(wp_id);
    `;
    
    await this.pool.query(createTableQuery);
  }

  private substituteVariables(content: string): string {
    let processedContent = content;

    // Replace basic variables - handle both {{}} and {} formats
    processedContent = processedContent.replace(/\{\{App Name\}\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{App Name\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{\{Brand Name\}\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{Brand Name\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{\{App URL\}\}/g, this.variables.appUrl);
    processedContent = processedContent.replace(/\{App URL\}/g, this.variables.appUrl);
    processedContent = processedContent.replace(/\{\{Support Email\}\}/g, this.variables.supportEmail);
    processedContent = processedContent.replace(/\{Support Email\}/g, this.variables.supportEmail);
    processedContent = processedContent.replace(/\{\{Support Center URL\}\}/g, this.variables.supportCenterUrl);
    processedContent = processedContent.replace(/\{Support Center URL\}/g, this.variables.supportCenterUrl);
    processedContent = processedContent.replace(/\{\{Knowledge Base URL\}\}/g, this.variables.knowledgeBaseUrl);
    processedContent = processedContent.replace(/\{Knowledge Base URL\}/g, this.variables.knowledgeBaseUrl);

    // Replace app features with bulleted list
    const featuresHtml = this.variables.appFeatures
      .map(feature => `<li>${feature}</li>`)
      .join('');
    processedContent = processedContent.replace(/\{\{App Features\}\}/g, `<ul>${featuresHtml}</ul>`);
    processedContent = processedContent.replace(/\{App Features\}/g, `<ul>${featuresHtml}</ul>`);

    // Replace legal page routes
    processedContent = processedContent.replace(/\{\{Privacy Route\}\}/g, this.variables.privacyRoute);
    processedContent = processedContent.replace(/\{Privacy Route\}/g, this.variables.privacyRoute);
    processedContent = processedContent.replace(/\{\{Terms Route\}\}/g, this.variables.termsRoute);
    processedContent = processedContent.replace(/\{Terms Route\}/g, this.variables.termsRoute);
    processedContent = processedContent.replace(/\{\{Cookies Route\}\}/g, this.variables.cookiesRoute);
    processedContent = processedContent.replace(/\{Cookies Route\}/g, this.variables.cookiesRoute);
    processedContent = processedContent.replace(/\{\{Cookie Route\}\}/g, this.variables.cookiesRoute);
    processedContent = processedContent.replace(/\{Cookie Route\}/g, this.variables.cookiesRoute);
    processedContent = processedContent.replace(/\{\{GDPR Route\}\}/g, this.variables.gdprRoute);
    processedContent = processedContent.replace(/\{GDPR Route\}/g, this.variables.gdprRoute);

    // Additional common variations
    processedContent = processedContent.replace(/\{\{Company Name\}\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{Company Name\}/g, this.variables.appName);
    processedContent = processedContent.replace(/\{\{Website\}\}/g, this.variables.appUrl);
    processedContent = processedContent.replace(/\{Website\}/g, this.variables.appUrl);
    processedContent = processedContent.replace(/\{\{Contact Email\}\}/g, this.variables.supportEmail);
    processedContent = processedContent.replace(/\{Contact Email\}/g, this.variables.supportEmail);

    return processedContent;
  }

  private cleanHtmlContent(html: string): string {
    if (!html) return '';
    
    return html
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#8217;/g, "'")
      .replace(/&#8220;/g, '"')
      .replace(/&#8221;/g, '"')
      .trim();
  }

  private async upsertLegalPage(page: WordPressPage): Promise<void> {
    const cleanContent = this.cleanHtmlContent(page.content.rendered);
    const processedContent = this.substituteVariables(cleanContent);
    
    const query = `
      INSERT INTO legal_pages (wp_id, slug, title, content, raw_content, last_modified, cached_at)
      VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)
      ON CONFLICT (wp_id) 
      DO UPDATE SET 
        slug = EXCLUDED.slug,
        title = EXCLUDED.title,
        content = EXCLUDED.content,
        raw_content = EXCLUDED.raw_content,
        last_modified = EXCLUDED.last_modified,
        cached_at = CURRENT_TIMESTAMP
    `;
    
    await this.pool.query(query, [
      page.id,
      page.slug,
      page.title.rendered,
      processedContent,
      cleanContent,
      new Date(page.modified)
    ]);
  }

  async fetchAndCacheLegalPages(): Promise<void> {
    try {
      await this.ensureTableExists();

      // Create agent with disabled SSL verification for development
      const agent = new https.Agent({
        rejectUnauthorized: false,
      });

      // Fetch legal pages from WordPress
      const legalSlugs = ['privacy-policy', 'terms-of-service', 'cookie-policy', 'gdpr-compliance'];
      
      for (const slug of legalSlugs) {
        try {
          const response = await fetch(`${this.wpApiUrl}?slug=${slug}&_fields=id,title,slug,content,date,modified`, {
            agent,
          });

          if (!response.ok) {
            console.warn(`Failed to fetch legal page ${slug}: ${response.status}`);
            continue;
          }

          const pages: WordPressPage[] = await response.json() as WordPressPage[];
          
          if (pages && pages.length > 0) {
            await this.upsertLegalPage(pages[0]);
            console.log(`✓ Cached legal page: ${slug}`);
          } else {
            console.warn(`No legal page found for slug: ${slug}`);
          }
        } catch (error) {
          console.error(`Error fetching legal page ${slug}:`, error);
        }
      }

      console.log('Legal pages caching completed');
    } catch (error) {
      console.error('Error in fetchAndCacheLegalPages:', error);
      throw error;
    }
  }

  async getLegalPage(slug: string): Promise<any> {
    try {
      const query = 'SELECT * FROM legal_pages WHERE slug = $1 ORDER BY cached_at DESC LIMIT 1';
      const result = await this.pool.query(query, [slug]);
      
      if (result.rows.length === 0) {
        return null;
      }

      const page = result.rows[0];
      return {
        id: page.wp_id,
        slug: page.slug,
        title: this.substituteVariables(page.title),
        content: this.substituteVariables(page.content),
        lastModified: page.last_modified,
        cachedAt: page.cached_at
      };
    } catch (error) {
      console.error('Error getting legal page:', error);
      throw error;
    }
  }

  async getAllLegalPages(): Promise<any[]> {
    try {
      const query = 'SELECT * FROM legal_pages ORDER BY title ASC';
      const result = await this.pool.query(query);
      
      return result.rows.map(page => ({
        id: page.wp_id,
        slug: page.slug,
        title: this.substituteVariables(page.title),
        content: this.substituteVariables(page.content),
        lastModified: page.last_modified,
        cachedAt: page.cached_at
      }));
    } catch (error) {
      console.error('Error getting all legal pages:', error);
      throw error;
    }
  }

  async refreshLegalPage(slug: string): Promise<void> {
    try {
      const agent = new https.Agent({
        rejectUnauthorized: false,
      });

      const response = await fetch(`${this.wpApiUrl}?slug=${slug}&_fields=id,title,slug,content,date,modified`, {
        agent,
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch legal page ${slug}: ${response.status}`);
      }

      const pages: WordPressPage[] = await response.json() as WordPressPage[];
      
      if (pages && pages.length > 0) {
        await this.upsertLegalPage(pages[0]);
        console.log(`✓ Refreshed legal page: ${slug}`);
      } else {
        throw new Error(`No legal page found for slug: ${slug}`);
      }
    } catch (error) {
      console.error(`Error refreshing legal page ${slug}:`, error);
      throw error;
    }
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

export const legalPagesService = new LegalPagesService();