import { RequestHandler } from "express";
import { storage } from "../storage";

// Middleware to check if user has Pro subscription
export const requiresPro: RequestHandler = async (req: any, res, next) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(userId);
    
    if (!user || !user.isPro) {
      return res.status(403).json({ 
        message: "Pro subscription required",
        upgradeRequired: true,
        feature: "pro"
      });
    }

    next();
  } catch (error) {
    console.error("Error checking Pro access:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Middleware to check if user is admin
export const requiresAdmin: RequestHandler = async (req: any, res, next) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser(userId);
    
    if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
      return res.status(403).json({ 
        message: "Admin access required",
        adminRequired: true
      });
    }

    next();
  } catch (error) {
    console.error("Error checking admin access:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Middleware to add user context to request
export const addUserContext: RequestHandler = async (req: any, res, next) => {
  try {
    if (req.isAuthenticated() && req.user?.claims?.sub) {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      req.userContext = user;
    }
    next();
  } catch (error) {
    console.error("Error adding user context:", error);
    next(); // Continue even if user context fails
  }
};

// Feature access control based on subscription tier
export const checkFeatureAccess = (feature: string): RequestHandler => {
  return async (req: any, res, next) => {
    try {
      const userId = req.user?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Define feature access levels
      const proFeatures = [
        'advanced-resume-analysis',
        'unlimited-improvements',
        'priority-processing',
        'ai-fine-tuning',
        'advanced-interview-prep',
        'career-path-planning',
        'job-board-integrations',
        'video-analysis',
        'custom-templates',
        'analytics-dashboard'
      ];

      const freeFeatures = [
        'basic-resume-review',
        'basic-interview-prep',
        'job-tracking',
        'skill-highlights',
        'newsletter-signup'
      ];

      // Check if feature requires Pro
      if (proFeatures.includes(feature) && !user.isPro) {
        return res.status(403).json({
          message: `${feature} requires Pro subscription`,
          upgradeRequired: true,
          feature: feature
        });
      }

      // Add feature usage tracking
      req.featureAccess = {
        feature,
        tier: user.isPro ? 'pro' : 'free',
        userId: user.id
      };

      next();
    } catch (error) {
      console.error("Error checking feature access:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  };
};

// Rate limiting for free users
export const rateLimitFree = (maxRequests: number, windowMs: number = 3600000): RequestHandler => {
  const requestCounts = new Map<string, { count: number; resetTime: number }>();

  return async (req: any, res, next) => {
    try {
      const userId = req.user?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      
      // Pro users bypass rate limiting
      if (user?.isPro) {
        return next();
      }

      const now = Date.now();
      const userKey = `${userId}:${req.route?.path || req.path}`;
      const userRequests = requestCounts.get(userKey);

      if (!userRequests || now > userRequests.resetTime) {
        requestCounts.set(userKey, { count: 1, resetTime: now + windowMs });
        return next();
      }

      if (userRequests.count >= maxRequests) {
        return res.status(429).json({
          message: "Rate limit exceeded. Upgrade to Pro for unlimited access.",
          upgradeRequired: true,
          retryAfter: Math.ceil((userRequests.resetTime - now) / 1000)
        });
      }

      userRequests.count++;
      next();
    } catch (error) {
      console.error("Error in rate limiting:", error);
      next(); // Continue on error to avoid blocking
    }
  };
};