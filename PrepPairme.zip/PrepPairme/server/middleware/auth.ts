import { Request, Response, NextFunction } from 'express';

// Enhanced request interface with user context
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    publicMetadata?: Record<string, any>;
    privateMetadata?: Record<string, any>;
  };
}

// Middleware to extract user from Clerk headers (set by client-side authentication)
export const extractUser = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    // Check for Clerk user data in headers (set by client-side Clerk)
    const userId = req.headers['x-clerk-user-id'] as string;
    const userEmail = req.headers['x-clerk-user-email'] as string;
    const userFirstName = req.headers['x-clerk-user-first-name'] as string;
    const userLastName = req.headers['x-clerk-user-last-name'] as string;
    const userPlan = req.headers['x-clerk-user-plan'] as string;
    const userRole = req.headers['x-clerk-user-role'] as string;
    
    if (userId) {
      req.user = {
        id: userId,
        email: userEmail,
        firstName: userFirstName,
        lastName: userLastName,
        publicMetadata: {
          plan: userPlan || 'free',
          role: userRole || 'user'
        },
        privateMetadata: {}
      };
    }
    
    next();
  } catch (error) {
    console.error('Error extracting user:', error);
    next();
  }
};

// Require authentication middleware
export const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user?.id) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'You must be signed in to access this resource'
    });
  }
  next();
};

// Require Pro plan middleware
export const requirePro = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user?.id) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'You must be signed in to access this resource'
    });
  }
  
  // Check if user has Pro plan in metadata
  const userPlan = req.user.publicMetadata?.plan || 'free';
  if (userPlan !== 'pro' && userPlan !== 'career_coach') {
    return res.status(403).json({ 
      error: 'Pro plan required',
      message: 'This feature requires a Pro or Career Coach plan',
      currentPlan: userPlan
    });
  }
  
  next();
};

// Require Career Coach plan middleware
export const requireCareerCoach = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user?.id) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'You must be signed in to access this resource'
    });
  }
  
  // Check if user has Career Coach plan
  const userPlan = req.user.publicMetadata?.plan || 'free';
  if (userPlan !== 'career_coach') {
    return res.status(403).json({ 
      error: 'Career Coach plan required',
      message: 'This feature requires a Career Coach plan',
      currentPlan: userPlan
    });
  }
  
  next();
};

// Require admin access middleware
export const requireAdmin = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user?.id) {
    return res.status(401).json({ 
      error: 'Authentication required',
      message: 'You must be signed in to access this resource'
    });
  }
  
  // Check if user has admin role
  const userRole = req.user.publicMetadata?.role || 'user';
  if (userRole !== 'admin') {
    return res.status(403).json({ 
      error: 'Admin access required',
      message: 'This resource requires administrator privileges',
      currentRole: userRole
    });
  }
  
  next();
};

// Rate limiting middleware for free tier
export const rateLimitFree = (limit: number = 10) => {
  const requestCounts = new Map<string, { count: number; resetTime: number }>();
  
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const userId = req.user?.id;
    const userPlan = req.user?.publicMetadata?.plan || 'free';
    
    // Skip rate limiting for paid plans
    if (userPlan === 'pro' || userPlan === 'career_coach') {
      return next();
    }
    
    if (!userId) {
      return res.status(401).json({ 
        error: 'Authentication required',
        message: 'You must be signed in to access this resource'
      });
    }
    
    const now = Date.now();
    const windowMs = 60 * 60 * 1000; // 1 hour window
    const userRequests = requestCounts.get(userId);
    
    if (!userRequests || now > userRequests.resetTime) {
      requestCounts.set(userId, { count: 1, resetTime: now + windowMs });
      return next();
    }
    
    if (userRequests.count >= limit) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message: `Free tier limited to ${limit} requests per hour. Upgrade to Pro for unlimited access.`,
        resetTime: userRequests.resetTime
      });
    }
    
    userRequests.count++;
    next();
  };
};

// Feature access checker
export const checkFeatureAccess = (feature: string) => {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const userPlan = req.user?.publicMetadata?.plan || 'free';
    
    const featureAccess: Record<string, string[]> = {
      'basic_interview_prep': ['free', 'pro', 'career_coach'],
      'advanced_interview_prep': ['pro', 'career_coach'],
      'resume_optimization': ['pro', 'career_coach'],
      'job_tracking': ['pro', 'career_coach'],
      'video_practice': ['pro', 'career_coach'],
      'ai_fine_tuning': ['career_coach'],
      'skill_extraction': ['pro', 'career_coach'],
      'career_visualization': ['career_coach'],
      'job_board_integrations': ['pro', 'career_coach'],
      'admin_dashboard': ['admin']
    };
    
    const allowedPlans = featureAccess[feature] || [];
    const userRole = req.user?.publicMetadata?.role || 'user';
    
    // Check if user has required plan or admin role
    if (!allowedPlans.includes(userPlan) && userRole !== 'admin') {
      return res.status(403).json({
        error: 'Feature access denied',
        message: `This feature requires: ${allowedPlans.join(' or ')} plan`,
        currentPlan: userPlan,
        feature
      });
    }
    
    next();
  };
};