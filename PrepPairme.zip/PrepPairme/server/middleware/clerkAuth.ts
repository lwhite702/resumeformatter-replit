import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '@clerk/backend';

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email?: string;
        firstName?: string;
        lastName?: string;
        publicMetadata?: Record<string, any>;
        privateMetadata?: Record<string, any>;
      };
    }
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    // Extract session token from Authorization header
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid authorization header' });
    }

    const sessionToken = authHeader.substring(7);
    if (!sessionToken) {
      return res.status(401).json({ error: 'Session token not found' });
    }

    // Verify the session token with Clerk
    const payload = await verifyToken(sessionToken, {
      secretKey: process.env.CLERK_SECRET_KEY!,
    });

    if (!payload) {
      return res.status(401).json({ error: 'Invalid session token' });
    }

    // Attach user information to request
    req.user = {
      id: payload.sub,
      email: payload.email as string | undefined,
      firstName: payload.firstName as string | undefined,
      lastName: payload.lastName as string | undefined,
      publicMetadata: payload.publicMetadata as Record<string, any> | undefined,
      privateMetadata: payload.privateMetadata as Record<string, any> | undefined,
    };

    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ error: 'Authentication failed' });
  }
}

export function requireFeature(featureName: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Check if user has the required feature
    const hasFeature = req.user.publicMetadata?.features?.[featureName] === true ||
                      req.user.publicMetadata?.subscription?.features?.includes(featureName) ||
                      false;

    if (!hasFeature) {
      return res.status(403).json({ 
        error: 'Feature access denied',
        feature: featureName,
        upgradeRequired: true
      });
    }

    next();
  };
}

export function requirePlan(planName: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const userPlan = req.user.publicMetadata?.plan || 
                    req.user.publicMetadata?.subscription?.plan || 
                    'free';

    if (userPlan !== planName) {
      return res.status(403).json({ 
        error: 'Plan access denied',
        currentPlan: userPlan,
        requiredPlan: planName,
        upgradeRequired: true
      });
    }

    next();
  };
}