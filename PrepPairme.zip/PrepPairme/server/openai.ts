import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface InterviewGuideContent {
  title: string;
  summary: string;
  keySkills: string[];
  questions: Array<{
    question: string;
    answer: string;
    category: string;
  }>;
  starStories: Array<{
    situation: string;
    task: string;
    action: string;
    result: string;
    question: string;
  }>;
  talkingPoints: string[];
  followUpEmail: string;
}

export interface ResumeAnalysis {
  atsScore: number;
  keywordMatches: number;
  totalKeywords: number;
  suggestions: string[];
  bulletImprovements: Array<{
    original: string;
    improved: string;
    reasoning: string;
  }>;
}

export async function generateInterviewGuide(
  jobDescription: string,
  resumeContent: string,
  isPro: boolean = false
): Promise<InterviewGuideContent> {
  const prompt = `
    You are an expert interview coach. Create a comprehensive interview guide based on the job description and resume provided.
    
    Job Description:
    ${jobDescription}
    
    Resume:
    ${resumeContent}
    
    Generate a detailed interview guide with the following structure (respond in JSON format):
    {
      "title": "Interview Guide for [Position] at [Company]",
      "summary": "Brief overview of the role and what to expect",
      "keySkills": ["skill1", "skill2", "skill3"],
      "questions": [
        {
          "question": "Sample interview question",
          "answer": "Sample answer using candidate's background",
          "category": "behavioral|technical|situational"
        }
      ],
      "starStories": [
        {
          "situation": "Describe the situation",
          "task": "What was your task/responsibility",
          "action": "What actions did you take",
          "result": "What was the outcome",
          "question": "What question this story answers"
        }
      ],
      "talkingPoints": ["key point 1", "key point 2"],
      "followUpEmail": "Professional thank you email template"
    }
    
    Make the content specific to the candidate's background and the role requirements.
    Include 8-10 questions with detailed answers.
    ${isPro ? 'Include 3-4 detailed STAR stories.' : 'Include 1 STAR story sample.'}
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert interview coach. Always respond with valid JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = JSON.parse(response.choices[0].message.content || "{}");
    return content as InterviewGuideContent;
  } catch (error) {
    console.error("Error generating interview guide:", error);
    throw new Error("Failed to generate interview guide");
  }
}

export async function analyzeResume(
  resumeContent: string,
  jobDescription: string
): Promise<ResumeAnalysis> {
  const prompt = `
    Analyze this resume against the job description and provide ATS optimization insights.
    
    Resume:
    ${resumeContent}
    
    Job Description:
    ${jobDescription}
    
    Provide analysis in this JSON format:
    {
      "atsScore": 85,
      "keywordMatches": 12,
      "totalKeywords": 15,
      "suggestions": [
        "Add more industry-specific keywords",
        "Include quantified achievements",
        "Improve formatting for ATS readability"
      ],
      "bulletImprovements": [
        {
          "original": "Worked on web development projects",
          "improved": "Developed 5+ responsive web applications using React and Node.js, improving user engagement by 40%",
          "reasoning": "Added specific numbers and technologies"
        }
      ]
    }
    
    Focus on keyword optimization, quantifiable achievements, and ATS compatibility.
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert resume and ATS optimization specialist. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const analysis = JSON.parse(response.choices[0].message.content || "{}");
    return analysis as ResumeAnalysis;
  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw new Error("Failed to analyze resume");
  }
}

export async function generateThankYouNote(
  interviewerName: string,
  company: string,
  jobTitle: string,
  resumeContent?: string
): Promise<string> {
  const prompt = `
    Generate a professional thank you email for after an interview.
    
    Details:
    - Interviewer: ${interviewerName}
    - Company: ${company}
    - Position: ${jobTitle}
    ${resumeContent ? `- Candidate background: ${resumeContent.slice(0, 500)}...` : ''}
    
    Create a personalized, professional thank you email that:
    - Thanks the interviewer for their time
    - Reiterates interest in the position
    - Mentions a specific topic from the interview (general)
    - Offers to provide additional information
    - Professional closing
    
    Keep it concise but genuine.
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional communication expert. Create polished, authentic thank you emails."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.6,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error generating thank you note:", error);
    throw new Error("Failed to generate thank you note");
  }
}

export async function improveBulletPoint(
  originalBullet: string,
  jobDescription: string,
  context: string = ""
): Promise<string> {
  const prompt = `
    Improve this resume bullet point to better match the job requirements and be more impactful:
    
    Original: "${originalBullet}"
    Job Requirements: ${jobDescription.slice(0, 500)}...
    ${context ? `Additional context: ${context}` : ''}
    
    Make it:
    - More specific and quantified
    - Keyword-optimized for ATS
    - Action-oriented with strong verbs
    - Results-focused when possible
    
    Return only the improved bullet point.
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional resume writer specializing in ATS optimization and impactful achievements."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.4,
    });

    return response.choices[0].message.content || originalBullet;
  } catch (error) {
    console.error("Error improving bullet point:", error);
    throw new Error("Failed to improve bullet point");
  }
}

export async function generateAnswerForQuestion(
  question: string,
  tone: string = "professional",
  resumeContent?: string
): Promise<string> {
  const prompt = `
    Generate a strong interview answer for this question: "${question}"
    
    ${resumeContent ? `Candidate background: ${resumeContent.slice(0, 400)}...` : ''}
    
    Tone: ${tone}
    
    Create an answer that:
    - Is specific and detailed
    - Uses the STAR method when appropriate
    - Shows confidence and competence
    - Is authentic and conversational
    - Matches the requested tone
    
    Keep it concise but comprehensive (2-3 paragraphs).
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert interview coach. Generate answers in a ${tone} tone that sound natural and confident.`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error generating answer:", error);
    throw new Error("Failed to generate answer");
  }
}

export async function extractTextFromPDF(pdfBuffer: Buffer): Promise<string> {
  // OpenAI's vision API doesn't support PDF files directly
  // We'll need to inform the user to paste the content manually
  throw new Error("PDF parsing requires manual text input. Please copy and paste your resume content.");
}

export interface VideoFeedbackResult {
  overallScore: number;
  contentScore: number;
  deliveryScore: number;
  clarityScore: number;
  confidenceScore: number;
  strengths: string[];
  improvements: string[];
  keyInsights: string[];
  speakingPace: string;
  fillerWords: number;
  eyeContact: string;
  bodyLanguage: string;
  practiceAreas: string[];
  suggestedQuestions: string[];
}

export async function analyzeVideoInterview(
  transcription: string,
  question: string,
  duration: number
): Promise<VideoFeedbackResult> {
  try {
    const prompt = `
      Analyze this interview response and provide detailed feedback:
      
      Question: "${question}"
      Response: "${transcription}"
      Duration: ${duration} seconds
      
      Provide comprehensive feedback in JSON format with these exact fields:
      {
        "overallScore": (1-100),
        "contentScore": (1-100),
        "deliveryScore": (1-100), 
        "clarityScore": (1-100),
        "confidenceScore": (1-100),
        "strengths": ["strength1", "strength2", "strength3"],
        "improvements": ["improvement1", "improvement2", "improvement3"],
        "keyInsights": ["insight1", "insight2", "insight3"],
        "speakingPace": "slow|normal|fast",
        "fillerWords": (estimated count),
        "eyeContact": "poor|fair|good|excellent",
        "bodyLanguage": "poor|fair|good|excellent", 
        "practiceAreas": ["area1", "area2", "area3"],
        "suggestedQuestions": ["question1", "question2", "question3"]
      }
      
      Focus on content relevance, structure, examples, confidence, and professional communication.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert interview coach and communication specialist. Provide detailed, constructive feedback to help candidates improve their interview performance."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const feedback = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and ensure all required fields are present
    return {
      overallScore: Math.max(1, Math.min(100, feedback.overallScore || 50)),
      contentScore: Math.max(1, Math.min(100, feedback.contentScore || 50)),
      deliveryScore: Math.max(1, Math.min(100, feedback.deliveryScore || 50)),
      clarityScore: Math.max(1, Math.min(100, feedback.clarityScore || 50)),
      confidenceScore: Math.max(1, Math.min(100, feedback.confidenceScore || 50)),
      strengths: feedback.strengths || ["Response provided"],
      improvements: feedback.improvements || ["Consider adding more specific examples"],
      keyInsights: feedback.keyInsights || ["Practice will improve performance"],
      speakingPace: feedback.speakingPace || "normal",
      fillerWords: Math.max(0, feedback.fillerWords || 0),
      eyeContact: feedback.eyeContact || "fair",
      bodyLanguage: feedback.bodyLanguage || "fair",
      practiceAreas: feedback.practiceAreas || ["Communication skills"],
      suggestedQuestions: feedback.suggestedQuestions || ["Tell me about yourself"]
    };
  } catch (error) {
    console.error("Error analyzing video interview:", error);
    throw new Error("Failed to analyze video interview: " + (error as Error).message);
  }
}
