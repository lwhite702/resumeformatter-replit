import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "./db";
import * as schema from "@shared/schema";
import { desc } from "drizzle-orm";
import { 
  extractUser, 
  requireAuth, 
  requirePro, 
  requireCareerCoach, 
  requireAdmin, 
  rateLimitFree,
  checkFeatureAccess,
  type AuthenticatedRequest
} from "./middleware/auth";
import { requireAuth as clerkRequireAuth } from "./middleware/clerkAuth";
import { autoApplyService } from "./autoApplyIntegration";
import { legalPagesService } from "./legalPagesService";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Apply user extraction middleware to all routes
  app.use('/api', extractUser);
  
  // Health check endpoint (public)
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Legal pages API endpoints - Uses cached WordPress content with variable substitution
  app.get('/api/legal-pages', async (req, res) => {
    try {
      const pages = await legalPagesService.getAllLegalPages();
      res.json({ pages });
    } catch (error) {
      console.error("Error fetching legal pages:", error);
      res.status(500).json({ message: "Failed to fetch legal pages" });
    }
  });

  app.get('/api/legal-pages/:slug', async (req, res) => {
    try {
      const { slug } = req.params;
      const page = await legalPagesService.getLegalPage(slug);
      
      if (!page) {
        return res.status(404).json({ message: "Legal page not found" });
      }

      res.json(page);
    } catch (error) {
      console.error("Error fetching legal page:", error);
      res.status(500).json({ message: "Failed to fetch legal page" });
    }
  });

  app.post('/api/legal-pages/refresh', requireAdmin, async (req, res) => {
    try {
      await legalPagesService.fetchAndCacheLegalPages();
      res.json({ message: "Legal pages refreshed successfully" });
    } catch (error) {
      console.error("Error refreshing legal pages:", error);
      res.status(500).json({ message: "Failed to refresh legal pages" });
    }
  });

  app.post('/api/legal-pages/:slug/refresh', requireAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      await legalPagesService.refreshLegalPage(slug);
      res.json({ message: `Legal page ${slug} refreshed successfully` });
    } catch (error) {
      console.error("Error refreshing legal page:", error);
      res.status(500).json({ message: "Failed to refresh legal page" });
    }
  });

  // Public endpoints
  app.get('/api/blog-posts', async (req, res) => {
    try {
      // Fetch cached WordPress posts from database
      const cachedPosts = await db.select().from(schema.cachedPosts).orderBy(desc(schema.cachedPosts.updatedAt)).limit(10);
      
      // Transform to API format
      const posts = cachedPosts.map((post, index) => ({
        id: post.id,
        title: { rendered: post.title },
        excerpt: { rendered: post.excerpt || '' },
        content: { rendered: post.content },
        date: post.publishedAt?.toISOString() || new Date().toISOString(),
        slug: post.slug,
        link: `/blog/${post.slug}`,
        featured_media_url: `https://images.unsplash.com/photo-${1560472354443 + index}?w=800&h=400&fit=crop`,
        categories: [1]
      }));

      res.json({ posts });
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      res.status(500).json({ message: 'Failed to fetch blog posts' });
    }
  });

  // WordPress cached posts endpoint (public)
  app.get('/api/wp-posts', async (req, res) => {
    const { WordPressCacher } = await import('./cacheWpPosts');
    const cacher = new WordPressCacher();
    const limit = parseInt(req.query.limit as string) || 10;
    
    try {
      const posts = await cacher.getRecentPosts(limit);
      
      res.json({
        success: true,
        posts,
        count: posts.length,
        cached: true
      });
      
    } catch (error) {
      console.error('Failed to fetch cached posts:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch cached posts',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      await cacher.close();
    }
  });

  // Admin API endpoints
  app.get('/api/admin/feature-flags', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const flags = [
        {
          id: 1,
          app: 'PrepPair.me',
          name: 'ai_resume_optimization',
          description: 'Advanced AI-powered resume optimization with detailed feedback',
          enabled: true,
          requiredPlan: 'pro_monthly',
          createdAt: '2025-06-18T00:00:00Z',
          updatedAt: '2025-06-18T12:00:00Z'
        },
        {
          id: 2,
          app: 'PrepPair.me',
          name: 'video_interview_practice',
          description: 'Video-based interview practice with AI feedback',
          enabled: true,
          requiredPlan: 'pro_monthly',
          createdAt: '2025-06-18T00:00:00Z',
          updatedAt: '2025-06-18T12:00:00Z'
        },
        {
          id: 3,
          app: 'PrepPair.me',
          name: 'career_visualization',
          description: 'Interactive career path visualization and planning',
          enabled: true,
          requiredPlan: 'pro_quarterly',
          createdAt: '2025-06-18T00:00:00Z',
          updatedAt: '2025-06-18T12:00:00Z'
        },
        {
          id: 4,
          app: 'PrepPair.me',
          name: 'job_board_integrations',
          description: 'Connect with external job boards for application tracking',
          enabled: false,
          requiredPlan: 'pro_monthly',
          createdAt: '2025-06-18T00:00:00Z',
          updatedAt: '2025-06-18T12:00:00Z'
        }
      ];
      
      res.json({ flags });
    } catch (error) {
      console.error('Error fetching feature flags:', error);
      res.status(500).json({ message: 'Failed to fetch feature flags' });
    }
  });

  app.patch('/api/admin/feature-flags/:id', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const { enabled } = req.body;
      
      // In a real implementation, this would update the database
      console.log(`Feature flag ${id} ${enabled ? 'enabled' : 'disabled'} by admin ${req.user?.id || 'unknown'}`);
      
      res.json({ 
        success: true, 
        message: `Feature flag ${enabled ? 'enabled' : 'disabled'}` 
      });
    } catch (error) {
      console.error('Error updating feature flag:', error);
      res.status(500).json({ message: 'Failed to update feature flag' });
    }
  });

  app.post('/api/admin/feature-flags', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const { name, description, enabled, requiredPlan, app } = req.body;
      
      const newFlag = {
        id: Date.now(),
        app: app || 'PrepPair.me',
        name,
        description,
        enabled,
        requiredPlan,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      console.log(`New feature flag created: ${name} by admin ${req.user?.id || 'unknown'}`);
      
      res.status(201).json({ flag: newFlag });
    } catch (error) {
      console.error('Error creating feature flag:', error);
      res.status(500).json({ message: 'Failed to create feature flag' });
    }
  });

  app.get('/api/admin/billing-plans', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const plans = [
        {
          id: 'free',
          name: 'free',
          displayName: 'Free',
          price: 0,
          interval: 'month',
          features: [
            '3 resume optimizations per month',
            'Basic ATS scoring',
            '5 interview practice sessions',
            'Basic job application tracking',
            'Community access'
          ],
          stripeProductId: 'prod_free_preppair',
          stripePriceId: 'price_free_preppair',
          metadata: { plan_type: 'free', display_order: 1 },
          active: true
        },
        {
          id: 'pro_monthly',
          name: 'pro_monthly',
          displayName: 'Pro Monthly',
          price: 19,
          interval: 'month',
          features: [
            'Unlimited resume optimizations',
            'Advanced ATS scoring with insights',
            'Unlimited interview practice',
            'AI-powered skill highlights',
            'Job board integrations',
            'Video interview feedback',
            'Career path visualization',
            'Priority support'
          ],
          stripeProductId: 'prod_pro_monthly_preppair',
          stripePriceId: 'price_pro_monthly_preppair',
          metadata: { plan_type: 'pro', display_order: 2, popular: true },
          active: true
        },
        {
          id: 'pro_quarterly',
          name: 'pro_quarterly',
          displayName: 'Pro Quarterly',
          price: 49,
          interval: 'quarter',
          features: [
            'Everything in Pro Monthly',
            '3 months of premium access',
            'Extended analytics history',
            'Bulk resume processing',
            'Priority customer support',
            'Advanced career insights',
            'Quarterly progress reports',
            'Best value - Save 18%'
          ],
          stripeProductId: 'prod_pro_quarterly_preppair',
          stripePriceId: 'price_pro_quarterly_preppair',
          metadata: { plan_type: 'pro', display_order: 3, best_value: true },
          active: true
        }
      ];
      
      res.json({ plans });
    } catch (error) {
      console.error('Error fetching billing plans:', error);
      res.status(500).json({ message: 'Failed to fetch billing plans' });
    }
  });

  app.post('/api/admin/sync-stripe', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      // In a real implementation, this would sync with Stripe API
      console.log(`Stripe data sync initiated by admin ${req.user?.id || 'unknown'}`);
      
      res.json({ 
        success: true, 
        message: 'Stripe data synchronized successfully',
        syncedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error syncing Stripe data:', error);
      res.status(500).json({ message: 'Failed to sync Stripe data' });
    }
  });

  app.get('/api/admin/knowledge-file', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const knowledgeFile = {
        id: 1,
        title: 'PrepPair.me Knowledge Base',
        content: `# PrepPair.me Knowledge Base

## Application Overview
PrepPair.me is an AI-powered career development platform that provides interview preparation, resume optimization, and job tracking tools.

### Current Status
- **Environment**: Production
- **Version**: 2.1.0
- **Last Updated**: ${new Date().toISOString()}
- **Active Users**: 1,247
- **Subscription Revenue**: $5,491 MRR

### Core Features

#### Interview Preparation
- AI-powered mock interviews with GPT-4
- Industry-specific question databases
- Real-time feedback and STAR method coaching
- Video practice sessions with analysis

#### Resume Optimization
- ATS scoring and compatibility checks
- Keyword optimization suggestions
- Professional template library
- Export to multiple formats (PDF, DOCX)

#### Job Application Tracking
- Application status monitoring with ApplyCaptain integration
- Interview scheduling and reminders
- Follow-up email templates
- Analytics and success metrics

### Technical Infrastructure
- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Express.js + PostgreSQL + Drizzle ORM
- **Authentication**: Clerk OAuth with role-based access
- **Payments**: Stripe with webhook handling
- **AI**: OpenAI GPT-4 API integration
- **Hosting**: Replit with auto-scaling
- **Database**: PostgreSQL via Neon

### Pricing & Plans
- **Free**: $0/month - Basic features, limited usage
- **Pro Monthly**: $19/month - Full access to all features
- **Pro Quarterly**: $49/quarter - Best value with 18% savings
- **ApplyCaptain Add-on**: $10/month for Pro subscribers

### Admin Access
- Dashboard: Real-time metrics and system health
- User Management: Search, modify roles, track activity
- Subscription Monitoring: Stripe integration, MRR tracking
- Content Management: Blog posts, legal pages, knowledge base
- Feature Flags: Real-time feature control
- Support Tools: Ticket management, user feedback

### Security & Compliance
- Admin-only routes protected with Clerk role verification
- All admin pages include noindex meta tags
- Environment variable security for API keys
- HTTPS encryption and secure cookie handling
- GDPR and CCPA compliance measures

### Performance Metrics
- Page load time: <2 seconds on mobile
- Lighthouse score: 85+ across all metrics
- System uptime: 99.9% weekly average
- API response time: <500ms average

### Support Information
- **Primary Contact**: admin@preppair.me
- **Documentation**: Available at /admin/docs (admin-only)
- **Error Monitoring**: Integrated logging and alerting
- **Backup Schedule**: Daily automated backups

---
*This knowledge base is maintained by the PrepPair.me admin team and updated regularly.*`,
        version: '2.1.0',
        createdAt: '2025-06-18T00:00:00Z',
        updatedAt: new Date().toISOString(),
        createdBy: 'admin@preppair.me',
        app: 'PrepPair.me'
      };
      
      res.json(knowledgeFile);
    } catch (error) {
      console.error('Error fetching knowledge file:', error);
      res.status(500).json({ message: 'Failed to fetch knowledge file' });
    }
  });

  app.put('/api/admin/knowledge-file', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const { title, content, changeNotes } = req.body;
      
      // In a real implementation, this would save to database with version control
      console.log(`Knowledge file updated by admin ${req.user?.id || 'unknown'}: ${changeNotes}`);
      
      const updatedFile = {
        id: 1,
        title,
        content,
        version: '2.1.1',
        createdAt: '2025-06-18T00:00:00Z',
        updatedAt: new Date().toISOString(),
        createdBy: req.user?.email || 'admin',
        app: 'PrepPair.me'
      };
      
      res.json({ 
        success: true, 
        file: updatedFile,
        message: 'Knowledge file updated successfully'
      });
    } catch (error) {
      console.error('Error updating knowledge file:', error);
      res.status(500).json({ message: 'Failed to update knowledge file' });
    }
  });

  app.get('/api/admin/knowledge-file/versions', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const versions = [
        {
          id: 1,
          version: '2.1.0',
          content: 'Initial production release...',
          createdAt: '2025-06-18T00:00:00Z',
          createdBy: 'admin@preppair.me',
          changeNotes: 'Initial production documentation'
        },
        {
          id: 2,
          version: '2.0.5',
          content: 'Beta release documentation...',
          createdAt: '2025-06-17T00:00:00Z',
          createdBy: 'admin@preppair.me',
          changeNotes: 'Updated feature descriptions and pricing'
        }
      ];
      
      res.json({ versions });
    } catch (error) {
      console.error('Error fetching knowledge file versions:', error);
      res.status(500).json({ message: 'Failed to fetch versions' });
    }
  });

  app.get('/api/knowledge/categories', async (req, res) => {
    try {
      const categories = [
        {
          id: 1,
          name: "Interview Preparation",
          slug: "interview-preparation",
          description: "Complete guides for interview success",
          parentId: null,
          sortOrder: 1,
          color: "#3B82F6",
          icon: "mic",
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 2,
          name: "Resume Optimization",
          slug: "resume-optimization", 
          description: "Expert tips for resume improvement",
          parentId: null,
          sortOrder: 2,
          color: "#10B981",
          icon: "file-text",
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      res.json(categories);
    } catch (error) {
      console.error("Error fetching knowledge categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/knowledge/articles', async (req, res) => {
    try {
      const articles = [
        {
          id: 1,
          title: "Getting Started with Interview Preparation",
          content: "Complete guide to preparing for your next interview...",
          excerpt: "Learn the fundamentals of interview preparation",
          slug: "getting-started-interview-prep",
          category: "Interview Preparation",
          tags: ["beginner", "preparation"],
          status: "published",
          author_name: "PrepPair Team",
          created_at: new Date().toISOString(),
          view_count: 0,
          helpful_count: 0
        }
      ];
      res.json(articles);
    } catch (error) {
      console.error("Error fetching knowledge articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.get('/api/knowledge/faqs', async (req, res) => {
    try {
      const faqs = [
        {
          id: 1,
          question: "How do I prepare for behavioral interview questions?",
          answer: "Use the STAR method (Situation, Task, Action, Result) to structure your answers.",
          category_id: 1,
          is_active: true,
          view_count: 0,
          helpful_count: 0,
          tags: ["behavioral", "STAR method"],
          created_at: new Date().toISOString()
        }
      ];
      res.json(faqs);
    } catch (error) {
      console.error("Error fetching FAQ items:", error);
      res.status(500).json({ message: "Failed to fetch FAQs" });
    }
  });

  // User profile endpoint (requires authentication)
  app.get('/api/user/profile', requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const user = {
        id: req.user!.id,
        email: req.user!.email,
        firstName: req.user!.firstName,
        lastName: req.user!.lastName,
        plan: req.user!.publicMetadata?.plan || 'free',
        role: req.user!.publicMetadata?.role || 'user'
      };
      res.json(user);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  // Basic interview questions (free tier with rate limiting)
  app.get('/api/interview/questions/basic', requireAuth, rateLimitFree(20), async (req: AuthenticatedRequest, res) => {
    try {
      const questions = [
        {
          id: 1,
          question: "Tell me about yourself",
          category: "General",
          difficulty: "easy",
          tags: ["introduction", "basic"]
        },
        {
          id: 2,
          question: "Why do you want to work here?",
          category: "Company",
          difficulty: "easy",
          tags: ["motivation", "basic"]
        }
      ];
      res.json({ questions, plan: req.user!.publicMetadata?.plan || 'free' });
    } catch (error) {
      console.error("Error fetching basic interview questions:", error);
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });

  // Advanced interview questions (Pro plan required)
  app.get('/api/interview/questions/advanced', requirePro, checkFeatureAccess('advanced_interview_prep'), async (req: AuthenticatedRequest, res) => {
    try {
      const questions = [
        {
          id: 10,
          question: "Describe a challenging situation you faced and how you handled it",
          category: "Behavioral",
          difficulty: "hard",
          tags: ["behavioral", "problem-solving", "STAR"],
          sampleAnswer: "Use the STAR method to structure your response..."
        },
        {
          id: 11,
          question: "How do you handle conflict in a team environment?",
          category: "Behavioral",
          difficulty: "medium",
          tags: ["teamwork", "conflict-resolution"],
          sampleAnswer: "Focus on collaboration and finding common ground..."
        }
      ];
      res.json({ questions, plan: req.user!.publicMetadata?.plan });
    } catch (error) {
      console.error("Error fetching advanced interview questions:", error);
      res.status(500).json({ message: "Failed to fetch advanced questions" });
    }
  });

  // Resume optimization (Pro plan required)
  app.post('/api/resume/optimize', requirePro, checkFeatureAccess('resume_optimization'), async (req: AuthenticatedRequest, res) => {
    try {
      const { resumeText, jobDescription } = req.body;
      
      if (!resumeText) {
        return res.status(400).json({ message: "Resume text is required" });
      }

      const optimization = {
        atsScore: 85,
        suggestions: [
          "Add more quantifiable achievements",
          "Include relevant keywords from the job description",
          "Strengthen action verbs"
        ],
        improvedBullets: [
          {
            original: "Managed team projects",
            improved: "Led cross-functional team of 8 members to deliver 3 major projects on time, resulting in 15% cost savings"
          }
        ],
        userId: req.user!.id
      };
      
      res.json(optimization);
    } catch (error) {
      console.error("Error optimizing resume:", error);
      res.status(500).json({ message: "Failed to optimize resume" });
    }
  });

  // Job tracking (Pro plan required)
  app.get('/api/jobs/tracking', requirePro, checkFeatureAccess('job_tracking'), async (req: AuthenticatedRequest, res) => {
    try {
      const jobs = [
        {
          id: 1,
          title: "Software Engineer",
          company: "TechCorp",
          status: "applied",
          appliedAt: new Date().toISOString(),
          userId: req.user!.id
        }
      ];
      res.json({ jobs, plan: req.user!.publicMetadata?.plan });
    } catch (error) {
      console.error("Error fetching job tracking:", error);
      res.status(500).json({ message: "Failed to fetch job tracking data" });
    }
  });

  app.post('/api/jobs/tracking', requirePro, checkFeatureAccess('job_tracking'), async (req: AuthenticatedRequest, res) => {
    try {
      const jobData = {
        ...req.body,
        userId: req.user!.id,
        id: Date.now(),
        createdAt: new Date().toISOString()
      };
      res.status(201).json(jobData);
    } catch (error) {
      console.error("Error creating job tracking entry:", error);
      res.status(500).json({ message: "Failed to create job tracking entry" });
    }
  });

  // Video practice sessions (Pro plan required)
  app.get('/api/video/sessions', requirePro, checkFeatureAccess('video_practice'), async (req: AuthenticatedRequest, res) => {
    try {
      const sessions = [
        {
          id: 1,
          title: "Behavioral Interview Practice",
          duration: 300,
          createdAt: new Date().toISOString(),
          userId: req.user!.id
        }
      ];
      res.json({ sessions, plan: req.user!.publicMetadata?.plan });
    } catch (error) {
      console.error("Error fetching video sessions:", error);
      res.status(500).json({ message: "Failed to fetch video sessions" });
    }
  });

  // AI Fine-tuning (Career Coach plan required)
  app.post('/api/ai/fine-tune', requireCareerCoach, checkFeatureAccess('ai_fine_tuning'), async (req: AuthenticatedRequest, res) => {
    try {
      const { industry, jobRole } = req.body;
      
      const fineTuningJob = {
        id: Date.now(),
        industry,
        jobRole,
        status: "processing",
        userId: req.user!.id,
        createdAt: new Date().toISOString()
      };
      
      res.json(fineTuningJob);
    } catch (error) {
      console.error("Error starting AI fine-tuning:", error);
      res.status(500).json({ message: "Failed to start AI fine-tuning" });
    }
  });

  // Career visualization (Career Coach plan required)
  app.get('/api/career/visualization', requireCareerCoach, checkFeatureAccess('career_visualization'), async (req: AuthenticatedRequest, res) => {
    try {
      const visualization = {
        currentPosition: "Software Engineer",
        targetPosition: "Senior Software Engineer",
        pathways: [
          {
            id: 1,
            title: "Technical Leadership Path",
            steps: ["Lead Developer", "Engineering Manager", "Director of Engineering"],
            timeframe: "2-3 years"
          }
        ],
        userId: req.user!.id
      };
      res.json(visualization);
    } catch (error) {
      console.error("Error fetching career visualization:", error);
      res.status(500).json({ message: "Failed to fetch career visualization" });
    }
  });

  // Job board integrations (Career Coach plan required)
  app.get('/api/integrations/job-boards', requireCareerCoach, checkFeatureAccess('job_board_integrations'), async (req: AuthenticatedRequest, res) => {
    try {
      const integrations = [
        {
          id: 1,
          platform: "LinkedIn",
          status: "connected",
          lastSync: new Date().toISOString(),
          userId: req.user!.id
        }
      ];
      res.json({ integrations, plan: req.user!.publicMetadata?.plan });
    } catch (error) {
      console.error("Error fetching job board integrations:", error);
      res.status(500).json({ message: "Failed to fetch integrations" });
    }
  });

  // Admin dashboard (Admin access required)
  app.get('/api/admin/dashboard', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const dashboardData = {
        totalUsers: 1250,
        activeUsers: 850,
        paidUsers: 125,
        revenueThisMonth: "$15,750",
        topFeatures: [
          { name: "Interview Prep", usage: 75 },
          { name: "Resume Optimization", usage: 60 },
          { name: "Job Tracking", usage: 45 }
        ]
      };
      res.json(dashboardData);
    } catch (error) {
      console.error("Error fetching admin dashboard:", error);
      res.status(500).json({ message: "Failed to fetch admin dashboard" });
    }
  });

  // Admin user management
  app.get('/api/admin/users', requireAdmin, async (req: AuthenticatedRequest, res) => {
    try {
      const users = [
        {
          id: "user_123",
          email: "user@example.com",
          plan: "pro",
          role: "user",
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString()
        }
      ];
      res.json({ users, total: users.length });
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Plan upgrade endpoint
  app.post('/api/user/upgrade', requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { plan } = req.body;
      
      if (!['pro', 'career_coach'].includes(plan)) {
        return res.status(400).json({ message: "Invalid plan type" });
      }

      // In a real app, this would integrate with Stripe/payment processing
      const upgradeData = {
        userId: req.user!.id,
        newPlan: plan,
        status: "pending_payment",
        createdAt: new Date().toISOString()
      };
      
      res.json(upgradeData);
    } catch (error) {
      console.error("Error processing plan upgrade:", error);
      res.status(500).json({ message: "Failed to process plan upgrade" });
    }
  });

  // ApplyCaptain Integration Endpoints (Pro members with add-on)
  app.get('/api/integrations/autoapply/status', requirePro, checkFeatureAccess('job_board_integrations'), async (req: AuthenticatedRequest, res) => {
    try {
      // Check if user has ApplyCaptain add-on enabled
      const userPlan = req.user!.publicMetadata?.plan;
      const hasApplyCaptainAddon = req.user!.publicMetadata?.applyCaptainAddon === true;
      
      const status = {
        enabled: hasApplyCaptainAddon,
        plan: userPlan,
        lastSync: new Date().toISOString(),
        applicationsCount: 0,
        integrationActive: hasApplyCaptainAddon,
        addonPrice: "$10/month",
        regularPrice: "$20/month",
        discount: "50% off for Pro members"
      };
      
      res.json(status);
    } catch (error) {
      console.error("Error getting ApplyCaptain integration status:", error);
      res.status(500).json({ message: "Failed to get integration status" });
    }
  });

  app.post('/api/integrations/autoapply/sync', requirePro, checkFeatureAccess('job_board_integrations'), async (req: AuthenticatedRequest, res) => {
    try {
      // Check if user has ApplyCaptain add-on enabled
      const hasApplyCaptainAddon = req.user!.publicMetadata?.applyCaptainAddon === true;
      
      if (!hasApplyCaptainAddon) {
        return res.status(403).json({ 
          message: "ApplyCaptain add-on required",
          error: "This feature requires the ApplyCaptain add-on ($10/month for Pro members)",
          upgradeUrl: "https://applycaptain.com"
        });
      }

      // Use server-side ApplyCaptain integration
      const serverApiKey = process.env.AUTOAPPLY_API_KEY;
      
      if (!serverApiKey) {
        return res.status(503).json({ 
          message: "ApplyCaptain integration temporarily unavailable",
          error: "Service configuration pending"
        });
      }

      // Fetch applications from ApplyCaptain using server credentials
      const applications = await autoApplyService.fetchApplications(serverApiKey);
      
      // Filter applications by user if needed (based on user email or other identifier)
      const userApplications = applications.applications.filter(app => {
        // In a real implementation, you'd filter by user's email or account identifier
        return true; // For now, return all applications
      });
      
      // Sync to PrepPair API
      const syncData = {
        userId: req.user!.id,
        source: 'applycaptain',
        applications: userApplications,
        syncedAt: new Date().toISOString()
      };

      const prepPairResult = await autoApplyService.syncToPrepPairApi(syncData);
      
      res.json({
        success: true,
        applicationsFound: userApplications?.length || 0,
        prepPairSync: prepPairResult,
        message: `Synchronized ${userApplications?.length || 0} applications from ApplyCaptain`,
        integration: "applycaptain"
      });
    } catch (error) {
      console.error("Error syncing ApplyCaptain applications:", error);
      res.status(500).json({ message: "Failed to sync applications" });
    }
  });

  app.post('/api/integrations/autoapply/enable', requirePro, checkFeatureAccess('job_board_integrations'), async (req: AuthenticatedRequest, res) => {
    try {
      // Enable ApplyCaptain add-on for Pro members ($10/month)
      // In a real implementation, this would integrate with Stripe for payment processing
      
      const integration = {
        userId: req.user!.id,
        enabled: true,
        enabledAt: new Date().toISOString(),
        plan: req.user!.publicMetadata?.plan,
        addonName: "ApplyCaptain",
        monthlyPrice: 10,
        discount: "50% off regular price",
        regularPrice: 20
      };
      
      res.json({
        success: true,
        message: "ApplyCaptain add-on activated successfully! You can now sync job applications.",
        integration,
        nextSteps: [
          "Your ApplyCaptain integration is now active",
          "Use the Sync tab to synchronize your job applications",
          "View analytics and set up reminders for better tracking"
        ]
      });
    } catch (error) {
      console.error("Error enabling ApplyCaptain integration:", error);
      res.status(500).json({ message: "Failed to enable ApplyCaptain integration" });
    }
  });

  // PrepPair API integration endpoints
  app.get('/api/analytics/preppair', requireCareerCoach, async (req: AuthenticatedRequest, res) => {
    try {
      const result = await autoApplyService.getAnalytics(req.user!.id);
      
      if (result.success) {
        res.json(result.data);
      } else {
        res.status(400).json({ message: result.message });
      }
    } catch (error) {
      console.error("Error fetching PrepPair analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.post('/api/reminders/create', requirePro, async (req: AuthenticatedRequest, res) => {
    try {
      const { applicationId, type, dueDate, message } = req.body;
      
      if (!applicationId || !type || !dueDate || !message) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const result = await autoApplyService.createReminder(req.user!.id, {
        applicationId,
        type,
        dueDate,
        message
      });
      
      if (result.success) {
        res.json(result.data);
      } else {
        res.status(400).json({ message: result.message });
      }
    } catch (error) {
      console.error("Error creating reminder:", error);
      res.status(500).json({ message: "Failed to create reminder" });
    }
  });

  // User profile endpoint with Clerk authentication
  app.get('/api/user/profile', clerkRequireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const user = {
        id: req.user.id,
        email: req.user.email,
        firstName: req.user.firstName,
        lastName: req.user.lastName,
        plan: req.user.publicMetadata?.plan || 'free',
        role: req.user.publicMetadata?.role || 'user',
        joinedAt: '2024-01-01T00:00:00Z',
      };
      
      res.json(user);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      res.status(500).json({ message: 'Failed to fetch user profile' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}