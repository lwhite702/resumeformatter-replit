import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import * as schema from "@shared/schema";
import { desc } from "drizzle-orm";
// Authentication middleware
import { requireAuth as isAuthenticated, requireAdmin, requirePro, requireCareerCoach } from "./middleware/auth";
import { requiresPro, addUserContext, checkFeatureAccess, rateLimitFree } from "./middleware/accessControl";
import { skillExtractionService } from "./skillExtractionService";
import { aiFineTuningService } from "./aiFineTuning";
import { jobBoardService } from "./jobBoardService";
import { WordPressCacher } from "./cacheWpPosts";
import { legalPagesService } from "./legalPagesService";
import Stripe from "stripe";
import multer from "multer";
import * as openai from "./openai";
import { 
  insertResumeSchema, 
  insertJobPostingSchema, 
  insertInterviewGuideSchema, 
  insertThankYouNoteSchema, 
  insertReflectionSchema, 
  insertVideoPracticeSessionSchema, 
  insertVideoFeedbackSchema, 
  insertJobBoardIntegrationSchema, 
  insertExternalApplicationSchema, 
  insertQuestionSchema,
  knowledgeCategories,
  knowledgeArticles,
  supportTickets,
  supportTicketMessages,
  faqItems,
  supportAnalytics,
  knowledgeBaseFeedback,
  supportTags,
  type KnowledgeCategory,
  type KnowledgeArticle,
  type SupportTicket,
  type SupportTicketMessage,
  type FaqItem,
  type InsertKnowledgeCategory,
  type InsertKnowledgeArticle,
  type InsertSupportTicket,
  type InsertSupportTicketMessage,
  type InsertFaqItem,
  type InsertKnowledgeBaseFeedback
} from "@shared/schema";
import { z } from "zod";
import mammoth from "mammoth";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
});

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOCX, and TXT files are allowed.'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Using Clerk authentication on client-side only
  
  // Add user context to all authenticated routes
  app.use('/api', addUserContext);

  // Blog posts API endpoint - Uses cached WordPress content
  app.get('/api/blog-posts', async (req, res) => {
    try {
      // Fetch cached posts from database
      const cachedPosts = await db.select().from(schema.cachedPosts).orderBy(desc(schema.cachedPosts.updatedAt)).limit(10);
      
      // Transform cached posts to API format
      const blogPosts = cachedPosts.map((post, index) => ({
        id: post.id,
        title: { rendered: post.title },
        excerpt: { rendered: post.excerpt || '' },
        content: { rendered: post.content },
        date: post.publishedAt?.toISOString() || new Date().toISOString(),
        slug: post.slug,
        link: `/blog/${post.slug}`,
        featured_media_url: `https://images.unsplash.com/photo-${1560472354443 + index}?w=800&h=400&fit=crop`,
        categories: [1]
      }));

      res.json({
        posts: blogPosts,
        total: blogPosts.length,
        totalPages: 1
      });
    } catch (error) {
      console.error("Error serving blog posts:", error);
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  // Legal pages API endpoints - Uses cached WordPress content with variable substitution
  app.get('/api/legal-pages', async (req, res) => {
    try {
      const pages = await legalPagesService.getAllLegalPages();
      res.json({ pages });
    } catch (error) {
      console.error("Error fetching legal pages:", error);
      res.status(500).json({ message: "Failed to fetch legal pages" });
    }
  });

  app.get('/api/legal-pages/:slug', async (req, res) => {
    try {
      const { slug } = req.params;
      const page = await legalPagesService.getLegalPage(slug);
      
      if (!page) {
        return res.status(404).json({ message: "Legal page not found" });
      }

      res.json(page);
    } catch (error) {
      console.error("Error fetching legal page:", error);
      res.status(500).json({ message: "Failed to fetch legal page" });
    }
  });

  app.post('/api/legal-pages/refresh', requireAdmin, async (req, res) => {
    try {
      await legalPagesService.fetchAndCacheLegalPages();
      res.json({ message: "Legal pages refreshed successfully" });
    } catch (error) {
      console.error("Error refreshing legal pages:", error);
      res.status(500).json({ message: "Failed to refresh legal pages" });
    }
  });

  app.post('/api/legal-pages/:slug/refresh', requireAdmin, async (req, res) => {
    try {
      const { slug } = req.params;
      await legalPagesService.refreshLegalPage(slug);
      res.json({ message: `Legal page ${slug} refreshed successfully` });
    } catch (error) {
      console.error("Error refreshing legal page:", error);
      res.status(500).json({ message: "Failed to refresh legal page" });
    }
  });

  // Auth routes
  app.get('/api/login', (req, res) => {
    res.redirect('/api/auth/login');
  });

  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Atlas user entitlements endpoint
  app.get("/api/atlas/user-entitlements", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Make request to Atlas API to get user entitlements
      const atlasUrl = `${req.protocol}://${req.get('host')}/api/atlas/atlas-api/user-entitlements`;
      const response = await fetch(atlasUrl, {
        headers: {
          'Authorization': req.headers.authorization || '',
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        console.error('Atlas entitlements fetch failed:', response.status);
        return res.json({ entitlements: [] });
      }

      const data = await response.json();
      res.json({ entitlements: data.entitlements || [] });
    } catch (error) {
      console.error("Error fetching user entitlements:", error);
      res.json({ entitlements: [] });
    }
  });

  // Resume routes
  app.post('/api/resumes', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { name, content } = req.body;
      
      console.log('Resume upload request:', {
        hasFile: !!req.file,
        fileName: req.file?.originalname,
        fileSize: req.file?.size,
        mimeType: req.file?.mimetype,
        hasContent: !!content,
        contentLength: content?.length
      });
      
      let resumeContent = content;
      let fileName = null;
      
      if (req.file) {
        fileName = req.file.originalname;
        
        try {
          // Parse different file types
          if (req.file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            const result = await mammoth.extractRawText({ buffer: req.file.buffer });
            resumeContent = result.value;
          } else if (req.file.mimetype === 'text/plain') {
            resumeContent = req.file.buffer.toString('utf-8');
          } else if (req.file.mimetype === 'application/pdf') {
            // Use OpenAI to extract text from PDF
            try {
              resumeContent = await openai.extractTextFromPDF(req.file.buffer);
            } catch (pdfError) {
              console.error("PDF processing error:", pdfError);
              
              if (!content) {
                return res.status(400).json({ 
                  message: "Failed to parse PDF file. Please copy and paste your resume content in the text area below." 
                });
              }
              resumeContent = content;
            }
          } else {
            return res.status(400).json({ 
              message: "Unsupported file type. Please upload a PDF, DOCX, or TXT file, or paste your resume content directly." 
            });
          }
        } catch (parseError) {
          console.error("File parsing error:", parseError);
          if (!content) {
            return res.status(400).json({ 
              message: "Failed to parse the uploaded file. Please paste your resume content directly in the text area." 
            });
          }
          // If manual content is provided, use that as fallback
          resumeContent = content;
        }
      }

      if (!resumeContent || resumeContent.trim().length === 0) {
        return res.status(400).json({ 
          message: "Resume content is required. Please upload a valid file or paste your resume text." 
        });
      }

      const resumeData = insertResumeSchema.parse({
        userId,
        name: name || fileName || 'Untitled Resume',
        content: resumeContent.trim(),
        fileName,
      });

      const resume = await storage.createResume(resumeData);
      res.json(resume);
    } catch (error) {
      console.error("Error creating resume:", error);
      res.status(500).json({ message: "Failed to create resume" });
    }
  });

  app.get('/api/resumes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumes = await storage.getUserResumes(userId);
      res.json(resumes);
    } catch (error) {
      console.error("Error fetching resumes:", error);
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });

  app.get('/api/resumes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const resume = await storage.getResume(resumeId);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      if (resume.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(resume);
    } catch (error) {
      console.error("Error fetching resume:", error);
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });

  // Job posting routes
  app.post('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobData = insertJobPostingSchema.parse({
        ...req.body,
        userId,
      });

      const job = await storage.createJobPosting(jobData);
      res.json(job);
    } catch (error) {
      console.error("Error creating job posting:", error);
      res.status(500).json({ message: "Failed to create job posting" });
    }
  });

  app.get('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobs = await storage.getUserJobPostings(userId);
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.put('/api/jobs/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.id);
      
      const existingJob = await storage.getJobPosting(jobId);
      if (!existingJob || existingJob.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      const job = await storage.updateJobPosting(jobId, req.body);
      res.json(job);
    } catch (error) {
      console.error("Error updating job:", error);
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  // Interview guide routes
  app.post('/api/interview-guides', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { jobDescription, resumeContent, jobPostingId, resumeId } = req.body;

      if (!jobDescription || !resumeContent) {
        return res.status(400).json({ message: "Job description and resume content are required" });
      }

      // Check credits for non-Pro users
      if (!user.isPro && user.credits < 1) {
        return res.status(402).json({ message: "Insufficient credits" });
      }

      // Generate interview guide using AI
      const guideContent = await openai.generateInterviewGuide(
        jobDescription,
        resumeContent,
        user.isPro
      );

      const guideData = insertInterviewGuideSchema.parse({
        userId,
        jobPostingId: jobPostingId || null,
        resumeId: resumeId || null,
        title: guideContent.title,
        content: guideContent,
      });

      const guide = await storage.createInterviewGuide(guideData);

      // Deduct credit for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 1);
      }

      res.json(guide);
    } catch (error) {
      console.error("Error creating interview guide:", error);
      res.status(500).json({ message: "Failed to create interview guide" });
    }
  });

  app.get('/api/interview-guides', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const guides = await storage.getUserInterviewGuides(userId);
      res.json(guides);
    } catch (error) {
      console.error("Error fetching interview guides:", error);
      res.status(500).json({ message: "Failed to fetch interview guides" });
    }
  });

  app.get('/api/interview-guides/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const guideId = parseInt(req.params.id);
      
      const guide = await storage.getInterviewGuide(guideId);
      
      if (!guide) {
        return res.status(404).json({ message: "Interview guide not found" });
      }
      
      if (guide.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Increment view count
      await storage.incrementGuideViews(guideId);
      
      res.json(guide);
    } catch (error) {
      console.error("Error fetching interview guide:", error);
      res.status(500).json({ message: "Failed to fetch interview guide" });
    }
  });

  // Resume analysis/optimization - Pro feature with rate limiting for free users
  app.post('/api/resumes/:id/analyze', isAuthenticated, rateLimitFree(2), checkFeatureAccess('advanced-resume-analysis'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeId = parseInt(req.params.id);
      const { jobDescription } = req.body;

      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      if (!jobDescription) {
        return res.status(400).json({ message: "Job description is required" });
      }

      const analysis = await openai.analyzeResume(resume.content, jobDescription);
      
      // Update resume with ATS score
      await storage.updateResume(resumeId, { atsScore: analysis.atsScore });

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing resume:", error);
      res.status(500).json({ message: "Failed to analyze resume" });
    }
  });

  // Bullet point improvement - Pro feature with rate limiting
  app.post('/api/improve-bullet', isAuthenticated, rateLimitFree(3), checkFeatureAccess('unlimited-improvements'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.isPro && user.credits < 1) {
        return res.status(402).json({ message: "Insufficient credits" });
      }

      const { originalBullet, jobDescription, context } = req.body;

      if (!originalBullet || !jobDescription) {
        return res.status(400).json({ message: "Original bullet and job description are required" });
      }

      const improvedBullet = await openai.improveBulletPoint(originalBullet, jobDescription, context);

      // Deduct credit for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 1);
      }

      res.json({ improved: improvedBullet });
    } catch (error) {
      console.error("Error improving bullet point:", error);
      res.status(500).json({ message: "Failed to improve bullet point" });
    }
  });

  // One-click skill highlights generator - Pro feature
  app.post('/api/resumes/:id/skill-highlights', isAuthenticated, rateLimitFree(2), checkFeatureAccess('skill-highlights'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.isPro && user.credits < 2) {
        return res.status(402).json({ message: "Insufficient credits. Skill analysis requires 2 credits." });
      }

      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const skillAnalysis = await skillExtractionService.generateSkillHighlights(resumeId, userId);

      // Deduct credits for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 2);
      }

      res.json(skillAnalysis);
    } catch (error) {
      console.error("Error generating skill highlights:", error);
      res.status(500).json({ message: "Failed to generate skill highlights" });
    }
  });

  // Get skill highlights for a resume
  app.get('/api/resumes/:id/skill-highlights', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeId = parseInt(req.params.id);

      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const skills = await skillExtractionService.getSkillHighlights(resumeId, userId);
      res.json({ skills });
    } catch (error) {
      console.error("Error fetching skill highlights:", error);
      res.status(500).json({ message: "Failed to fetch skill highlights" });
    }
  });

  // Verify/unverify a skill
  app.patch('/api/skill-highlights/:skillId/verify', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const skillId = parseInt(req.params.skillId);
      const { isVerified } = req.body;

      await skillExtractionService.verifySkill(skillId, userId, isVerified);
      res.json({ success: true });
    } catch (error) {
      console.error("Error verifying skill:", error);
      res.status(500).json({ message: "Failed to verify skill" });
    }
  });

  // Get skill categories
  app.get('/api/skill-categories', async (req, res) => {
    try {
      const categories = await skillExtractionService.getSkillCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching skill categories:", error);
      res.status(500).json({ message: "Failed to fetch skill categories" });
    }
  });

  // Thank you note generation
  app.post('/api/thank-you-notes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.isPro && user.credits < 1) {
        return res.status(402).json({ message: "Insufficient credits" });
      }

      const { interviewerName, company, jobTitle, jobPostingId, resumeContent } = req.body;

      if (!interviewerName || !company || !jobTitle) {
        return res.status(400).json({ message: "Interviewer name, company, and job title are required" });
      }

      const content = await openai.generateThankYouNote(interviewerName, company, jobTitle, resumeContent);

      const noteData = insertThankYouNoteSchema.parse({
        userId,
        jobPostingId: jobPostingId || null,
        interviewerName,
        company,
        jobTitle,
        content,
      });

      const note = await storage.createThankYouNote(noteData);

      // Deduct credit for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 1);
      }

      res.json(note);
    } catch (error) {
      console.error("Error creating thank you note:", error);
      res.status(500).json({ message: "Failed to create thank you note" });
    }
  });

  app.get('/api/thank-you-notes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notes = await storage.getUserThankYouNotes(userId);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching thank you notes:", error);
      res.status(500).json({ message: "Failed to fetch thank you notes" });
    }
  });

  // Questions and answers - freely accessible
  app.get('/api/questions', async (req, res) => {
    try {
      const { category } = req.query;
      let questions = await storage.getQuestionsByCategory(category as string);
      
      // Add authentic questions from provided SQL data if database is empty
      if (questions.length === 0) {
        const authenticQuestions = [
          // Healthcare Questions
          {
            category: 'behavioral',
            question: 'How do you ensure patient confidentiality in your daily work?',
            difficulty: 'easy',
            tags: ['healthcare', 'HIPAA', 'confidentiality', 'ethics']
          },
          {
            category: 'technical',
            question: 'Describe your experience with electronic health record (EHR) systems.',
            difficulty: 'medium',
            tags: ['healthcare', 'EHR', 'technology', 'documentation']
          },
          
          // Behavioral Questions
          {
            category: 'behavioral',
            question: 'Tell me about a time you had to refactor a complex piece of code.',
            difficulty: 'medium',
            tags: ['technical', 'code quality', 'refactoring']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you took initiative beyond your job description.',
            difficulty: 'medium',
            tags: ['initiative', 'leadership', 'proactive']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you motivated a team during a difficult project.',
            difficulty: 'hard',
            tags: ['leadership', 'motivation', 'team management']
          },
          
          // Leadership Questions
          {
            category: 'leadership',
            question: 'Describe a leadership decision you made that didn\'t go as planned. What did you learn?',
            difficulty: 'hard',
            tags: ['decision making', 'learning from failure', 'leadership']
          },
          {
            category: 'leadership',
            question: 'How do you personally define leadership?',
            difficulty: 'medium',
            tags: ['leadership philosophy', 'personal values', 'management style']
          },
          {
            category: 'leadership',
            question: 'How do you support diversity and inclusion in team settings?',
            difficulty: 'hard',
            tags: ['diversity', 'inclusion', 'team dynamics']
          },
          {
            category: 'leadership',
            question: 'How do you help quiet team members feel included?',
            difficulty: 'medium',
            tags: ['inclusion', 'team facilitation', 'communication']
          },
          
          // Situational Questions
          {
            category: 'situational',
            question: 'How do you prioritize tasks when everything feels urgent?',
            difficulty: 'hard',
            tags: ['prioritization', 'time management', 'stress management']
          },
          {
            category: 'situational',
            question: 'Describe a situation where you had to persuade someone to see your point of view.',
            difficulty: 'medium',
            tags: ['persuasion', 'communication', 'influence']
          },
          {
            category: 'situational',
            question: 'How do you handle difficult questions during a presentation?',
            difficulty: 'hard',
            tags: ['presentation skills', 'communication', 'confidence']
          },
          {
            category: 'situational',
            question: 'Tell me about a time you turned feedback into a breakthrough.',
            difficulty: 'medium',
            tags: ['feedback', 'growth', 'improvement']
          },
          
          // Soft Skills Questions
          {
            category: 'soft_skill',
            question: 'What is your greatest strength?',
            difficulty: 'easy',
            tags: ['self awareness', 'strengths', 'personal brand']
          },
          {
            category: 'soft_skill',
            question: 'Why do you want to work here?',
            difficulty: 'medium',
            tags: ['company research', 'motivation', 'cultural fit']
          },
          {
            category: 'soft_skill',
            question: 'How do you approach setting professional goals for yourself?',
            difficulty: 'medium',
            tags: ['goal setting', 'career development', 'planning']
          },
          {
            category: 'soft_skill',
            question: 'What motivates you to do your best work?',
            difficulty: 'medium',
            tags: ['motivation', 'work ethic', 'drive']
          },
          {
            category: 'soft_skill',
            question: 'Tell me about a time you asked for help—and how it paid off.',
            difficulty: 'medium',
            tags: ['collaboration', 'humility', 'learning']
          },
          {
            category: 'soft_skill',
            question: 'What\'s a professional risk you took, and what happened?',
            difficulty: 'hard',
            tags: ['risk taking', 'courage', 'growth']
          },
          
          // Remote Work Questions
          {
            category: 'remote_work',
            question: 'How do you motivate yourself when working independently without much oversight?',
            difficulty: 'medium',
            tags: ['self motivation', 'independence', 'remote work']
          },
          
          // Internship Questions
          {
            category: 'internship',
            question: 'What would you do if you were assigned a task you didn\'t know how to complete?',
            difficulty: 'easy',
            tags: ['learning', 'problem solving', 'asking for help']
          },
          {
            category: 'internship',
            question: 'What would you do if you were asked to use a tool or software you\'ve never used before?',
            difficulty: 'easy',
            tags: ['adaptability', 'learning', 'technology']
          },
          {
            category: 'internship',
            question: 'Why do you believe you\'re ready for this opportunity?',
            difficulty: 'medium',
            tags: ['confidence', 'readiness', 'growth']
          },
          {
            category: 'internship',
            question: 'What\'s a project you\'ve worked on that you\'re particularly proud of, and why?',
            difficulty: 'easy',
            tags: ['achievement', 'pride', 'project management']
          },
          
          // Contractor Role Questions
          {
            category: 'contractor_role',
            question: 'How do you handle situations where you and a client have different creative visions?',
            difficulty: 'hard',
            tags: ['client management', 'conflict resolution', 'creativity']
          },
          {
            category: 'contractor_role',
            question: 'How do you maintain quality while working on tight timelines?',
            difficulty: 'hard',
            tags: ['quality management', 'time pressure', 'prioritization']
          },
          {
            category: 'contractor_role',
            question: 'What steps do you take when starting a new contract with an unfamiliar client or industry?',
            difficulty: 'medium',
            tags: ['client onboarding', 'research', 'preparation']
          },
          {
            category: 'contractor_role',
            question: 'How do you handle situations where a client changes direction late in a project?',
            difficulty: 'hard',
            tags: ['change management', 'client communication', 'flexibility']
          },
          {
            category: 'contractor_role',
            question: 'How would you approach learning a completely new industry for a project?',
            difficulty: 'medium',
            tags: ['learning', 'industry research', 'adaptability']
          },
          {
            category: 'contractor_role',
            question: 'How do you scope a project when a client gives you limited information?',
            difficulty: 'hard',
            tags: ['project scoping', 'requirements gathering', 'communication']
          },
          {
            category: 'contractor_role',
            question: 'Describe how you manage deadlines when working with multiple clients.',
            difficulty: 'hard',
            tags: ['time management', 'multiple clients', 'organization']
          },
          {
            category: 'behavioral',
            question: 'Describe a situation where you had to learn a new technology or skill quickly.',
            difficulty: 'medium',
            tags: ['adaptability', 'learning', 'growth mindset']
          },
          {
            category: 'behavioral',
            question: 'Give me an example of a goal you reached and tell me how you achieved it.',
            difficulty: 'easy',
            tags: ['goal setting', 'achievement', 'planning']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you made a mistake. How did you handle it?',
            difficulty: 'hard',
            tags: ['accountability', 'learning from failure', 'problem solving']
          },
          {
            category: 'behavioral',
            question: 'How do you ensure patient confidentiality in your daily work?',
            difficulty: 'easy',
            tags: ['healthcare', 'HIPAA', 'confidentiality', 'ethics']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you had to refactor a complex piece of code.',
            difficulty: 'medium',
            tags: ['technical', 'code quality', 'refactoring']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you took initiative beyond your job description.',
            difficulty: 'medium',
            tags: ['initiative', 'leadership', 'proactive']
          },
          {
            category: 'behavioral',
            question: 'Tell me about a time you motivated a team during a difficult project.',
            difficulty: 'hard',
            tags: ['leadership', 'motivation', 'team management']
          },
          
          // Technical Questions
          {
            category: 'technical',
            question: 'Explain the difference between REST and GraphQL APIs.',
            difficulty: 'medium',
            tags: ['APIs', 'REST', 'GraphQL', 'web development']
          },
          {
            category: 'technical',
            question: 'How would you optimize a slow database query?',
            difficulty: 'hard',
            tags: ['database', 'optimization', 'performance']
          },
          {
            category: 'technical',
            question: 'What is the difference between authentication and authorization?',
            difficulty: 'easy',
            tags: ['security', 'authentication', 'authorization']
          },
          {
            category: 'technical',
            question: 'Describe how you would implement rate limiting in an API.',
            difficulty: 'hard',
            tags: ['API design', 'rate limiting', 'scalability']
          },
          {
            category: 'technical',
            question: 'Walk me through how you would debug a production issue that users are reporting.',
            difficulty: 'medium',
            tags: ['debugging', 'production issues', 'troubleshooting']
          },
          
          // Leadership Questions
          {
            category: 'leadership',
            question: 'Describe a time when you had to motivate a team during a challenging project.',
            difficulty: 'hard',
            tags: ['motivation', 'team leadership', 'project management']
          },
          {
            category: 'leadership',
            question: 'How do you handle disagreements with your manager?',
            difficulty: 'medium',
            tags: ['conflict resolution', 'communication', 'management']
          },
          {
            category: 'leadership',
            question: 'Tell me about a time you had to give difficult feedback to a team member.',
            difficulty: 'hard',
            tags: ['feedback', 'difficult conversations', 'team development']
          },
          {
            category: 'leadership',
            question: 'How do you personally define leadership?',
            difficulty: 'medium',
            tags: ['leadership philosophy', 'personal values', 'management style']
          },
          {
            category: 'leadership',
            question: 'Describe a leadership decision you made that didn\'t go as planned. What did you learn?',
            difficulty: 'hard',
            tags: ['decision making', 'learning from failure', 'leadership']
          },
          
          // Situational Questions
          {
            category: 'situational',
            question: 'How do you prioritize tasks when everything feels urgent?',
            difficulty: 'hard',
            tags: ['prioritization', 'time management', 'stress management']
          },
          {
            category: 'situational',
            question: 'Describe a situation where you had to persuade someone to see your point of view.',
            difficulty: 'medium',
            tags: ['persuasion', 'communication', 'influence']
          },
          {
            category: 'situational',
            question: 'How do you handle difficult questions during a presentation?',
            difficulty: 'hard',
            tags: ['presentation skills', 'communication', 'confidence']
          },
          {
            category: 'situational',
            question: 'Tell me about a time you turned feedback into a breakthrough.',
            difficulty: 'medium',
            tags: ['feedback', 'growth', 'improvement']
          },
          
          // Problem-Solving Questions
          {
            category: 'problem-solving',
            question: 'Walk me through how you would debug a production issue that users are reporting.',
            difficulty: 'medium',
            tags: ['debugging', 'systematic approach', 'troubleshooting']
          },
          {
            category: 'problem-solving',
            question: 'How would you approach building a feature when requirements are unclear?',
            difficulty: 'medium',
            tags: ['requirements gathering', 'stakeholder communication', 'iterative development']
          },
          {
            category: 'problem-solving',
            question: 'Describe a complex problem you solved and your thought process.',
            difficulty: 'hard',
            tags: ['analytical thinking', 'problem solving', 'systematic approach']
          }
        ];

        // Insert all questions into database
        for (const questionData of authenticQuestions) {
          await storage.createQuestion(questionData);
        }
        
        // Fetch questions again after insertion
        questions = await storage.getQuestionsByCategory(category as string);
      }
      
      res.json(questions);
    } catch (error) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });

  app.post('/api/questions/:id/answer', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.isPro && user.credits < 1) {
        return res.status(402).json({ message: "Insufficient credits" });
      }

      const questionId = parseInt(req.params.id);
      const { tone = "professional", resumeContent } = req.body;

      const question = await storage.getQuestion(questionId);
      if (!question) {
        return res.status(404).json({ message: "Question not found" });
      }

      const answer = await openai.generateAnswerForQuestion(question.question, tone, resumeContent);

      const answerData = {
        userId,
        questionId,
        answer,
        tone,
      };

      const userAnswer = await storage.createUserAnswer(answerData);

      // Deduct credit for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 1);
      }

      res.json(userAnswer);
    } catch (error) {
      console.error("Error generating answer:", error);
      res.status(500).json({ message: "Failed to generate answer" });
    }
  });

  // Reflections
  app.post('/api/reflections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reflectionData = insertReflectionSchema.parse({
        ...req.body,
        userId,
      });

      const reflection = await storage.createReflection(reflectionData);
      res.json(reflection);
    } catch (error) {
      console.error("Error creating reflection:", error);
      res.status(500).json({ message: "Failed to create reflection" });
    }
  });

  app.get('/api/reflections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reflections = await storage.getUserReflections(userId);
      res.json(reflections);
    } catch (error) {
      console.error("Error fetching reflections:", error);
      res.status(500).json({ message: "Failed to fetch reflections" });
    }
  });

  // Video Practice Session routes
  app.post('/api/video-practice', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionData = insertVideoPracticeSessionSchema.parse({
        ...req.body,
        userId,
      });

      const session = await storage.createVideoPracticeSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error creating video practice session:", error);
      res.status(500).json({ message: "Failed to create practice session" });
    }
  });

  app.get('/api/video-practice', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessions = await storage.getUserVideoPracticeSessions(userId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching video practice sessions:", error);
      res.status(500).json({ message: "Failed to fetch practice sessions" });
    }
  });

  app.get('/api/video-practice/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = parseInt(req.params.id);
      
      const session = await storage.getVideoPracticeSession(sessionId);
      
      if (!session) {
        return res.status(404).json({ message: "Practice session not found" });
      }
      
      if (session.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(session);
    } catch (error) {
      console.error("Error fetching practice session:", error);
      res.status(500).json({ message: "Failed to fetch practice session" });
    }
  });

  app.put('/api/video-practice/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = parseInt(req.params.id);
      
      const existingSession = await storage.getVideoPracticeSession(sessionId);
      if (!existingSession || existingSession.userId !== userId) {
        return res.status(404).json({ message: "Practice session not found" });
      }

      const session = await storage.updateVideoPracticeSession(sessionId, req.body);
      res.json(session);
    } catch (error) {
      console.error("Error updating practice session:", error);
      res.status(500).json({ message: "Failed to update practice session" });
    }
  });

  app.delete('/api/video-practice/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = parseInt(req.params.id);
      
      const existingSession = await storage.getVideoPracticeSession(sessionId);
      if (!existingSession || existingSession.userId !== userId) {
        return res.status(404).json({ message: "Practice session not found" });
      }

      await storage.deleteVideoPracticeSession(sessionId);
      res.json({ message: "Practice session deleted successfully" });
    } catch (error) {
      console.error("Error deleting practice session:", error);
      res.status(500).json({ message: "Failed to delete practice session" });
    }
  });

  // Video upload and processing
  app.post('/api/video-practice/:id/upload', isAuthenticated, upload.single('video'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = parseInt(req.params.id);
      
      const session = await storage.getVideoPracticeSession(sessionId);
      if (!session || session.userId !== userId) {
        return res.status(404).json({ message: "Practice session not found" });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }

      // For now, we'll simulate video processing
      // In a real implementation, you would:
      // 1. Save the video file to cloud storage (AWS S3, etc.)
      // 2. Use a speech-to-text service to transcribe the audio
      // 3. Generate AI feedback based on the transcription

      const videoUrl = `videos/${sessionId}_${Date.now()}.webm`;
      
      // Update session with video URL and processing status
      await storage.updateVideoPracticeSession(sessionId, {
        videoUrl,
        status: 'processing'
      });

      res.json({ 
        message: "Video uploaded successfully", 
        videoUrl,
        status: 'processing'
      });
    } catch (error) {
      console.error("Error uploading video:", error);
      res.status(500).json({ message: "Failed to upload video" });
    }
  });

  // Manual transcription submission and AI feedback generation
  app.post('/api/video-practice/:id/analyze', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const sessionId = parseInt(req.params.id);
      const { transcription } = req.body;
      
      const session = await storage.getVideoPracticeSession(sessionId);
      if (!session || session.userId !== userId) {
        return res.status(404).json({ message: "Practice session not found" });
      }

      if (!transcription) {
        return res.status(400).json({ message: "Transcription is required for analysis" });
      }

      // Check credits for non-Pro users
      if (!user.isPro && user.credits < 1) {
        return res.status(402).json({ message: "Insufficient credits" });
      }

      // Get the question text
      let questionText = session.customQuestion || "";
      if (session.questionId) {
        const question = await storage.getQuestion(session.questionId);
        questionText = question?.question || "";
      }

      // Update session with transcription
      await storage.updateVideoPracticeSession(sessionId, {
        transcription,
        status: 'completed'
      });

      // Generate AI feedback
      const feedbackResult = await openai.analyzeVideoInterview(
        transcription,
        questionText,
        session.duration || 0
      );

      // Save feedback to database
      const feedbackData = insertVideoFeedbackSchema.parse({
        sessionId,
        ...feedbackResult
      });

      const feedback = await storage.createVideoFeedback(feedbackData);

      // Deduct credit for non-Pro users
      if (!user.isPro) {
        await storage.updateUserCredits(userId, user.credits - 1);
      }

      res.json({
        session: await storage.getVideoPracticeSession(sessionId),
        feedback
      });
    } catch (error) {
      console.error("Error analyzing video:", error);
      res.status(500).json({ message: "Failed to analyze video" });
    }
  });

  // Get feedback for a session
  app.get('/api/video-practice/:id/feedback', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sessionId = parseInt(req.params.id);
      
      const session = await storage.getVideoPracticeSession(sessionId);
      if (!session || session.userId !== userId) {
        return res.status(404).json({ message: "Practice session not found" });
      }

      const feedback = await storage.getVideoFeedbackBySession(sessionId);
      
      if (!feedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }

      res.json(feedback);
    } catch (error) {
      console.error("Error fetching feedback:", error);
      res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  // Create Pro subscription (monthly or quarterly)
  app.post('/api/create-pro-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { billingCycle } = req.body; // 'monthly' or 'quarterly'
      let user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        res.json({
          subscriptionId: subscription.id,
          clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
        });
        return;
      }

      if (!user.email) {
        return res.status(400).json({ message: 'No user email on file' });
      }

      // Create or get customer
      let customer;
      if (user.stripeCustomerId) {
        customer = await stripe.customers.retrieve(user.stripeCustomerId);
      } else {
        customer = await stripe.customers.create({
          email: user.email,
          name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
          metadata: { userId }
        });
        await storage.updateUserStripeCustomerId(userId, customer.id);
      }

      // Set price based on billing cycle - $19/month or $49/quarter
      const priceId = billingCycle === 'quarterly' 
        ? process.env.STRIPE_PRO_QUARTERLY_PRICE_ID
        : process.env.STRIPE_PRO_MONTHLY_PRICE_ID;

      if (!priceId) {
        return res.status(500).json({ 
          error: { message: "Stripe price configuration is missing. Please contact support." } 
        });
      }

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          userId,
          tier: billingCycle === 'quarterly' ? 'pro_quarterly' : 'pro_monthly'
        }
      });

      // Update user subscription info
      await storage.updateUserSubscription(userId, {
        stripeSubscriptionId: subscription.id,
        subscriptionTier: billingCycle === 'quarterly' ? 'pro_quarterly' : 'pro_monthly',
        subscriptionStatus: 'active',
        isPro: true
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating Pro subscription:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Create Career Coach team subscription
  app.post('/api/create-team-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { teamName, teamDescription, initialUsers = 3 } = req.body;
      let user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.email) {
        return res.status(400).json({ message: 'No user email on file' });
      }

      // Create or get customer
      let customer;
      if (user.stripeCustomerId) {
        customer = await stripe.customers.retrieve(user.stripeCustomerId);
      } else {
        customer = await stripe.customers.create({
          email: user.email,
          name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
          metadata: { userId, teamOwner: 'true' }
        });
        await storage.updateUserStripeCustomerId(userId, customer.id);
      }

      // Create team record
      const team = await storage.createTeam({
        name: teamName,
        description: teamDescription,
        ownerId: userId,
        maxUsers: initialUsers,
        currentUsers: 1,
        subscriptionTier: 'career_coach',
        billingCycle: 'quarterly',
        pricePerUser: '39.00'
      });

      // Calculate total amount (minimum 3 users * $39 quarterly)
      const totalAmount = Math.max(initialUsers, 3) * 39 * 3; // Quarterly billing
      
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: process.env.STRIPE_CAREER_COACH_PRICE_ID || 'price_career_coach',
          quantity: Math.max(initialUsers, 3)
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          userId,
          teamId: team.id.toString(),
          tier: 'career_coach',
          initialUsers: initialUsers.toString()
        }
      });

      // Update team with subscription info
      await storage.updateTeamSubscription(team.id, {
        stripeSubscriptionId: subscription.id,
        subscriptionStatus: 'active'
      });

      // Update user as team owner
      await storage.updateUserTeamInfo(userId, {
        teamId: team.id,
        isTeamOwner: true,
        subscriptionTier: 'career_coach',
        subscriptionStatus: 'active',
        isPro: true
      });

      res.json({
        subscriptionId: subscription.id,
        teamId: team.id,
        clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating team subscription:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Legacy endpoint for backward compatibility
  app.post('/api/get-or-create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        res.json({
          subscriptionId: subscription.id,
          clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
        });
        return;
      }

      // Default to monthly Pro subscription for legacy endpoint
      const { body } = req;
      body.billingCycle = 'monthly';
      return app._router.handle({ ...req, body }, res);
    } catch (error: any) {
      console.error("Error with legacy subscription:", error);
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Buy credits (one-time payment)
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    try {
      const { amount, credits } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: req.user.claims.sub,
          credits: credits.toString(),
        },
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Analytics/stats
  app.get('/api/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const [guides, resumes, jobs] = await Promise.all([
        storage.getUserInterviewGuides(userId),
        storage.getUserResumes(userId),
        storage.getUserJobPostings(userId),
      ]);

      const avgAtsScore = resumes.length > 0 
        ? Math.round(resumes.reduce((sum, r) => sum + (r.atsScore || 0), 0) / resumes.length)
        : 0;

      const interviewJobs = jobs.filter(j => j.status === 'interview').length;
      const appliedJobs = jobs.filter(j => j.status === 'applied' || j.status === 'interview').length;
      const successRate = appliedJobs > 0 ? Math.round((interviewJobs / appliedJobs) * 100) : 0;

      res.json({
        totalGuides: guides.length,
        totalResumes: resumes.length,
        totalJobs: jobs.length,
        avgAtsScore,
        successRate,
        beforeScore: 62, // Mock baseline score
        currentScore: avgAtsScore,
      });
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Job Board Integration API Routes
  
  // Get supported job boards
  app.get('/api/job-boards', isAuthenticated, async (req: any, res) => {
    try {
      const supportedBoards = jobBoardService.getSupportedJobBoards();
      res.json(supportedBoards);
    } catch (error: any) {
      console.error("Error fetching supported job boards:", error);
      res.status(500).json({ message: "Failed to fetch supported job boards" });
    }
  });

  // Get user's job board integrations
  app.get('/api/job-board-integrations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrations = await storage.getUserJobBoardIntegrations(userId);
      
      // Remove sensitive data before sending to client
      const sanitizedIntegrations = integrations.map(integration => ({
        ...integration,
        accessToken: undefined,
        refreshToken: undefined,
      }));
      
      res.json(sanitizedIntegrations);
    } catch (error: any) {
      console.error("Error fetching job board integrations:", error);
      res.status(500).json({ message: "Failed to fetch integrations" });
    }
  });

  // Create new job board integration
  app.post('/api/job-board-integrations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { jobBoard, credentials } = req.body;

      if (!jobBoard || !credentials) {
        return res.status(400).json({ message: "Job board and credentials are required" });
      }

      const integration = await jobBoardService.createIntegration(userId, jobBoard, credentials);
      
      // Remove sensitive data before sending to client
      const sanitizedIntegration = {
        ...integration,
        accessToken: undefined,
        refreshToken: undefined,
      };
      
      res.json(sanitizedIntegration);
    } catch (error: any) {
      console.error("Error creating job board integration:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Update job board integration
  app.put('/api/job-board-integrations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrationId = parseInt(req.params.id);
      const updateData = req.body;

      // Verify ownership
      const integration = await storage.getJobBoardIntegration(integrationId);
      if (!integration || integration.userId !== userId) {
        return res.status(404).json({ message: "Integration not found" });
      }

      const updated = await storage.updateJobBoardIntegration(integrationId, updateData);
      
      // Remove sensitive data before sending to client
      const sanitizedIntegration = {
        ...updated,
        accessToken: undefined,
        refreshToken: undefined,
      };
      
      res.json(sanitizedIntegration);
    } catch (error: any) {
      console.error("Error updating job board integration:", error);
      res.status(500).json({ message: "Failed to update integration" });
    }
  });

  // Delete job board integration
  app.delete('/api/job-board-integrations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrationId = parseInt(req.params.id);

      // Verify ownership
      const integration = await storage.getJobBoardIntegration(integrationId);
      if (!integration || integration.userId !== userId) {
        return res.status(404).json({ message: "Integration not found" });
      }

      await storage.deleteJobBoardIntegration(integrationId);
      res.json({ message: "Integration deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting job board integration:", error);
      res.status(500).json({ message: "Failed to delete integration" });
    }
  });

  // Trigger manual sync for an integration
  app.post('/api/job-board-integrations/:id/sync', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrationId = parseInt(req.params.id);

      // Verify ownership
      const integration = await storage.getJobBoardIntegration(integrationId);
      if (!integration || integration.userId !== userId) {
        return res.status(404).json({ message: "Integration not found" });
      }

      // Start sync in background
      jobBoardService.syncApplications(integrationId).catch(error => {
        console.error(`Sync failed for integration ${integrationId}:`, error);
      });

      res.json({ message: "Sync started" });
    } catch (error: any) {
      console.error("Error starting sync:", error);
      res.status(500).json({ message: "Failed to start sync" });
    }
  });

  // Get external applications (job board applications)
  app.get('/api/external-applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getUserExternalApplications(userId);
      res.json(applications);
    } catch (error: any) {
      console.error("Error fetching external applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  // Get application events for an external application
  app.get('/api/external-applications/:id/events', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = parseInt(req.params.id);

      // Verify ownership
      const application = await storage.getExternalApplication(applicationId);
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }

      const events = await storage.getApplicationEvents(applicationId);
      res.json(events);
    } catch (error: any) {
      console.error("Error fetching application events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Update external application (add notes, etc.)
  app.put('/api/external-applications/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationId = parseInt(req.params.id);
      const updateData = req.body;

      // Verify ownership
      const application = await storage.getExternalApplication(applicationId);
      if (!application || application.userId !== userId) {
        return res.status(404).json({ message: "Application not found" });
      }

      const updated = await storage.updateExternalApplication(applicationId, updateData);
      res.json(updated);
    } catch (error: any) {
      console.error("Error updating external application:", error);
      res.status(500).json({ message: "Failed to update application" });
    }
  });

  // Manual CSV import for job applications
  app.post('/api/external-applications/import', isAuthenticated, upload.single('csvFile'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      if (!req.file) {
        return res.status(400).json({ message: "CSV file is required" });
      }

      const csvContent = req.file.buffer.toString('utf-8');
      const lines = csvContent.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        return res.status(400).json({ message: "CSV must contain headers and at least one data row" });
      }

      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      const requiredHeaders = ['job_title', 'company', 'application_status', 'applied_at'];
      
      const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
      if (missingHeaders.length > 0) {
        return res.status(400).json({ 
          message: `Missing required headers: ${missingHeaders.join(', ')}. Required: ${requiredHeaders.join(', ')}` 
        });
      }

      const importedApplications = [];
      const errors = [];

      for (let i = 1; i < lines.length; i++) {
        try {
          const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
          const rowData: any = {};
          
          headers.forEach((header, index) => {
            rowData[header] = values[index] || '';
          });

          // Validate required fields
          if (!rowData.job_title || !rowData.company || !rowData.application_status || !rowData.applied_at) {
            errors.push(`Row ${i + 1}: Missing required fields`);
            continue;
          }

          // Parse date
          const appliedDate = new Date(rowData.applied_at);
          if (isNaN(appliedDate.getTime())) {
            errors.push(`Row ${i + 1}: Invalid date format for applied_at`);
            continue;
          }

          const applicationData = {
            userId,
            integrationId: null,
            externalId: rowData.external_id || `manual-${Date.now()}-${i}`,
            jobBoard: 'manual_import',
            jobTitle: rowData.job_title,
            company: rowData.company,
            location: rowData.location || null,
            jobUrl: rowData.job_url || null,
            description: rowData.description || null,
            requirements: rowData.requirements || null,
            salaryRange: rowData.salary_range || null,
            jobType: rowData.job_type || null,
            applicationStatus: rowData.application_status.toLowerCase(),
            appliedAt: appliedDate,
            lastUpdatedAt: rowData.last_updated_at ? new Date(rowData.last_updated_at) : appliedDate,
            resumeUsed: rowData.resume_used || null,
            coverLetter: rowData.cover_letter || null,
            notes: rowData.notes || null,
            rawData: rowData,
            syncedAt: new Date(),
          };

          const application = await storage.createExternalApplication(applicationData);
          
          // Create import event
          await storage.createApplicationEvent({
            applicationId: application.id,
            eventType: 'application_imported',
            eventData: { source: 'csv_import', row: i + 1 },
            eventDate: appliedDate,
            description: 'Application imported from CSV',
            isAutomated: false,
          });

          importedApplications.push(application);
        } catch (error: any) {
          errors.push(`Row ${i + 1}: ${error.message}`);
        }
      }

      res.json({
        imported: importedApplications.length,
        errors: errors.length,
        errorDetails: errors,
        applications: importedApplications
      });

    } catch (error: any) {
      console.error("CSV import error:", error);
      res.status(500).json({ message: "Failed to import CSV: " + error.message });
    }
  });

  // Email parsing for job applications
  app.post('/api/external-applications/parse-email', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { subject, body, sender, receivedAt } = req.body;

      if (!subject || !body || !sender) {
        return res.status(400).json({ message: "Email subject, body, and sender are required" });
      }

      const { emailService } = await import('./emailService');
      const parseResult = await emailService.parseJobApplicationEmail(
        subject,
        body,
        sender,
        new Date(receivedAt || Date.now())
      );

      if (parseResult.isJobRelated && parseResult.data) {
        // Create application from parsed email data
        const applicationData = {
          userId,
          integrationId: null,
          externalId: `email-${Date.now()}-${Math.random().toString(36).substring(7)}`,
          jobBoard: 'email_import',
          jobTitle: parseResult.data.jobTitle || 'Unknown Position',
          company: parseResult.data.company || 'Unknown Company',
          location: parseResult.data.location || null,
          jobUrl: parseResult.data.jobUrl || null,
          description: null,
          requirements: null,
          salaryRange: parseResult.data.salaryRange || null,
          jobType: parseResult.data.jobType || null,
          applicationStatus: parseResult.data.applicationStatus,
          appliedAt: parseResult.data.appliedAt,
          lastUpdatedAt: parseResult.data.appliedAt,
          resumeUsed: null,
          coverLetter: null,
          notes: `Imported from email. Confidence: ${parseResult.confidence}%`,
          rawData: { emailSubject: subject, emailSender: sender, parseResult },
          syncedAt: new Date(),
        };

        const application = await storage.createExternalApplication(applicationData);
        
        // Create import event
        await storage.createApplicationEvent({
          applicationId: application.id,
          eventType: 'email_import',
          eventData: { 
            confidence: parseResult.confidence,
            emailSubject: subject,
            emailSender: sender 
          },
          eventDate: parseResult.data.appliedAt,
          description: `Application imported from email with ${parseResult.confidence}% confidence`,
          isAutomated: true,
        });

        res.json({
          success: true,
          application,
          confidence: parseResult.confidence,
          reasoning: parseResult.reasoning
        });
      } else {
        res.json({
          success: false,
          isJobRelated: parseResult.isJobRelated,
          confidence: parseResult.confidence,
          reasoning: parseResult.reasoning
        });
      }

    } catch (error: any) {
      console.error("Email parsing error:", error);
      res.status(500).json({ message: "Failed to parse email: " + error.message });
    }
  });

  // Career path visualization routes
  app.get('/api/career-paths', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let careerPaths = await storage.getUserCareerPaths(userId);
      
      // Create sample career path if none exist
      if (careerPaths.length === 0) {
        const samplePath = await storage.createCareerPath({
          userId,
          title: "Software Engineering Career Path",
          description: "A comprehensive career progression from junior developer to senior engineering leadership",
          industry: "technology",
          isPublic: false,
          isTemplate: false
        });
        
        // Create sample nodes
        const juniorNode = await storage.createCareerPathNode({
          pathId: samplePath.id,
          title: "Junior Developer",
          description: "Entry-level position focused on learning fundamentals",
          level: "entry",
          salaryRange: "$50K-70K",
          requiredSkills: ["JavaScript", "HTML", "CSS", "Git"],
          timeToReach: 0,
          positionX: 100,
          positionY: 100,
          nodeType: "position",
          isCompleted: true,
          completedAt: new Date()
        });
        
        const seniorNode = await storage.createCareerPathNode({
          pathId: samplePath.id,
          title: "Senior Developer",
          description: "Experienced developer with technical leadership responsibilities",
          level: "senior",
          salaryRange: "$90K-130K",
          requiredSkills: ["React", "Node.js", "System Design", "Mentoring"],
          timeToReach: 36,
          positionX: 300,
          positionY: 100,
          nodeType: "position",
          isCompleted: false
        });
        
        const leadNode = await storage.createCareerPathNode({
          pathId: samplePath.id,
          title: "Tech Lead",
          description: "Technical leadership role guiding team architecture decisions",
          level: "senior",
          salaryRange: "$120K-160K",
          requiredSkills: ["Architecture", "Team Leadership", "Project Management"],
          timeToReach: 60,
          positionX: 500,
          positionY: 100,
          nodeType: "milestone",
          isCompleted: false
        });
        
        // Create connections
        await storage.createCareerPathConnection({
          pathId: samplePath.id,
          fromNodeId: juniorNode.id,
          toNodeId: seniorNode.id,
          connectionType: "progression",
          description: "Typical career advancement after gaining experience",
          probability: 85
        });
        
        await storage.createCareerPathConnection({
          pathId: samplePath.id,
          fromNodeId: seniorNode.id,
          toNodeId: leadNode.id,
          connectionType: "progression",
          description: "Leadership track progression",
          probability: 60
        });
        
        careerPaths = [samplePath];
      }
      
      res.json(careerPaths);
    } catch (error: any) {
      console.error("Failed to fetch career paths:", error);
      res.status(500).json({ message: "Failed to fetch career paths" });
    }
  });

  app.post('/api/career-paths', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const careerPath = await storage.createCareerPath({
        ...req.body,
        userId
      });
      res.json(careerPath);
    } catch (error: any) {
      console.error("Failed to create career path:", error);
      res.status(500).json({ message: "Failed to create career path" });
    }
  });

  app.get('/api/career-paths/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const careerPath = await storage.getCareerPath(id);
      
      if (!careerPath) {
        return res.status(404).json({ message: "Career path not found" });
      }
      
      res.json(careerPath);
    } catch (error: any) {
      console.error("Failed to fetch career path:", error);
      res.status(500).json({ message: "Failed to fetch career path" });
    }
  });

  app.get('/api/career-paths/:id/nodes', isAuthenticated, async (req: any, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const nodes = await storage.getCareerPathNodes(pathId);
      res.json(nodes);
    } catch (error: any) {
      console.error("Failed to fetch career path nodes:", error);
      res.status(500).json({ message: "Failed to fetch career path nodes" });
    }
  });

  app.get('/api/career-paths/:id/connections', isAuthenticated, async (req: any, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const connections = await storage.getCareerPathConnections(pathId);
      res.json(connections);
    } catch (error: any) {
      console.error("Failed to fetch career path connections:", error);
      res.status(500).json({ message: "Failed to fetch career path connections" });
    }
  });

  app.get('/api/industry-trends/:industry', isAuthenticated, async (req: any, res) => {
    try {
      const industry = req.params.industry;
      const metric = req.query.metric;
      let trends = await storage.getIndustryTrends(industry, metric);
      
      // Create sample trends if none exist for technology industry
      if (trends.length === 0 && industry === 'technology') {
        const sampleTrends = [
          {
            industry: 'technology',
            position: 'Software Engineer',
            metric: 'salary',
            value: "95000",
            period: '2024',
            source: 'Market Research',
            lastUpdated: new Date(),
            metadata: { experience_level: 'mid', location: 'US' }
          },
          {
            industry: 'technology',
            position: 'Senior Software Engineer',
            metric: 'salary',
            value: "130000",
            period: '2024',
            source: 'Market Research',
            lastUpdated: new Date(),
            metadata: { experience_level: 'senior', location: 'US' }
          },
          {
            industry: 'technology',
            position: 'Tech Lead',
            metric: 'salary',
            value: "155000",
            period: '2024',
            source: 'Market Research',
            lastUpdated: new Date(),
            metadata: { experience_level: 'lead', location: 'US' }
          },
          {
            industry: 'technology',
            position: 'Software Engineer',
            metric: 'demand',
            value: "85.2",
            period: '2024',
            source: 'Job Market Analytics',
            lastUpdated: new Date(),
            metadata: { growth_trend: 'increasing' }
          },
          {
            industry: 'technology',
            position: 'Software Engineer',
            metric: 'growth_rate',
            value: "12.5",
            period: '2024-2025',
            source: 'Bureau of Labor Statistics',
            lastUpdated: new Date(),
            metadata: { projection_period: '10_year' }
          }
        ];
        
        for (const trendData of sampleTrends) {
          await storage.createIndustryTrend(trendData);
        }
        
        trends = await storage.getIndustryTrends(industry, metric);
      }
      
      res.json(trends);
    } catch (error: any) {
      console.error("Failed to fetch industry trends:", error);
      res.status(500).json({ message: "Failed to fetch industry trends" });
    }
  });

  app.get('/api/career-path-templates', isAuthenticated, async (req: any, res) => {
    try {
      const industry = req.query.industry;
      const templates = await storage.getCareerPathTemplates(industry);
      res.json(templates);
    } catch (error: any) {
      console.error("Failed to fetch career path templates:", error);
      res.status(500).json({ message: "Failed to fetch career path templates" });
    }
  });

  // OAuth callback for LinkedIn
  app.get('/api/auth/linkedin/callback', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { code, state } = req.query;

      if (!code) {
        return res.status(400).json({ message: "Authorization code required" });
      }

      const credentials = {
        code: code as string,
        redirectUri: `${req.protocol}://${req.get('host')}/api/auth/linkedin/callback`,
      };

      const integration = await jobBoardService.createIntegration(userId, 'linkedin', credentials);
      
      // Redirect to frontend with success
      res.redirect(`${req.protocol}://${req.get('host')}/?integration=success`);
    } catch (error: any) {
      console.error("LinkedIn OAuth callback error:", error);
      res.redirect(`${req.protocol}://${req.get('host')}/?integration=error&message=${encodeURIComponent(error.message)}`);
    }
  });

  // Admin Question Management Routes
  app.get('/api/admin/questions', isAuthenticated, async (req: any, res) => {
    try {
      const questions = await storage.getAllQuestions();
      res.json(questions);
    } catch (error: any) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });

  app.post('/api/admin/questions', isAuthenticated, async (req: any, res) => {
    try {
      const questionData = insertQuestionSchema.parse(req.body);
      const question = await storage.createQuestion(questionData);
      res.json(question);
    } catch (error: any) {
      console.error("Error creating question:", error);
      res.status(500).json({ message: "Failed to create question" });
    }
  });

  app.patch('/api/admin/questions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      const question = await storage.updateQuestion(id, updateData);
      res.json(question);
    } catch (error: any) {
      console.error("Error updating question:", error);
      res.status(500).json({ message: "Failed to update question" });
    }
  });

  app.delete('/api/admin/questions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteQuestion(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting question:", error);
      res.status(500).json({ message: "Failed to delete question" });
    }
  });

  app.post('/api/admin/questions/bulk', isAuthenticated, async (req: any, res) => {
    try {
      const { questions } = req.body;
      const results = [];
      
      for (const questionData of questions) {
        try {
          const validatedData = insertQuestionSchema.parse(questionData);
          const question = await storage.createQuestion(validatedData);
          results.push(question);
        } catch (error) {
          console.error("Error creating bulk question:", error);
        }
      }
      
      res.json({ created: results.length, questions: results });
    } catch (error: any) {
      console.error("Error bulk creating questions:", error);
      res.status(500).json({ message: "Failed to bulk create questions" });
    }
  });

  app.get('/api/questions/categories', async (req, res) => {
    try {
      const categories = await storage.getQuestionCategories();
      res.json(categories);
    } catch (error: any) {
      console.error("Error fetching question categories:", error);
      res.status(500).json({ message: "Failed to fetch question categories" });
    }
  });

  // Resume Import API Endpoints for External Services
  app.post('/api/resume/import/external', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { resumeData, source, apiKey } = req.body;

      if (!resumeData) {
        return res.status(400).json({ message: "Resume data is required" });
      }

      // Validate the import source and API key
      const isValidSource = await storage.validateResumeImportSource(apiKey, source);
      if (!isValidSource) {
        return res.status(401).json({ message: "Invalid API key or source" });
      }

      // Import the resume
      const importedResume = await storage.importResumeFromExternal(userId, {
        ...resumeData,
        source: source || 'resumeformatter.io'
      });

      res.json({
        success: true,
        resume: importedResume,
        message: "Resume imported successfully"
      });
    } catch (error: any) {
      console.error("Error importing resume:", error);
      res.status(500).json({ message: "Failed to import resume" });
    }
  });

  app.post('/api/resume/import/resumeformatter', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { resumeformatterData, apiKey } = req.body;

      if (!resumeformatterData) {
        return res.status(400).json({ message: "ResumeFormatter data is required" });
      }

      if (!apiKey) {
        return res.status(400).json({ 
          message: "API key required for ResumeFormatter.io integration. Please provide your ResumeFormatter API key." 
        });
      }

      // Transform ResumeFormatter data to our format
      const transformedData = {
        fileName: resumeformatterData.filename || 'ResumeFormatter Import',
        content: resumeformatterData.formatted_content || resumeformatterData.content,
        extractedText: resumeformatterData.extracted_text || resumeformatterData.content,
        skills: resumeformatterData.skills || [],
        experience: resumeformatterData.work_experience || [],
        education: resumeformatterData.education || [],
        summary: resumeformatterData.summary || null,
        atsScore: resumeformatterData.ats_score || null,
        suggestions: resumeformatterData.improvement_suggestions || [],
        source: 'resumeformatter.io'
      };

      const importedResume = await storage.importResumeFromExternal(userId, transformedData);

      res.json({
        success: true,
        resume: importedResume,
        message: "Resume imported from ResumeFormatter.io successfully"
      });
    } catch (error: any) {
      console.error("Error importing from ResumeFormatter:", error);
      res.status(500).json({ message: "Failed to import from ResumeFormatter.io" });
    }
  });

  app.get('/api/resume/import/status/:resumeId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeId = parseInt(req.params.resumeId);

      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      res.json({
        id: resume.id,
        fileName: resume.fileName,
        source: resume.source,
        uploadedAt: resume.uploadedAt,
        atsScore: resume.atsScore,
        status: 'imported'
      });
    } catch (error: any) {
      console.error("Error fetching import status:", error);
      res.status(500).json({ message: "Failed to fetch import status" });
    }
  });

  app.post('/api/resume/import/validate-key', isAuthenticated, async (req, res) => {
    try {
      const { apiKey, source } = req.body;

      if (!apiKey || !source) {
        return res.status(400).json({ message: "API key and source are required" });
      }

      const isValid = await storage.validateResumeImportSource(apiKey, source);
      
      res.json({
        valid: isValid,
        source,
        message: isValid ? "API key is valid" : "Invalid API key"
      });
    } catch (error: any) {
      console.error("Error validating API key:", error);
      res.status(500).json({ message: "Failed to validate API key" });
    }
  });

  app.get('/api/resume/import/sources', isAuthenticated, async (req, res) => {
    try {
      const supportedSources = [
        {
          id: 'resumeformatter.io',
          name: 'ResumeFormatter.io',
          description: 'Import professionally formatted resumes with ATS optimization',
          requiresApiKey: true,
          endpoint: '/api/resume/import/resumeformatter'
        },
        {
          id: 'external',
          name: 'External Source',
          description: 'Import from any external resume service with API integration',
          requiresApiKey: true,
          endpoint: '/api/resume/import/external'
        }
      ];

      res.json(supportedSources);
    } catch (error: any) {
      console.error("Error fetching import sources:", error);
      res.status(500).json({ message: "Failed to fetch import sources" });
    }
  });

  // AI Fine-tuning routes for industry-specific content - Pro feature
  app.get('/api/ai/industries', async (req, res) => {
    try {
      const industries = aiFineTuningService.getSupportedIndustries();
      res.json(industries);
    } catch (error) {
      console.error("Error fetching industries:", error);
      res.status(500).json({ message: "Failed to fetch industries" });
    }
  });

  app.post('/api/ai/generate-industry-questions', isAuthenticated, requiresPro, async (req, res) => {
    try {
      const { industry, jobRole, count = 10 } = req.body;

      if (!industry || !jobRole) {
        return res.status(400).json({ message: "Industry and job role are required" });
      }

      const questions = await aiFineTuningService.generateIndustryQuestions(
        industry,
        jobRole,
        count
      );

      res.json({ questions });
    } catch (error) {
      console.error("Error generating industry questions:", error);
      res.status(500).json({ message: "Failed to generate industry-specific questions" });
    }
  });

  app.post('/api/ai/optimize-answer', isAuthenticated, requiresPro, async (req, res) => {
    try {
      const { question, answer, industry, jobRole } = req.body;

      if (!question || !answer || !industry || !jobRole) {
        return res.status(400).json({ message: "Question, answer, industry, and job role are required" });
      }

      const optimizedResult = await aiFineTuningService.optimizeAnswerForIndustry(
        question,
        answer,
        industry,
        jobRole
      );

      res.json(optimizedResult);
    } catch (error) {
      console.error("Error optimizing answer:", error);
      res.status(500).json({ message: "Failed to optimize answer for industry" });
    }
  });

  app.get('/api/ai/industry-metrics/:industry', isAuthenticated, async (req, res) => {
    try {
      const { industry } = req.params;
      const metrics = await aiFineTuningService.getIndustryMetrics(industry);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching industry metrics:", error);
      res.status(500).json({ message: "Failed to fetch industry metrics" });
    }
  });

  app.post('/api/ai/create-fine-tuned-model', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isPro) {
        return res.status(403).json({ message: "Fine-tuning requires Pro subscription" });
      }

      const { industry } = req.body;

      if (!industry) {
        return res.status(400).json({ message: "Industry is required" });
      }

      const jobId = await aiFineTuningService.createFineTunedModel(industry);
      res.json({ jobId, message: "Fine-tuning job started" });
    } catch (error) {
      console.error("Error creating fine-tuned model:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to create fine-tuned model" });
    }
  });

  app.post('/api/ai/add-training-example', isAuthenticated, requiresPro, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isPro) {
        return res.status(403).json({ message: "Adding training examples requires Pro subscription" });
      }

      const { industry, prompt, completion, category } = req.body;

      if (!industry || !prompt || !completion || !category) {
        return res.status(400).json({ message: "Industry, prompt, completion, and category are required" });
      }

      await aiFineTuningService.addTrainingExample({
        industry,
        prompt,
        completion,
        category
      });

      res.json({ message: "Training example added successfully" });
    } catch (error) {
      console.error("Error adding training example:", error);
      res.status(500).json({ message: "Failed to add training example" });
    }
  });

  // AI Fine-Tuning routes
  app.get('/api/ai/industries', async (req, res) => {
    try {
      const industries = aiFineTuningService.getSupportedIndustries();
      res.json(industries);
    } catch (error) {
      console.error("Error fetching industries:", error);
      res.status(500).json({ message: "Failed to fetch industries" });
    }
  });

  app.get('/api/ai/industry-metrics/:industry', isAuthenticated, async (req, res) => {
    try {
      const { industry } = req.params;
      const metrics = await aiFineTuningService.getIndustryMetrics(industry);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching industry metrics:", error);
      res.status(500).json({ message: "Failed to fetch industry metrics" });
    }
  });

  app.post('/api/ai/generate-industry-questions', async (req, res) => {
    try {
      const { industry, jobRole, count } = req.body;
      const questions = await aiFineTuningService.generateIndustryQuestions(
        industry,
        jobRole,
        count || 10
      );
      res.json({ questions });
    } catch (error) {
      console.error("Error generating questions:", error);
      res.status(500).json({ message: "Failed to generate questions" });
    }
  });

  app.post('/api/ai/optimize-answer', async (req, res) => {
    try {
      const { question, answer, industry, jobRole } = req.body;
      const result = await aiFineTuningService.optimizeAnswerForIndustry(
        question,
        answer,
        industry,
        jobRole
      );
      res.json(result);
    } catch (error) {
      console.error("Error optimizing answer:", error);
      res.status(500).json({ message: "Failed to optimize answer" });
    }
  });

  app.post('/api/ai/create-fine-tuned-model', isAuthenticated, async (req, res) => {
    try {
      const { industry } = req.body;
      const jobId = await aiFineTuningService.createFineTunedModel(industry);
      res.json({ jobId });
    } catch (error) {
      console.error("Error creating fine-tuned model:", error);
      res.status(500).json({ message: "Failed to create fine-tuned model" });
    }
  });

  // Career mood board routes
  app.get('/api/mood-entries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moodEntries = await storage.getUserMoodEntries(userId);
      res.json(moodEntries);
    } catch (error) {
      console.error("Error fetching mood entries:", error);
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.post('/api/mood-entries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moodData = { ...req.body, userId };
      
      const moodEntry = await storage.createMoodEntry(moodData);
      res.status(201).json(moodEntry);
    } catch (error) {
      console.error("Error creating mood entry:", error);
      res.status(500).json({ message: "Failed to create mood entry" });
    }
  });

  app.get('/api/mood-entries/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entryId = parseInt(req.params.id);
      
      const moodEntry = await storage.getMoodEntry(entryId, userId);
      if (!moodEntry) {
        return res.status(404).json({ message: "Mood entry not found" });
      }
      
      res.json(moodEntry);
    } catch (error) {
      console.error("Error fetching mood entry:", error);
      res.status(500).json({ message: "Failed to fetch mood entry" });
    }
  });

  app.put('/api/mood-entries/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entryId = parseInt(req.params.id);
      
      const moodEntry = await storage.updateMoodEntry(entryId, userId, req.body);
      res.json(moodEntry);
    } catch (error) {
      console.error("Error updating mood entry:", error);
      res.status(500).json({ message: "Failed to update mood entry" });
    }
  });

  app.delete('/api/mood-entries/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const entryId = parseInt(req.params.id);
      
      await storage.deleteMoodEntry(entryId, userId);
      res.json({ message: "Mood entry deleted successfully" });
    } catch (error) {
      console.error("Error deleting mood entry:", error);
      res.status(500).json({ message: "Failed to delete mood entry" });
    }
  });

  app.get('/api/mood-board-templates', isAuthenticated, async (req: any, res) => {
    try {
      const templates = await storage.getMoodBoardTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching mood board templates:", error);
      res.status(500).json({ message: "Failed to fetch mood board templates" });
    }
  });

  app.post('/api/mood-board-templates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const templateData = { ...req.body, createdBy: userId };
      
      const template = await storage.createMoodBoardTemplate(templateData);
      res.status(201).json(template);
    } catch (error) {
      console.error("Error creating mood board template:", error);
      res.status(500).json({ message: "Failed to create mood board template" });
    }
  });

  // Beehiiv Newsletter Integration
  app.post('/api/beehiiv/subscribe', async (req, res) => {
    try {
      const { email, firstName, source } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }

      // Beehiiv API integration using their subscription endpoint
      const beehiivData = {
        email,
        reactivate_existing: false,
        send_welcome_email: true,
        utm_source: source || 'website',
        utm_medium: 'newsletter_signup',
        utm_campaign: 'job_jumpstart',
        referring_site: 'preppair.me'
      };

      const beehiivResponse = await fetch(`${process.env.BEEHIIV_API_URL}/publications/${process.env.BEEHIIV_PUBLICATION_ID}/subscriptions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.BEEHIIV_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(beehiivData),
      });

      if (!beehiivResponse.ok) {
        const errorData = await beehiivResponse.text();
        console.error('Beehiiv subscription error:', errorData);
        return res.status(500).json({ message: 'Newsletter subscription failed' });
      }

      const result = await beehiivResponse.json();
      
      // Log subscription for analytics
      console.log(`Newsletter subscription: ${email} from ${source}`);
      
      res.json({ 
        success: true, 
        message: 'Successfully subscribed to The Job Jumpstart newsletter',
        subscription_id: result.data?.id 
      });
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // KNOWLEDGE BASE AND SUPPORT SYSTEM API FOR WRELIK.COM UNIFIED SUPPORT DESK
  
  // ===========================================
  // KNOWLEDGE BASE CATEGORIES API
  // ===========================================
  
  // Get all knowledge base categories (public endpoint for Wrelik.com)
  app.get('/api/knowledge/categories', async (req, res) => {
    try {
      const { parent_id, include_inactive } = req.query;
      const categories = await storage.getKnowledgeCategories({
        parentId: parent_id ? parseInt(parent_id as string) : undefined,
        includeInactive: include_inactive === 'true'
      });
      res.json(categories);
    } catch (error) {
      console.error("Error fetching knowledge categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Create knowledge base category (admin only)
  app.post('/api/knowledge/categories', requiresAdmin, async (req: any, res) => {
    try {
      const categoryData = req.body;
      const category = await storage.createKnowledgeCategory({
        ...categoryData,
        slug: categoryData.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
      });
      res.status(201).json(category);
    } catch (error) {
      console.error("Error creating knowledge category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Update knowledge base category (admin only)
  app.put('/api/knowledge/categories/:id', requiresAdmin, async (req: any, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const updateData = req.body;
      const category = await storage.updateKnowledgeCategory(categoryId, updateData);
      res.json(category);
    } catch (error) {
      console.error("Error updating knowledge category:", error);
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  // ===========================================
  // KNOWLEDGE BASE ARTICLES API
  // ===========================================

  // Get published articles with search and filtering (public endpoint for Wrelik.com)
  app.get('/api/knowledge/articles', async (req, res) => {
    try {
      const { 
        category_id, 
        search, 
        status = 'published', 
        limit = 50, 
        offset = 0,
        tags 
      } = req.query;

      const articles = await storage.getKnowledgeArticles({
        categoryId: category_id ? parseInt(category_id as string) : undefined,
        search: search as string,
        status: status as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
        tags: tags ? (tags as string).split(',') : undefined
      });
      
      res.json(articles);
    } catch (error) {
      console.error("Error fetching knowledge articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  // Get single article by slug (public endpoint)
  app.get('/api/knowledge/articles/:slug', async (req, res) => {
    try {
      const { slug } = req.params;
      const article = await storage.getKnowledgeArticleBySlug(slug);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }

      // Increment view count
      await storage.incrementArticleViewCount(article.id);
      
      res.json(article);
    } catch (error) {
      console.error("Error fetching knowledge article:", error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  // Create knowledge base article (admin only)
  app.post('/api/knowledge/articles', requiresAdmin, async (req: any, res) => {
    try {
      const articleData = req.body;
      const article = await storage.createKnowledgeArticle({
        ...articleData,
        authorId: req.user.claims.sub,
        slug: articleData.title.toLowerCase()
          .replace(/\s+/g, '-')
          .replace(/[^a-z0-9-]/g, '')
          .substring(0, 100),
        publishedAt: articleData.status === 'published' ? new Date() : null
      });
      res.status(201).json(article);
    } catch (error) {
      console.error("Error creating knowledge article:", error);
      res.status(500).json({ message: "Failed to create article" });
    }
  });

  // Update knowledge base article (admin only)
  app.put('/api/knowledge/articles/:id', requiresAdmin, async (req: any, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const updateData = req.body;
      
      // Update publishedAt if status changed to published
      if (updateData.status === 'published' && !updateData.publishedAt) {
        updateData.publishedAt = new Date();
      }
      
      const article = await storage.updateKnowledgeArticle(articleId, updateData);
      res.json(article);
    } catch (error) {
      console.error("Error updating knowledge article:", error);
      res.status(500).json({ message: "Failed to update article" });
    }
  });

  // ===========================================
  // FAQ ITEMS API
  // ===========================================

  // Get FAQ items (public endpoint for Wrelik.com)
  app.get('/api/knowledge/faqs', async (req, res) => {
    try {
      const { category_id, search, limit = 50 } = req.query;
      const faqs = await storage.getFaqItems({
        categoryId: category_id ? parseInt(category_id as string) : undefined,
        search: search as string,
        limit: parseInt(limit as string)
      });
      res.json(faqs);
    } catch (error) {
      console.error("Error fetching FAQ items:", error);
      res.status(500).json({ message: "Failed to fetch FAQs" });
    }
  });

  // Create FAQ item (admin only)
  app.post('/api/knowledge/faqs', requiresAdmin, async (req: any, res) => {
    try {
      const faqData = req.body;
      const faq = await storage.createFaqItem(faqData);
      res.status(201).json(faq);
    } catch (error) {
      console.error("Error creating FAQ item:", error);
      res.status(500).json({ message: "Failed to create FAQ" });
    }
  });

  // Update FAQ item (admin only)
  app.put('/api/knowledge/faqs/:id', requiresAdmin, async (req: any, res) => {
    try {
      const faqId = parseInt(req.params.id);
      const updateData = req.body;
      const faq = await storage.updateFaqItem(faqId, updateData);
      res.json(faq);
    } catch (error) {
      console.error("Error updating FAQ item:", error);
      res.status(500).json({ message: "Failed to update FAQ" });
    }
  });

  // ===========================================
  // SUPPORT TICKETS API
  // ===========================================

  // Get support tickets (admin view with filters)
  app.get('/api/support/tickets', requiresAdmin, async (req: any, res) => {
    try {
      const {
        status,
        priority,
        assigned_to,
        category_id,
        customer_email,
        limit = 50,
        offset = 0,
        sort_by = 'created_at',
        sort_order = 'desc'
      } = req.query;

      const tickets = await storage.getSupportTickets({
        status: status as string,
        priority: priority as string,
        assignedTo: assigned_to as string,
        categoryId: category_id ? parseInt(category_id as string) : undefined,
        customerEmail: customer_email as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
        sortBy: sort_by as string,
        sortOrder: sort_order as string
      });

      res.json(tickets);
    } catch (error) {
      console.error("Error fetching support tickets:", error);
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  // Get single support ticket with messages (admin only)
  app.get('/api/support/tickets/:id', requiresAdmin, async (req: any, res) => {
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getSupportTicketWithMessages(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      res.json(ticket);
    } catch (error) {
      console.error("Error fetching support ticket:", error);
      res.status(500).json({ message: "Failed to fetch ticket" });
    }
  });

  // Create support ticket (public endpoint for Wrelik.com customers)
  app.post('/api/support/tickets', async (req, res) => {
    try {
      const ticketData = req.body;
      
      // Generate unique ticket number
      const ticketNumber = `WK-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
      
      const ticket = await storage.createSupportTicket({
        ...ticketData,
        ticketNumber,
        source: 'web',
        metadata: {
          userAgent: req.headers['user-agent'],
          ip: req.ip,
          referer: req.headers.referer
        }
      });

      // Send initial auto-response
      await storage.createSupportTicketMessage({
        ticketId: ticket.id,
        senderEmail: 'support@wrelik.com',
        senderName: 'Wrelik Support',
        message: `Thank you for contacting Wrelik support. Your ticket ${ticketNumber} has been received and will be reviewed by our team. We'll respond within 24 hours.`,
        isInternal: false,
        messageType: 'message'
      });

      res.status(201).json(ticket);
    } catch (error) {
      console.error("Error creating support ticket:", error);
      res.status(500).json({ message: "Failed to create ticket" });
    }
  });

  // Update support ticket (admin only)
  app.put('/api/support/tickets/:id', requiresAdmin, async (req: any, res) => {
    try {
      const ticketId = parseInt(req.params.id);
      const updateData = req.body;
      
      // Update resolution timestamp if status changed to resolved
      if (updateData.status === 'resolved' && !updateData.resolvedAt) {
        updateData.resolvedAt = new Date();
      }
      
      const ticket = await storage.updateSupportTicket(ticketId, updateData);
      res.json(ticket);
    } catch (error) {
      console.error("Error updating support ticket:", error);
      res.status(500).json({ message: "Failed to update ticket" });
    }
  });

  // ===========================================
  // SUPPORT TICKET MESSAGES API
  // ===========================================

  // Add message to support ticket
  app.post('/api/support/tickets/:id/messages', async (req, res) => {
    try {
      const ticketId = parseInt(req.params.id);
      const messageData = req.body;
      
      const message = await storage.createSupportTicketMessage({
        ...messageData,
        ticketId
      });

      // Update ticket last activity
      await storage.updateTicketLastActivity(ticketId);
      
      // Set first response time if this is the first non-automated response
      if (!messageData.isInternal && messageData.senderId) {
        await storage.setFirstResponseTime(ticketId);
      }

      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating ticket message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // ===========================================
  // KNOWLEDGE BASE FEEDBACK API
  // ===========================================

  // Submit feedback for article or FAQ (public endpoint)
  app.post('/api/knowledge/feedback', async (req, res) => {
    try {
      const feedbackData = req.body;
      const feedback = await storage.createKnowledgeBaseFeedback({
        ...feedbackData,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent']
      });

      // Update helpful counts on the article/FAQ
      if (feedbackData.articleId) {
        await storage.updateArticleHelpfulness(feedbackData.articleId, feedbackData.isHelpful);
      } else if (feedbackData.faqId) {
        await storage.updateFaqHelpfulness(feedbackData.faqId, feedbackData.isHelpful);
      }

      res.status(201).json(feedback);
    } catch (error) {
      console.error("Error creating knowledge base feedback:", error);
      res.status(500).json({ message: "Failed to submit feedback" });
    }
  });

  // ===========================================
  // SUPPORT ANALYTICS API
  // ===========================================

  // Get support analytics dashboard (admin only)
  app.get('/api/support/analytics', requiresAdmin, async (req: any, res) => {
    try {
      const { start_date, end_date, period = 'daily' } = req.query;
      
      const analytics = await storage.getSupportAnalytics({
        startDate: start_date ? new Date(start_date as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        endDate: end_date ? new Date(end_date as string) : new Date(),
        period: period as string
      });

      res.json(analytics);
    } catch (error) {
      console.error("Error fetching support analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Get real-time support metrics (admin only)
  app.get('/api/support/metrics', requiresAdmin, async (req: any, res) => {
    try {
      const metrics = await storage.getRealTimeSupportMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching support metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // ===========================================
  // WORDPRESS BLOG CACHE API
  // ===========================================

  // Manual cache refresh endpoint (admin only)
  app.post('/api/wp-posts/refresh', requiresAdmin, async (req: any, res) => {
    const cacher = new WordPressCacher();
    
    try {
      await cacher.fetchAndCachePosts();
      
      const recentPosts = await cacher.getRecentPosts(10);
      
      res.json({
        success: true,
        message: `Successfully cached ${recentPosts.length} posts from WordPress`,
        postsCount: recentPosts.length,
        lastUpdate: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('WordPress cache refresh failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to refresh WordPress cache',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      await cacher.close();
    }
  });

  // Get cached posts endpoint (public)
  app.get('/api/wp-posts', async (req, res) => {
    const cacher = new WordPressCacher();
    const limit = parseInt(req.query.limit as string) || 10;
    
    try {
      const posts = await cacher.getRecentPosts(limit);
      
      res.json({
        success: true,
        posts,
        count: posts.length,
        cached: true
      });
      
    } catch (error) {
      console.error('Failed to fetch cached posts:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch cached posts',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      await cacher.close();
    }
  });

  // ===========================================
  // SUPPORT TAGS API
  // ===========================================

  // Get all support tags (admin only)
  app.get('/api/support/tags', requiresAdmin, async (req: any, res) => {
    try {
      const tags = await storage.getSupportTags();
      res.json(tags);
    } catch (error) {
      console.error("Error fetching support tags:", error);
      res.status(500).json({ message: "Failed to fetch tags" });
    }
  });

  // Create support tag (admin only)
  app.post('/api/support/tags', requiresAdmin, async (req: any, res) => {
    try {
      const tagData = req.body;
      const tag = await storage.createSupportTag(tagData);
      res.status(201).json(tag);
    } catch (error) {
      console.error("Error creating support tag:", error);
      res.status(500).json({ message: "Failed to create tag" });
    }
  });

  // ===========================================
  // WRELIK.COM INTEGRATION ENDPOINTS
  // ===========================================

  // Search across all knowledge base content (public endpoint for Wrelik.com site search)
  app.get('/api/knowledge/search', async (req, res) => {
    try {
      const { q, type = 'all', limit = 20 } = req.query;
      
      if (!q || (q as string).length < 2) {
        return res.status(400).json({ message: "Search query must be at least 2 characters" });
      }

      const results = await storage.searchKnowledgeBase({
        query: q as string,
        type: type as string,
        limit: parseInt(limit as string)
      });

      res.json(results);
    } catch (error) {
      console.error("Error searching knowledge base:", error);
      res.status(500).json({ message: "Failed to search knowledge base" });
    }
  });

  // Get popular/featured content for Wrelik.com homepage
  app.get('/api/knowledge/featured', async (req, res) => {
    try {
      const { type = 'articles', limit = 5 } = req.query;
      
      const featured = await storage.getFeaturedKnowledgeContent({
        type: type as string,
        limit: parseInt(limit as string)
      });

      res.json(featured);
    } catch (error) {
      console.error("Error fetching featured knowledge content:", error);
      res.status(500).json({ message: "Failed to fetch featured content" });
    }
  });

  // Get knowledge base statistics for Wrelik.com admin dashboard
  app.get('/api/knowledge/stats', requiresAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getKnowledgeBaseStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching knowledge base stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Bulk import knowledge content (admin only, for content migration)
  app.post('/api/knowledge/bulk-import', requiresAdmin, async (req: any, res) => {
    try {
      const { articles, faqs, categories } = req.body;
      const results = await storage.bulkImportKnowledgeContent({
        articles: articles || [],
        faqs: faqs || [],
        categories: categories || [],
        authorId: req.user.claims.sub
      });
      res.json(results);
    } catch (error) {
      console.error("Error bulk importing knowledge content:", error);
      res.status(500).json({ message: "Failed to import content" });
    }
  });

  // ===========================================
  // MARKETING ANALYTICS ENDPOINTS
  // ===========================================

  // Track marketing events and conversions
  app.post('/api/marketing/track', async (req, res) => {
    try {
      const {
        event,
        channel,
        campaign,
        source,
        medium,
        content,
        term,
        userId,
        sessionId,
        timestamp,
        page,
        referrer,
        userAgent,
        ...additionalData
      } = req.body;

      if (!event || !channel || !sessionId) {
        return res.status(400).json({ message: "Missing required fields: event, channel, sessionId" });
      }

      await storage.trackMarketingEvent({
        event,
        channel,
        campaign,
        source,
        medium,
        content,
        term,
        userId,
        sessionId,
        timestamp: timestamp || Date.now(),
        page,
        referrer,
        userAgent,
        metadata: additionalData,
        createdAt: new Date()
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking marketing event:", error);
      res.status(500).json({ message: "Failed to track event" });
    }
  });

  // Get marketing analytics dashboard data (admin only)
  app.get('/api/marketing/analytics', requireAdmin, async (req: any, res) => {
    try {
      const { 
        startDate, 
        endDate, 
        channel, 
        campaign,
        groupBy = 'day'
      } = req.query;

      const analytics = await storage.getMarketingAnalytics({
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        endDate: endDate ? new Date(endDate as string) : new Date(),
        channel: channel as string,
        campaign: campaign as string,
        groupBy: groupBy as string
      });

      res.json(analytics);
    } catch (error) {
      console.error("Error fetching marketing analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Get conversion funnel data
  app.get('/api/marketing/funnel', requireAdmin, async (req: any, res) => {
    try {
      const { channel, campaign, startDate, endDate } = req.query;

      const funnel = await storage.getConversionFunnel({
        channel: channel as string,
        campaign: campaign as string,
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        endDate: endDate ? new Date(endDate as string) : new Date()
      });

      res.json(funnel);
    } catch (error) {
      console.error("Error fetching conversion funnel:", error);
      res.status(500).json({ message: "Failed to fetch funnel data" });
    }
  });

  // Get channel performance comparison
  app.get('/api/marketing/channels', requireAdmin, async (req: any, res) => {
    try {
      const { startDate, endDate } = req.query;

      const channels = await storage.getChannelPerformance({
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        endDate: endDate ? new Date(endDate as string) : new Date()
      });

      res.json(channels);
    } catch (error) {
      console.error("Error fetching channel performance:", error);
      res.status(500).json({ message: "Failed to fetch channel data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
