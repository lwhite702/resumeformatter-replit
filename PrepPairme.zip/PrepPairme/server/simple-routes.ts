import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "./db";
import * as schema from "@shared/schema";
import { desc } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Blog posts endpoint (public) - Returns cached WordPress content
  app.get('/api/blog-posts', async (req, res) => {
    try {
      // Fetch cached posts from database
      const cachedPosts = await db.select().from(schema.cachedPosts).orderBy(desc(schema.cachedPosts.updatedAt)).limit(10);
      
      // Transform cached posts to API format
      const posts = cachedPosts.map((post, index) => ({
        id: post.id,
        title: { rendered: post.title },
        excerpt: { rendered: post.excerpt || '' },
        content: { rendered: post.content },
        date: post.publishedAt?.toISOString() || new Date().toISOString(),
        slug: post.slug,
        link: `/blog/${post.slug}`,
        featured_media_url: `https://images.unsplash.com/photo-${1560472354443 + index}?w=800&h=400&fit=crop`,
        categories: [1]
      }));

      res.json({ 
        posts,
        total: posts.length,
        totalPages: 1
      });
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      res.status(500).json({ message: 'Failed to fetch blog posts' });
    }
  });

  // Knowledge base endpoints (public)
  app.get('/api/knowledge/categories', async (req, res) => {
    try {
      const categories = [
        {
          id: 1,
          name: "Interview Preparation",
          slug: "interview-preparation",
          description: "Complete guides for interview success",
          parentId: null,
          sortOrder: 1,
          color: "#3B82F6",
          icon: "mic",
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 2,
          name: "Resume Optimization",
          slug: "resume-optimization", 
          description: "Expert tips for resume improvement",
          parentId: null,
          sortOrder: 2,
          color: "#10B981",
          icon: "file-text",
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      res.json(categories);
    } catch (error) {
      console.error("Error fetching knowledge categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/knowledge/articles', async (req, res) => {
    try {
      const articles = [
        {
          id: 1,
          title: "Getting Started with Interview Preparation",
          content: "Complete guide to preparing for your next interview...",
          excerpt: "Learn the fundamentals of interview preparation",
          slug: "getting-started-interview-prep",
          category: "Interview Preparation",
          tags: ["beginner", "preparation"],
          status: "published",
          author_name: "PrepPair Team",
          created_at: new Date().toISOString(),
          view_count: 0,
          helpful_count: 0
        }
      ];
      res.json(articles);
    } catch (error) {
      console.error("Error fetching knowledge articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.get('/api/knowledge/faqs', async (req, res) => {
    try {
      const faqs = [
        {
          id: 1,
          question: "How do I prepare for behavioral interview questions?",
          answer: "Use the STAR method (Situation, Task, Action, Result) to structure your answers.",
          category_id: 1,
          is_active: true,
          view_count: 0,
          helpful_count: 0,
          tags: ["behavioral", "STAR method"],
          created_at: new Date().toISOString()
        }
      ];
      res.json(faqs);
    } catch (error) {
      console.error("Error fetching FAQ items:", error);
      res.status(500).json({ message: "Failed to fetch FAQs" });
    }
  });

  app.get('/api/knowledge/search', async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || (q as string).length < 2) {
        return res.status(400).json({ message: "Search query must be at least 2 characters" });
      }

      const results = {
        articles: [
          {
            id: 1,
            title: "Interview Preparation Guide",
            excerpt: "Complete guide for interview success",
            category: "Interview Preparation",
            view_count: 0,
            helpful_count: 0
          }
        ],
        faqs: []
      };
      res.json(results);
    } catch (error) {
      console.error("Error searching knowledge base:", error);
      res.status(500).json({ message: "Failed to search knowledge base" });
    }
  });

  app.get('/api/knowledge/featured', async (req, res) => {
    try {
      const featured = [
        {
          id: 1,
          title: "Top Interview Tips",
          excerpt: "Essential tips for interview success",
          category: "Interview Preparation",
          view_count: 100,
          helpful_count: 25
        }
      ];
      res.json(featured);
    } catch (error) {
      console.error("Error fetching featured knowledge content:", error);
      res.status(500).json({ message: "Failed to fetch featured content" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}