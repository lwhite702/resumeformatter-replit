import OpenAI from "openai";
import { db } from "./db";
import { skillHighlights, skillCategories, resumes } from "@shared/schema";
import { eq, and } from "drizzle-orm";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ExtractedSkill {
  skillName: string;
  category: 'technical' | 'soft' | 'industry' | 'certification' | 'language';
  proficiencyLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  yearsOfExperience: number | null;
  contextualExamples: string[];
  relevanceScore: number; // 1-100
  extractedFrom: string;
}

export interface SkillExtractionResult {
  extractedSkills: ExtractedSkill[];
  summary: {
    totalSkillsFound: number;
    technicalSkills: number;
    softSkills: number;
    industrySkills: number;
    certifications: number;
    languages: number;
  };
  recommendations: string[];
}

export class SkillExtractionService {
  
  /**
   * One-click skill highlights generator
   * Analyzes resume content and generates comprehensive skill highlights
   */
  async generateSkillHighlights(resumeId: number, userId: string): Promise<SkillExtractionResult> {
    // Get resume content
    const [resume] = await db
      .select()
      .from(resumes)
      .where(and(eq(resumes.id, resumeId), eq(resumes.userId, userId)));

    if (!resume) {
      throw new Error("Resume not found");
    }

    // Extract skills using AI
    const extractionResult = await this.extractSkillsFromText(resume.content);

    // Store skill highlights in database
    await this.storeSkillHighlights(resumeId, userId, extractionResult.extractedSkills);

    // Update resume with skill analysis timestamp
    await db
      .update(resumes)
      .set({ 
        lastSkillAnalysisAt: new Date(),
        skillHighlights: extractionResult
      })
      .where(eq(resumes.id, resumeId));

    return extractionResult;
  }

  /**
   * Extract skills from resume text using OpenAI
   */
  private async extractSkillsFromText(resumeText: string): Promise<SkillExtractionResult> {
    const prompt = `
    Analyze the following resume text and extract all relevant skills. For each skill identified, provide:

    1. Skill name (specific and standardized)
    2. Category (technical, soft, industry, certification, language)
    3. Proficiency level (beginner, intermediate, advanced, expert) based on context
    4. Years of experience (estimate from context, null if unclear)
    5. Contextual examples (where/how the skill was mentioned)
    6. Relevance score (1-100 based on current job market demand)
    7. Source context (which section it was extracted from)

    Resume Text:
    ${resumeText}

    Please respond with a JSON object in this exact format:
    {
      "extractedSkills": [
        {
          "skillName": "JavaScript",
          "category": "technical",
          "proficiencyLevel": "advanced",
          "yearsOfExperience": 3,
          "contextualExamples": ["Built React applications", "Node.js backend development"],
          "relevanceScore": 95,
          "extractedFrom": "work experience section"
        }
      ],
      "summary": {
        "totalSkillsFound": 25,
        "technicalSkills": 15,
        "softSkills": 7,
        "industrySkills": 2,
        "certifications": 1,
        "languages": 2
      },
      "recommendations": [
        "Consider highlighting cloud computing skills more prominently",
        "Add specific metrics to quantify technical achievements"
      ]
    }

    Focus on:
    - Industry-standard skill naming conventions
    - Realistic proficiency assessments
    - Current market relevance
    - Actionable improvement recommendations
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert resume analyzer and career consultant specializing in skill extraction and assessment. Provide comprehensive, accurate skill analysis based on resume content."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return result as SkillExtractionResult;

    } catch (error) {
      console.error("Error extracting skills:", error);
      throw new Error("Failed to extract skills from resume");
    }
  }

  /**
   * Store extracted skills in database
   */
  private async storeSkillHighlights(resumeId: number, userId: string, skills: ExtractedSkill[]): Promise<void> {
    // Delete existing skill highlights for this resume
    await db
      .delete(skillHighlights)
      .where(eq(skillHighlights.resumeId, resumeId));

    // Insert new skill highlights
    if (skills.length > 0) {
      await db.insert(skillHighlights).values(
        skills.map(skill => ({
          resumeId,
          userId,
          skillName: skill.skillName,
          category: skill.category,
          proficiencyLevel: skill.proficiencyLevel,
          yearsOfExperience: skill.yearsOfExperience,
          contextualExamples: skill.contextualExamples,
          relevanceScore: skill.relevanceScore,
          isAIGenerated: true,
          isUserVerified: false,
          extractedFrom: skill.extractedFrom,
        }))
      );
    }
  }

  /**
   * Get skill highlights for a resume
   */
  async getSkillHighlights(resumeId: number, userId: string): Promise<ExtractedSkill[]> {
    const highlights = await db
      .select()
      .from(skillHighlights)
      .where(and(eq(skillHighlights.resumeId, resumeId), eq(skillHighlights.userId, userId)));

    return highlights.map(highlight => ({
      skillName: highlight.skillName,
      category: highlight.category as ExtractedSkill['category'],
      proficiencyLevel: highlight.proficiencyLevel as ExtractedSkill['proficiencyLevel'],
      yearsOfExperience: highlight.yearsOfExperience,
      contextualExamples: highlight.contextualExamples as string[],
      relevanceScore: highlight.relevanceScore || 0,
      extractedFrom: highlight.extractedFrom || 'resume',
    }));
  }

  /**
   * Update user verification status for a skill
   */
  async verifySkill(skillId: number, userId: string, isVerified: boolean): Promise<void> {
    await db
      .update(skillHighlights)
      .set({ isUserVerified: isVerified })
      .where(and(eq(skillHighlights.id, skillId), eq(skillHighlights.userId, userId)));
  }

  /**
   * Get skill categories for organization
   */
  async getSkillCategories(): Promise<typeof skillCategories.$inferSelect[]> {
    return await db
      .select()
      .from(skillCategories)
      .where(eq(skillCategories.isActive, true))
      .orderBy(skillCategories.sortOrder);
  }

  /**
   * Initialize default skill categories
   */
  async initializeSkillCategories(): Promise<void> {
    const defaultCategories = [
      {
        name: 'Technical Skills',
        description: 'Programming languages, frameworks, tools, and technologies',
        color: '#3B82F6',
        icon: 'Code',
        sortOrder: 1,
      },
      {
        name: 'Soft Skills',
        description: 'Communication, leadership, teamwork, and interpersonal skills',
        color: '#10B981',
        icon: 'Users',
        sortOrder: 2,
      },
      {
        name: 'Industry Knowledge',
        description: 'Domain-specific expertise and industry understanding',
        color: '#F59E0B',
        icon: 'Building',
        sortOrder: 3,
      },
      {
        name: 'Certifications',
        description: 'Professional certifications and credentials',
        color: '#8B5CF6',
        icon: 'Award',
        sortOrder: 4,
      },
      {
        name: 'Languages',
        description: 'Spoken and written language proficiencies',
        color: '#EF4444',
        icon: 'Globe',
        sortOrder: 5,
      },
    ];

    for (const category of defaultCategories) {
      try {
        await db.insert(skillCategories).values(category).onConflictDoNothing();
      } catch (error) {
        // Category already exists, continue
      }
    }
  }
}

export const skillExtractionService = new SkillExtractionService();