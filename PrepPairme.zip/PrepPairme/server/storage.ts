import {
  users,
  teams,
  teamInvitations,
  resumes,
  jobPostings,
  interviewGuides,
  questions,
  thankYouNotes,
  reflections,
  videoPracticeSessions,
  videoFeedback,
  jobBoardIntegrations,
  externalApplications,
  applicationEvents,
  adminLogs,
  payments,
  creditTransactions,
  resumeTemplates,
  systemSettings,
  careerPaths,
  careerPathNodes,
  careerPathConnections,
  industryTrends,
  skillHighlights,
  skillCategories,
  careerMoodEntries,
  moodBoardTemplates,
  knowledgeCategories,
  knowledgeArticles,
  supportTickets,
  supportTicketMessages,
  faqItems,
  supportAnalytics,
  knowledgeBaseFeedback,
  supportTags,
  type User,
  type UpsertUser,
  type Resume,
  type InsertResume,
  type JobPosting,
  type InsertJobPosting,
  type InterviewGuide,
  type InsertInterviewGuide,
  type Question,
  type ThankYouNote,
  type InsertThankYouNote,
  type Reflection,
  type InsertReflection,
  type VideoPracticeSession,
  type InsertVideoPracticeSession,
  type VideoFeedback,
  type InsertVideoFeedback,
  type JobBoardIntegration,
  type InsertJobBoardIntegration,
  type ExternalApplication,
  type InsertExternalApplication,
  type ApplicationEvent,
  type InsertApplicationEvent,
  type Payment,
  type ResumeTemplate,
  type SystemSetting,
  type CareerMoodEntry,
  type InsertCareerMoodEntry,
  type MoodBoardTemplate,
  type InsertMoodBoardTemplate,
  type InsertAdminLog,
  type InsertCreditTransaction,
  type SkillHighlight,
  type InsertSkillHighlight,
  type SkillCategory,
  type InsertSkillCategory,
  type CareerPath,
  type InsertCareerPath,
  type CareerPathNode,
  type InsertCareerPathNode,
  type CareerPathConnection,
  type InsertCareerPathConnection,
  type IndustryTrend,
  type InsertIndustryTrend,
  type KnowledgeCategory,
  type InsertKnowledgeCategory,
  type KnowledgeArticle,
  type InsertKnowledgeArticle,
  type SupportTicket,
  type InsertSupportTicket,
  type SupportTicketMessage,
  type InsertSupportTicketMessage,
  type FaqItem,
  type InsertFaqItem,
  type SupportAnalytics,
  type InsertSupportAnalytics,
  type KnowledgeBaseFeedback,
  type InsertKnowledgeBaseFeedback,
  type SupportTag,
  type InsertSupportTag,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sum, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Subscription operations
  updateUserStripeCustomerId(userId: string, customerId: string): Promise<User>;
  updateUserSubscription(userId: string, data: any): Promise<User>;
  updateUserTeamInfo(userId: string, data: any): Promise<User>;
  
  // Team operations
  createTeam(data: any): Promise<any>;
  updateTeamSubscription(teamId: number, data: any): Promise<any>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, data: Partial<User>): Promise<User>;
  getAdminStats(): Promise<any>;
  getAllPayments(): Promise<Payment[]>;
  processRefund(paymentId: number, amount: number): Promise<any>;
  getAllTemplates(): Promise<ResumeTemplate[]>;
  updateTemplate(id: number, data: Partial<ResumeTemplate>): Promise<ResumeTemplate>;
  grantCredits(userId: string, amount: number, reason: string, adminId: string): Promise<any>;
  logAdminAction(action: InsertAdminLog): Promise<void>;

  // Resume operations
  createResume(resume: InsertResume): Promise<Resume>;
  getUserResumes(userId: string): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  updateResume(id: number, data: Partial<InsertResume>): Promise<Resume>;
  deleteResume(id: number): Promise<void>;
  
  // Job posting operations
  createJobPosting(jobPosting: InsertJobPosting): Promise<JobPosting>;
  getUserJobPostings(userId: string): Promise<JobPosting[]>;
  getJobPosting(id: number): Promise<JobPosting | undefined>;
  updateJobPosting(id: number, data: Partial<InsertJobPosting>): Promise<JobPosting>;
  deleteJobPosting(id: number): Promise<void>;
  
  // Interview guide operations
  createInterviewGuide(guide: InsertInterviewGuide): Promise<InterviewGuide>;
  getUserInterviewGuides(userId: string): Promise<InterviewGuide[]>;
  getInterviewGuide(id: number): Promise<InterviewGuide | undefined>;
  updateInterviewGuide(id: number, data: Partial<InsertInterviewGuide>): Promise<InterviewGuide>;
  deleteInterviewGuide(id: number): Promise<void>;
  incrementGuideViews(id: number): Promise<void>;
  
  // Question operations
  getQuestionsByCategory(category?: string): Promise<Question[]>;
  getQuestion(id: number): Promise<Question | undefined>;
  getAllQuestions(): Promise<Question[]>;
  createQuestion(question: any): Promise<Question>;
  updateQuestion(id: number, data: any): Promise<Question>;
  deleteQuestion(id: number): Promise<void>;
  getQuestionCategories(): Promise<any[]>;
  
  // Thank you note operations
  createThankYouNote(note: InsertThankYouNote): Promise<ThankYouNote>;
  getUserThankYouNotes(userId: string): Promise<ThankYouNote[]>;
  
  // Reflection operations
  createReflection(reflection: InsertReflection): Promise<Reflection>;
  getUserReflections(userId: string): Promise<Reflection[]>;
  
  // Video practice operations
  createVideoPracticeSession(session: InsertVideoPracticeSession): Promise<VideoPracticeSession>;
  getUserVideoPracticeSessions(userId: string): Promise<VideoPracticeSession[]>;
  getVideoPracticeSession(id: number): Promise<VideoPracticeSession | undefined>;
  updateVideoPracticeSession(id: number, data: Partial<InsertVideoPracticeSession>): Promise<VideoPracticeSession>;
  deleteVideoPracticeSession(id: number): Promise<void>;
  
  // Video feedback operations
  createVideoFeedback(feedback: InsertVideoFeedback): Promise<VideoFeedback>;
  getVideoFeedbackBySession(sessionId: number): Promise<VideoFeedback | undefined>;
  
  // Job board integration operations
  createJobBoardIntegration(integration: InsertJobBoardIntegration): Promise<JobBoardIntegration>;
  getUserJobBoardIntegrations(userId: string): Promise<JobBoardIntegration[]>;
  getJobBoardIntegration(id: number): Promise<JobBoardIntegration | undefined>;
  updateJobBoardIntegration(id: number, data: Partial<InsertJobBoardIntegration>): Promise<JobBoardIntegration>;
  deleteJobBoardIntegration(id: number): Promise<void>;
  
  // External application operations
  createExternalApplication(application: InsertExternalApplication): Promise<ExternalApplication>;
  getUserExternalApplications(userId: string): Promise<ExternalApplication[]>;
  getExternalApplication(id: number): Promise<ExternalApplication | undefined>;
  updateExternalApplication(id: number, data: Partial<InsertExternalApplication>): Promise<ExternalApplication>;
  deleteExternalApplication(id: number): Promise<void>;
  getExternalApplicationByExternalId(externalId: string, jobBoard: string): Promise<ExternalApplication | undefined>;
  
  // Application event operations
  createApplicationEvent(event: InsertApplicationEvent): Promise<ApplicationEvent>;
  getApplicationEvents(applicationId: number): Promise<ApplicationEvent[]>;

  // Career path operations
  createCareerPath(path: InsertCareerPath): Promise<CareerPath>;
  getUserCareerPaths(userId: string): Promise<CareerPath[]>;
  getCareerPath(id: number): Promise<CareerPath | undefined>;
  getCareerPathWithNodes(id: number): Promise<CareerPath & { nodes: CareerPathNode[]; connections: CareerPathConnection[] } | undefined>;
  updateCareerPath(id: number, data: Partial<InsertCareerPath>): Promise<CareerPath>;
  deleteCareerPath(id: number): Promise<void>;
  
  // Career path node operations
  createCareerPathNode(node: InsertCareerPathNode): Promise<CareerPathNode>;
  updateCareerPathNode(id: number, data: Partial<InsertCareerPathNode>): Promise<CareerPathNode>;
  deleteCareerPathNode(id: number): Promise<void>;
  
  // Career path connection operations
  createCareerPathConnection(connection: InsertCareerPathConnection): Promise<CareerPathConnection>;
  updateCareerPathConnection(id: number, data: Partial<InsertCareerPathConnection>): Promise<CareerPathConnection>;
  deleteCareerPathConnection(id: number): Promise<void>;
  
  // Industry trend operations
  getIndustryTrends(industry?: string): Promise<IndustryTrend[]>;
  createIndustryTrend(trend: InsertIndustryTrend): Promise<IndustryTrend>;
  getCareerTemplates(industry?: string): Promise<CareerPath[]>;

  // Credit operations
  updateUserCredits(userId: string, credits: number): Promise<User>;

  // Skill highlights operations
  createSkillHighlight(highlight: InsertSkillHighlight): Promise<SkillHighlight>;
  getSkillHighlightsByResume(resumeId: number, userId: string): Promise<SkillHighlight[]>;
  updateSkillHighlight(id: number, data: Partial<InsertSkillHighlight>): Promise<SkillHighlight>;
  deleteSkillHighlight(id: number): Promise<void>;

  // Skill categories operations
  getSkillCategories(): Promise<SkillCategory[]>;
  createSkillCategory(category: InsertSkillCategory): Promise<SkillCategory>;

  // Knowledge Base operations for Wrelik.com unified support desk
  getKnowledgeCategories(options?: { parentId?: number; includeInactive?: boolean }): Promise<KnowledgeCategory[]>;
  createKnowledgeCategory(data: InsertKnowledgeCategory): Promise<KnowledgeCategory>;
  updateKnowledgeCategory(id: number, data: Partial<KnowledgeCategory>): Promise<KnowledgeCategory>;
  
  getKnowledgeArticles(options: { categoryId?: number; search?: string; status?: string; limit: number; offset: number; tags?: string[] }): Promise<KnowledgeArticle[]>;
  getKnowledgeArticleBySlug(slug: string): Promise<KnowledgeArticle | undefined>;
  createKnowledgeArticle(data: InsertKnowledgeArticle): Promise<KnowledgeArticle>;
  updateKnowledgeArticle(id: number, data: Partial<KnowledgeArticle>): Promise<KnowledgeArticle>;
  incrementArticleViewCount(id: number): Promise<void>;
  updateArticleHelpfulness(id: number, isHelpful: boolean): Promise<void>;
  
  getFaqItems(options: { categoryId?: number; search?: string; limit: number }): Promise<FaqItem[]>;
  createFaqItem(data: InsertFaqItem): Promise<FaqItem>;
  updateFaqItem(id: number, data: Partial<FaqItem>): Promise<FaqItem>;
  updateFaqHelpfulness(id: number, isHelpful: boolean): Promise<void>;
  
  // Support operations for Wrelik.com unified support desk
  getSupportTickets(options: { status?: string; priority?: string; assignedTo?: string; categoryId?: number; customerEmail?: string; limit: number; offset: number; sortBy: string; sortOrder: string }): Promise<SupportTicket[]>;
  getSupportTicketWithMessages(id: number): Promise<SupportTicket & { messages: SupportTicketMessage[] } | undefined>;
  createSupportTicket(data: InsertSupportTicket): Promise<SupportTicket>;
  updateSupportTicket(id: number, data: Partial<SupportTicket>): Promise<SupportTicket>;
  createSupportTicketMessage(data: InsertSupportTicketMessage): Promise<SupportTicketMessage>;
  updateTicketLastActivity(ticketId: number): Promise<void>;
  setFirstResponseTime(ticketId: number): Promise<void>;
  
  getSupportTags(): Promise<SupportTag[]>;
  createSupportTag(data: InsertSupportTag): Promise<SupportTag>;
  
  // Knowledge Base feedback and analytics for Wrelik.com
  createKnowledgeBaseFeedback(data: InsertKnowledgeBaseFeedback): Promise<KnowledgeBaseFeedback>;
  getSupportAnalytics(options: { startDate: Date; endDate: Date; period: string }): Promise<any>;
  getRealTimeSupportMetrics(): Promise<any>;
  getKnowledgeBaseStats(): Promise<any>;
  
  // Search and featured content for Wrelik.com integration
  searchKnowledgeBase(options: { query: string; type: string; limit: number }): Promise<any>;
  getFeaturedKnowledgeContent(options: { type: string; limit: number }): Promise<any>;
  bulkImportKnowledgeContent(data: { articles: any[]; faqs: any[]; categories: any[]; authorId: string }): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Subscription operations
  async updateUserStripeCustomerId(userId: string, customerId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ stripeCustomerId: customerId, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserSubscription(userId: string, data: any): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserTeamInfo(userId: string, data: any): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Team operations
  async createTeam(data: any): Promise<any> {
    const [team] = await db
      .insert(teams)
      .values({
        ...data,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return team;
  }

  async updateTeamSubscription(teamId: number, data: any): Promise<any> {
    const [team] = await db
      .update(teams)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(teams.id, teamId))
      .returning();
    return team;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: string, data: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAdminStats(): Promise<any> {
    const totalUsers = await db.select({ count: count() }).from(users);
    const activeUsers = await db.select({ count: count() }).from(users).where(eq(users.isActive, true));
    
    return {
      totalUsers: totalUsers[0]?.count || 0,
      activeUsers: activeUsers[0]?.count || 0,
      totalRevenue: 0,
      monthlyRevenue: 0,
      totalCreditsIssued: 0,
      totalCreditsUsed: 0,
      totalTemplates: 0,
      activeSubscriptions: 0,
      pendingPayments: 0,
      recentSignups: 0,
    };
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  async processRefund(paymentId: number, amount: number): Promise<any> {
    // Implementation would handle Stripe refund processing
    return { success: true };
  }

  async getAllTemplates(): Promise<ResumeTemplate[]> {
    return await db.select().from(resumeTemplates).orderBy(desc(resumeTemplates.createdAt));
  }

  async updateTemplate(id: number, data: Partial<ResumeTemplate>): Promise<ResumeTemplate> {
    const [template] = await db
      .update(resumeTemplates)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(resumeTemplates.id, id))
      .returning();
    return template;
  }

  async grantCredits(userId: string, amount: number, reason: string, adminId: string): Promise<any> {
    // Update user credits
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));
    
    if (user) {
      await db
        .update(users)
        .set({ 
          credits: user.credits + amount,
          updatedAt: new Date()
        })
        .where(eq(users.id, userId));
    }

    // Log credit transaction
    await db.insert(creditTransactions).values({
      userId,
      amount,
      type: 'admin_grant',
      description: reason,
      adminId,
    });

    return { success: true };
  }

  async logAdminAction(action: InsertAdminLog): Promise<void> {
    await db.insert(adminLogs).values(action);
  }

  // Resume operations
  async createResume(resume: InsertResume): Promise<Resume> {
    const [createdResume] = await db.insert(resumes).values(resume).returning();
    return createdResume;
  }

  async getUserResumes(userId: string): Promise<Resume[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId)).orderBy(desc(resumes.uploadedAt));
  }

  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async updateResume(id: number, data: Partial<InsertResume>): Promise<Resume> {
    const [resume] = await db.update(resumes).set(data).where(eq(resumes.id, id)).returning();
    return resume;
  }

  async deleteResume(id: number): Promise<void> {
    await db.delete(resumes).where(eq(resumes.id, id));
  }

  // Job posting operations
  async createJobPosting(jobPosting: InsertJobPosting): Promise<JobPosting> {
    const [createdJobPosting] = await db.insert(jobPostings).values(jobPosting).returning();
    return createdJobPosting;
  }

  async getUserJobPostings(userId: string): Promise<JobPosting[]> {
    return await db.select().from(jobPostings).where(eq(jobPostings.userId, userId)).orderBy(desc(jobPostings.addedAt));
  }

  async getJobPosting(id: number): Promise<JobPosting | undefined> {
    const [jobPosting] = await db.select().from(jobPostings).where(eq(jobPostings.id, id));
    return jobPosting;
  }

  async updateJobPosting(id: number, data: Partial<InsertJobPosting>): Promise<JobPosting> {
    const [jobPosting] = await db.update(jobPostings).set(data).where(eq(jobPostings.id, id)).returning();
    return jobPosting;
  }

  async deleteJobPosting(id: number): Promise<void> {
    await db.delete(jobPostings).where(eq(jobPostings.id, id));
  }

  // Interview guide operations
  async createInterviewGuide(guide: InsertInterviewGuide): Promise<InterviewGuide> {
    const [createdGuide] = await db.insert(interviewGuides).values(guide).returning();
    return createdGuide;
  }

  async getUserInterviewGuides(userId: string): Promise<InterviewGuide[]> {
    return await db.select().from(interviewGuides).where(eq(interviewGuides.userId, userId)).orderBy(desc(interviewGuides.generatedAt));
  }

  async getInterviewGuide(id: number): Promise<InterviewGuide | undefined> {
    const [guide] = await db.select().from(interviewGuides).where(eq(interviewGuides.id, id));
    return guide;
  }

  async updateInterviewGuide(id: number, data: Partial<InsertInterviewGuide>): Promise<InterviewGuide> {
    const [guide] = await db.update(interviewGuides).set(data).where(eq(interviewGuides.id, id)).returning();
    return guide;
  }

  async deleteInterviewGuide(id: number): Promise<void> {
    await db.delete(interviewGuides).where(eq(interviewGuides.id, id));
  }

  async incrementGuideViews(id: number): Promise<void> {
    // Implementation for view tracking if needed
  }

  // Question operations
  async getQuestionsByCategory(category?: string): Promise<Question[]> {
    if (category) {
      return await db.select().from(questions).where(eq(questions.category, category));
    }
    return await db.select().from(questions);
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  // Thank you note operations
  async createThankYouNote(note: InsertThankYouNote): Promise<ThankYouNote> {
    const [createdNote] = await db.insert(thankYouNotes).values(note).returning();
    return createdNote;
  }

  async getUserThankYouNotes(userId: string): Promise<ThankYouNote[]> {
    return await db.select().from(thankYouNotes).where(eq(thankYouNotes.userId, userId)).orderBy(desc(thankYouNotes.generatedAt));
  }

  // Reflection operations
  async createReflection(reflection: InsertReflection): Promise<Reflection> {
    const [createdReflection] = await db.insert(reflections).values(reflection).returning();
    return createdReflection;
  }

  async getUserReflections(userId: string): Promise<Reflection[]> {
    return await db.select().from(reflections).where(eq(reflections.userId, userId)).orderBy(desc(reflections.createdAt));
  }

  // Video practice operations
  async createVideoPracticeSession(session: InsertVideoPracticeSession): Promise<VideoPracticeSession> {
    const [createdSession] = await db.insert(videoPracticeSessions).values(session).returning();
    return createdSession;
  }

  async getUserVideoPracticeSessions(userId: string): Promise<VideoPracticeSession[]> {
    return await db.select().from(videoPracticeSessions).where(eq(videoPracticeSessions.userId, userId)).orderBy(desc(videoPracticeSessions.createdAt));
  }

  async getVideoPracticeSession(id: number): Promise<VideoPracticeSession | undefined> {
    const [session] = await db.select().from(videoPracticeSessions).where(eq(videoPracticeSessions.id, id));
    return session;
  }

  async updateVideoPracticeSession(id: number, data: Partial<InsertVideoPracticeSession>): Promise<VideoPracticeSession> {
    const [session] = await db.update(videoPracticeSessions).set(data).where(eq(videoPracticeSessions.id, id)).returning();
    return session;
  }

  async deleteVideoPracticeSession(id: number): Promise<void> {
    await db.delete(videoPracticeSessions).where(eq(videoPracticeSessions.id, id));
  }

  // Video feedback operations
  async createVideoFeedback(feedback: InsertVideoFeedback): Promise<VideoFeedback> {
    const [createdFeedback] = await db.insert(videoFeedback).values(feedback).returning();
    return createdFeedback;
  }

  async getVideoFeedbackBySession(sessionId: number): Promise<VideoFeedback | undefined> {
    const [feedback] = await db.select().from(videoFeedback).where(eq(videoFeedback.sessionId, sessionId));
    return feedback;
  }

  // Job board integration operations
  async createJobBoardIntegration(integration: InsertJobBoardIntegration): Promise<JobBoardIntegration> {
    const [createdIntegration] = await db.insert(jobBoardIntegrations).values(integration).returning();
    return createdIntegration;
  }

  async getUserJobBoardIntegrations(userId: string): Promise<JobBoardIntegration[]> {
    return await db.select().from(jobBoardIntegrations).where(eq(jobBoardIntegrations.userId, userId)).orderBy(desc(jobBoardIntegrations.createdAt));
  }

  async getJobBoardIntegration(id: number): Promise<JobBoardIntegration | undefined> {
    const [integration] = await db.select().from(jobBoardIntegrations).where(eq(jobBoardIntegrations.id, id));
    return integration;
  }

  async updateJobBoardIntegration(id: number, data: Partial<InsertJobBoardIntegration>): Promise<JobBoardIntegration> {
    const [integration] = await db.update(jobBoardIntegrations).set({ ...data, updatedAt: new Date() }).where(eq(jobBoardIntegrations.id, id)).returning();
    return integration;
  }

  async deleteJobBoardIntegration(id: number): Promise<void> {
    await db.delete(jobBoardIntegrations).where(eq(jobBoardIntegrations.id, id));
  }

  // External application operations
  async createExternalApplication(application: InsertExternalApplication): Promise<ExternalApplication> {
    const [createdApplication] = await db.insert(externalApplications).values(application).returning();
    return createdApplication;
  }

  async getUserExternalApplications(userId: string): Promise<ExternalApplication[]> {
    return await db.select().from(externalApplications).where(eq(externalApplications.userId, userId)).orderBy(desc(externalApplications.appliedAt));
  }

  async getExternalApplication(id: number): Promise<ExternalApplication | undefined> {
    const [application] = await db.select().from(externalApplications).where(eq(externalApplications.id, id));
    return application;
  }

  async updateExternalApplication(id: number, data: Partial<InsertExternalApplication>): Promise<ExternalApplication> {
    const [application] = await db.update(externalApplications).set(data).where(eq(externalApplications.id, id)).returning();
    return application;
  }

  async deleteExternalApplication(id: number): Promise<void> {
    await db.delete(externalApplications).where(eq(externalApplications.id, id));
  }

  async getExternalApplicationByExternalId(externalId: string, jobBoard: string): Promise<ExternalApplication | undefined> {
    const [application] = await db.select().from(externalApplications).where(and(eq(externalApplications.externalId, externalId), eq(externalApplications.jobBoard, jobBoard)));
    return application;
  }

  // Application event operations
  async createApplicationEvent(event: InsertApplicationEvent): Promise<ApplicationEvent> {
    const [createdEvent] = await db.insert(applicationEvents).values(event).returning();
    return createdEvent;
  }

  async getApplicationEvents(applicationId: number): Promise<ApplicationEvent[]> {
    return await db.select().from(applicationEvents).where(eq(applicationEvents.applicationId, applicationId)).orderBy(desc(applicationEvents.createdAt));
  }

  // Career path operations
  async createCareerPath(path: InsertCareerPath): Promise<CareerPath> {
    const [careerPath] = await db.insert(careerPaths).values(path).returning();
    return careerPath;
  }

  async getUserCareerPaths(userId: string): Promise<CareerPath[]> {
    return await db.select().from(careerPaths).where(eq(careerPaths.userId, userId)).orderBy(desc(careerPaths.createdAt));
  }

  async getCareerPath(id: number): Promise<CareerPath | undefined> {
    const [careerPath] = await db.select().from(careerPaths).where(eq(careerPaths.id, id));
    return careerPath;
  }

  async getCareerPathWithNodes(id: number): Promise<CareerPath & { nodes: CareerPathNode[]; connections: CareerPathConnection[] } | undefined> {
    const [careerPath] = await db.select().from(careerPaths).where(eq(careerPaths.id, id));
    if (!careerPath) return undefined;

    const nodes = await db.select().from(careerPathNodes).where(eq(careerPathNodes.pathId, id));
    const connections = await db.select().from(careerPathConnections).where(eq(careerPathConnections.pathId, id));

    return {
      ...careerPath,
      nodes,
      connections
    };
  }

  async updateCareerPath(id: number, data: Partial<InsertCareerPath>): Promise<CareerPath> {
    const [careerPath] = await db.update(careerPaths).set({ ...data, updatedAt: new Date() }).where(eq(careerPaths.id, id)).returning();
    return careerPath;
  }

  async deleteCareerPath(id: number): Promise<void> {
    // Delete associated nodes and connections first
    await db.delete(careerPathConnections).where(eq(careerPathConnections.pathId, id));
    await db.delete(careerPathNodes).where(eq(careerPathNodes.pathId, id));
    await db.delete(careerPaths).where(eq(careerPaths.id, id));
  }

  // Career path node operations
  async createCareerPathNode(node: InsertCareerPathNode): Promise<CareerPathNode> {
    const [careerPathNode] = await db.insert(careerPathNodes).values(node).returning();
    return careerPathNode;
  }

  async updateCareerPathNode(id: number, data: Partial<InsertCareerPathNode>): Promise<CareerPathNode> {
    const [careerPathNode] = await db.update(careerPathNodes).set({ ...data, updatedAt: new Date() }).where(eq(careerPathNodes.id, id)).returning();
    return careerPathNode;
  }

  async deleteCareerPathNode(id: number): Promise<void> {
    // Delete associated connections first
    await db.delete(careerPathConnections).where(
      sql`${careerPathConnections.fromNodeId} = ${id} OR ${careerPathConnections.toNodeId} = ${id}`
    );
    await db.delete(careerPathNodes).where(eq(careerPathNodes.id, id));
  }

  // Career path connection operations
  async createCareerPathConnection(connection: InsertCareerPathConnection): Promise<CareerPathConnection> {
    const [careerPathConnection] = await db.insert(careerPathConnections).values(connection).returning();
    return careerPathConnection;
  }

  async updateCareerPathConnection(id: number, data: Partial<InsertCareerPathConnection>): Promise<CareerPathConnection> {
    const [careerPathConnection] = await db.update(careerPathConnections).set(data).where(eq(careerPathConnections.id, id)).returning();
    return careerPathConnection;
  }

  async deleteCareerPathConnection(id: number): Promise<void> {
    await db.delete(careerPathConnections).where(eq(careerPathConnections.id, id));
  }

  // Industry trend operations
  async getIndustryTrends(industry?: string): Promise<IndustryTrend[]> {
    if (industry) {
      return await db.select().from(industryTrends).where(eq(industryTrends.industry, industry)).orderBy(desc(industryTrends.lastUpdated));
    }
    return await db.select().from(industryTrends).orderBy(desc(industryTrends.lastUpdated));
  }

  async createIndustryTrend(trend: InsertIndustryTrend): Promise<IndustryTrend> {
    const [industryTrend] = await db.insert(industryTrends).values(trend).returning();
    return industryTrend;
  }

  async getCareerTemplates(industry?: string): Promise<CareerPath[]> {
    if (industry) {
      return await db.select().from(careerPaths).where(
        and(eq(careerPaths.isTemplate, true), eq(careerPaths.industry, industry))
      ).orderBy(desc(careerPaths.createdAt));
    }
    return await db.select().from(careerPaths).where(eq(careerPaths.isTemplate, true)).orderBy(desc(careerPaths.createdAt));
  }

  // Credit operations
  async updateUserCredits(userId: string, credits: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ credits })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Skill highlights operations
  async createSkillHighlight(highlight: InsertSkillHighlight): Promise<SkillHighlight> {
    const [skillHighlight] = await db.insert(skillHighlights).values(highlight).returning();
    return skillHighlight;
  }

  async getSkillHighlightsByResume(resumeId: number, userId: string): Promise<SkillHighlight[]> {
    return await db
      .select()
      .from(skillHighlights)
      .where(and(eq(skillHighlights.resumeId, resumeId), eq(skillHighlights.userId, userId)))
      .orderBy(desc(skillHighlights.relevanceScore));
  }

  async updateSkillHighlight(id: number, data: Partial<InsertSkillHighlight>): Promise<SkillHighlight> {
    const [skillHighlight] = await db
      .update(skillHighlights)
      .set(data)
      .where(eq(skillHighlights.id, id))
      .returning();
    return skillHighlight;
  }

  async deleteSkillHighlight(id: number): Promise<void> {
    await db.delete(skillHighlights).where(eq(skillHighlights.id, id));
  }

  // Skill categories operations
  async getSkillCategories(): Promise<SkillCategory[]> {
    return await db.select().from(skillCategories).orderBy(skillCategories.name);
  }

  // Career mood board operations
  async createMoodEntry(entry: InsertCareerMoodEntry): Promise<CareerMoodEntry> {
    const [moodEntry] = await db.insert(careerMoodEntries).values(entry).returning();
    return moodEntry;
  }

  async getUserMoodEntries(userId: string): Promise<CareerMoodEntry[]> {
    return await db
      .select()
      .from(careerMoodEntries)
      .where(eq(careerMoodEntries.userId, userId))
      .orderBy(desc(careerMoodEntries.createdAt));
  }

  async getMoodEntry(id: number, userId: string): Promise<CareerMoodEntry | undefined> {
    const [entry] = await db
      .select()
      .from(careerMoodEntries)
      .where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)));
    return entry;
  }

  async updateMoodEntry(id: number, userId: string, data: Partial<InsertCareerMoodEntry>): Promise<CareerMoodEntry> {
    const [moodEntry] = await db
      .update(careerMoodEntries)
      .set({ ...data, updatedAt: new Date() })
      .where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)))
      .returning();
    return moodEntry;
  }

  async deleteMoodEntry(id: number, userId: string): Promise<void> {
    await db.delete(careerMoodEntries).where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)));
  }

  async getMoodBoardTemplates(): Promise<MoodBoardTemplate[]> {
    return await db
      .select()
      .from(moodBoardTemplates)
      .where(eq(moodBoardTemplates.isPublic, true))
      .orderBy(desc(moodBoardTemplates.usageCount));
  }

  async createMoodBoardTemplate(template: InsertMoodBoardTemplate): Promise<MoodBoardTemplate> {
    const [moodTemplate] = await db.insert(moodBoardTemplates).values(template).returning();
    return moodTemplate;
  }

  async createSkillCategory(category: InsertSkillCategory): Promise<SkillCategory> {
    const [skillCategory] = await db.insert(skillCategories).values(category).returning();
    return skillCategory;
  }

  // Question management operations
  async getAllQuestions(): Promise<Question[]> {
    return await db.select().from(questions).orderBy(desc(questions.createdAt));
  }

  async createQuestion(questionData: any): Promise<Question> {
    const [question] = await db.insert(questions).values(questionData).returning();
    return question;
  }

  async updateQuestion(id: number, data: any): Promise<Question> {
    const [question] = await db.update(questions).set({ ...data, updatedAt: new Date() }).where(eq(questions.id, id)).returning();
    return question;
  }

  async deleteQuestion(id: number): Promise<void> {
    await db.delete(questions).where(eq(questions.id, id));
  }

  async getQuestionCategories(): Promise<any[]> {
    const categories = await db
      .select({ name: questions.category, count: count(questions.id) })
      .from(questions)
      .where(eq(questions.isActive, true))
      .groupBy(questions.category)
      .orderBy(questions.category);
    return categories;
  }

  // Resume import operations for external integrations
  async importResumeFromExternal(userId: string, resumeData: any): Promise<Resume> {
    const insertData: InsertResume = {
      userId,
      title: resumeData.fileName || 'Imported Resume',
      content: resumeData.content || '',
      fileName: resumeData.fileName || 'imported-resume.pdf',
      atsScore: resumeData.atsScore || null,
      optimizationSuggestions: resumeData.suggestions || []
    };
    
    return await this.createResume(insertData);
  }

  async validateResumeImportSource(apiKey: string, source: string): Promise<boolean> {
    // This would validate the API key with the external service
    // For now, we'll return true if an API key is provided
    return Boolean(apiKey);
  }

  // Career mood board operations
  async getUserMoodEntries(userId: string): Promise<any[]> {
    const entries = await db.select().from(careerMoodEntries)
      .where(eq(careerMoodEntries.userId, userId))
      .orderBy(desc(careerMoodEntries.createdAt));
    return entries;
  }

  async createMoodEntry(entryData: any): Promise<any> {
    const [moodEntry] = await db.insert(careerMoodEntries).values(entryData).returning();
    return moodEntry;
  }

  async getMoodEntry(id: number, userId: string): Promise<any | null> {
    const [entry] = await db.select().from(careerMoodEntries)
      .where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)));
    return entry || null;
  }

  async updateMoodEntry(id: number, userId: string, data: any): Promise<any> {
    const [entry] = await db.update(careerMoodEntries)
      .set({ ...data, updatedAt: new Date() })
      .where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)))
      .returning();
    return entry;
  }

  async deleteMoodEntry(id: number, userId: string): Promise<void> {
    await db.delete(careerMoodEntries)
      .where(and(eq(careerMoodEntries.id, id), eq(careerMoodEntries.userId, userId)));
  }

  async getMoodBoardTemplates(): Promise<any[]> {
    const templates = await db.select().from(moodBoardTemplates)
      .where(eq(moodBoardTemplates.isPublic, true))
      .orderBy(desc(moodBoardTemplates.usageCount));
    return templates;
  }

  async createMoodBoardTemplate(templateData: any): Promise<any> {
    const [template] = await db.insert(moodBoardTemplates).values(templateData).returning();
    return template;
  }

  // KNOWLEDGE BASE AND SUPPORT SYSTEM IMPLEMENTATION FOR WRELIK.COM
  
  // Knowledge Base Categories
  async getKnowledgeCategories(options: { parentId?: number; includeInactive?: boolean } = {}): Promise<KnowledgeCategory[]> {
    let query = db.select().from(knowledgeCategories);
    
    const conditions = [];
    if (options.parentId !== undefined) {
      conditions.push(eq(knowledgeCategories.parentId, options.parentId));
    }
    if (!options.includeInactive) {
      conditions.push(eq(knowledgeCategories.isActive, true));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(knowledgeCategories.sortOrder, knowledgeCategories.name);
  }

  async createKnowledgeCategory(data: InsertKnowledgeCategory): Promise<KnowledgeCategory> {
    const [category] = await db.insert(knowledgeCategories).values(data).returning();
    return category;
  }

  async updateKnowledgeCategory(id: number, data: Partial<KnowledgeCategory>): Promise<KnowledgeCategory> {
    const [category] = await db.update(knowledgeCategories)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(knowledgeCategories.id, id))
      .returning();
    return category;
  }

  // Knowledge Base Articles
  async getKnowledgeArticles(options: { 
    categoryId?: number; 
    search?: string; 
    status?: string; 
    limit: number; 
    offset: number; 
    tags?: string[] 
  }): Promise<any[]> {
    try {
      let queryText = `
        SELECT id, title, content, excerpt, slug, category, tags, status, 
               author_id, author_name, created_at, updated_at, view_count, 
               helpful_count, published_at
        FROM knowledge_articles 
        WHERE is_public = true
      `;
      
      if (options.search) {
        queryText += ` AND (title ILIKE '%${options.search}%' OR content ILIKE '%${options.search}%')`;
      }
      
      if (options.status && options.status !== 'published') {
        queryText += ` AND status = '${options.status}'`;
      }
      
      queryText += ` ORDER BY created_at DESC LIMIT ${options.limit} OFFSET ${options.offset}`;
      
      const result = await db.execute(sql.raw(queryText));
      return result.rows || [];
    } catch (error) {
      console.error('Error in getKnowledgeArticles:', error);
      return [];
    }
  }

  async getKnowledgeArticleBySlug(slug: string): Promise<KnowledgeArticle | undefined> {
    const [article] = await db.select().from(knowledgeArticles)
      .where(and(
        eq(knowledgeArticles.slug, slug),
        eq(knowledgeArticles.status, 'published')
      ));
    return article;
  }

  async createKnowledgeArticle(data: InsertKnowledgeArticle): Promise<KnowledgeArticle> {
    const [article] = await db.insert(knowledgeArticles).values(data).returning();
    return article;
  }

  async updateKnowledgeArticle(id: number, data: Partial<KnowledgeArticle>): Promise<KnowledgeArticle> {
    const [article] = await db.update(knowledgeArticles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(knowledgeArticles.id, id))
      .returning();
    return article;
  }

  async incrementArticleViewCount(id: number): Promise<void> {
    await db.update(knowledgeArticles)
      .set({ viewCount: sql`${knowledgeArticles.viewCount} + 1` })
      .where(eq(knowledgeArticles.id, id));
  }

  async updateArticleHelpfulness(id: number, isHelpful: boolean): Promise<void> {
    if (isHelpful) {
      await db.update(knowledgeArticles)
        .set({ helpfulCount: sql`${knowledgeArticles.helpfulCount} + 1` })
        .where(eq(knowledgeArticles.id, id));
    } else {
      // Note: 'notHelpfulCount' column doesn't exist in current schema
      // This would need to be added to the database schema if required
      console.log(`Article ${id} marked as not helpful`);
    }
  }

  // FAQ Items
  async getFaqItems(options: { categoryId?: number; search?: string; limit: number }): Promise<FaqItem[]> {
    let query = db.select().from(faqItems).where(eq(faqItems.isActive, true));
    
    const conditions = [eq(faqItems.isActive, true)];
    if (options.categoryId) {
      conditions.push(eq(faqItems.categoryId, options.categoryId));
    }
    if (options.search) {
      conditions.push(
        sql`(${faqItems.question} ILIKE ${`%${options.search}%`} OR 
            ${faqItems.answer} ILIKE ${`%${options.search}%`})`
      );
    }
    
    return await db.select().from(faqItems)
      .where(and(...conditions))
      .orderBy(faqItems.sortOrder, faqItems.question)
      .limit(options.limit);
  }

  async createFaqItem(data: InsertFaqItem): Promise<FaqItem> {
    const [faq] = await db.insert(faqItems).values(data).returning();
    return faq;
  }

  async updateFaqItem(id: number, data: Partial<FaqItem>): Promise<FaqItem> {
    const [faq] = await db.update(faqItems)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(faqItems.id, id))
      .returning();
    return faq;
  }

  async updateFaqHelpfulness(id: number, isHelpful: boolean): Promise<void> {
    if (isHelpful) {
      await db.update(faqItems)
        .set({ helpfulCount: sql`${faqItems.helpfulCount} + 1` })
        .where(eq(faqItems.id, id));
    } else {
      await db.update(faqItems)
        .set({ notHelpfulCount: sql`${faqItems.notHelpfulCount} + 1` })
        .where(eq(faqItems.id, id));
    }
  }

  // Support Tickets
  async getSupportTickets(options: { 
    status?: string; 
    priority?: string; 
    assignedTo?: string; 
    categoryId?: number; 
    customerEmail?: string; 
    limit: number; 
    offset: number; 
    sortBy: string; 
    sortOrder: string 
  }): Promise<SupportTicket[]> {
    let query = db.select().from(supportTickets);
    
    const conditions = [];
    if (options.status) {
      conditions.push(eq(supportTickets.status, options.status as any));
    }
    if (options.priority) {
      conditions.push(eq(supportTickets.priority, options.priority as any));
    }
    if (options.assignedTo) {
      conditions.push(eq(supportTickets.assignedToId, options.assignedTo));
    }
    if (options.categoryId) {
      conditions.push(eq(supportTickets.categoryId, options.categoryId));
    }
    if (options.customerEmail) {
      conditions.push(eq(supportTickets.customerEmail, options.customerEmail));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    const orderColumn = options.sortBy === 'created_at' ? supportTickets.createdAt : supportTickets.lastActivityAt;
    const orderDirection = options.sortOrder === 'asc' ? orderColumn : desc(orderColumn);
    
    return await query
      .orderBy(orderDirection)
      .limit(options.limit)
      .offset(options.offset);
  }

  async getSupportTicketWithMessages(id: number): Promise<SupportTicket & { messages: SupportTicketMessage[] } | undefined> {
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.id, id));
    
    if (!ticket) return undefined;
    
    const messages = await db.select().from(supportTicketMessages)
      .where(eq(supportTicketMessages.ticketId, id))
      .orderBy(supportTicketMessages.createdAt);
    
    return { ...ticket, messages };
  }

  async createSupportTicket(data: InsertSupportTicket): Promise<SupportTicket> {
    const [ticket] = await db.insert(supportTickets).values(data).returning();
    return ticket;
  }

  async updateSupportTicket(id: number, data: Partial<SupportTicket>): Promise<SupportTicket> {
    const [ticket] = await db.update(supportTickets)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(supportTickets.id, id))
      .returning();
    return ticket;
  }

  async createSupportTicketMessage(data: InsertSupportTicketMessage): Promise<SupportTicketMessage> {
    const [message] = await db.insert(supportTicketMessages).values(data).returning();
    return message;
  }

  async updateTicketLastActivity(ticketId: number): Promise<void> {
    await db.update(supportTickets)
      .set({ lastActivityAt: new Date() })
      .where(eq(supportTickets.id, ticketId));
  }

  async setFirstResponseTime(ticketId: number): Promise<void> {
    await db.update(supportTickets)
      .set({ firstResponseAt: new Date() })
      .where(and(
        eq(supportTickets.id, ticketId),
        sql`${supportTickets.firstResponseAt} IS NULL`
      ));
  }

  // Support Tags
  async getSupportTags(): Promise<SupportTag[]> {
    return await db.select().from(supportTags)
      .where(eq(supportTags.isActive, true))
      .orderBy(desc(supportTags.usageCount), supportTags.name);
  }

  async createSupportTag(data: InsertSupportTag): Promise<SupportTag> {
    const [tag] = await db.insert(supportTags).values(data).returning();
    return tag;
  }

  // Knowledge Base Feedback
  async createKnowledgeBaseFeedback(data: InsertKnowledgeBaseFeedback): Promise<KnowledgeBaseFeedback> {
    const [feedback] = await db.insert(knowledgeBaseFeedback).values(data).returning();
    return feedback;
  }

  // Analytics and Stats
  async getSupportAnalytics(options: { startDate: Date; endDate: Date; period: string }): Promise<any> {
    const ticketStats = await db.select({
      totalTickets: count(),
      openTickets: sum(sql`CASE WHEN ${supportTickets.status} = 'open' THEN 1 ELSE 0 END`),
      resolvedTickets: sum(sql`CASE WHEN ${supportTickets.status} = 'resolved' THEN 1 ELSE 0 END`)
    }).from(supportTickets)
    .where(and(
      sql`${supportTickets.createdAt} >= ${options.startDate}`,
      sql`${supportTickets.createdAt} <= ${options.endDate}`
    ));

    return {
      period: options.period,
      startDate: options.startDate,
      endDate: options.endDate,
      ...ticketStats[0]
    };
  }

  async getRealTimeSupportMetrics(): Promise<any> {
    const openTickets = await db.select({ count: count() })
      .from(supportTickets)
      .where(eq(supportTickets.status, 'open'));
    
    const todayTickets = await db.select({ count: count() })
      .from(supportTickets)
      .where(sql`DATE(${supportTickets.createdAt}) = CURRENT_DATE`);

    return {
      openTickets: openTickets[0].count,
      todayTickets: todayTickets[0].count,
      timestamp: new Date()
    };
  }

  async getKnowledgeBaseStats(): Promise<any> {
    const articleStats = await db.select({
      totalArticles: count(),
      publishedArticles: sum(sql`CASE WHEN ${knowledgeArticles.status} = 'published' THEN 1 ELSE 0 END`)
    }).from(knowledgeArticles);

    const faqStats = await db.select({
      totalFaqs: count()
    }).from(faqItems).where(eq(faqItems.isActive, true));

    return {
      ...articleStats[0],
      ...faqStats[0]
    };
  }

  // Search and Featured Content
  async searchKnowledgeBase(options: { query: string; type: string; limit: number }): Promise<any> {
    try {
      const results = { articles: [], faqs: [] };
      
      if (options.type === 'all' || options.type === 'articles') {
        const articleQuery = `
          SELECT id, title, content, excerpt, slug, category, tags, status, 
                 author_id, author_name, created_at, updated_at, view_count, 
                 helpful_count, published_at
          FROM knowledge_articles 
          WHERE status = 'published' AND is_public = true
            AND (title ILIKE '%${options.query}%' OR content ILIKE '%${options.query}%')
          ORDER BY view_count DESC, helpful_count DESC
          LIMIT ${options.limit}
        `;
        const articleResult = await db.execute(sql.raw(articleQuery));
        results.articles = articleResult.rows || [];
      }
      
      if (options.type === 'all' || options.type === 'faqs') {
        const faqQuery = `
          SELECT id, question, answer, category_id, sort_order, is_active, 
                 view_count, helpful_count, not_helpful_count, tags, created_at, updated_at
          FROM faq_items 
          WHERE is_active = true 
            AND (question ILIKE '%${options.query}%' OR answer ILIKE '%${options.query}%')
          ORDER BY helpful_count DESC, view_count DESC
          LIMIT ${options.limit}
        `;
        const faqResult = await db.execute(sql.raw(faqQuery));
        results.faqs = faqResult.rows || [];
      }
      
      return results;
    } catch (error) {
      console.error('Error in searchKnowledgeBase:', error);
      return { articles: [], faqs: [] };
    }
  }

  async getFeaturedKnowledgeContent(options: { type: string; limit: number }): Promise<any> {
    try {
      if (options.type === 'articles') {
        const articleQuery = `
          SELECT id, title, content, excerpt, slug, category, tags, status, 
                 author_id, author_name, created_at, updated_at, view_count, 
                 helpful_count, published_at
          FROM knowledge_articles 
          WHERE status = 'published' AND is_public = true
          ORDER BY view_count DESC, helpful_count DESC, created_at DESC
          LIMIT ${options.limit}
        `;
        const result = await db.execute(sql.raw(articleQuery));
        return result.rows || [];
      }
      
      if (options.type === 'faqs') {
        const faqQuery = `
          SELECT id, question, answer, category_id, sort_order, is_active, 
                 view_count, helpful_count, not_helpful_count, tags, created_at, updated_at
          FROM faq_items 
          WHERE is_active = true 
          ORDER BY helpful_count DESC, view_count DESC, created_at DESC
          LIMIT ${options.limit}
        `;
        const result = await db.execute(sql.raw(faqQuery));
        return result.rows || [];
      }
      
      return [];
    } catch (error) {
      console.error('Error in getFeaturedKnowledgeContent:', error);
      return [];
    }
  }

  async bulkImportKnowledgeContent(data: { 
    articles: any[]; 
    faqs: any[]; 
    categories: any[]; 
    authorId: string 
  }): Promise<any> {
    const results = { categories: [], articles: [], faqs: [] };
    
    // Import categories first
    if (data.categories.length > 0) {
      results.categories = await db.insert(knowledgeCategories)
        .values(data.categories)
        .returning();
    }
    
    // Import articles
    if (data.articles.length > 0) {
      const articlesWithAuthor = data.articles.map(article => ({
        ...article,
        authorId: data.authorId,
        publishedAt: article.status === 'published' ? new Date() : null
      }));
      results.articles = await db.insert(knowledgeArticles)
        .values(articlesWithAuthor)
        .returning();
    }
    
    // Import FAQs
    if (data.faqs.length > 0) {
      results.faqs = await db.insert(faqItems)
        .values(data.faqs)
        .returning();
    }
    
    return results;
  }
}

export const storage = new DatabaseStorage();