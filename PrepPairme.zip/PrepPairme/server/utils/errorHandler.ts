import type { Response } from "express";

export function handleServerError(res: Response, error: any, context?: string) {
  console.error(`Error in ${context || 'server operation'}:`, error);
  
  // In production, send generic error messages to prevent information leakage
  const isProduction = process.env.NODE_ENV === 'production';
  const message = isProduction 
    ? "An internal server error occurred"
    : error instanceof Error 
      ? error.message 
      : "Unknown error occurred";
  
  res.status(500).json({ 
    message,
    ...(isProduction ? {} : { stack: error?.stack })
  });
}

export function handleValidationError(res: Response, message: string) {
  res.status(400).json({ message });
}

export function handleUnauthorizedError(res: Response, message = "Unauthorized") {
  res.status(401).json({ message });
}

export function handleForbiddenError(res: Response, message = "Forbidden") {
  res.status(403).json({ message });
}

export function handleNotFoundError(res: Response, message = "Resource not found") {
  res.status(404).json({ message });
}