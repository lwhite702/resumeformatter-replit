#!/usr/bin/env node

/**
 * WordPress Blog Post Caching Runner
 * 
 * This script runs the WordPress post caching system.
 * Can be used for manual runs or scheduled via cron.
 * 
 * Usage:
 * - Manual: node server/wp-cache-runner.js
 * - Cron: 0 */6 * * * cd /path/to/project && node server/wp-cache-runner.js
 */

const { spawn } = require('child_process');
const path = require('path');

console.log(`[${new Date().toISOString()}] Starting WordPress cache update...`);

// Run the TypeScript caching script
const child = spawn('npx', ['tsx', 'server/cacheWpPosts.ts'], {
  stdio: 'inherit',
  cwd: process.cwd()
});

child.on('close', (code) => {
  if (code === 0) {
    console.log(`[${new Date().toISOString()}] ✅ WordPress cache update completed successfully`);
  } else {
    console.error(`[${new Date().toISOString()}] ❌ WordPress cache update failed with exit code ${code}`);
    process.exit(code);
  }
});

child.on('error', (error) => {
  console.error(`[${new Date().toISOString()}] Error running WordPress cache script:`, error);
  process.exit(1);
});