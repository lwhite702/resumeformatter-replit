import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  decimal,
  uuid,
  pgEnum,
  primaryKey,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["user", "admin", "super_admin"]);
export const subscriptionTierEnum = pgEnum("subscription_tier", ["free", "pro_monthly", "pro_quarterly", "career_coach"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", ["active", "inactive", "cancelled", "past_due", "trialing"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "completed", "failed", "refunded"]);
export const applicationStatusEnum = pgEnum("application_status", ["applied", "in_review", "interviewed", "offered", "rejected", "withdrawn"]);
export const moodEnum = pgEnum("mood", ["excited", "confident", "nervous", "frustrated", "hopeful", "overwhelmed", "motivated", "exhausted", "optimistic", "anxious"]);
export const supportTicketStatusEnum = pgEnum("support_ticket_status", ["open", "in_progress", "waiting_for_customer", "resolved", "closed", "cancelled"]);
export const supportTicketPriorityEnum = pgEnum("support_ticket_priority", ["low", "normal", "high", "urgent"]);
export const knowledgeArticleStatusEnum = pgEnum("knowledge_article_status", ["draft", "published", "archived", "under_review"]);

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Teams table for Career Coach subscriptions
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  ownerId: varchar("owner_id").notNull(),
  maxUsers: integer("max_users").default(3).notNull(),
  currentUsers: integer("current_users").default(1).notNull(),
  subscriptionTier: subscriptionTierEnum("subscription_tier").default("career_coach").notNull(),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  subscriptionStatus: subscriptionStatusEnum("subscription_status").default("inactive"),
  subscriptionEndsAt: timestamp("subscription_ends_at"),
  billingCycle: varchar("billing_cycle").default("quarterly").notNull(),
  pricePerUser: decimal("price_per_user", { precision: 10, scale: 2 }).default("39.00").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Team invitations
export const teamInvitations = pgTable("team_invitations", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull().references(() => teams.id),
  email: varchar("email").notNull(),
  invitedBy: varchar("invited_by").notNull(),
  token: varchar("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  acceptedAt: timestamp("accepted_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Users table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").default("user").notNull(),
  credits: integer("credits").default(10).notNull(),
  isPro: boolean("is_pro").default(false).notNull(),
  subscriptionTier: subscriptionTierEnum("subscription_tier").default("free").notNull(),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  subscriptionStatus: subscriptionStatusEnum("subscription_status").default("inactive"),
  subscriptionEndsAt: timestamp("subscription_ends_at"),
  teamId: integer("team_id"),
  isTeamOwner: boolean("is_team_owner").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
  isActive: boolean("is_active").default(true).notNull(),
});

// Admin Activity Logs
export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminId: varchar("admin_id").notNull().references(() => users.id),
  action: varchar("action").notNull(),
  targetType: varchar("target_type"), // user, payment, template, etc.
  targetId: varchar("target_id"),
  details: jsonb("details"),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payments table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  stripePaymentIntentId: varchar("stripe_payment_intent_id").unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency").default("usd").notNull(),
  status: paymentStatusEnum("status").default("pending").notNull(),
  description: text("description"),
  metadata: jsonb("metadata"),
  refundedAmount: decimal("refunded_amount", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Credit Transactions
export const creditTransactions = pgTable("credit_transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(), // positive for credit, negative for debit
  type: varchar("type").notNull(), // purchase, usage, refund, admin_grant
  description: text("description"),
  relatedId: varchar("related_id"), // payment_id, feature_usage_id, etc.
  adminId: varchar("admin_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Resume Templates
export const resumeTemplates = pgTable("resume_templates", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  category: varchar("category").notNull(),
  industry: varchar("industry"),
  templateData: jsonb("template_data").notNull(),
  previewImageUrl: varchar("preview_image_url"),
  isPremium: boolean("is_premium").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdBy: varchar("created_by").references(() => users.id),
  usageCount: integer("usage_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// System Settings
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key").unique().notNull(),
  value: text("value").notNull(),
  description: text("description"),
  category: varchar("category").default("general"),
  isPublic: boolean("is_public").default(false).notNull(),
  updatedBy: varchar("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Existing tables (resuming from previous schema)
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  templateId: integer("template_id").references(() => resumeTemplates.id),
  fileName: varchar("file_name"),
  fileSize: integer("file_size"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  lastOptimizedAt: timestamp("last_optimized_at"),
  atsScore: integer("ats_score"),
  optimizationSuggestions: jsonb("optimization_suggestions"),
  skillHighlights: jsonb("skill_highlights"), // Generated skill highlights
  lastSkillAnalysisAt: timestamp("last_skill_analysis_at"),
});

// Skill Highlights table for storing extracted and generated skills
export const skillHighlights = pgTable("skill_highlights", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  skillName: varchar("skill_name").notNull(),
  category: varchar("category").notNull(), // technical, soft, industry, certification
  proficiencyLevel: varchar("proficiency_level"), // beginner, intermediate, advanced, expert
  yearsOfExperience: integer("years_of_experience"),
  contextualExamples: jsonb("contextual_examples"), // Where this skill was mentioned/used
  relevanceScore: integer("relevance_score"), // 1-100 based on job market demand
  isAIGenerated: boolean("is_ai_generated").default(true).notNull(),
  isUserVerified: boolean("is_user_verified").default(false).notNull(),
  extractedFrom: varchar("extracted_from"), // resume_text, job_description, user_input
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Skill Categories for organization
export const skillCategories = pgTable("skill_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  description: text("description"),
  color: varchar("color").default("#3B82F6"), // For UI display
  icon: varchar("icon"), // Icon name for UI
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobPostings = pgTable("job_postings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  company: varchar("company").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements"),
  location: varchar("location"),
  salaryRange: varchar("salary_range"),
  jobType: varchar("job_type"),
  url: varchar("url"),
  addedAt: timestamp("added_at").defaultNow(),
});

export const interviewGuides = pgTable("interview_guides", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobPostingId: integer("job_posting_id").references(() => jobPostings.id),
  resumeId: integer("resume_id").references(() => resumes.id),
  title: varchar("title").notNull(),
  content: jsonb("content").notNull(),
  generatedAt: timestamp("generated_at").defaultNow(),
});

export const thankYouNotes = pgTable("thank_you_notes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  interviewGuideId: integer("interview_guide_id").references(() => interviewGuides.id),
  content: text("content").notNull(),
  recipientName: varchar("recipient_name"),
  recipientEmail: varchar("recipient_email"),
  subject: varchar("subject"),
  generatedAt: timestamp("generated_at").defaultNow(),
  sentAt: timestamp("sent_at"),
});

export const reflections = pgTable("reflections", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  interviewGuideId: integer("interview_guide_id").references(() => interviewGuides.id),
  content: text("content").notNull(),
  mood: varchar("mood"),
  confidence: integer("confidence"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  category: varchar("category").notNull(),
  question: text("question").notNull(),
  answer: text("answer"), // Keep existing column name for compatibility
  sampleAnswer: text("sample_answer"), // Add new column name
  explanation: text("explanation"),
  tags: jsonb("tags"),
  difficulty: varchar("difficulty"),
  industry: varchar("industry"),
  isActive: boolean("is_active").default(true).notNull(),
  isHighlighted: boolean("is_highlighted").default(false).notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const videoPracticeSessions = pgTable("video_practice_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  questionId: integer("question_id").references(() => questions.id),
  sessionTitle: varchar("session_title").notNull(),
  videoPath: varchar("video_path"),
  duration: integer("duration"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const videoFeedback = pgTable("video_feedback", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => videoPracticeSessions.id),
  overallScore: integer("overall_score").notNull(),
  contentScore: integer("content_score").notNull(),
  deliveryScore: integer("delivery_score").notNull(),
  clarityScore: integer("clarity_score").notNull(),
  confidenceScore: integer("confidence_score").notNull(),
  strengths: jsonb("strengths").notNull(),
  improvements: jsonb("improvements").notNull(),
  keyInsights: jsonb("key_insights").notNull(),
  speakingPace: varchar("speaking_pace").notNull(),
  fillerWords: integer("filler_words").notNull(),
  eyeContact: varchar("eye_contact").notNull(),
  bodyLanguage: varchar("body_language").notNull(),
  practiceAreas: jsonb("practice_areas").notNull(),
  suggestedQuestions: jsonb("suggested_questions").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobBoardIntegrations = pgTable("job_board_integrations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobBoard: varchar("job_board").notNull(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true).notNull(),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const externalApplications = pgTable("external_applications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  integrationId: integer("integration_id").references(() => jobBoardIntegrations.id),
  externalId: varchar("external_id").notNull(),
  jobBoard: varchar("job_board").notNull(),
  jobTitle: varchar("job_title").notNull(),
  company: varchar("company").notNull(),
  location: varchar("location"),
  jobUrl: varchar("job_url"),
  description: text("description"),
  requirements: text("requirements"),
  salaryRange: varchar("salary_range"),
  jobType: varchar("job_type"),
  applicationStatus: applicationStatusEnum("application_status").notNull(),
  appliedAt: timestamp("applied_at").notNull(),
  lastUpdatedAt: timestamp("last_updated_at"),
  resumeUsed: varchar("resume_used"),
  coverLetter: text("cover_letter"),
  notes: text("notes"),
  rawData: jsonb("raw_data"),
  syncedAt: timestamp("synced_at").defaultNow(),
});

export const applicationEvents = pgTable("application_events", {
  id: serial("id").primaryKey(),
  applicationId: integer("application_id").notNull().references(() => externalApplications.id),
  eventType: varchar("event_type").notNull(),
  eventData: jsonb("event_data"),
  eventDate: timestamp("event_date").notNull(),
  description: text("description"),
  isAutomated: boolean("is_automated").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const industryModels = pgTable("industry_models", {
  id: serial("id").primaryKey(),
  industry: varchar("industry").notNull().unique(),
  modelId: varchar("model_id"),
  status: varchar("status").default("inactive").notNull(),
  trainingJobId: varchar("training_job_id"),
  performanceMetrics: jsonb("performance_metrics"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trainingData = pgTable("training_data", {
  id: serial("id").primaryKey(),
  industry: varchar("industry").notNull(),
  prompt: text("prompt").notNull(),
  completion: text("completion").notNull(),
  category: varchar("category").notNull(),
  isValidated: boolean("is_validated").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Career visualization tables
// Career Path Tables
export const careerPaths = pgTable("career_paths", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  description: text("description"),
  industry: varchar("industry").notNull(),
  isPublic: boolean("is_public").default(false).notNull(),
  isTemplate: boolean("is_template").default(false).notNull(),
  templateId: integer("template_id").references(() => careerPaths.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const careerPathNodes = pgTable("career_path_nodes", {
  id: serial("id").primaryKey(),
  pathId: integer("path_id").notNull().references(() => careerPaths.id),
  title: varchar("title").notNull(),
  description: text("description"),
  level: varchar("level").notNull(), // entry, mid, senior, executive
  salaryRange: varchar("salary_range"),
  requiredSkills: jsonb("required_skills").$type<string[]>(),
  timeToReach: integer("time_to_reach"), // months
  positionX: decimal("position_x").notNull(),
  positionY: decimal("position_y").notNull(),
  nodeType: varchar("node_type").notNull(), // role, milestone, skill, certification
  isCompleted: boolean("is_completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
  marketDemand: integer("market_demand"), // 1-100
  growthRate: decimal("growth_rate"), // percentage
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const careerPathConnections = pgTable("career_path_connections", {
  id: serial("id").primaryKey(),
  pathId: integer("path_id").notNull().references(() => careerPaths.id),
  fromNodeId: integer("from_node_id").notNull().references(() => careerPathNodes.id),
  toNodeId: integer("to_node_id").notNull().references(() => careerPathNodes.id),
  connectionType: varchar("connection_type").notNull(), // direct, alternative, optional
  description: text("description"),
  probability: decimal("probability"), // 0-1
  timeRequired: integer("time_required"), // months
  difficulty: varchar("difficulty"), // easy, medium, hard
  createdAt: timestamp("created_at").defaultNow(),
});

export const industryTrends = pgTable("industry_trends", {
  id: serial("id").primaryKey(),
  industry: varchar("industry").notNull(),
  position: varchar("position").notNull(),
  metric: varchar("metric").notNull(), // salary, growth, demand, satisfaction
  value: decimal("value").notNull(),
  period: varchar("period").notNull(), // Q1-2024, 2024, etc.
  source: varchar("source").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow(),
  metadata: jsonb("metadata"),
  trend: varchar("trend").notNull(), // up, down, stable
  confidence: integer("confidence").notNull(), // 1-100
  createdAt: timestamp("created_at").defaultNow(),
});

export const careerMoodEntries = pgTable("career_mood_entries", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  mood: moodEnum("mood").notNull(),
  emoji: varchar("emoji").notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  category: varchar("category").notNull(), // application, interview, networking, learning, milestone, setback
  tags: jsonb("tags").$type<string[]>(),
  intensity: integer("intensity").notNull(), // 1-10 scale
  location: varchar("location"), // where they were when feeling this
  weatherMood: varchar("weather_mood"), // sunny, cloudy, rainy to add fun context
  linkedApplicationId: integer("linked_application_id").references(() => externalApplications.id),
  linkedJobId: integer("linked_job_id").references(() => jobPostings.id),
  goals: jsonb("goals").$type<string[]>(),
  gratitude: text("gratitude"), // what they're grateful for
  learnings: text("learnings"), // what they learned that day
  tomorrowFocus: text("tomorrow_focus"), // what they want to focus on tomorrow
  isPrivate: boolean("is_private").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const moodBoardTemplates = pgTable("mood_board_templates", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  category: varchar("category").notNull(), // daily, weekly, milestone, reflection
  prompts: jsonb("prompts").$type<string[]>(),
  suggestedMoods: jsonb("suggested_moods").$type<string[]>(),
  isPublic: boolean("is_public").default(false).notNull(),
  createdBy: varchar("created_by").references(() => users.id),
  usageCount: integer("usage_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Knowledge Base and Support System Tables for Wrelik.com Integration

// Knowledge Base Categories
export const knowledgeCategories = pgTable("knowledge_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  slug: varchar("slug").notNull().unique(),
  description: text("description"),
  parentId: integer("parent_id"),
  sortOrder: integer("sort_order").default(0),
  color: varchar("color").default("#3B82F6"),
  icon: varchar("icon"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Knowledge Base Articles
export const knowledgeArticles = pgTable("knowledge_articles", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  slug: varchar("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  categoryId: integer("category_id").notNull().references(() => knowledgeCategories.id),
  authorId: varchar("author_id").notNull().references(() => users.id),
  status: knowledgeArticleStatusEnum("status").default("draft").notNull(),
  tags: jsonb("tags"),
  metadata: jsonb("metadata"), // SEO, custom fields, etc.
  featuredImageUrl: varchar("featured_image_url"),
  viewCount: integer("view_count").default(0).notNull(),
  helpfulCount: integer("helpful_count").default(0).notNull(),
  notHelpfulCount: integer("not_helpful_count").default(0).notNull(),
  searchKeywords: text("search_keywords"), // For improved search
  relatedArticleIds: jsonb("related_article_ids"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Support Tickets
export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  ticketNumber: varchar("ticket_number").notNull().unique(),
  userId: varchar("user_id").references(() => users.id),
  customerEmail: varchar("customer_email").notNull(),
  customerName: varchar("customer_name"),
  subject: varchar("subject").notNull(),
  description: text("description").notNull(),
  status: supportTicketStatusEnum("status").default("open").notNull(),
  priority: supportTicketPriorityEnum("priority").default("normal").notNull(),
  assignedToId: varchar("assigned_to_id").references(() => users.id),
  categoryId: integer("category_id").references(() => knowledgeCategories.id),
  source: varchar("source").default("web").notNull(), // web, email, chat, phone
  metadata: jsonb("metadata"), // Browser info, system info, etc.
  tags: jsonb("tags"),
  resolvedAt: timestamp("resolved_at"),
  firstResponseAt: timestamp("first_response_at"),
  lastActivityAt: timestamp("last_activity_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Support Ticket Messages
export const supportTicketMessages = pgTable("support_ticket_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => supportTickets.id),
  senderId: varchar("sender_id").references(() => users.id),
  senderEmail: varchar("sender_email").notNull(),
  senderName: varchar("sender_name").notNull(),
  message: text("message").notNull(),
  isInternal: boolean("is_internal").default(false).notNull(),
  attachments: jsonb("attachments"),
  messageType: varchar("message_type").default("message").notNull(), // message, note, status_change
  createdAt: timestamp("created_at").defaultNow(),
});

// FAQ Items
export const faqItems = pgTable("faq_items", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  categoryId: integer("category_id").references(() => knowledgeCategories.id),
  sortOrder: integer("sort_order").default(0),
  isActive: boolean("is_active").default(true).notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  helpfulCount: integer("helpful_count").default(0).notNull(),
  notHelpfulCount: integer("not_helpful_count").default(0).notNull(),
  tags: jsonb("tags"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Support Analytics
export const supportAnalytics = pgTable("support_analytics", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  totalTickets: integer("total_tickets").default(0).notNull(),
  openTickets: integer("open_tickets").default(0).notNull(),
  resolvedTickets: integer("resolved_tickets").default(0).notNull(),
  avgResolutionTime: integer("avg_resolution_time"), // in minutes
  avgFirstResponseTime: integer("avg_first_response_time"), // in minutes
  customerSatisfactionScore: decimal("customer_satisfaction_score", { precision: 3, scale: 2 }),
  topCategories: jsonb("top_categories"),
  agentPerformance: jsonb("agent_performance"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Knowledge Base Feedback
export const knowledgeBaseFeedback = pgTable("knowledge_base_feedback", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").references(() => knowledgeArticles.id),
  faqId: integer("faq_id").references(() => faqItems.id),
  userId: varchar("user_id").references(() => users.id),
  userEmail: varchar("user_email"),
  isHelpful: boolean("is_helpful").notNull(),
  feedback: text("feedback"),
  suggestions: text("suggestions"),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Support Tags for categorization
export const supportTags = pgTable("support_tags", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  color: varchar("color").default("#3B82F6"),
  description: text("description"),
  usageCount: integer("usage_count").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// WordPress Blog Post Cache
export const cachedPosts = pgTable("cached_posts", {
  id: serial("id").primaryKey(),
  wpId: integer("wp_id").notNull().unique(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  publishedAt: timestamp("published_at").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  resumes: many(resumes),
  jobPostings: many(jobPostings),
  interviewGuides: many(interviewGuides),
  thankYouNotes: many(thankYouNotes),
  reflections: many(reflections),
  videoPracticeSessions: many(videoPracticeSessions),
  jobBoardIntegrations: many(jobBoardIntegrations),
  externalApplications: many(externalApplications),
  payments: many(payments),
  creditTransactions: many(creditTransactions),
  adminLogs: many(adminLogs),
  careerPaths: many(careerPaths),
  careerMoodEntries: many(careerMoodEntries),
  moodBoardTemplates: many(moodBoardTemplates),
}));

export const resumesRelations = relations(resumes, ({ one, many }) => ({
  user: one(users, { fields: [resumes.userId], references: [users.id] }),
  template: one(resumeTemplates, { fields: [resumes.templateId], references: [resumeTemplates.id] }),
  interviewGuides: many(interviewGuides),
  skillHighlights: many(skillHighlights),
}));

export const skillHighlightsRelations = relations(skillHighlights, ({ one }) => ({
  resume: one(resumes, { fields: [skillHighlights.resumeId], references: [resumes.id] }),
  user: one(users, { fields: [skillHighlights.userId], references: [users.id] }),
}));

export const jobPostingsRelations = relations(jobPostings, ({ one, many }) => ({
  user: one(users, { fields: [jobPostings.userId], references: [users.id] }),
  interviewGuides: many(interviewGuides),
}));

export const interviewGuidesRelations = relations(interviewGuides, ({ one, many }) => ({
  user: one(users, { fields: [interviewGuides.userId], references: [users.id] }),
  jobPosting: one(jobPostings, { fields: [interviewGuides.jobPostingId], references: [jobPostings.id] }),
  resume: one(resumes, { fields: [interviewGuides.resumeId], references: [resumes.id] }),
  thankYouNotes: many(thankYouNotes),
  reflections: many(reflections),
}));

export const thankYouNotesRelations = relations(thankYouNotes, ({ one }) => ({
  user: one(users, { fields: [thankYouNotes.userId], references: [users.id] }),
  interviewGuide: one(interviewGuides, { fields: [thankYouNotes.interviewGuideId], references: [interviewGuides.id] }),
}));

export const reflectionsRelations = relations(reflections, ({ one }) => ({
  user: one(users, { fields: [reflections.userId], references: [users.id] }),
  interviewGuide: one(interviewGuides, { fields: [reflections.interviewGuideId], references: [interviewGuides.id] }),
}));

export const videoPracticeSessionsRelations = relations(videoPracticeSessions, ({ one, many }) => ({
  user: one(users, { fields: [videoPracticeSessions.userId], references: [users.id] }),
  question: one(questions, { fields: [videoPracticeSessions.questionId], references: [questions.id] }),
  feedback: many(videoFeedback),
}));

export const videoFeedbackRelations = relations(videoFeedback, ({ one }) => ({
  session: one(videoPracticeSessions, { fields: [videoFeedback.sessionId], references: [videoPracticeSessions.id] }),
}));

export const jobBoardIntegrationsRelations = relations(jobBoardIntegrations, ({ one, many }) => ({
  user: one(users, { fields: [jobBoardIntegrations.userId], references: [users.id] }),
  applications: many(externalApplications),
}));

export const externalApplicationsRelations = relations(externalApplications, ({ one, many }) => ({
  user: one(users, { fields: [externalApplications.userId], references: [users.id] }),
  integration: one(jobBoardIntegrations, { fields: [externalApplications.integrationId], references: [jobBoardIntegrations.id] }),
  events: many(applicationEvents),
}));

export const applicationEventsRelations = relations(applicationEvents, ({ one }) => ({
  application: one(externalApplications, { fields: [applicationEvents.applicationId], references: [externalApplications.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, { fields: [payments.userId], references: [users.id] }),
}));

export const creditTransactionsRelations = relations(creditTransactions, ({ one }) => ({
  user: one(users, { fields: [creditTransactions.userId], references: [users.id] }),
  admin: one(users, { fields: [creditTransactions.adminId], references: [users.id] }),
}));

export const adminLogsRelations = relations(adminLogs, ({ one }) => ({
  admin: one(users, { fields: [adminLogs.adminId], references: [users.id] }),
}));

export const resumeTemplatesRelations = relations(resumeTemplates, ({ one, many }) => ({
  creator: one(users, { fields: [resumeTemplates.createdBy], references: [users.id] }),
  resumes: many(resumes),
}));

export const careerPathsRelations = relations(careerPaths, ({ one, many }) => ({
  user: one(users, { fields: [careerPaths.userId], references: [users.id] }),
  template: one(careerPaths, { fields: [careerPaths.templateId], references: [careerPaths.id] }),
  nodes: many(careerPathNodes),
  connections: many(careerPathConnections),
}));

export const careerPathNodesRelations = relations(careerPathNodes, ({ one }) => ({
  path: one(careerPaths, { fields: [careerPathNodes.pathId], references: [careerPaths.id] }),
}));

export const careerPathConnectionsRelations = relations(careerPathConnections, ({ one }) => ({
  path: one(careerPaths, { fields: [careerPathConnections.pathId], references: [careerPaths.id] }),
  fromNode: one(careerPathNodes, { fields: [careerPathConnections.fromNodeId], references: [careerPathNodes.id] }),
  toNode: one(careerPathNodes, { fields: [careerPathConnections.toNodeId], references: [careerPathNodes.id] }),
}));

export const careerMoodEntriesRelations = relations(careerMoodEntries, ({ one }) => ({
  user: one(users, { fields: [careerMoodEntries.userId], references: [users.id] }),
  linkedApplication: one(externalApplications, { fields: [careerMoodEntries.linkedApplicationId], references: [externalApplications.id] }),
  linkedJob: one(jobPostings, { fields: [careerMoodEntries.linkedJobId], references: [jobPostings.id] }),
}));

export const moodBoardTemplatesRelations = relations(moodBoardTemplates, ({ one }) => ({
  creator: one(users, { fields: [moodBoardTemplates.createdBy], references: [users.id] }),
}));

// Knowledge Base and Support Relations
export const knowledgeCategoriesRelations = relations(knowledgeCategories, ({ one, many }) => ({
  parent: one(knowledgeCategories, { fields: [knowledgeCategories.parentId], references: [knowledgeCategories.id] }),
  children: many(knowledgeCategories),
  articles: many(knowledgeArticles),
  faqs: many(faqItems),
  tickets: many(supportTickets),
}));

export const knowledgeArticlesRelations = relations(knowledgeArticles, ({ one, many }) => ({
  category: one(knowledgeCategories, { fields: [knowledgeArticles.categoryId], references: [knowledgeCategories.id] }),
  author: one(users, { fields: [knowledgeArticles.authorId], references: [users.id] }),
  feedback: many(knowledgeBaseFeedback),
}));

export const supportTicketsRelations = relations(supportTickets, ({ one, many }) => ({
  user: one(users, { fields: [supportTickets.userId], references: [users.id] }),
  assignedTo: one(users, { fields: [supportTickets.assignedToId], references: [users.id] }),
  category: one(knowledgeCategories, { fields: [supportTickets.categoryId], references: [knowledgeCategories.id] }),
  messages: many(supportTicketMessages),
}));

export const supportTicketMessagesRelations = relations(supportTicketMessages, ({ one }) => ({
  ticket: one(supportTickets, { fields: [supportTicketMessages.ticketId], references: [supportTickets.id] }),
  sender: one(users, { fields: [supportTicketMessages.senderId], references: [users.id] }),
}));

export const faqItemsRelations = relations(faqItems, ({ one, many }) => ({
  category: one(knowledgeCategories, { fields: [faqItems.categoryId], references: [knowledgeCategories.id] }),
  feedback: many(knowledgeBaseFeedback),
}));

export const knowledgeBaseFeedbackRelations = relations(knowledgeBaseFeedback, ({ one }) => ({
  article: one(knowledgeArticles, { fields: [knowledgeBaseFeedback.articleId], references: [knowledgeArticles.id] }),
  faq: one(faqItems, { fields: [knowledgeBaseFeedback.faqId], references: [faqItems.id] }),
  user: one(users, { fields: [knowledgeBaseFeedback.userId], references: [users.id] }),
}));

// Type exports
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Resume = typeof resumes.$inferSelect;
export type InsertResume = typeof resumes.$inferInsert;
export type SkillHighlight = typeof skillHighlights.$inferSelect;
export type InsertSkillHighlight = typeof skillHighlights.$inferInsert;

// Knowledge Base and Support Types
export type KnowledgeCategory = typeof knowledgeCategories.$inferSelect;
export type InsertKnowledgeCategory = typeof knowledgeCategories.$inferInsert;
export type KnowledgeArticle = typeof knowledgeArticles.$inferSelect;
export type InsertKnowledgeArticle = typeof knowledgeArticles.$inferInsert;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;
export type SupportTicketMessage = typeof supportTicketMessages.$inferSelect;
export type InsertSupportTicketMessage = typeof supportTicketMessages.$inferInsert;
export type FaqItem = typeof faqItems.$inferSelect;
export type InsertFaqItem = typeof faqItems.$inferInsert;
export type SupportAnalytics = typeof supportAnalytics.$inferSelect;
export type InsertSupportAnalytics = typeof supportAnalytics.$inferInsert;
export type KnowledgeBaseFeedback = typeof knowledgeBaseFeedback.$inferSelect;
export type InsertKnowledgeBaseFeedback = typeof knowledgeBaseFeedback.$inferInsert;
export type SupportTag = typeof supportTags.$inferSelect;
export type InsertSupportTag = typeof supportTags.$inferInsert;
export type CachedPost = typeof cachedPosts.$inferSelect;
export type InsertCachedPost = typeof cachedPosts.$inferInsert;
export type SkillCategory = typeof skillCategories.$inferSelect;
export type InsertSkillCategory = typeof skillCategories.$inferInsert;
export type User = typeof users.$inferSelect;
export type CareerPath = typeof careerPaths.$inferSelect;
export type InsertCareerPath = typeof careerPaths.$inferInsert;
export type CareerPathNode = typeof careerPathNodes.$inferSelect;
export type InsertCareerPathNode = typeof careerPathNodes.$inferInsert;
export type CareerPathConnection = typeof careerPathConnections.$inferSelect;
export type InsertCareerPathConnection = typeof careerPathConnections.$inferInsert;
export type IndustryTrend = typeof industryTrends.$inferSelect;
export type InsertIndustryTrend = typeof industryTrends.$inferInsert;
export type InsertResume = typeof resumes.$inferInsert;
export type Resume = typeof resumes.$inferSelect;
export type InsertJobPosting = typeof jobPostings.$inferInsert;
export type JobPosting = typeof jobPostings.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;
export type InsertInterviewGuide = typeof interviewGuides.$inferInsert;
export type InterviewGuide = typeof interviewGuides.$inferSelect;
export type InsertThankYouNote = typeof thankYouNotes.$inferInsert;
export type ThankYouNote = typeof thankYouNotes.$inferSelect;
export type InsertReflection = typeof reflections.$inferInsert;
export type Reflection = typeof reflections.$inferSelect;
export type InsertVideoPracticeSession = typeof videoPracticeSessions.$inferInsert;
export type VideoPracticeSession = typeof videoPracticeSessions.$inferSelect;
export type InsertVideoFeedback = typeof videoFeedback.$inferInsert;
export type VideoFeedback = typeof videoFeedback.$inferSelect;
export type InsertJobBoardIntegration = typeof jobBoardIntegrations.$inferInsert;
export type JobBoardIntegration = typeof jobBoardIntegrations.$inferSelect;
export type InsertExternalApplication = typeof externalApplications.$inferInsert;
export type ExternalApplication = typeof externalApplications.$inferSelect;
export type InsertApplicationEvent = typeof applicationEvents.$inferInsert;
export type ApplicationEvent = typeof applicationEvents.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;
export type Payment = typeof payments.$inferSelect;
export type InsertCreditTransaction = typeof creditTransactions.$inferInsert;
export type CreditTransaction = typeof creditTransactions.$inferSelect;
export type InsertAdminLog = typeof adminLogs.$inferInsert;
export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertResumeTemplate = typeof resumeTemplates.$inferInsert;
export type ResumeTemplate = typeof resumeTemplates.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;
export type SystemSetting = typeof systemSettings.$inferSelect;
export type CareerMoodEntry = typeof careerMoodEntries.$inferSelect;
export type InsertCareerMoodEntry = typeof careerMoodEntries.$inferInsert;
export type MoodBoardTemplate = typeof moodBoardTemplates.$inferSelect;
export type InsertMoodBoardTemplate = typeof moodBoardTemplates.$inferInsert;

// Zod schemas
export const insertResumeSchema = createInsertSchema(resumes).omit({ id: true, uploadedAt: true });
export const insertJobPostingSchema = createInsertSchema(jobPostings).omit({ id: true, addedAt: true });
export const insertInterviewGuideSchema = createInsertSchema(interviewGuides).omit({ id: true, generatedAt: true });
export const insertThankYouNoteSchema = createInsertSchema(thankYouNotes).omit({ id: true, generatedAt: true });
export const insertReflectionSchema = createInsertSchema(reflections).omit({ id: true, createdAt: true });
export const insertVideoPracticeSessionSchema = createInsertSchema(videoPracticeSessions).omit({ id: true, createdAt: true });
export const insertVideoFeedbackSchema = createInsertSchema(videoFeedback).omit({ id: true, createdAt: true });
export const insertJobBoardIntegrationSchema = createInsertSchema(jobBoardIntegrations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertExternalApplicationSchema = createInsertSchema(externalApplications).omit({ id: true, syncedAt: true });
export const insertCareerMoodEntrySchema = createInsertSchema(careerMoodEntries).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMoodBoardTemplateSchema = createInsertSchema(moodBoardTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertApplicationEventSchema = createInsertSchema(applicationEvents).omit({ id: true, createdAt: true });
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCreditTransactionSchema = createInsertSchema(creditTransactions).omit({ id: true, createdAt: true });
export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({ id: true, createdAt: true });
export const insertResumeTemplateSchema = createInsertSchema(resumeTemplates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({ id: true, updatedAt: true });
export const insertQuestionSchema = createInsertSchema(questions).omit({ id: true, createdAt: true, updatedAt: true });

export type InsertResumeType = z.infer<typeof insertResumeSchema>;
export type InsertJobPostingType = z.infer<typeof insertJobPostingSchema>;
export type InsertInterviewGuideType = z.infer<typeof insertInterviewGuideSchema>;
export type InsertThankYouNoteType = z.infer<typeof insertThankYouNoteSchema>;
export type InsertReflectionType = z.infer<typeof insertReflectionSchema>;
export type InsertVideoPracticeSessionType = z.infer<typeof insertVideoPracticeSessionSchema>;
export type InsertVideoFeedbackType = z.infer<typeof insertVideoFeedbackSchema>;
export type InsertJobBoardIntegrationType = z.infer<typeof insertJobBoardIntegrationSchema>;
export type InsertExternalApplicationType = z.infer<typeof insertExternalApplicationSchema>;
export type InsertApplicationEventType = z.infer<typeof insertApplicationEventSchema>;
export type InsertPaymentType = z.infer<typeof insertPaymentSchema>;
export type InsertCreditTransactionType = z.infer<typeof insertCreditTransactionSchema>;
export type InsertAdminLogType = z.infer<typeof insertAdminLogSchema>;
export type InsertResumeTemplateType = z.infer<typeof insertResumeTemplateSchema>;
export type InsertSystemSettingType = z.infer<typeof insertSystemSettingSchema>;
export type InsertQuestionType = z.infer<typeof insertQuestionSchema>;