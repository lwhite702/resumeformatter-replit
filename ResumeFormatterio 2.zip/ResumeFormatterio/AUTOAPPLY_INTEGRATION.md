# AutoApply Integration Documentation

## Overview
ResumeFormatter.io provides seamless integration with AutoApply (autoapply.wrelik.com) for automated job application processing. This integration allows users to sync their resumes and leverage AutoApply's job application automation features.

## API Endpoints

### Base URL
```
https://api.resumeformatter.io
```

### Authentication
All API requests require Bearer token authentication using the `RESUME_FORMATTER_API_KEY`.

```http
Authorization: Bearer {RESUME_FORMATTER_API_KEY}
```

### Available Endpoints

#### 1. Get User Resumes
```http
GET /v1/resumes?userId={userId}
```

**Response Format:**
```json
[
  {
    "id": "string",
    "name": "string",
    "fileName": "string", 
    "skills": ["string"],
    "experience": "string",
    "focus": "string",
    "lastModified": "ISO date string",
    "downloadUrl": "string"
  }
]
```

**Example Response:**
```json
[
  {
    "id": "123",
    "name": "Senior Software Engineer Resume",
    "fileName": "Senior_Software_Engineer_Resume.pdf",
    "skills": ["JavaScript", "React", "Node.js", "TypeScript", "PostgreSQL"],
    "experience": "Senior",
    "focus": "Full Stack Development",
    "lastModified": "2024-06-14T10:30:00.000Z",
    "downloadUrl": "https://api.resumeformatter.io/v1/resumes/123/download"
  }
]
```

#### 2. Download Resume
```http
GET /v1/resumes/{id}/download?userId={userId}
```

Returns the resume as a PDF file for download.

**Response:** Binary PDF data with appropriate headers.

## Integration Features

### Intelligent Data Extraction
The integration automatically extracts and analyzes:

- **Skills**: Technical and soft skills from resume content
- **Experience Level**: Entry Level, Junior, Mid-Level, Senior
- **Focus Area**: Frontend, Backend, Full Stack, Data Science, DevOps, etc.
- **File Metadata**: Optimized filenames and download URLs

### Resume Edit URLs
Each resume can be edited using the following URL format:
```
https://resumeformatter.io/editor/{resumeId}
```

### Sync Endpoints (Internal)
For manual synchronization between platforms:

#### Sync Individual Resume
```http
POST /api/autoapply/sync/{resumeId}
Content-Type: application/json

{
  "userId": "string"
}
```

#### Sync All User Resumes
```http
POST /api/autoapply/sync-all
Content-Type: application/json

{
  "userId": "string"
}
```

## Environment Configuration

### Required Environment Variables
```bash
# API Authentication
RESUME_FORMATTER_API_KEY=your_secure_api_key_here

# AutoApply Integration
AUTOAPPLY_API_KEY=your_autoapply_api_key
AUTOAPPLY_BASE_URL=https://autoapply.wrelik.com
```

## Data Processing

### Skill Extraction
The system uses advanced pattern matching to identify:
- Technical skills (programming languages, frameworks, tools)
- Industry-specific keywords
- Certifications and qualifications
- Soft skills mentioned in context

### Experience Level Detection
Experience levels are determined by:
- Years of experience explicitly mentioned
- Job title seniority indicators (Senior, Lead, Principal, etc.)
- Number of work experiences listed
- Responsibility complexity analysis

### Focus Area Classification
Focus areas are classified based on:
- Job titles and roles
- Technical skills mentioned
- Project descriptions
- Industry keywords

## Frontend Integration

### AutoApply Integration Component
The platform includes a comprehensive UI component for managing AutoApply integration:

- **Resume Sync Status**: View synchronization status for each resume
- **Batch Operations**: Sync all resumes at once
- **Preview Data**: See how resumes will appear in AutoApply format
- **Integration Health**: Monitor connection and configuration status

### User Experience Features
- Real-time sync status updates
- Intelligent error handling and retry mechanisms
- Preview of extracted data before synchronization
- Easy access to edit resumes directly from sync interface

## Error Handling

### Common Error Codes
- `400`: Missing required parameters (userId, invalid format)
- `401`: Invalid or missing API key
- `404`: Resume not found or access denied
- `500`: Internal server error or processing failure

### Error Response Format
```json
{
  "error": "Error description",
  "code": "ERROR_CODE",
  "timestamp": "2024-06-14T10:30:00.000Z"
}
```

## Security Considerations

### Authentication
- All API endpoints require valid Bearer tokens
- User data isolation enforced at the API level
- Rate limiting applied to prevent abuse

### Data Privacy
- Resume content is processed server-side only
- No sensitive data stored in logs
- GDPR and privacy compliance maintained

## Development Setup

### Local Testing
```bash
# Set environment variables
export RESUME_FORMATTER_API_KEY="test_key_123"
export AUTOAPPLY_BASE_URL="http://localhost:3000"

# Test API endpoints
curl -H "Authorization: Bearer test_key_123" \
  "http://localhost:5000/v1/resumes?userId=test_user_123"
```

### Integration Testing
Use the provided test endpoints to verify:
1. Authentication is working correctly
2. Resume data format matches expectations
3. Download URLs are accessible
4. Sync operations complete successfully

## Support and Troubleshooting

### Common Issues
1. **Authentication Failures**: Verify API key is correctly configured
2. **Missing Resumes**: Ensure userId parameter is correct
3. **Download Errors**: Check resume exists and user has access
4. **Sync Failures**: Verify AutoApply API connectivity

### Debugging
Enable debug logging by setting:
```bash
NODE_ENV=development
```

This will provide detailed logs for troubleshooting integration issues.

## Changelog

### Version 1.0.0 (Current)
- Initial AutoApply integration
- Resume data extraction and formatting
- Sync API endpoints
- Frontend integration component
- Authentication and security implementation