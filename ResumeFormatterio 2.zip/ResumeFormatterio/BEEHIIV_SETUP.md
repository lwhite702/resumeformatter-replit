# Beehiiv Newsletter Integration Setup

## Overview
The application integrates with Beehiiv to manage "The Resume Refresh" newsletter subscriptions. This provides professional email marketing capabilities with automation, analytics, and subscriber management.

## Required Environment Variables

Add these to your `.env` file:

```
BEEHIIV_API_KEY=your_beehiiv_api_key_here
BEEHIIV_PUBLICATION_ID=your_publication_id_here
```

## Getting Your Beehiiv Credentials

### 1. API Key
1. Log into your Beehiiv account
2. Go to Settings > Integrations > API
3. Generate a new API key
4. Copy the key and add it to `BEEHIIV_API_KEY`

### 2. Publication ID
1. In your Beehiiv dashboard, go to your publication
2. The Publication ID is in the URL: `https://app.beehiiv.com/publications/{PUBLICATION_ID}`
3. Copy this ID and add it to `BEEHIIV_PUBLICATION_ID`

## Features Implemented

### Subscription Management
- ✅ New subscriber registration via website forms
- ✅ Duplicate prevention
- ✅ Custom fields and tags for segmentation
- ✅ Welcome email automation
- ✅ Unsubscribe handling

### Data Integration
- ✅ Local database backup of all subscribers
- ✅ Beehiiv and local data synchronization
- ✅ Error handling for API failures

### Admin Analytics
- ✅ Newsletter statistics endpoint
- ✅ Subscriber growth tracking
- ✅ Beehiiv analytics integration

## API Endpoints

### Subscribe to Newsletter
```
POST /api/newsletter/subscribe
{
  "email": "user@example.com",
  "name": "User Name",
  "source": "website"
}
```

### Unsubscribe from Newsletter
```
POST /api/newsletter/unsubscribe
{
  "email": "user@example.com",
  "token": "unsubscribe_token"
}
```

### Get Newsletter Stats (Admin)
```
GET /api/newsletter/stats
Authorization: Bearer <token>
```

## Newsletter Branding

**Name:** The Resume Refresh
**Description:** Monthly resume tips, Markdown tricks, and template spotlights
**Tags:** resume-refresh, website-signup
**Custom Fields:** signup_source, user_type

## Testing

After adding your credentials:

1. Restart the application
2. Try subscribing via the blog or landing page forms
3. Check your Beehiiv dashboard for new subscribers
4. Verify welcome emails are sent
5. Test unsubscribe functionality

## Error Handling

The system gracefully handles:
- Missing API credentials (falls back to local storage)
- Beehiiv API failures (still stores locally)
- Invalid email addresses
- Duplicate subscriptions
- Network timeouts

## Support

If you encounter issues:
1. Verify your API credentials are correct
2. Check the server logs for detailed error messages
3. Ensure your Beehiiv plan supports API access
4. Contact Beehiiv support for API-related issues