# ResumeFormatter.io - Comprehensive Knowledge File

**Last Updated:** June 06, 2025  
**Version:** 1.1  
**Status:** 75% Launch Ready - Critical Fixes Applied

---

## 1. Product Overview

ResumeFormatter.io is a modern, AI-powered resume builder designed for developers, technical professionals, and job seekers. The platform features Markdown-first editing with live preview, AI-assisted optimization, multiple export formats, and comprehensive versioning tools.

### Core Value Proposition
- Markdown-based editing for technical professionals
- AI-powered ATS optimization and scoring
- Multiple professional templates with live preview
- Export to PDF, DOCX, and HTML formats
- Resume versioning and optimization history
- Cover letter generation with customizable tone

---

## 2. Target Personas

### Primary Users
- **Developers & Technical Professionals**: Prefer Markdown workflow, need ATS-compliant formats
- **Job Seekers**: Require professional templates with optimization features
- **Students & Recent Graduates**: Need guidance and templates for first resumes
- **Freelancers & Creatives**: Want customizable designs with export flexibility

### User Journey
1. Create account (Replit Auth integration)
2. Choose from 12+ professional templates
3. Edit resume using Markdown editor with live preview
4. Optimize resume using AI analysis (Pro feature)
5. Export in multiple formats (PDF free, DOCX/HTML Pro)
6. Generate cover letters (Pro feature)

---

## 3. Feature Table

| Feature | Plan | Route | Status | Description |
|---------|------|-------|--------|-------------|
| Markdown Editor | Free/Pro | `/editor` | ✅ Active | Full-featured editor with syntax highlighting |
| Live Preview | Free/Pro | `/editor` | ✅ Active | Real-time preview with scroll sync |
| Template Selection | Free/Pro | `/templates` | ✅ Active | 3 free + 12 pro templates with access control |
| PDF Export | Free/Pro | `/api/resumes/:id/export/pdf` | ✅ Active | Free with watermark, Pro without |
| DOCX Export | Pro | `/api/resumes/:id/export/docx` | ✅ Active | Microsoft Word format |
| HTML Export | Pro | N/A | ❌ Missing | Web-ready HTML format (needs implementation) |
| Resume Optimization | Pro | `/api/resumes/:id/optimize` | ✅ Active | AI-powered ATS analysis |
| Cover Letter Generation | Pro | `/api/cover-letters/generate` | ✅ Active | AI-generated cover letters |
| Resume Versioning | Pro | `/api/resumes/:id/versions` | ✅ Active | Version history and restoration |
| Resume Import | Free/Pro | `/api/resumes/import` | ✅ Active | PDF/DOCX import with parsing |
| User Dashboard | Free/Pro | `/dashboard` | ✅ Active | Resume management interface |
| Subscription Management | Pro | `/pricing` | ✅ Active | Stripe integration for payments |
| Admin Dashboard | Admin | `/admin` | ✅ Active | Analytics and user management |
| API Integrations | Pro | `/api/integrations` | ✅ Active | Export to external platforms |
| Help Center | All | `/support` | ✅ Active | Comprehensive documentation and support |

---

## 4. Design System Reference

### Theme & Colors
- **Primary**: Blue gradient (#3B82F6 to #1D4ED8)
- **Background**: Light gray (#F9FAFB) with white cards
- **Text**: Dark gray (#1F2937) with light gray (#6B7280) secondary
- **Accent**: Green (#10B981) for success states
- **Warning**: Amber (#F59E0B) for ATS scores
- **Error**: Red (#EF4444) for validation

### Typography
- **Headings**: Inter font family, various weights
- **Body**: System font stack for optimal readability
- **Code**: Monospace for Markdown syntax

### Component Standards
- Shadcn UI component library
- Tailwind CSS for styling
- Responsive mobile-first design
- Dark mode support with system preference detection

---

## 5. Pricing Model

### Free Plan
- Unlimited resume editing
- 3 basic professional templates (Modern Tech, Minimal Dev, Classic Professional)
- PDF export with watermark
- Basic editing features
- Community support

### Pro Plan ($3.99 one-time)
- Unlimited resumes
- All 15+ premium templates
- PDF export without watermark
- DOCX export
- AI optimization and ATS scoring (50 credits/month)
- Cover letter generation
- Resume versioning
- API integrations
- Priority support

### Credit System
- Pro users: 50 AI credits/month
- Additional credits: $0.10 per credit
- Credits used for optimization and cover letter generation

---

## 6. Credit Rules

### AI Feature Costs
- Resume ATS analysis: 3 credits
- Content optimization suggestions: 5 credits
- Cover letter generation: 7 credits
- Bullet point rewrites: 2 credits each

### Credit Management
- Monthly reset for Pro subscribers
- Rollover of unused credits (max 100)
- Credit purchase available in packs of 25, 50, 100

---

## 7. Accessibility Summary

### WCAG 2.1 AA Compliance
- ✅ Keyboard navigation throughout application
- ✅ Focus indicators on all interactive elements
- ✅ Color contrast ratios meet AA standards
- ✅ Screen reader compatibility with semantic HTML
- ✅ Alternative text for images and icons
- ✅ Proper heading hierarchy (H1-H6)

### Mobile Accessibility
- Touch targets minimum 44px
- Swipe gestures for editor/preview toggle
- Voice input support for text fields

---

## 8. Route Map

```
/                    - Landing page with feature overview
/editor              - Resume editing interface (authenticated)
/editor/:id          - Edit specific resume (authenticated)
/templates           - Template selection gallery
/dashboard           - User dashboard with resume list (authenticated)
/pricing             - Subscription plans and pricing
/features            - Feature overview and benefits
/about               - About the platform
/contact             - Contact information
/privacy             - Privacy policy
/legal               - Legal information
/support             - Help center and documentation
/admin               - Admin dashboard (role-based)
/api/auth/*          - Authentication endpoints
/api/resumes/*       - Resume CRUD operations
/api/cover-letters/* - Cover letter generation
/api/export/*        - Export functionality
/api/integrations/*  - API integration management
```

---

## 9. Admin Controls

### User Management
- View all user accounts with activity status
- Modify user plans and credit balances
- Reset passwords and manage access
- View subscription and payment history

### Analytics Dashboard
- User registration and engagement metrics
- Revenue tracking and subscription analytics
- Export usage and feature adoption rates
- AI credit consumption patterns

### Content Management
- Template updates and new template deployment
- Feature flag management for gradual rollouts
- Error monitoring and system health checks

### Access Control
- Role-based permissions (Admin, Support, ReadOnly)
- Audit logging for all admin actions
- Two-factor authentication for admin accounts

---

## 10. Legal Information

### Compliance
- GDPR compliant data handling
- CCPA privacy rights implementation
- SOC 2 Type II security standards
- Regular security audits and penetration testing

### Data Protection
- User data encrypted in transit and at rest
- Resume content stored securely with user ownership
- Right to data export and deletion
- Minimal data collection principle

### Terms & Policies
- Clear terms of service with usage guidelines
- Privacy policy detailing data collection and use
- Cookie policy for tracking and analytics
- Refund policy for subscription services

---

## 11. Technical Architecture

### Frontend
- React with TypeScript
- Vite build system
- Shadcn UI components
- TailwindCSS styling
- Wouter routing

### Backend
- Node.js with Express
- PostgreSQL database
- Drizzle ORM
- Replit authentication
- Stripe payment processing

### External Services
- OpenAI for content optimization
- Puppeteer for PDF generation
- Stripe for payment processing
- Replit hosting and deployment

---

## 12. Deployment Status

### Environment Configuration
- ✅ Production environment variables configured with fallbacks
- ✅ Database migrations applied via Drizzle ORM
- ✅ SSL certificates active via Replit deployment
- ✅ Authentication system configured for production/development
- ✅ Stripe payment processing active
- ✅ OpenAI integration for AI features
- 🔄 Error monitoring and logging (basic implementation)

### Performance Metrics
- Page load time: <2 seconds
- Time to interactive: <3 seconds
- Core Web Vitals: All green
- Uptime SLA: 99.9%

---

**End of Knowledge File**

*This document serves as the comprehensive reference for ResumeFormatter.io's features, architecture, and operational guidelines. It should be updated with each major release or significant feature addition.*