# ResumeFormatter.io Support API Documentation
**For Wrelik.com Unified Support Desk Integration**

## Overview
ResumeFormatter.io provides a comprehensive API for external support desk integration, enabling Wrelik.com's unified support system to access knowledge base articles, user context, analytics, and support ticket information.

## Base URL
```
https://resumeformatter.io/api/support
```

## Authentication
All endpoints are publicly accessible for support desk integration. User-specific endpoints require the user ID parameter.

## Available Endpoints

### 1. Health Check
**GET** `/health`

Returns API status and available features.

**Response:**
```json
{
  "status": "healthy",
  "service": "ResumeFormatter.io Support API",
  "version": "1.0.0",
  "timestamp": "2025-06-13T18:11:40.210Z",
  "features": [
    "knowledge_base",
    "user_context", 
    "analytics",
    "real_time_support"
  ],
  "integrations": {
    "database": "connected",
    "beehiiv": "configured",
    "wordpress": "connected"
  }
}
```

### 2. Knowledge Base Articles
**GET** `/articles`

Retrieve knowledge base articles with optional filtering.

**Query Parameters:**
- `category` (optional): Filter by category (basics, formatting, optimization, templates, export, ai, support, account)
- `search` (optional): Search articles by title, content, or tags
- `limit` (optional): Maximum number of articles to return (default: 20)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "getting-started",
      "title": "Getting Started with ResumeFormatter.io",
      "content": "Learn how to create your first professional resume...",
      "category": "basics",
      "tags": ["beginner", "setup", "markdown"],
      "lastUpdated": "2024-12-13",
      "views": 1500,
      "helpful": 142,
      "status": "published"
    }
  ],
  "total": 6,
  "categories": ["basics", "formatting", "optimization", "templates", "export", "ai", "support", "account"]
}
```

### 3. Specific Article
**GET** `/articles/{articleId}`

Get full content of a specific knowledge base article.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "getting-started",
    "content": "# Getting Started with ResumeFormatter.io\n\nWelcome to ResumeFormatter.io!...",
    "lastUpdated": "2025-06-13"
  }
}
```

### 4. User Context
**GET** `/user/{userId}/context`

Get comprehensive user information for support context.

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "user123",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "plan": "free",
      "credits": 2,
      "createdAt": "2024-11-15T08:30:00Z",
      "updatedAt": "2024-12-13T11:45:00Z"
    },
    "usage": {
      "resumesCreated": 3,
      "activeResumes": 2,
      "lastActivity": "2024-12-13T11:45:00Z"
    },
    "recentResumes": [
      {
        "id": 1,
        "title": "Software Engineer Resume",
        "updatedAt": "2024-12-13T11:30:00Z",
        "templateId": "modern"
      }
    ]
  }
}
```

### 5. Support Analytics
**GET** `/analytics`

Get platform analytics for support team insights.

**Response:**
```json
{
  "success": true,
  "data": {
    "users": {
      "total": 1247,
      "active": 892,
      "newThisWeek": 89,
      "plans": {"free": 980, "pro": 267}
    },
    "resumes": {
      "total": 3450,
      "createdThisWeek": 156,
      "avgPerUser": 2.8
    },
    "engagement": {
      "dailyActiveUsers": 234,
      "weeklyActiveUsers": 567,
      "avgSessionTime": "12 minutes"
    },
    "support": {
      "ticketsOpen": 23,
      "avgResponseTime": "2 hours",
      "satisfactionScore": 4.6
    }
  },
  "generatedAt": "2025-06-13T18:11:35.428Z"
}
```

### 6. Support Tickets
**GET** `/tickets`

Retrieve support tickets with filtering options.

**Query Parameters:**
- `status` (optional): Filter by ticket status (open, in-progress, resolved, closed)
- `priority` (optional): Filter by priority (low, medium, high, urgent)
- `userId` (optional): Filter by specific user
- `limit` (optional): Maximum tickets to return (default: 50)

**Response:**
```json
{
  "success": true,
  "data": [],
  "total": 0,
  "stats": {
    "open": 0,
    "inProgress": 0,
    "resolved": 0,
    "closed": 0
  }
}
```

## Usage Examples

### Search Knowledge Base
```bash
curl "https://resumeformatter.io/api/support/articles?search=markdown&category=formatting"
```

### Get User Support Context
```bash
curl "https://resumeformatter.io/api/support/user/user123/context"
```

### Check Platform Health
```bash
curl "https://resumeformatter.io/api/support/health"
```

### Get Support Analytics
```bash
curl "https://resumeformatter.io/api/support/analytics"
```

## Common Use Cases

### 1. Knowledge Base Search
When a user contacts support, search the knowledge base for relevant articles to provide immediate help:
```
GET /articles?search={user_query}
```

### 2. User Account Investigation
Get complete user context when investigating account issues:
```
GET /user/{userId}/context
```

### 3. Platform Health Monitoring
Monitor API status and integrations:
```
GET /health
```

### 4. Support Metrics Dashboard
Get analytics for support team dashboards:
```
GET /analytics
```

## Error Handling

All endpoints return consistent error responses:

```json
{
  "message": "Error description",
  "success": false
}
```

Common HTTP status codes:
- `200`: Success
- `400`: Bad Request (invalid parameters)
- `404`: Resource not found
- `500`: Internal server error

## Rate Limiting
Currently no rate limiting is implemented. Contact technical team if rate limiting is needed for high-volume usage.

## Integration Notes

1. **Real-time Data**: All user context and analytics are pulled from live database
2. **Knowledge Base**: Articles are maintained in the application and updated regularly
3. **Security**: No authentication required for support desk access, but user data is only accessible via user ID
4. **Scalability**: API is designed to handle high-volume requests from support systems

## Contact Information
For technical questions about this API integration:
- Technical Team: dev@wrelik.com
- Platform Issues: support@resumeformatter.io

---
*Last Updated: June 13, 2025*
*API Version: 1.0.0*