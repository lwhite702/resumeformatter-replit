import { Switch, Route } from "wouter";
import { SignedIn, SignedOut } from "@clerk/clerk-react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import ScrollToTop from "@/components/ScrollToTop";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import Editor from "@/pages/editor";
import Admin from "@/pages/admin";
import Features from "@/pages/features";
import Pricing from "@/pages/pricing";
import Templates from "@/pages/templates";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import Privacy from "@/pages/privacy";
import Legal from "@/pages/legal";
import Support from "@/pages/support";
import BlogPage from "@/pages/blog";
import BlogPostPage from "@/pages/blog-post";
import BlogTest from "@/pages/blog-test";
import KnowledgeBase from "@/pages/knowledge-base";
import SupportApiTest from "@/pages/support-api-test";
import AdminDocs from "@/pages/admin-docs";
import AdminSettings from "@/pages/admin-settings";
import Profile from "@/pages/profile";
import Organization from "@/pages/organization";
import Settings from "@/pages/settings";
import BrandingDemo from "@/components/branding/BrandingDemo";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <>
      <ScrollToTop />
      <Switch>
      {/* Public routes - always available */}
      <Route path="/features" component={Features} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/templates" component={Templates} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/legal" component={Legal} />
      <Route path="/support" component={Support} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/blog/:slug" component={BlogPostPage} />
      <Route path="/blog-test" component={BlogTest} />
      <Route path="/knowledge-base" component={KnowledgeBase} />
      <Route path="/support-api-test" component={SupportApiTest} />
      <Route path="/admin/docs" component={AdminDocs} />
      <Route path="/admin/settings" component={AdminSettings} />
      <Route path="/branding-demo" component={BrandingDemo} />
      
      {/* Profile and Organization routes */}
      <Route path="/profile" component={Profile} />
      <Route path="/organization" component={Organization} />
      <Route path="/settings" component={Settings} />
      
      {/* Admin route - accessible but handles auth internally */}
      <Route path="/admin" component={Admin} />
      
      {/* Root route - conditional based on authentication */}
      <Route path="/">
        <SignedOut>
          <Landing />
        </SignedOut>
        <SignedIn>
          <Home />
        </SignedIn>
      </Route>
      
      {/* Protected routes - only accessible when signed in */}
      <Route path="/dashboard">
        <SignedIn>
          <Dashboard />
        </SignedIn>
        <SignedOut>
          <Landing />
        </SignedOut>
      </Route>
      
      <Route path="/editor/:id?">
        <SignedIn>
          <Editor />
        </SignedIn>
        <SignedOut>
          <Editor />
        </SignedOut>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
