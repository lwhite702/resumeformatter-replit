
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { GitCommit, Plus, Bug, Zap } from 'lucide-react';

export default function AdminChangelog() {
  const changes = [
    {
      version: "2.1.0",
      date: "2024-12-06",
      type: "feature",
      title: "AI Resume Optimization",
      description: "Added AI-powered resume optimization with ATS scoring"
    },
    {
      version: "2.0.5",
      date: "2024-12-05",
      type: "fix",
      title: "Export Bug Fix",
      description: "Fixed PDF export formatting issues"
    },
    {
      version: "2.0.4",
      date: "2024-12-04",
      type: "improvement",
      title: "Performance Enhancement",
      description: "Improved editor performance and responsiveness"
    }
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'feature': return <Plus className="h-4 w-4" />;
      case 'fix': return <Bug className="h-4 w-4" />;
      case 'improvement': return <Zap className="h-4 w-4" />;
      default: return <GitCommit className="h-4 w-4" />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'feature': return 'bg-green-100 text-green-800';
      case 'fix': return 'bg-red-100 text-red-800';
      case 'improvement': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GitCommit className="h-5 w-5" />
          Recent Changes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {changes.map((change, index) => (
            <div key={index} className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                {getIcon(change.type)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm font-medium">{change.title}</p>
                  <Badge className={getColor(change.type)} variant="secondary">
                    {change.type}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-1">
                  {change.description}
                </p>
                <p className="text-xs text-muted-foreground">
                  v{change.version} • {change.date}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
