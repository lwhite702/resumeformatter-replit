
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Book, FileText, HelpCircle, Plus } from 'lucide-react';

export default function AdminKnowledge() {
  const articles = [
    { title: "Getting Started with Resume Formatter", views: 1234, status: "published" },
    { title: "Markdown Syntax Guide", views: 856, status: "published" },
    { title: "Template Customization", views: 432, status: "draft" },
    { title: "Export Options Explained", views: 678, status: "published" }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Book className="h-5 w-5" />
          Knowledge Base
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Manage help articles and user documentation
            </p>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              New Article
            </Button>
          </div>
          
          <div className="space-y-3">
            {articles.map((article, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <FileText className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm font-medium">{article.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {article.views} views • {article.status}
                    </p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Edit
                </Button>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
