
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Map, Clock, CheckCircle, Circle } from 'lucide-react';

export default function AdminRoadmap() {
  const roadmapItems = [
    {
      title: "Advanced Template Editor",
      status: "in-progress",
      progress: 75,
      eta: "Q1 2025"
    },
    {
      title: "Team Collaboration Features",
      status: "planned",
      progress: 0,
      eta: "Q2 2025"
    },
    {
      title: "LinkedIn Integration",
      status: "completed",
      progress: 100,
      eta: "Completed"
    },
    {
      title: "Mobile App",
      status: "planned",
      progress: 15,
      eta: "Q3 2025"
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'in-progress': return <Clock className="h-4 w-4 text-blue-600" />;
      default: return <Circle className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Map className="h-5 w-5" />
          Product Roadmap
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {roadmapItems.map((item, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getStatusIcon(item.status)}
                  <span className="font-medium">{item.title}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(item.status)} variant="secondary">
                    {item.status.replace('-', ' ')}
                  </Badge>
                  <span className="text-sm text-muted-foreground">{item.eta}</span>
                </div>
              </div>
              {item.status !== 'planned' && (
                <Progress value={item.progress} className="h-2" />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
