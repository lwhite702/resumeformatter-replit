import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  FileText, 
  Plus, 
  Save,
  Clock,
  CheckCircle,
  User,
  Settings,
  LogOut,
  CreditCard,
  Menu
} from "lucide-react";
import { User as UserType } from "@shared/schema";

interface AppHeaderProps {
  user?: UserType;
  onCreateResume: () => void;
  autoSaveStatus: 'saved' | 'saving' | 'draft';
}

export default function AppHeader({ user, onCreateResume, autoSaveStatus }: AppHeaderProps) {
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const getAutoSaveIcon = () => {
    switch (autoSaveStatus) {
      case 'saved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'saving':
        return <Clock className="h-4 w-4 text-yellow-500 animate-spin" />;
      case 'draft':
        return <Save className="h-4 w-4 text-gray-500" />;
    }
  };

  const getAutoSaveText = () => {
    switch (autoSaveStatus) {
      case 'saved':
        return 'Auto-saved';
      case 'saving':
        return 'Saving...';
      case 'draft':
        return 'Draft saved locally';
    }
  };

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return 'U';
  };

  return (
    <header className="bg-white elevation-1 sticky top-0 z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center elevation-1">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-gray-900 hidden sm:block">
                ResumeFormatter.io
              </span>
            </div>

            {/* Auto-save status */}
            <div className="hidden md:flex items-center space-x-2 bg-gray-50 px-3 py-1.5 rounded-full">
              {getAutoSaveIcon()}
              <span className="text-sm text-gray-600">{getAutoSaveText()}</span>
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Create New Resume */}
            <Button
              onClick={onCreateResume}
              className="bg-primary hover:bg-primary/90 text-white ripple"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Resume
            </Button>

            {/* Credits Display */}
            {user && (
              <Badge 
                variant="secondary" 
                className="bg-secondary/10 text-secondary border-secondary/20 px-3 py-1"
              >
                {user.planType === 'pro' ? (
                  <>
                    <CreditCard className="h-4 w-4 mr-1" />
                    Pro Plan
                  </>
                ) : (
                  <>
                    <span className="font-medium">{user.credits || 0}</span> credits
                  </>
                )}
              </Badge>
            )}

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user?.profileImageUrl || undefined} alt="Profile" />
                    <AvatarFallback className="bg-primary text-white">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <div className="flex flex-col space-y-1 p-2">
                  <p className="text-sm font-medium leading-none">
                    {user?.firstName && user?.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user?.email || 'User'
                    }
                  </p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user?.email}
                  </p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.location.href = "/subscribe"}>
                  <CreditCard className="mr-2 h-4 w-4" />
                  <span>{user?.planType === 'pro' ? 'Billing' : 'Upgrade to Pro'}</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => window.location.href = "/api/logout"}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            className="md:hidden"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>

        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="space-y-3">
              {/* Auto-save status */}
              <div className="flex items-center space-x-2 px-2">
                {getAutoSaveIcon()}
                <span className="text-sm text-gray-600">{getAutoSaveText()}</span>
              </div>

              {/* Credits */}
              {user && (
                <div className="px-2">
                  <Badge 
                    variant="secondary" 
                    className="bg-secondary/10 text-secondary border-secondary/20"
                  >
                    {user.planType === 'pro' ? 'Pro Plan' : `${user.credits || 0} credits`}
                  </Badge>
                </div>
              )}

              {/* Actions */}
              <Button
                onClick={onCreateResume}
                className="w-full bg-primary hover:bg-primary/90 text-white ripple"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Resume
              </Button>

              {/* User options */}
              <div className="space-y-2 pt-2 border-t border-gray-200">
                <Button variant="ghost" className="w-full justify-start">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start"
                  onClick={() => window.location.href = "/subscribe"}
                >
                  <CreditCard className="mr-2 h-4 w-4" />
                  {user?.planType === 'pro' ? 'Billing' : 'Upgrade to Pro'}
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-red-600 hover:text-red-700"
                  onClick={() => window.location.href = "/api/logout"}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Log out
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
