import { 
  RedirectToSignIn, 
  RedirectToSignUp, 
  RedirectToUserProfile,
  RedirectToCreateOrganization,
  RedirectToOrganizationProfile 
} from "@clerk/clerk-react";

// Sign-in redirect component
export function SignInRedirect() {
  return <RedirectToSignIn />;
}

// Sign-up redirect component  
export function SignUpRedirect() {
  return <RedirectToSignUp />;
}

// User profile redirect component
export function UserProfileRedirect() {
  return <RedirectToUserProfile />;
}

// Create organization redirect component
export function CreateOrganizationRedirect() {
  return <RedirectToCreateOrganization />;
}

// Organization profile redirect component
export function OrganizationProfileRedirect() {
  return <RedirectToOrganizationProfile />;
}