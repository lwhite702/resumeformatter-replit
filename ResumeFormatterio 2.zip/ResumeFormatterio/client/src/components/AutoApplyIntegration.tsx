import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ExternalLink, RefreshCw, CheckCircle, AlertCircle, Clock } from "lucide-react";

interface AutoApplyResumeData {
  id: string;
  name: string;
  fileName: string;
  skills: string[];
  experience: string;
  focus: string;
  lastModified: string;
  downloadUrl: string;
}

export default function AutoApplyIntegration() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [syncingResumeId, setSyncingResumeId] = useState<number | null>(null);
  const [syncingAll, setSyncingAll] = useState(false);

  // Check AutoApply integration availability
  const { data: integrationStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/autoapply/status', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const response = await fetch(`/api/autoapply/status?userId=${user.id}`);
      return response.json();
    },
    enabled: !!user?.id,
  });

  // Fetch user's resumes formatted for AutoApply
  const { data: autoApplyResumes, isLoading } = useQuery({
    queryKey: ['/api/autoapply/resumes', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      // Get regular resumes from API
      const response = await fetch(`/api/resumes/${user.id}`);
      const resumes = await response.json();
      
      // Transform to AutoApply format for preview
      return resumes.map((resume: any) => ({
        id: resume.id.toString(),
        name: resume.title,
        fileName: `${resume.title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`,
        skills: extractSkillsPreview(resume.content),
        experience: extractExperiencePreview(resume.content),
        focus: determineFocusPreview(resume.content, resume.title),
        lastModified: new Date(resume.updatedAt || resume.createdAt).toISOString(),
        downloadUrl: `/api/resumes/${user.id}/${resume.id}/download`,
        editUrl: `https://resumeformatter.io/editor/${resume.id}`
      }));
    },
    enabled: !!user?.id,
  });

  // Sync individual resume with AutoApply
  const syncResumeMutation = useMutation({
    mutationFn: async (resumeId: number) => {
      const response = await fetch(`/api/autoapply/sync/${resumeId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user?.id }),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Resume synced with AutoApply successfully",
      });
      setSyncingResumeId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/autoapply/resumes'] });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Failed to sync resume with AutoApply",
        variant: "destructive",
      });
      setSyncingResumeId(null);
    },
  });

  // Sync all resumes with AutoApply
  const syncAllMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/autoapply/sync-all', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user?.id }),
      });
      return response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Sync Complete",
        description: `${data.success} resumes synced successfully, ${data.failed} failed`,
      });
      setSyncingAll(false);
      queryClient.invalidateQueries({ queryKey: ['/api/autoapply/resumes'] });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Failed to sync resumes with AutoApply",
        variant: "destructive",
      });
      setSyncingAll(false);
    },
  });

  const handleSyncResume = (resumeId: number) => {
    setSyncingResumeId(resumeId);
    syncResumeMutation.mutate(resumeId);
  };

  const handleSyncAll = () => {
    setSyncingAll(true);
    syncAllMutation.mutate();
  };

  if (statusLoading || isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AutoApply Integration</CardTitle>
          <CardDescription>Loading integration status...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  // Show upgrade prompt for non-Pro users
  if (integrationStatus && !integrationStatus.available) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ExternalLink className="h-5 w-5" />
            AutoApply Integration
          </CardTitle>
          <CardDescription>
            Automated job application processing with AutoApply
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-amber-500" />
            <h3 className="text-lg font-semibold mb-2">Pro Membership Required</h3>
            <p className="text-muted-foreground mb-4">
              AutoApply integration is available exclusively for Pro members. 
              Upgrade your plan to sync resumes with AutoApply for automated job applications.
            </p>
            <div className="space-y-3">
              <div className="text-sm">
                <p><strong>Current Plan:</strong> {integrationStatus.userPlan || 'Free'}</p>
              </div>
              <Button className="w-full max-w-sm">
                Upgrade to Pro
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <ExternalLink className="h-5 w-5" />
                AutoApply Integration
              </CardTitle>
              <CardDescription>
                Sync your resumes with AutoApply for automated job applications
              </CardDescription>
            </div>
            <Button 
              onClick={handleSyncAll}
              disabled={syncingAll || !autoApplyResumes?.length}
              className="flex items-center gap-2"
            >
              {syncingAll ? (
                <Clock className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              Sync All Resumes
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CheckCircle className="h-4 w-4 text-green-500" />
              AutoApply integration is active for Pro members
            </div>
            
            <div className="text-sm">
              <p className="font-medium mb-2">Pro Member Benefits:</p>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Automatic resume sync with AutoApply platform</li>
                <li>• Server-side authentication (no API keys required)</li>
                <li>• Intelligent skill extraction and job matching</li>
                <li>• Direct integration with autoapply.wrelik.com</li>
              </ul>
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
                Current Plan: {integrationStatus?.userPlan || 'Pro'}
              </p>
              <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                All integrations are managed server-side for security and convenience
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Resume Sync Status</CardTitle>
          <CardDescription>
            View and sync your resumes with AutoApply platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!autoApplyResumes?.length ? (
            <div className="text-center py-8 text-muted-foreground">
              <AlertCircle className="h-8 w-8 mx-auto mb-2" />
              <p>No resumes found. Create a resume to get started.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {autoApplyResumes.map((resume: AutoApplyResumeData) => (
                <div key={resume.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">{resume.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Last modified: {new Date(resume.lastModified).toLocaleDateString()}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleSyncResume(parseInt(resume.id))}
                      disabled={syncingResumeId === parseInt(resume.id)}
                      className="flex items-center gap-2"
                    >
                      {syncingResumeId === parseInt(resume.id) ? (
                        <Clock className="h-3 w-3 animate-spin" />
                      ) : (
                        <RefreshCw className="h-3 w-3" />
                      )}
                      Sync
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-muted-foreground">Experience Level</p>
                      <Badge variant="secondary">{resume.experience}</Badge>
                    </div>
                    <div>
                      <p className="font-medium text-muted-foreground">Focus Area</p>
                      <Badge variant="outline">{resume.focus}</Badge>
                    </div>
                    <div>
                      <p className="font-medium text-muted-foreground">File Name</p>
                      <code className="text-xs bg-muted px-2 py-1 rounded">
                        {resume.fileName}
                      </code>
                    </div>
                  </div>

                  <div>
                    <p className="font-medium text-muted-foreground mb-2">Skills</p>
                    <div className="flex flex-wrap gap-1">
                      {resume.skills.slice(0, 8).map((skill: string, index: number) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {resume.skills.length > 8 && (
                        <Badge variant="secondary" className="text-xs">
                          +{resume.skills.length - 8} more
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Helper functions for preview (simplified versions)
function extractSkillsPreview(content: string): string[] {
  const skills = new Set<string>();
  const commonSkills = [
    'JavaScript', 'TypeScript', 'Python', 'React', 'Node.js', 'HTML', 'CSS', 'SQL'
  ];
  
  commonSkills.forEach(skill => {
    if (new RegExp(`\\b${skill}\\b`, 'gi').test(content)) {
      skills.add(skill);
    }
  });
  
  return Array.from(skills).slice(0, 6);
}

function extractExperiencePreview(content: string): string {
  if (/\b(?:senior|lead|principal)\b/gi.test(content)) return 'Senior';
  if (/\b(?:junior|entry)\b/gi.test(content)) return 'Entry Level';
  return 'Mid-Level';
}

function determineFocusPreview(content: string, title: string): string {
  const combined = `${title} ${content}`.toLowerCase();
  if (combined.includes('frontend') || combined.includes('react')) return 'Frontend Development';
  if (combined.includes('backend') || combined.includes('api')) return 'Backend Development';
  if (combined.includes('full stack')) return 'Full Stack Development';
  return 'Software Engineering';
}