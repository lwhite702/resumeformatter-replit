import { FeaturesSectionWithHoverEffects } from "@/components/blocks/feature-section-with-hover-effects";

export default function BentoFeatures() {
  return (
    <section className="py-24 px-4 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
      <div className="absolute top-40 right-10 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
      <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-2000"></div>

      <div className="max-w-7xl mx-auto relative">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent mb-6">
            Everything you need to land your dream job
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional resume building made simple with our powerful Markdown-based editor
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Markdown Editor */}
          <div className="glass-card p-8 hover:scale-105 transition-all duration-300 border border-white/20 group animate-scale-in">
            <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center mb-6 glow-primary group-hover:scale-110 transition-all duration-300">
              <Edit3 className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Markdown Editor
            </h3>
            <p className="text-gray-600 mb-4">
              Write your resume in clean Markdown syntax. Focus on content while we handle the formatting.
            </p>
            <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg p-4 font-mono text-sm text-gray-700 border border-gray-200/50">
              ## Work Experience<br/>
              **Software Engineer** at TechCorp<br/>
              *Jan 2023 - Present*
            </div>
          </div>
        <FeaturesSectionWithHoverEffects />
      </div>
    </section>
  );
}