import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowRight } from "lucide-react";

interface BlogPost {
  id: number;
  date: string;
  slug: string;
  title: { rendered: string };
  content: { rendered: string };
  excerpt: { rendered: string };
  featured_media: number;
  categories: number[];
  tags: number[];
}

export default function BlogPreview() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/blog/posts", 1],
    queryFn: () => fetch("/api/blog/posts?per_page=3").then(res => res.json()),
    select: (data) => data as BlogPost[]
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, "").trim();
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse border border-gray-200">
            <CardHeader>
              <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-gray-200 rounded mb-4"></div>
              <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!posts || posts.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">
          Our blog articles are loading. Check back soon for resume tips and formatting guides!
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {posts.map((post) => (
        <Card key={post.id} className="border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200 group">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl font-semibold text-gray-900 group-hover:text-blue-600 transition-colors leading-tight line-clamp-2">
              <Link href={`/blog/${post.slug}`} className="no-underline">
                {stripHtml(post.title.rendered)}
              </Link>
            </CardTitle>
            <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(post.date)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-4 h-4" />
                <span>5 min read</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-gray-600 leading-relaxed mb-4 line-clamp-3">
              {stripHtml(post.excerpt.rendered).substring(0, 150)}...
            </p>
            <Link href={`/blog/${post.slug}`}>
              <Button variant="outline" size="sm" className="group-hover:bg-blue-50 group-hover:border-blue-200 transition-all">
                Read More
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}