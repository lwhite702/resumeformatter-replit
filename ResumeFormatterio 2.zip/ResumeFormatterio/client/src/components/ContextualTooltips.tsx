import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DockDemo } from "@/components/DockDemo";
import { 
  Lightbulb, 
  X, 
  Target, 
  FileText, 
  Users, 
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Star,
  Zap
} from "lucide-react";

interface TooltipData {
  id: string;
  title: string;
  description: string;
  tips: string[];
  category: 'content' | 'formatting' | 'ats' | 'impact';
  priority: 'high' | 'medium' | 'low';
  icon: React.ReactNode;
  examples?: {
    good: string;
    bad: string;
  };
}

const resumeTips: TooltipData[] = [
  {
    id: 'quantify-achievements',
    title: 'Quantify Your Achievements',
    description: 'Use specific numbers, percentages, and metrics to demonstrate your impact.',
    category: 'impact',
    priority: 'high',
    icon: <TrendingUp className="h-4 w-4" />,
    tips: [
      'Include percentages of improvement (increased sales by 25%)',
      'Add dollar amounts for cost savings or revenue generated',
      'Mention team sizes you managed or collaborated with',
      'Specify timeframes for achieving results'
    ],
    examples: {
      good: "Increased team productivity by 30% by implementing new workflow automation",
      bad: "Improved team productivity through better processes"
    }
  },
  {
    id: 'action-verbs',
    title: 'Start with Strong Action Verbs',
    description: 'Begin each bullet point with powerful action verbs to demonstrate leadership and initiative.',
    category: 'content',
    priority: 'high',
    icon: <Zap className="h-4 w-4" />,
    tips: [
      'Use varied action verbs (achieved, implemented, optimized, spearheaded)',
      'Avoid weak verbs like "responsible for" or "helped with"',
      'Match verbs to the level of your involvement',
      'Use past tense for previous roles, present tense for current role'
    ],
    examples: {
      good: "Spearheaded cross-functional initiative to reduce processing time",
      bad: "Was responsible for helping with process improvements"
    }
  },
  {
    id: 'ats-keywords',
    title: 'Include Industry Keywords',
    description: 'Use relevant keywords from job descriptions to pass through Applicant Tracking Systems.',
    category: 'ats',
    priority: 'high',
    icon: <Target className="h-4 w-4" />,
    tips: [
      'Mirror language from job postings you\'re targeting',
      'Include technical skills and software you\'re proficient in',
      'Use industry-standard terminology and acronyms',
      'Balance keyword usage - avoid overstuffing'
    ],
    examples: {
      good: "Experience with React, Node.js, AWS, and agile development methodologies",
      bad: "Good with computers and web stuff"
    }
  },
  {
    id: 'professional-summary',
    title: 'Craft a Compelling Summary',
    description: 'Write a 2-3 line summary that highlights your unique value proposition.',
    category: 'content',
    priority: 'medium',
    icon: <Star className="h-4 w-4" />,
    tips: [
      'Keep it concise (2-3 sentences max)',
      'Highlight your most relevant experience',
      'Include your key skills and achievements',
      'Tailor it to the specific role you\'re applying for'
    ],
    examples: {
      good: "Results-driven marketing manager with 5+ years experience driving 40% revenue growth through data-driven campaigns",
      bad: "Hard-working professional seeking new opportunities to grow and learn"
    }
  },
  {
    id: 'consistent-formatting',
    title: 'Maintain Consistent Formatting',
    description: 'Use consistent fonts, spacing, and bullet points throughout your resume.',
    category: 'formatting',
    priority: 'medium',
    icon: <FileText className="h-4 w-4" />,
    tips: [
      'Use the same bullet point style throughout',
      'Keep font sizes consistent for similar elements',
      'Maintain uniform spacing between sections',
      'Align dates and locations consistently'
    ]
  },
  {
    id: 'relevant-experience',
    title: 'Prioritize Relevant Experience',
    description: 'Lead with experience most relevant to the position you\'re targeting.',
    category: 'content',
    priority: 'medium',
    icon: <CheckCircle className="h-4 w-4" />,
    tips: [
      'Order experiences by relevance, not just chronology',
      'Expand on roles that relate to your target position',
      'Include relevant volunteer work or projects',
      'Consider a functional format if changing industries'
    ]
  }
];

interface ContextualTooltipsProps {
  content: string;
  onClose?: () => void;
  compact?: boolean;
  onAction?: (action: string) => void;
}

export default function ContextualTooltips({ content, onClose, compact = false, onAction }: ContextualTooltipsProps) {
  const [activeTip, setActiveTip] = useState<TooltipData | null>(null);
  const [relevantTips, setRelevantTips] = useState<TooltipData[]>([]);
  const [showTooltips, setShowTooltips] = useState(true);

  useEffect(() => {
    // Analyze content and determine relevant tips
    const tips = analyzeContentForTips(content);
    setRelevantTips(tips.slice(0, 3)); // Show top 3 most relevant tips
  }, [content]);

  const analyzeContentForTips = (resumeContent: string): TooltipData[] => {
    const analysis = {
      hasNumbers: /\d+%|\$[\d,]+|\d+\+|[0-9]+(?:,\d{3})*/.test(resumeContent),
      hasActionVerbs: /^[\s]*[-*•]\s*(achieved|managed|developed|created|implemented|improved|increased|reduced|led|coordinated)/mi.test(resumeContent),
      hasKeywords: /(?:project|team|client|strategy|analysis|leadership|innovation|technology)/gi.test(resumeContent),
      hasSummary: /(?:summary|objective|profile|about)/i.test(resumeContent),
      hasConsistentFormatting: resumeContent.split('\n').filter(line => line.match(/^[\s]*[-*•]\s/)).length >= 3,
      wordCount: resumeContent.trim().split(/\s+/).length
    };

    const suggestions: TooltipData[] = [];

    // Prioritize tips based on content analysis
    if (!analysis.hasNumbers) {
      suggestions.push(resumeTips.find(tip => tip.id === 'quantify-achievements')!);
    }
    
    if (!analysis.hasActionVerbs) {
      suggestions.push(resumeTips.find(tip => tip.id === 'action-verbs')!);
    }
    
    if (!analysis.hasKeywords) {
      suggestions.push(resumeTips.find(tip => tip.id === 'ats-keywords')!);
    }
    
    if (!analysis.hasSummary) {
      suggestions.push(resumeTips.find(tip => tip.id === 'professional-summary')!);
    }
    
    if (!analysis.hasConsistentFormatting) {
      suggestions.push(resumeTips.find(tip => tip.id === 'consistent-formatting')!);
    }

    // Always include relevant experience tip for context
    suggestions.push(resumeTips.find(tip => tip.id === 'relevant-experience')!);

    // Sort by priority
    return suggestions.filter(Boolean).sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'impact': return 'bg-green-100 text-green-800 border-green-300';
      case 'content': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'ats': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'formatting': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="h-3 w-3 text-red-500" />;
      case 'medium': return <Lightbulb className="h-3 w-3 text-yellow-500" />;
      case 'low': return <CheckCircle className="h-3 w-3 text-green-500" />;
      default: return null;
    }
  };

  if (!showTooltips || relevantTips.length === 0) {
    return null;
  }

  if (compact) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Lightbulb className="h-4 w-4 text-yellow-500" />
            Resume Tips
          </h4>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowTooltips(false)}
            className="h-6 w-6 p-0"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
        
        <div className="space-y-2">
          {relevantTips.slice(0, 2).map((tip) => (
            <div 
              key={tip.id}
              className="flex items-start gap-2 p-2 rounded-lg bg-blue-50 hover:bg-blue-100 cursor-pointer transition-colors"
              onClick={() => setActiveTip(tip)}
            >
              <div className="flex items-center gap-1 mt-0.5">
                {tip.icon}
                {getPriorityIcon(tip.priority)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-blue-900 truncate">{tip.title}</p>
                <p className="text-xs text-blue-700 line-clamp-1">{tip.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-yellow-500" />
          Resume Building Tips
        </h3>
        {onClose && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {relevantTips.map((tip) => (
          <Card 
            key={tip.id}
            className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
              activeTip?.id === tip.id ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:bg-gray-50'
            }`}
            onClick={() => setActiveTip(activeTip?.id === tip.id ? null : tip)}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex items-center gap-1">
                  {tip.icon}
                  {getPriorityIcon(tip.priority)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-sm">{tip.title}</h4>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${getCategoryColor(tip.category)}`}
                    >
                      {tip.category}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">{tip.description}</p>
                  
                  {activeTip?.id === tip.id && (
                    <div className="space-y-3 mt-3 pt-3 border-t border-gray-200">
                      <div>
                        <h5 className="text-xs font-medium text-gray-900 mb-1">Best Practices:</h5>
                        <ul className="space-y-1">
                          {tip.tips.map((tipText, index) => (
                            <li key={index} className="text-xs text-gray-600 flex items-start gap-1">
                              <span className="text-blue-500 mt-0.5">•</span>
                              <span>{tipText}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {tip.examples && (
                        <div>
                          <h5 className="text-xs font-medium text-gray-900 mb-2">Examples:</h5>
                          <div className="space-y-2">
                            <div className="p-2 bg-green-50 rounded border border-green-200">
                              <p className="text-xs text-green-800 font-medium mb-1">✓ Good:</p>
                              <p className="text-xs text-green-700">{tip.examples.good}</p>
                            </div>
                            <div className="p-2 bg-red-50 rounded border border-red-200">
                              <p className="text-xs text-red-800 font-medium mb-1">✗ Avoid:</p>
                              <p className="text-xs text-red-700">{tip.examples.bad}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Interactive Quick Actions Dock */}
      <div className="mt-6">
        <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
          <Star className="h-4 w-4 text-yellow-500" />
          Quick Actions
        </h4>
        <DockDemo onAction={onAction} />
      </div>

      {/* Summary */}
      <div className="bg-blue-50 p-3 rounded-lg">
        <p className="text-xs text-blue-700">
          💡 <strong>Pro tip:</strong> These suggestions are based on your current resume content. 
          As you make improvements, new tips will appear to help you create an even stronger resume.
        </p>
      </div>
    </div>
  );
}