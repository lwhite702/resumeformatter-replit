import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Download, Coins, FileText, Sparkles } from "lucide-react";

interface CoverLetterModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeContent: string;
  userPlan: string;
  userCredits: number;
}

export default function CoverLetterModal({ 
  isOpen, 
  onClose, 
  resumeContent, 
  userPlan, 
  userCredits 
}: CoverLetterModalProps) {
  const [jobTitle, setJobTitle] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [tone, setTone] = useState("professional");
  const [generatedLetter, setGeneratedLetter] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Generate cover letter mutation
  const generateMutation = useMutation({
    mutationFn: async () => {
      if (userPlan === "free") {
        throw new Error("Cover letter generation requires a Pro subscription");
      }
      
      if (userCredits < 7) {
        throw new Error("Insufficient credits. Cover letter generation requires 7 credits.");
      }

      const response = await apiRequest("POST", "/api/cover-letters/generate", {
        resumeContent,
        jobTitle: jobTitle.trim(),
        companyName: companyName.trim(),
        tone
      });
      
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedLetter(data.content);
      setIsEditing(true);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Cover letter generated!",
        description: "Your AI-generated cover letter is ready for review and editing.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Export cover letter mutation
  const exportMutation = useMutation({
    mutationFn: async (format: string) => {
      const response = await apiRequest("POST", "/api/cover-letters/export", {
        content: generatedLetter,
        format,
        jobTitle: jobTitle.trim(),
        companyName: companyName.trim()
      });
      
      return response.blob();
    },
    onSuccess: (blob, format) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cover-letter-${companyName || 'company'}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Cover letter exported!",
        description: `Your cover letter has been downloaded as ${format.toUpperCase()}.`,
      });
    },
    onError: () => {
      toast({
        title: "Export failed",
        description: "Failed to export cover letter. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!jobTitle.trim()) {
      toast({
        title: "Job title required",
        description: "Please enter the job title you're applying for.",
        variant: "destructive",
      });
      return;
    }
    
    generateMutation.mutate();
  };

  const handleReset = () => {
    setGeneratedLetter("");
    setIsEditing(false);
    setJobTitle("");
    setCompanyName("");
    setTone("professional");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>AI Cover Letter Generator</span>
            {userPlan === "free" && (
              <Badge variant="outline" className="ml-2">Pro Feature</Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        {!isEditing ? (
          // Generation Form
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">
                  AI-Powered Cover Letter Generation
                </span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-blue-700">
                <Coins className="h-4 w-4" />
                <span>7 credits required</span>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Job Title *
                </label>
                <Input
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  placeholder="e.g., Senior Software Engineer"
                  disabled={generateMutation.isPending}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Company Name
                </label>
                <Input
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g., Google"
                  disabled={generateMutation.isPending}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tone
              </label>
              <Select value={tone} onValueChange={setTone} disabled={generateMutation.isPending}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="executive">Executive</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {userPlan === "free" && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <Sparkles className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-amber-800">
                      Upgrade to Pro Required
                    </h3>
                    <p className="text-sm text-amber-700 mt-1">
                      AI cover letter generation is available for Pro subscribers only. 
                      Upgrade to unlock this feature along with advanced templates and optimization tools.
                    </p>
                    <Button size="sm" className="mt-2" onClick={() => window.location.href = '/pricing'}>
                      Upgrade to Pro
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          // Editing Interface
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Generated Cover Letter</h3>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={handleReset}>
                  Generate New
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => exportMutation.mutate("pdf")}
                  disabled={exportMutation.isPending}
                >
                  <Download className="h-4 w-4 mr-1" />
                  PDF
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => exportMutation.mutate("docx")}
                  disabled={exportMutation.isPending}
                >
                  <Download className="h-4 w-4 mr-1" />
                  DOCX
                </Button>
              </div>
            </div>
            
            <Textarea
              value={generatedLetter}
              onChange={(e) => setGeneratedLetter(e.target.value)}
              rows={20}
              className="font-mono text-sm"
              placeholder="Your generated cover letter will appear here..."
            />
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          {!isEditing && (
            <Button 
              onClick={handleGenerate}
              disabled={generateMutation.isPending || userPlan === "free"}
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Cover Letter
                </>
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}