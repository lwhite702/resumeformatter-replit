import { SignUpButton } from "@clerk/clerk-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, FileText, Crown, Star } from "lucide-react";

interface DemoExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeTitle: string;
}

export default function DemoExportModal({ isOpen, onClose, resumeTitle }: DemoExportModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Resume
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Ready to download your resume?</h3>
            <p className="text-sm text-gray-600">
              Sign up for free to download "{resumeTitle}" as PDF, DOCX, or HTML.
            </p>
          </div>

          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Star className="h-4 w-4 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-blue-900 mb-1">Free Account Includes:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Unlimited resume editing</li>
                    <li>• PDF, DOCX & HTML downloads</li>
                    <li>• 16+ professional templates</li>
                    <li>• AI optimization suggestions</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <SignUpButton mode="modal">
              <Button className="w-full" size="lg">
                <Crown className="h-4 w-4 mr-2" />
                Sign Up Free & Download
              </Button>
            </SignUpButton>
            
            <Button variant="outline" onClick={onClose} className="w-full">
              Continue Editing
            </Button>
          </div>

          <p className="text-xs text-center text-gray-500">
            No credit card required • Takes less than 30 seconds
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}