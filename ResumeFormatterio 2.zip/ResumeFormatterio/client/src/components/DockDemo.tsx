import { Dock } from "@/components/ui/dock-two"
import {
  FileText,
  Lightbulb,
  BarChart3,
  Sparkles,
  Download,
  Eye,
  History
} from "lucide-react"

interface DockDemoProps {
  onAction?: (action: string) => void;
  activeActions?: string[];
}

export function DockDemo({ onAction, activeActions = [] }: DockDemoProps) {
  const items = [
    { 
      icon: FileText, 
      label: "Templates",
      onClick: () => onAction?.("templates")
    },
    { 
      icon: Lightbulb, 
      label: "Tips",
      onClick: () => onAction?.("tips")
    },
    { 
      icon: BarChart3, 
      label: "Health Score",
      onClick: () => onAction?.("health")
    },
    { 
      icon: Sparkles, 
      label: "AI Optimize",
      onClick: () => onAction?.("optimize")
    },
    { 
      icon: Eye, 
      label: "Preview",
      onClick: () => onAction?.("preview")
    },
    { 
      icon: History, 
      label: "Versions",
      onClick: () => onAction?.("versions")
    },
    { 
      icon: Download, 
      label: "Export",
      onClick: () => onAction?.("export")
    }
  ]

  return (
    <div className="w-full">
      <Dock 
        items={items} 
        className="h-32"
      />
    </div>
  )
}

