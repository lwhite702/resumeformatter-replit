import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Download, FileText, Globe, Crown, ExternalLink } from "lucide-react";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  resume: any;
  userPlan: string;
}

export default function ExportModal({ 
  isOpen, 
  onClose, 
  resume, 
  userPlan 
}: ExportModalProps) {
  const [activeTab, setActiveTab] = useState("formats");
  const { toast } = useToast();

  // Export mutations
  const pdfMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/resumes/${resume.id}/export/pdf`);
      if (!response.ok) throw new Error("Export failed");
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resume.title || 'resume'}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "PDF exported successfully!",
        description: "Your resume has been downloaded.",
      });
    },
    onError: () => {
      toast({
        title: "Export failed",
        description: "Failed to export PDF. Please try again.",
        variant: "destructive",
      });
    },
  });

  const docxMutation = useMutation({
    mutationFn: async () => {
      if (userPlan === "free") {
        throw new Error("DOCX export requires a Pro subscription");
      }
      
      const response = await fetch(`/api/resumes/${resume.id}/export/docx`);
      if (!response.ok) throw new Error("Export failed");
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resume.title || 'resume'}.docx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "DOCX exported successfully!",
        description: "Your resume has been downloaded.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const htmlMutation = useMutation({
    mutationFn: async () => {
      if (userPlan === "free") {
        throw new Error("HTML export requires a Pro subscription");
      }
      
      const response = await fetch(`/api/resumes/${resume.id}/export/html`);
      if (!response.ok) throw new Error("Export failed");
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resume.title || 'resume'}.html`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "HTML exported successfully!",
        description: "Your resume has been downloaded.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportIntegrationMutation = useMutation({
    mutationFn: async (platform: string) => {
      const response = await apiRequest("POST", `/api/export/${platform}/${resume.id}`, {});
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Export successful!",
        description: `Resume exported to ${data.platform} successfully.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportFormats = [
    {
      id: "pdf",
      name: "PDF",
      description: "Universal format, works everywhere",
      icon: FileText,
      available: true,
      watermark: userPlan === "free",
      mutation: pdfMutation,
      note: userPlan === "free" ? "Free version includes watermark" : "Professional quality PDF"
    },
    {
      id: "docx",
      name: "Word Document",
      description: "Microsoft Word format",
      icon: FileText,
      available: userPlan === "pro",
      watermark: false,
      mutation: docxMutation,
      note: userPlan === "free" ? "Upgrade to Pro to unlock" : "Fully editable Word document"
    },
    {
      id: "html",
      name: "Web Page",
      description: "HTML format for web sharing",
      icon: Globe,
      available: userPlan === "pro",
      watermark: false,
      mutation: htmlMutation,
      note: userPlan === "free" ? "Upgrade to Pro to unlock" : "Share online or host on your website"
    }
  ];

  const integrations = [
    {
      id: "preppair",
      name: "PrepPair.me",
      description: "Export to interview preparation platform",
      available: userPlan === "pro",
      comingSoon: false
    },
    {
      id: "linkedin",
      name: "LinkedIn",
      description: "Update LinkedIn profile",
      available: false,
      comingSoon: true
    },
    {
      id: "indeed",
      name: "Indeed",
      description: "Post to Indeed profile",
      available: false,
      comingSoon: true
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5" />
            <span>Export Resume</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="formats">Export Formats</TabsTrigger>
            <TabsTrigger value="integrations">Integrations</TabsTrigger>
          </TabsList>

          <TabsContent value="formats" className="space-y-4">
            <div className="grid gap-4">
              {exportFormats.map((format) => (
                <Card key={format.id} className={`${!format.available ? 'opacity-60' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <format.icon className="h-8 w-8 text-blue-600" />
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium">{format.name}</h3>
                            {format.watermark && (
                              <Badge variant="outline" className="text-xs">Watermark</Badge>
                            )}
                            {!format.available && (
                              <Badge className="text-xs bg-gradient-to-r from-yellow-400 to-orange-500">
                                <Crown className="h-3 w-3 mr-1" />
                                Pro
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{format.description}</p>
                          <p className="text-xs text-gray-500 mt-1">{format.note}</p>
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => format.mutation.mutate()}
                        disabled={!format.available || format.mutation.isPending}
                        size="sm"
                      >
                        {format.mutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Download className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {userPlan === "free" && (
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <Crown className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium text-blue-800">
                      Unlock Premium Export Formats
                    </h3>
                    <p className="text-sm text-blue-700 mt-1">
                      Upgrade to Pro for DOCX and HTML exports without watermarks, plus additional features.
                    </p>
                    <Button size="sm" className="mt-2" onClick={() => window.location.href = '/pricing'}>
                      Upgrade to Pro
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="integrations" className="space-y-4">
            <div className="grid gap-4">
              {integrations.map((integration) => (
                <Card key={integration.id} className={`${!integration.available && !integration.comingSoon ? 'opacity-60' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium">{integration.name}</h3>
                          {integration.comingSoon && (
                            <Badge variant="outline" className="text-xs">Coming Soon</Badge>
                          )}
                          {!integration.available && !integration.comingSoon && (
                            <Badge className="text-xs bg-gradient-to-r from-yellow-400 to-orange-500">
                              <Crown className="h-3 w-3 mr-1" />
                              Pro
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{integration.description}</p>
                      </div>
                      
                      <Button
                        onClick={() => exportIntegrationMutation.mutate(integration.id)}
                        disabled={!integration.available || integration.comingSoon || exportIntegrationMutation.isPending}
                        size="sm"
                        variant={integration.comingSoon ? "outline" : "default"}
                      >
                        {exportIntegrationMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : integration.comingSoon ? (
                          "Soon"
                        ) : (
                          <ExternalLink className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}