import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "How does the AI resume optimization work?",
      answer: "Our AI analyzes your resume content against current industry standards and ATS requirements. It provides specific suggestions for keywords, formatting, and content improvements to increase your chances of passing through applicant tracking systems and catching recruiters' attention."
    },
    {
      question: "Are your templates compatible with all ATS systems?",
      answer: "Yes, all our templates are designed with ATS compatibility in mind. We use clean formatting, standard fonts, and proper heading structures that work with major ATS platforms like Workday, Greenhouse, and Lever."
    },
    {
      question: "Can I import my existing resume?",
      answer: "Absolutely! You can upload PDF or DOCX files, or simply copy and paste your existing resume content. Our AI will convert it to clean markdown format while preserving all your information."
    },
    {
      question: "How many resume versions can I create?",
      answer: "You can create unlimited resume versions with our service. Each version is automatically saved, and you can easily switch between different versions tailored for specific job applications or industries."
    },
    {
      question: "What export formats do you support?",
      answer: "You can export your resume as PDF or DOCX. We also offer direct integration with PrepPair.me for interview preparation and LinkedIn for easy profile updates."
    },
    {
      question: "Is my personal information secure?",
      answer: "Yes, we take data security seriously. All personal information is encrypted and stored securely. We never share your data with third parties, and you can delete your account and all associated data at any time."
    },
    {
      question: "Do you offer cover letter creation?",
      answer: "Yes! Our AI can generate personalized cover letters based on your resume content and the specific job description you're targeting. Each cover letter is tailored to highlight relevant experience and skills."
    },
    {
      question: "Can I use this for free?",
      answer: "We offer a free tier that includes basic resume creation and one template. Premium features like AI optimization, multiple templates, and export options are available with our paid plans."
    },
    {
      question: "How often are your templates updated?",
      answer: "We regularly update our templates based on current hiring trends and recruiter feedback. New templates are added monthly, and existing ones are refined to ensure they meet current industry standards."
    },
    {
      question: "Do you provide customer support?",
      answer: "Yes, we offer comprehensive customer support through email and live chat. Our team is available to help with technical issues, template customization, and general resume advice."
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Everything you need to know about creating professional resumes with our platform
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-white rounded-lg border border-gray-200 px-6"
              >
                <AccordionTrigger className="text-left font-semibold text-gray-900 hover:text-blue-600">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <div className="space-x-4">
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              Contact Support
            </button>
            <span className="text-gray-400">|</span>
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              View Documentation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}