return (
    <div className="glass-card border border-white/20 rounded-lg shadow-lg overflow-hidden h-full flex flex-col animate-fade-in">
      {/* Preview Header */}
      <div className="bg-gradient-to-r from-gray-50/80 to-blue-50/80 backdrop-blur-sm border-b border-white/20 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Eye className="w-4 h-4 text-blue-600" />
          <span className="text-sm font-medium bg-gradient-to-r from-gray-700 to-blue-700 bg-clip-text text-transparent">Live Preview</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setScale(Math.max(0.5, scale - 0.1))}
            className="p-1 text-gray-500 hover:text-blue-600 transition-all duration-300 hover:scale-110 rounded"
            title="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono bg-white/50 px-2 py-1 rounded-full text-gray-700 min-w-[3rem] text-center">
            {Math.round(scale * 100)}%
          </span>
          <button
            onClick={() => setScale(Math.min(2, scale + 0.1))}
            className="p-1 text-gray-500 hover:text-blue-600 transition-all duration-300 hover:scale-110 rounded"
            title="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>
      </div>
{/* Preview Footer */}
      <div className="p-4 border-t border-white/20 bg-gradient-to-r from-gray-50/80 to-blue-50/80 backdrop-blur-sm text-center">
        <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center space-x-1 bg-white/50 px-2 py-1 rounded-full">
            <div 
              className="w-3 h-3 rounded-full glow-primary"
              style={{ backgroundColor: theme.colors.primary }}
            />
            <span className="font-medium">Theme: {theme.name}</span>
          </div>
          <div className="text-gray-400">•</div>
          <div className="bg-white/50 px-2 py-1 rounded-full">Spacing: {theme.layout.spacing}</div>
          <div className="text-gray-400">•</div>
          <div className="bg-white/50 px-2 py-1 rounded-full">Font: {theme.typography.headingFont}</div>
          {theme.isPro && (
            <>
              <div className="text-gray-400">•</div>
              <Badge variant="secondary" className="text-xs gradient-secondary text-white border-0 glow-secondary">Pro</Badge>
            </>
          )}
        </div>
      </div>