import { useState, useEffect, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { 
  Bold, 
  Italic, 
  List, 
  Link, 
  Heading1, 
  Heading2, 
  Heading3,
  Save
} from "lucide-react";

interface MarkdownEditorProps {
  content: string;
  onChange: (content: string) => void;
  onTitleChange: (title: string) => void;
  title: string;
  resumeId?: string;
  onAutoSaveStatusChange: (status: "saved" | "saving" | "unsaved") => void;
}

export default function MarkdownEditor({
  content,
  onChange,
  onTitleChange,
  title,
  resumeId,
  onAutoSaveStatusChange,
}: MarkdownEditorProps) {
  const { toast } = useToast();
  const [lastSavedContent, setLastSavedContent] = useState(content);
  const [lastSavedTitle, setLastSavedTitle] = useState(title);

  // Auto-save mutation
  const autoSaveMutation = useMutation({
    mutationFn: async ({ content, title }: { content: string; title: string }) => {
      if (!resumeId) return;
      await apiRequest("PATCH", `/api/resumes/${resumeId}`, { content, title });
    },
    onMutate: () => {
      onAutoSaveStatusChange("saving");
    },
    onSuccess: () => {
      onAutoSaveStatusChange("saved");
      setLastSavedContent(content);
      setLastSavedTitle(title);
    },
    onError: (error: Error) => {
      onAutoSaveStatusChange("unsaved");
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error("Auto-save failed:", error);
    },
  });

  // Auto-save logic
  useEffect(() => {
    const hasChanges = content !== lastSavedContent || title !== lastSavedTitle;
    
    if (hasChanges) {
      onAutoSaveStatusChange("unsaved");
      
      const timeoutId = setTimeout(() => {
        if (resumeId) {
          autoSaveMutation.mutate({ content, title });
        }
      }, 2000); // Auto-save after 2 seconds of inactivity

      return () => clearTimeout(timeoutId);
    }
  }, [content, title, lastSavedContent, lastSavedTitle, resumeId, autoSaveMutation, onAutoSaveStatusChange]);

  // Toolbar functions
  const insertAtCursor = useCallback((textToInsert: string, wrapSelection: boolean = false) => {
    const textarea = document.querySelector('textarea') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    
    let newText;
    if (wrapSelection && selectedText) {
      newText = content.substring(0, start) + textToInsert + selectedText + textToInsert + content.substring(end);
    } else {
      newText = content.substring(0, start) + textToInsert + content.substring(end);
    }
    
    onChange(newText);
    
    // Restore cursor position
    setTimeout(() => {
      const newPosition = start + textToInsert.length + (wrapSelection && selectedText ? selectedText.length : 0);
      textarea.focus();
      textarea.setSelectionRange(newPosition, newPosition);
    }, 0);
  }, [content, onChange]);

  const formatBold = () => insertAtCursor("**", true);
  const formatItalic = () => insertAtCursor("*", true);
  const formatHeading1 = () => insertAtCursor("# ");
  const formatHeading2 = () => insertAtCursor("## ");
  const formatHeading3 = () => insertAtCursor("### ");
  const formatList = () => insertAtCursor("- ");
  const formatLink = () => insertAtCursor("[link text](url)");

  const handleManualSave = () => {
    if (resumeId) {
      autoSaveMutation.mutate({ content, title });
    }
  };

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Editor Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold">Editor</h2>
          <div className="hidden sm:block">
            <Input
              value={title}
              onChange={(e) => onTitleChange(e.target.value)}
              className="max-w-xs"
              placeholder="Resume title..."
            />
          </div>
        </div>

        {/* Formatting Toolbar */}
        <div className="flex items-center space-x-1 bg-accent p-1 rounded-lg">
          <Button variant="ghost" size="sm" onClick={formatBold} title="Bold">
            <Bold className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={formatItalic} title="Italic">
            <Italic className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={formatHeading1} title="Heading 1">
            <Heading1 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={formatHeading2} title="Heading 2">
            <Heading2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={formatHeading3} title="Heading 3">
            <Heading3 className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={formatList} title="Bullet List">
            <List className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={formatLink} title="Add Link">
            <Link className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleManualSave}
            disabled={autoSaveMutation.isPending}
            title="Save"
          >
            <Save className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Mobile title input */}
      <div className="sm:hidden p-4 border-b border-border">
        <Input
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder="Resume title..."
        />
      </div>

      {/* Editor Content */}
      <div className="flex-1 relative">
        <Textarea
          value={content}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Start writing your resume in Markdown..."
          className="w-full h-full resize-none border-none focus:ring-0 font-mono text-sm leading-relaxed p-4"
          style={{ 
            minHeight: "100%",
            fontFamily: "'JetBrains Mono', 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace"
          }}
        />
        
        {/* Markdown guide overlay */}
        {!content && (
          <div className="absolute top-20 left-4 right-4 text-sm text-muted-foreground pointer-events-none">
            <div className="bg-accent/50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Markdown Quick Guide:</h4>
              <ul className="space-y-1 text-xs">
                <li><code># Header 1</code> - Main sections</li>
                <li><code>## Header 2</code> - Subsections</li>
                <li><code>**Bold text**</code> - Important info</li>
                <li><code>*Italic text*</code> - Emphasis</li>
                <li><code>- List item</code> - Bullet points</li>
                <li><code>[Link](url)</code> - Links</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
