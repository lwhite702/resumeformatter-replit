import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Zap, Share2 } from "lucide-react";
import QuickExport from "@/components/QuickExport";
import ExportModal from "@/components/ExportModal";
import DemoExportModal from "@/components/DemoExportModal";

interface MobileExportTabProps {
  resumeId: string;
  resumeTitle: string;
  resumeContent: string;
  templateId: number | null;
  userPlan?: string;
  demoMode?: boolean;
}

export default function MobileExportTab({
  resumeId,
  resumeTitle, 
  resumeContent,
  templateId,
  userPlan = 'free',
  demoMode = false
}: MobileExportTabProps) {
  const [showFullExport, setShowFullExport] = useState(false);

  return (
    <div className="p-4 space-y-6">
      {/* Quick Export Section */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="w-5 h-5 text-orange-500" />
              Quick Export
            </CardTitle>
            <Badge variant="secondary" className="text-xs">
              New
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <QuickExport
            resumeId={resumeId}
            resumeTitle={resumeTitle}
            resumeContent={resumeContent}
            templateId={templateId}
            userPlan={userPlan}
            demoMode={demoMode}
          />
        </CardContent>
      </Card>

      {/* Advanced Export Options */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Download className="w-5 h-5 text-blue-500" />
            More Export Options
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setShowFullExport(true)}
            >
              <Download className="w-4 h-4 mr-2" />
              Advanced Export Settings
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start"
              disabled={demoMode}
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share & Collaborate
              {demoMode && (
                <Badge variant="outline" className="ml-auto text-xs">
                  Sign In Required
                </Badge>
              )}
            </Button>
          </div>

          <div className="text-xs text-muted-foreground space-y-1">
            <div>• Advanced formatting options</div>
            <div>• Batch export multiple versions</div>
            <div>• Integration with job boards</div>
            <div>• Custom branding (Pro)</div>
          </div>
        </CardContent>
      </Card>

      {/* Export Tips */}
      <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/50">
        <CardContent className="pt-4">
          <div className="text-sm space-y-2">
            <div className="font-medium text-blue-700 dark:text-blue-300">
              Export Tips
            </div>
            <ul className="text-xs text-blue-600 dark:text-blue-400 space-y-1">
              <li>• PDF format is most compatible with ATS systems</li>
              <li>• LinkedIn export helps optimize your profile</li>
              <li>• JSON format is perfect for portfolio websites</li>
              <li>• Always preview before final export</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Full Export Modal */}
      {demoMode ? (
        <DemoExportModal
          isOpen={showFullExport}
          onClose={() => setShowFullExport(false)}
          resumeTitle={resumeTitle}
        />
      ) : (
        <ExportModal
          isOpen={showFullExport}
          onClose={() => setShowFullExport(false)}
          content={resumeContent}
          templateId={templateId}
          title={resumeTitle}
        />
      )}
    </div>
  );
}