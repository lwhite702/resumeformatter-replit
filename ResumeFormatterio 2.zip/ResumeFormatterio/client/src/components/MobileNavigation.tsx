import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  Eye, 
  Download, 
  Sparkles, 
  History, 
  FileText, 
  Menu 
} from "lucide-react";

interface MobileNavigationProps {
  activeTab: "edit" | "preview" | "export";
  onTabChange: (tab: "edit" | "preview" | "export") => void;
  onOptimize: () => void;
  onVersions: () => void;
  onExport: () => void;
  onCoverLetter: () => void;
  userPlan: string;
  autoSaveStatus: "saved" | "saving" | "unsaved";
}

export default function MobileNavigation({
  activeTab,
  onTabChange,
  onOptimize,
  onVersions,
  onExport,
  onCoverLetter,
  userPlan,
  autoSaveStatus
}: MobileNavigationProps) {
  const tabs = [
    {
      id: "edit" as const,
      label: "Edit",
      icon: Edit,
      onClick: () => onTabChange("edit")
    },
    {
      id: "preview" as const,
      label: "Preview",
      icon: Eye,
      onClick: () => onTabChange("preview")
    },
    {
      id: "export" as const,
      label: "Export",
      icon: Download,
      onClick: () => onTabChange("export")
    }
  ];

  const actions = [
    {
      label: "Optimize",
      icon: Sparkles,
      onClick: onOptimize,
      isPro: true,
      variant: "default" as const
    },
    {
      label: "Versions",
      icon: History,
      onClick: onVersions,
      isPro: true,
      variant: "outline" as const
    },
    {
      label: "Cover Letter",
      icon: FileText,
      onClick: onCoverLetter,
      isPro: true,
      variant: "outline" as const
    }
  ];

  const getAutoSaveIcon = () => {
    switch (autoSaveStatus) {
      case 'saving':
        return <div className="w-2 h-2 border border-primary border-t-transparent rounded-full animate-spin" />;
      case 'saved':
        return <div className="w-2 h-2 bg-green-500 rounded-full" />;
      case 'unsaved':
        return <div className="w-2 h-2 bg-red-500 rounded-full" />;
      default:
        return <div className="w-2 h-2 bg-green-500 rounded-full" />;
    }
  };

  return (
    <div className="md:hidden">
      {/* Bottom Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50">
        {/* Main Tabs */}
        <div className="flex justify-around mb-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={tab.onClick}
              className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center space-x-2 pb-2">
          {actions.map((action) => (
            <Button
              key={action.label}
              variant={action.variant}
              size="sm"
              onClick={action.onClick}
              disabled={action.isPro && userPlan === "free"}
              className="flex items-center space-x-1"
            >
              <action.icon className="h-4 w-4" />
              <span className="text-xs">{action.label}</span>
              {action.isPro && userPlan === "free" && (
                <Badge variant="outline" className="text-xs ml-1">Pro</Badge>
              )}
            </Button>
          ))}
        </div>

        {/* Auto-save Status */}
        <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
          {getAutoSaveIcon()}
          <span>
            {autoSaveStatus === 'saving' ? 'Saving...' : 
             autoSaveStatus === 'saved' ? 'Saved' : 
             'Unsaved changes'}
          </span>
        </div>
      </div>

      {/* Spacer to prevent content from being hidden behind fixed nav */}
      <div className="h-32" />
    </div>
  );
}