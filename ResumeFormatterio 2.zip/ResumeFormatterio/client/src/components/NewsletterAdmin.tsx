import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Mail, 
  Users, 
  TrendingUp, 
  UserPlus, 
  UserMinus, 
  BarChart3,
  Calendar,
  Download,
  Send
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface NewsletterStats {
  local: {
    totalSubscribers: number;
    newSubscribers7d: number;
  };
  beehiiv?: {
    total_subscribers: number;
    active_subscribers: number;
    total_posts: number;
    total_sends: number;
  };
}

export default function NewsletterAdmin() {
  const [testEmail, setTestEmail] = useState("");
  const [testName, setTestName] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/newsletter/stats"],
    select: (data) => data as NewsletterStats
  });

  const queryClient = useQueryClient();

  const subscribeTestMutation = useMutation({
    mutationFn: async (data: { email: string; name?: string }) => {
      const response = await fetch("/api/newsletter/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error("Subscription failed");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/newsletter/stats"] });
      setTestEmail("");
      setTestName("");
    }
  });

  const unsubscribeTestMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await fetch("/api/newsletter/unsubscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      if (!response.ok) throw new Error("Unsubscribe failed");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/newsletter/stats"] });
    }
  });

  const handleTestSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testEmail) return;
    
    subscribeTestMutation.mutate({
      email: testEmail,
      name: testName || undefined
    });
  };

  const handleTestUnsubscribe = () => {
    if (!testEmail) return;
    unsubscribeTestMutation.mutate(testEmail);
  };

  if (statsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-3">
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Newsletter Management</h2>
          <p className="text-gray-600 mt-1">Manage "The Resume Refresh" newsletter subscribers</p>
        </div>
        <div className="flex items-center space-x-2">
          <Mail className="w-5 h-5 text-blue-600" />
          <span className="font-medium text-gray-900">The Resume Refresh</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              Total Subscribers
            </CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {stats?.beehiiv?.active_subscribers || stats?.local?.totalSubscribers || 0}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {stats?.beehiiv ? "From Beehiiv" : "Local database"}
            </p>
          </CardContent>
        </Card>

        <Card className="border border-gray-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              New This Week
            </CardTitle>
            <UserPlus className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">
              {stats?.local?.newSubscribers7d || 0}
            </div>
            <p className="text-xs text-gray-500 mt-1">Last 7 days</p>
          </CardContent>
        </Card>

        {stats?.beehiiv && (
          <>
            <Card className="border border-gray-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Posts
                </CardTitle>
                <Send className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {stats.beehiiv.total_posts}
                </div>
                <p className="text-xs text-gray-500 mt-1">Published</p>
              </CardContent>
            </Card>

            <Card className="border border-gray-200">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Sends
                </CardTitle>
                <BarChart3 className="h-4 w-4 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">
                  {stats.beehiiv.total_sends.toLocaleString()}
                </div>
                <p className="text-xs text-gray-500 mt-1">All time</p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Integration Status */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Integration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                <span className="font-medium">Beehiiv API</span>
              </div>
              <Badge variant={stats?.beehiiv ? "default" : "secondary"}>
                {stats?.beehiiv ? "Connected" : "Not Configured"}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                <span className="font-medium">Local Database</span>
              </div>
              <Badge variant="default">Active</Badge>
            </div>

            {!stats?.beehiiv && (
              <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Setup Required:</strong> Configure BEEHIIV_API_KEY and BEEHIIV_PUBLICATION_ID 
                  environment variables to enable full newsletter management features.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Test Subscription */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Test Newsletter Subscription
          </CardTitle>
          <p className="text-sm text-gray-600">
            Test the subscription and unsubscription process
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleTestSubscribe} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                type="email"
                placeholder="Test email"
                value={testEmail}
                onChange={(e) => setTestEmail(e.target.value)}
                required
              />
              <Input
                type="text"
                placeholder="Test name (optional)"
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
              />
            </div>
            
            <div className="flex space-x-3">
              <Button
                type="submit"
                disabled={subscribeTestMutation.isPending || !testEmail}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {subscribeTestMutation.isPending ? "Subscribing..." : "Test Subscribe"}
                <UserPlus className="ml-2 w-4 h-4" />
              </Button>
              
              <Button
                type="button"
                variant="outline"
                onClick={handleTestUnsubscribe}
                disabled={unsubscribeTestMutation.isPending || !testEmail}
              >
                {unsubscribeTestMutation.isPending ? "Unsubscribing..." : "Test Unsubscribe"}
                <UserMinus className="ml-2 w-4 h-4" />
              </Button>
            </div>

            {subscribeTestMutation.isError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                <p className="text-sm text-red-700">
                  Subscription failed: {subscribeTestMutation.error?.message}
                </p>
              </div>
            )}

            {subscribeTestMutation.isSuccess && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                <p className="text-sm text-green-700">
                  Test subscription successful!
                </p>
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      {/* Newsletter Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            Newsletter Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900">The Resume Refresh</h4>
              <p className="text-sm text-gray-600 mt-1">
                Monthly resume tips, Markdown tricks, and template spotlights to help users build resumes that win.
              </p>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium text-gray-900">Target Audience:</span>
                <p className="text-gray-600">Job seekers, career changers, freelancers</p>
              </div>
              <div>
                <span className="font-medium text-gray-900">Content Focus:</span>
                <p className="text-gray-600">Resume formatting, ATS optimization, Markdown tips</p>
              </div>
              <div>
                <span className="font-medium text-gray-900">Frequency:</span>
                <p className="text-gray-600">Monthly</p>
              </div>
              <div>
                <span className="font-medium text-gray-900">Lead Magnet:</span>
                <p className="text-gray-600">Free resume template + Markdown guide</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}