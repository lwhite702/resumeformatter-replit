import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, ArrowRight, ArrowLeft, Eye, FileText, Download, Sparkles, Play } from "lucide-react";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  target: string;
  icon: React.ReactNode;
  position: "top" | "bottom" | "left" | "right";
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: "welcome",
    title: "Welcome to ResumeFormatter.io",
    description: "Build professional resumes with Markdown in under 3 minutes. Let's get you started!",
    target: ".editor-container",
    icon: <FileText className="w-5 h-5" />,
    position: "bottom"
  },
  {
    id: "editor",
    title: "Markdown Editor",
    description: "Type or paste your resume content here. Use Markdown for formatting - it's faster than traditional editors.",
    target: ".markdown-editor",
    icon: <FileText className="w-5 h-5" />,
    position: "right"
  },
  {
    id: "preview",
    title: "Live Preview",
    description: "Click the 👁️ to see your resume styled in real-time. Watch your changes appear instantly.",
    target: ".preview-toggle",
    icon: <Eye className="w-5 h-5" />,
    position: "bottom"
  },
  {
    id: "templates",
    title: "Professional Templates",
    description: "Switch between ATS-friendly templates instantly. Each template is optimized for different industries.",
    target: ".template-selector",
    icon: <Sparkles className="w-5 h-5" />,
    position: "left"
  },
  {
    id: "export",
    title: "Export Options",
    description: "Download as PDF, DOCX, or HTML. Perfect for job applications and sharing with recruiters.",
    target: ".export-button",
    icon: <Download className="w-5 h-5" />,
    position: "bottom"
  }
];

interface OnboardingTourProps {
  isOpen: boolean;
  onComplete: () => void;
  onSkip: () => void;
}

export default function OnboardingTour({ isOpen, onComplete, onSkip }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsVisible(true);
      setCurrentStep(0);
    }
  }, [isOpen]);

  if (!isVisible || !isOpen) return null;

  const step = onboardingSteps[currentStep];
  const isLastStep = currentStep === onboardingSteps.length - 1;
  const isFirstStep = currentStep === 0;

  const handleNext = () => {
    if (isLastStep) {
      handleComplete();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (!isFirstStep) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    onComplete();
  };

  const handleSkip = () => {
    setIsVisible(false);
    onSkip();
  };

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50" />
      
      {/* Tour Card */}
      <div className="fixed z-[60] max-w-sm">
        <Card className="border-2 border-blue-200 shadow-2xl">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                {step.icon}
                <Badge variant="outline" className="text-xs">
                  Step {currentStep + 1} of {onboardingSteps.length}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkip}
                className="h-6 w-6 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Content */}
            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                {step.description}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex space-x-1">
                {onboardingSteps.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1 flex-1 rounded-full ${
                      index <= currentStep ? "bg-blue-600" : "bg-gray-200"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                onClick={handlePrevious}
                disabled={isFirstStep}
                className="flex items-center space-x-1"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Previous</span>
              </Button>

              <Button
                onClick={handleNext}
                size="sm"
                className="flex items-center space-x-1 bg-blue-600 hover:bg-blue-700"
              >
                <span>{isLastStep ? "Get Started" : "Next"}</span>
                {isLastStep ? (
                  <Play className="w-4 h-4" />
                ) : (
                  <ArrowRight className="w-4 h-4" />
                )}
              </Button>
            </div>

            {/* Skip Option */}
            <div className="mt-4 text-center">
              <button
                onClick={handleSkip}
                className="text-xs text-gray-500 hover:text-gray-700 underline"
              >
                Skip tour
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

// Quick Start Sample Resume
export const sampleResumeMarkdown = `# Alex Johnson
**Software Engineer** | alex.johnson@email.com | (555) 123-4567  
LinkedIn: linkedin.com/in/alexjohnson | GitHub: github.com/alexjohnson

## Professional Summary
Experienced software engineer with 5+ years developing scalable web applications. Passionate about clean code, user experience, and continuous learning.

## Experience

### Senior Software Engineer | TechCorp Inc.
*January 2022 - Present*
- Built and maintained React applications serving 100k+ daily users
- Reduced page load times by 40% through performance optimization
- Led team of 4 developers on major product redesign project
- Implemented automated testing resulting in 95% code coverage

### Software Engineer | StartupXYZ
*June 2019 - December 2021*
- Developed RESTful APIs using Node.js and Express
- Collaborated with design team to implement responsive UI components
- Migrated legacy codebase to modern JavaScript frameworks
- Mentored 2 junior developers and conducted code reviews

## Education

### Bachelor of Science in Computer Science
**University of Technology** | 2015 - 2019
- Graduated Magna Cum Laude (GPA: 3.8/4.0)
- Relevant Coursework: Data Structures, Algorithms, Software Engineering

## Skills
- **Languages:** JavaScript, TypeScript, Python, Java
- **Frontend:** React, Vue.js, HTML5, CSS3, Tailwind CSS
- **Backend:** Node.js, Express, Django, PostgreSQL, MongoDB
- **Tools:** Git, Docker, AWS, Jenkins, Jest

## Projects

### Portfolio Website
Personal portfolio showcasing projects and technical blog posts
- Built with React and deployed on Vercel
- Integrated with headless CMS for content management

### Task Management App
Full-stack application for team project management
- React frontend with Node.js/Express backend
- Real-time updates using WebSocket connections
- User authentication and role-based permissions`;