import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle, AlertTriangle, Lightbulb, Coins } from "lucide-react";
import { cn } from "@/lib/utils";

interface OptimizationModalProps {
  resume: any;
  onClose: () => void;
  onOptimized: (resume: any) => void;
}

export default function OptimizationModal({ 
  resume, 
  onClose, 
  onOptimized 
}: OptimizationModalProps) {
  const [jobDescription, setJobDescription] = useState("");
  const [analysis, setAnalysis] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Analyze resume
  const analyzeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/resumes/${resume.id}/analyze`, {
        jobDescription: jobDescription.trim() || undefined,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setAnalysis(data);
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Apply optimizations
  const optimizeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/resumes/${resume.id}/optimize`, {
        suggestions: analysis.suggestions,
      });
      return res.json();
    },
    onSuccess: (data) => {
      onOptimized(data);
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Resume Optimized",
        description: "Your resume has been improved with AI suggestions.",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Optimization Failed",
        description: "Failed to optimize resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 75) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Lightbulb className="h-5 w-5 text-primary" />
            <span>AI Resume Optimization</span>
          </DialogTitle>
          <p className="text-sm text-gray-600">
            Improve your resume's ATS compatibility and impact
          </p>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6">
          {/* Job Description Input */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Job Description (Optional)
            </label>
            <Textarea
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the job description here to get tailored suggestions..."
              className="h-32 resize-none"
            />
          </div>

          {/* Analysis Button */}
          {!analysis && (
            <div className="flex justify-center">
              <Button
                onClick={() => analyzeMutation.mutate()}
                disabled={analyzeMutation.isPending}
                size="lg"
              >
                {analyzeMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Lightbulb className="mr-2 h-4 w-4" />
                    Analyze Resume
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Analysis Results */}
          {analysis && (
            <div className="space-y-6">
              {/* ATS Score */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      ATS Analysis
                    </h3>
                    <Badge className={cn(
                      "text-sm font-medium",
                      analysis.score >= 90 
                        ? "bg-green-100 text-green-800"
                        : analysis.score >= 75
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                    )}>
                      Score: {analysis.score}/100
                    </Badge>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Matched Keywords */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Matched Keywords ({analysis.matchedKeywords.length})
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {analysis.matchedKeywords.map((keyword: string, index: number) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="bg-green-100 text-green-800"
                          >
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Missing Keywords */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                        <AlertTriangle className="h-4 w-4 text-amber-500 mr-2" />
                        Missing Keywords ({analysis.missingKeywords.length})
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {analysis.missingKeywords.map((keyword: string, index: number) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="bg-amber-100 text-amber-800"
                          >
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Improvement Suggestions */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Top Improvement Suggestions
                </h3>
                <div className="space-y-4">
                  {analysis.suggestions.map((suggestion: any, index: number) => (
                    <Card key={index} className="border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex items-center justify-center w-6 h-6 bg-primary text-white rounded-full text-sm font-medium flex-shrink-0 mt-1">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 mb-2">
                              {suggestion.title}
                            </h4>
                            <p className="text-sm text-gray-700 mb-3">
                              {suggestion.description}
                            </p>
                            {suggestion.example && (
                              <div className="bg-gray-50 p-3 rounded-md text-sm">
                                <p className="text-gray-600 mb-2">
                                  <strong>Current:</strong> {suggestion.example.current}
                                </p>
                                <p className="text-gray-900">
                                  <strong>Suggested:</strong> {suggestion.example.suggested}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex items-center justify-between border-t pt-4">
          <div className="flex items-center text-sm text-gray-600">
            <Coins className="h-4 w-4 text-secondary mr-1" />
            This will use {analysis ? "2" : "1"} credits
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            {analysis && (
              <Button
                onClick={() => optimizeMutation.mutate()}
                disabled={optimizeMutation.isPending}
              >
                {optimizeMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Optimizing...
                  </>
                ) : (
                  "Apply Suggestions"
                )}
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
