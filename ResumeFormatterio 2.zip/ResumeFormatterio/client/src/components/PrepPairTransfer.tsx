import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, ExternalLink, Zap, CheckCircle, AlertCircle } from "lucide-react";

interface PrepPairTransferProps {
  resumeId: string | undefined;
  resumeTitle: string;
  onSuccess?: (interviewPrepUrl: string) => void;
  trigger?: React.ReactNode;
}

export default function PrepPairTransfer({ 
  resumeId, 
  resumeTitle, 
  onSuccess,
  trigger
}: PrepPairTransferProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const transferMutation = useMutation({
    mutationFn: async () => {
      if (!resumeId) throw new Error("Resume ID is required");
      const response = await fetch(`/api/resumes/${resumeId}/send-to-preppair`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Transfer failed");
      }
      
      return await response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Resume Sent Successfully!",
        description: "Your resume has been transferred to PrepPair.me for interview preparation.",
      });
      
      if (data.interview_prep_url && onSuccess) {
        onSuccess(data.interview_prep_url);
      }
      
      // Refresh transfer history
      queryClient.invalidateQueries({ queryKey: ["/api/preppair-transfers"] });
      setIsOpen(false);
    },
    onError: (error: any) => {
      let message = "Failed to transfer resume to PrepPair.me";
      
      if (error.message.includes("validation_error")) {
        message = error.message.replace("Error: ", "");
      } else if (error.message.includes("transfer_error")) {
        message = "PrepPair.me is temporarily unavailable. Please try again later.";
      }
      
      toast({
        title: "Transfer Failed",
        description: message,
        variant: "destructive",
      });
    },
  });

  const defaultTrigger = (
    <Button 
      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
      disabled={!resumeId}
    >
      <Zap className="w-4 h-4 mr-2" />
      Send to PrepPair
      <ArrowRight className="w-4 h-4 ml-2" />
    </Button>
  );

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-purple-600" />
            Send Resume to PrepPair.me
          </DialogTitle>
          <DialogDescription>
            Transfer your resume to PrepPair.me for AI-powered interview preparation and practice.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg border border-purple-200">
            <h3 className="font-medium text-purple-900 mb-2">What you'll get:</h3>
            <ul className="space-y-1 text-sm text-purple-800">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Personalized interview questions based on your resume
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                AI-powered mock interview practice sessions
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Performance feedback and improvement suggestions
              </li>
            </ul>
          </div>

          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <div className="text-sm text-amber-800">
              <strong>Resume:</strong> {resumeTitle || "Untitled Resume"}
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => transferMutation.mutate()}
              disabled={transferMutation.isPending || !resumeId}
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {transferMutation.isPending ? (
                <>
                  <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Transferring...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Send Resume
                </>
              )}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              disabled={transferMutation.isPending}
            >
              Cancel
            </Button>
          </div>

          <div className="text-xs text-gray-600 text-center">
            Your resume will be securely transferred using Replit OAuth authentication
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}