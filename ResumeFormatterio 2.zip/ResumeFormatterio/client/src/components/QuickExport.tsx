import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Download, 
  FileText, 
  Users, 
  Code,
  ExternalLink,
  Copy,
  CheckCircle,
  AlertCircle,
  Loader2
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface QuickExportProps {
  resumeId: string | number;
  resumeTitle: string;
  resumeContent: string;
  templateId: number | null;
  userPlan?: string;
  demoMode?: boolean;
}

interface ExportFormat {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
  isPro: boolean;
  features: string[];
  action: string;
}

interface ExportProgress {
  format: string;
  status: 'idle' | 'processing' | 'success' | 'error';
  progress: number;
  url?: string;
  error?: string;
}

export default function QuickExport({ 
  resumeId, 
  resumeTitle, 
  resumeContent,
  templateId,
  userPlan = 'free',
  demoMode = false
}: QuickExportProps) {
  const [exportProgress, setExportProgress] = useState<Record<string, ExportProgress>>({});
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const { toast } = useToast();

  const exportFormats: ExportFormat[] = [
    {
      id: 'pdf',
      name: 'PDF',
      description: 'Professional PDF for job applications',
      icon: FileText,
      color: 'text-red-600 bg-red-50 border-red-200',
      isPro: false,
      features: ['ATS-friendly', 'Print-ready', 'Universal format'],
      action: 'Download'
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      description: 'Optimized format for LinkedIn profile',
      icon: Users,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      isPro: true,
      features: ['Profile optimization', 'Skill extraction', 'Summary generation'],
      action: 'Generate'
    },
    {
      id: 'json',
      name: 'JSON',
      description: 'Structured data for integrations',
      icon: Code,
      color: 'text-green-600 bg-green-50 border-green-200',
      isPro: false,
      features: ['API integration', 'Data portability', 'Custom processing'],
      action: 'Generate'
    }
  ];

  const initializeProgress = (format: string) => {
    setExportProgress(prev => ({
      ...prev,
      [format]: {
        format,
        status: 'processing',
        progress: 0
      }
    }));
  };

  const updateProgress = (format: string, progress: number) => {
    setExportProgress(prev => ({
      ...prev,
      [format]: {
        ...prev[format],
        progress: Math.min(progress, 100)
      }
    }));
  };

  const completeProgress = (format: string, url?: string, error?: string) => {
    setExportProgress(prev => ({
      ...prev,
      [format]: {
        ...prev[format],
        status: error ? 'error' : 'success',
        progress: 100,
        url,
        error
      }
    }));
  };

  // PDF Export Mutation
  const pdfMutation = useMutation({
    mutationFn: async () => {
      if (demoMode) {
        throw new Error("Please sign in to export your resume to PDF");
      }
      
      const response = await apiRequest(`/api/resumes/${resumeId}/export/pdf`, {
        method: 'POST',
        body: {
          templateId: templateId || 1,
          options: { addWatermark: userPlan === 'free' }
        }
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'PDF export failed');
      }

      return response.blob();
    },
    onMutate: () => {
      initializeProgress('pdf');
      const interval = setInterval(() => {
        updateProgress('pdf', exportProgress.pdf?.progress || 0 + 20);
      }, 300);
      
      setTimeout(() => clearInterval(interval), 2000);
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resumeTitle || 'resume'}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      completeProgress('pdf');
      toast({
        title: "PDF exported successfully!",
        description: "Your resume has been downloaded.",
      });
    },
    onError: (error: Error) => {
      completeProgress('pdf', undefined, error.message);
      toast({
        title: "Export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // LinkedIn Export Mutation
  const linkedinMutation = useMutation({
    mutationFn: async () => {
      if (demoMode) {
        throw new Error("Please sign in to generate LinkedIn content");
      }

      if (userPlan === 'free') {
        throw new Error("LinkedIn export is a Pro feature. Upgrade to access this functionality.");
      }

      const response = await apiRequest(`/api/resumes/${resumeId}/export/linkedin`, {
        method: 'POST',
        body: { content: resumeContent }
      });

      return response.json();
    },
    onMutate: () => {
      initializeProgress('linkedin');
      const interval = setInterval(() => {
        updateProgress('linkedin', exportProgress.linkedin?.progress || 0 + 15);
      }, 400);
      
      setTimeout(() => clearInterval(interval), 3000);
    },
    onSuccess: (data) => {
      completeProgress('linkedin', data.url || '#');
      toast({
        title: "LinkedIn content generated!",
        description: "Your LinkedIn-optimized content is ready.",
      });
    },
    onError: (error: Error) => {
      completeProgress('linkedin', undefined, error.message);
      toast({
        title: "LinkedIn export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // JSON Export Mutation
  const jsonMutation = useMutation({
    mutationFn: async () => {
      if (demoMode) {
        throw new Error("Please sign in to export resume data");
      }

      const response = await apiRequest(`/api/resumes/${resumeId}/export/json`, {
        method: 'POST',
        body: { 
          content: resumeContent,
          title: resumeTitle,
          templateId: templateId || 1
        }
      });

      return response.json();
    },
    onMutate: () => {
      initializeProgress('json');
      const interval = setInterval(() => {
        updateProgress('json', exportProgress.json?.progress || 0 + 25);
      }, 200);
      
      setTimeout(() => clearInterval(interval), 1500);
    },
    onSuccess: (data) => {
      const jsonBlob = new Blob([JSON.stringify(data, null, 2)], {
        type: 'application/json'
      });
      const url = window.URL.createObjectURL(jsonBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resumeTitle || 'resume'}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      completeProgress('json', url);
      toast({
        title: "JSON exported successfully!",
        description: "Your structured resume data has been downloaded.",
      });
    },
    onError: (error: Error) => {
      completeProgress('json', undefined, error.message);
      toast({
        title: "JSON export failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleExport = (format: ExportFormat) => {
    switch (format.id) {
      case 'pdf':
        pdfMutation.mutate();
        break;
      case 'linkedin':
        linkedinMutation.mutate();
        break;
      case 'json':
        jsonMutation.mutate();
        break;
    }
  };

  const copyToClipboard = async (text: string, format: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedUrl(format);
      setTimeout(() => setCopiedUrl(null), 2000);
      toast({
        title: "Copied to clipboard",
        description: "The content has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Could not copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  const isProcessing = pdfMutation.isPending || linkedinMutation.isPending || jsonMutation.isPending;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Quick Export</h3>
        <Badge variant="outline" className="text-xs">
          {exportFormats.filter(f => !f.isPro || userPlan === 'pro').length} formats available
        </Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {exportFormats.map((format) => {
          const progress = exportProgress[format.id];
          const Icon = format.icon;
          const isBlocked = format.isPro && userPlan !== 'pro';
          const isActive = progress?.status === 'processing';
          const isCompleted = progress?.status === 'success';
          const hasError = progress?.status === 'error';

          return (
            <Card 
              key={format.id} 
              className={`transition-all duration-200 ${
                isActive ? 'ring-2 ring-primary ring-offset-2' : 
                isCompleted ? 'ring-2 ring-green-500 ring-offset-2' :
                hasError ? 'ring-2 ring-red-500 ring-offset-2' : ''
              } ${isBlocked ? 'opacity-60' : ''}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className={`p-2 rounded-lg ${format.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  {format.isPro && (
                    <Badge variant="secondary" className="text-xs">
                      Pro
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-base">{format.name}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  {format.description}
                </p>
                
                <div className="space-y-1">
                  {format.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-xs text-muted-foreground">
                      <div className="w-1 h-1 bg-current rounded-full mr-2" />
                      {feature}
                    </div>
                  ))}
                </div>

                {progress && (
                  <div className="space-y-2">
                    <Progress value={progress.progress} className="h-2" />
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">
                        {progress.status === 'processing' ? 'Processing...' : 
                         progress.status === 'success' ? 'Completed' : 
                         progress.status === 'error' ? 'Failed' : ''}
                      </span>
                      <span className="text-muted-foreground">
                        {progress.progress}%
                      </span>
                    </div>
                  </div>
                )}

                {hasError && (
                  <div className="flex items-start gap-2 p-2 bg-red-50 rounded-lg border border-red-200">
                    <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <span className="text-xs text-red-700">{progress?.error}</span>
                  </div>
                )}

                {isCompleted && progress?.url && format.id === 'linkedin' && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-xs text-green-700">Ready to use</span>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 text-xs"
                        onClick={() => window.open(progress.url, '_blank')}
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(progress.url || '', format.id)}
                      >
                        {copiedUrl === format.id ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                <Button
                  className="w-full"
                  onClick={() => handleExport(format)}
                  disabled={isBlocked || isProcessing || isCompleted}
                  variant={isCompleted ? "outline" : "default"}
                >
                  {isActive ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : isCompleted ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Completed
                    </>
                  ) : isBlocked ? (
                    'Upgrade Required'
                  ) : (
                    <>
                      <Download className="w-4 h-4 mr-2" />
                      {format.action}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {demoMode && (
        <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm font-medium">Demo Mode</span>
            </div>
            <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">
              Sign in to export your resume to PDF, generate LinkedIn content, and access structured JSON data.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}