import { Button } from "@/components/ui/button";
import { Play, FileText } from "lucide-react";
import { sampleResumeMarkdown } from "./OnboardingTour";

interface QuickStartButtonProps {
  onQuickStart: (content: string) => void;
  variant?: "default" | "outline" | "secondary";
  size?: "sm" | "default" | "lg";
  className?: string;
}

export default function QuickStartButton({ 
  onQuickStart, 
  variant = "default",
  size = "default",
  className = ""
}: QuickStartButtonProps) {
  const handleQuickStart = () => {
    onQuickStart(sampleResumeMarkdown);
  };

  return (
    <Button
      onClick={handleQuickStart}
      variant={variant}
      size={size}
      className={`flex items-center space-x-2 ${className}`}
    >
      <Play className="w-4 h-4" />
      <span>Quick Start</span>
      <FileText className="w-4 h-4" />
    </Button>
  );
}