
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { FileText, Upload, Palette, Download } from 'lucide-react';

interface QuickStartDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function QuickStartDialog({ open, onOpenChange }: QuickStartDialogProps) {
  const steps = [
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Create Your Resume",
      description: "Start with a template or import your existing resume"
    },
    {
      icon: <Upload className="h-6 w-6" />,
      title: "Add Your Content",
      description: "Use our markdown editor to add your experience and skills"
    },
    {
      icon: <Palette className="h-6 w-6" />,
      title: "Choose a Template",
      description: "Select from our collection of professional templates"
    },
    {
      icon: <Download className="h-6 w-6" />,
      title: "Export & Apply",
      description: "Download your resume and start applying to jobs"
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Welcome to Resume Formatter!</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-muted-foreground">
            Get started with these simple steps to create your professional resume.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {steps.map((step, index) => (
              <Card key={index} className="p-4">
                <CardContent className="p-0">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                      {step.icon}
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">{step.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Skip for now
            </Button>
            <Button onClick={() => onOpenChange(false)}>
              Get Started
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
