import { useState, useEffect, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Save, Bold, Italic, List, Link, FileText } from "lucide-react";
import { debounce } from "lodash-es";

interface ResumeEditorProps {
  resume: any;
  onResumeChange: (resume: any) => void;
}

export default function ResumeEditor({ resume, onResumeChange }: ResumeEditorProps) {
  const [markdown, setMarkdown] = useState(resume?.markdown || "");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Auto-save mutation
  const saveMutation = useMutation({
    mutationFn: async (content: string) => {
      if (resume?.id) {
        const res = await apiRequest("PUT", `/api/resumes/${resume.id}`, {
          markdown: content,
        });
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/resumes", {
          title: "New Resume",
          markdown: content,
          templateId: 1,
        });
        return res.json();
      }
    },
    onSuccess: (updatedResume) => {
      setLastSaved(new Date());
      onResumeChange(updatedResume);
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: "Failed to save resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Debounced auto-save
  const debouncedSave = useCallback(
    debounce((content: string) => {
      if (content.trim()) {
        saveMutation.mutate(content);
      }
    }, 2000),
    [resume?.id]
  );

  // Handle content changes
  const handleChange = (value: string) => {
    setMarkdown(value);
    debouncedSave(value);
  };

  // Manual save
  const handleManualSave = () => {
    if (markdown.trim()) {
      saveMutation.mutate(markdown);
    }
  };

  // Formatting functions
  const insertFormatting = (before: string, after: string = "") => {
    const textarea = document.querySelector('textarea') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = markdown.slice(start, end);
    const newText = before + selectedText + after;
    
    const newValue = markdown.slice(0, start) + newText + markdown.slice(end);
    setMarkdown(newValue);
    
    // Reset cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, start + before.length + selectedText.length);
    }, 0);
  };

  // Initialize with resume content
  useEffect(() => {
    if (resume?.markdown) {
      setMarkdown(resume.markdown);
    }
  }, [resume?.id]);

  const defaultMarkdown = `# Your Name
## Job Title

**Email:** your.email@example.com  
**Phone:** (555) 123-4567  
**Location:** City, State  
**LinkedIn:** linkedin.com/in/yourname  

---

## Summary

Write a compelling 2-3 sentence summary that highlights your key qualifications and career goals.

---

## Experience

### **Job Title** | Company Name | Start Date - End Date
- Achievement-focused bullet point with quantified results
- Another accomplishment that demonstrates your impact
- Technical skills or tools used in this role

### **Previous Job Title** | Previous Company | Start Date - End Date  
- Key responsibility or achievement
- Quantified result that shows your value
- Relevant skills or technologies

---

## Skills

**Technical Skills:** List your relevant technical skills  
**Languages:** Programming languages or spoken languages  
**Tools:** Software, platforms, or tools you're proficient in

---

## Education

### **Degree Name**
Institution Name | Graduation Year  
**Relevant Info:** GPA, honors, relevant coursework

---

## Projects

### **Project Name**
Brief description of the project and your role  
**Technologies:** Tech stack used  
**Link:** github.com/username/project
`;

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold text-gray-900">Editor</h2>
          {lastSaved && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Save className="h-4 w-4 text-green-500" />
              <span>Saved {lastSaved.toLocaleTimeString()}</span>
            </div>
          )}
        </div>

        {/* Formatting Toolbar */}
        <div className="hidden sm:flex items-center space-x-1 bg-gray-100 p-1 rounded-md">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => insertFormatting("**", "**")}
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => insertFormatting("*", "*")}
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => insertFormatting("- ", "")}
            title="Bullet List"
          >
            <List className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => insertFormatting("[", "](url)")}
            title="Link"
          >
            <Link className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 relative">
        <Textarea
          value={markdown || defaultMarkdown}
          onChange={(e) => handleChange(e.target.value)}
          placeholder="Start writing your resume in Markdown..."
          className="w-full h-full border-0 resize-none font-mono text-sm leading-relaxed focus-visible:ring-0"
        />

        {/* Save button for mobile */}
        <div className="absolute bottom-4 right-4 lg:hidden">
          <Button
            onClick={handleManualSave}
            disabled={saveMutation.isPending}
            className="rounded-full shadow-lg"
          >
            {saveMutation.isPending ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
