"use client";

import * as React from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import {
  FileText,
  Sparkles,
  Download,
  History,
  Eye,
  Shield,
  ArrowUpRight,
} from "lucide-react";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function Card({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="card"
      className={cn(
        "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
        className
      )}
      {...props}
    />
  );
}

function CardContent({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="card-content"
      className={cn("px-6", className)}
      {...props}
    />
  );
}

const features = [
  {
    title: "Professional Templates",
    description:
      "Choose from 16+ ATS-optimized templates designed by industry experts for maximum impact.",
    href: "#templates",
    icon: FileText,
    iconForeground: "text-blue-700",
    iconBackground: "bg-blue-50 dark:bg-blue-950/30",
    ringColorClass: "ring-blue-700/30",
  },
  {
    title: "AI-Powered Optimization",
    description:
      "Get intelligent suggestions to improve your resume score and pass ATS screening systems.",
    href: "#ai",
    icon: Sparkles,
    iconForeground: "text-purple-700",
    iconBackground: "bg-purple-50 dark:bg-purple-950/30",
    ringColorClass: "ring-purple-700/30",
  },
  {
    title: "Multiple Export Formats",
    description:
      "Download your resume as PDF, DOCX, or HTML. Perfect formatting guaranteed every time.",
    href: "#export",
    icon: Download,
    iconForeground: "text-green-700",
    iconBackground: "bg-green-50 dark:bg-green-950/30",
    ringColorClass: "ring-green-700/30",
  },
  {
    title: "Version Control",
    description:
      "Keep track of all changes and easily switch between different resume versions for various jobs.",
    href: "#versions",
    icon: History,
    iconForeground: "text-orange-700",
    iconBackground: "bg-orange-50 dark:bg-orange-950/30",
    ringColorClass: "ring-orange-700/30",
  },
  {
    title: "Real-time Preview",
    description:
      "See exactly how your resume will look while you edit with our live markdown preview system.",
    href: "#preview",
    icon: Eye,
    iconForeground: "text-indigo-700",
    iconBackground: "bg-indigo-50 dark:bg-indigo-950/30",
    ringColorClass: "ring-indigo-700/30",
  },
  {
    title: "Privacy & Security",
    description:
      "Your personal information is encrypted and secure. Delete your data anytime with one click.",
    href: "#security",
    icon: Shield,
    iconForeground: "text-red-700",
    iconBackground: "bg-red-50 dark:bg-red-950/30",
    ringColorClass: "ring-red-700/30",
  },
];

export default function ResumeFeatures() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need for the Perfect Resume
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Professional tools and features designed to help you create, optimize, and export resumes that get results
          </p>
        </div>
        
        <div className="flex items-center justify-center">
          <div className="overflow-hidden rounded-[1rem] bg-gray-50 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 sm:gap-0.5 space-y-0.5 sm:space-y-0 p-0.5 max-w-6xl">
            {features.map((feature) => (
              <Card
                key={feature.title}
                className={cn(
                  "group relative rounded-xl border-0 bg-white p-0 focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-inset hover:shadow-lg transition-all duration-200"
                )}
              >
                <CardContent className="p-6">
                  <div>
                    <span
                      className={cn(
                        feature.iconBackground,
                        feature.iconForeground,
                        "inline-flex rounded-lg p-3 ring-2 ring-inset",
                        feature.ringColorClass
                      )}
                    >
                      <feature.icon aria-hidden="true" className="h-6 w-6" />
                    </span>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-base font-semibold text-gray-900">
                      <a href={feature.href} className="focus:outline-none">
                        <span aria-hidden="true" className="absolute inset-0" />
                        {feature.title}
                      </a>
                    </h3>
                    <p className="mt-2 text-sm text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute top-6 right-6 text-gray-400 group-hover:text-gray-500"
                  >
                    <ArrowUpRight className="h-6 w-6" />
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}