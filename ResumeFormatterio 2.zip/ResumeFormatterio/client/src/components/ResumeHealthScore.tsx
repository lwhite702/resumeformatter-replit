import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  Target,
  FileText,
  Clock,
  Eye,
  Zap
} from "lucide-react";

interface ResumeHealthScoreProps {
  content: string;
  title?: string;
  onImprove?: () => void;
}

interface HealthMetric {
  id: string;
  name: string;
  score: number;
  maxScore: number;
  status: 'excellent' | 'good' | 'needs-improvement' | 'critical';
  description: string;
  suggestions: string[];
  icon: React.ReactNode;
}

export default function ResumeHealthScore({ content, title = "", onImprove }: ResumeHealthScoreProps) {
  const [animatedScore, setAnimatedScore] = useState(0);
  const [showDetails, setShowDetails] = useState(false);
  const [metrics, setMetrics] = useState<HealthMetric[]>([]);

  const analyzeResume = (resumeContent: string, resumeTitle: string): HealthMetric[] => {
    const wordCount = resumeContent.trim().split(/\s+/).length;
    const lines = resumeContent.trim().split('\n').filter(line => line.trim().length > 0);
    
    // 1. RELEVANCE TO ROLE (25 points)
    const actionVerbs = ['achieved', 'managed', 'developed', 'created', 'implemented', 'improved', 'increased', 'reduced', 'led', 'coordinated', 'designed', 'built', 'optimized', 'delivered', 'launched', 'executed', 'streamlined', 'established'];
    const actionVerbMatches = actionVerbs.filter(verb => new RegExp(`\\b${verb}`, 'i').test(resumeContent)).length;
    const industryKeywords = /(?:project|team|client|strategy|analysis|leadership|innovation|technology|digital|business|management|operations|sales|marketing|development)/gi;
    const keywordMatches = (resumeContent.match(industryKeywords) || []).length;
    const roleRelevanceScore = Math.min(25, (actionVerbMatches * 1.5) + Math.min(keywordMatches * 0.8, 10));

    // 2. READABILITY (20 points)
    const avgWordsPerLine = lines.length ? wordCount / lines.length : 0;
    const optimalReadability = avgWordsPerLine >= 5 && avgWordsPerLine <= 12;
    const bulletPoints = (resumeContent.match(/^[\s]*[-*•]\s/gm) || []).length;
    const hasGoodStructure = bulletPoints >= 5;
    const properSentenceStructure = /[.!?]\s*$/.test(resumeContent.trim());
    const readabilityScore = (optimalReadability ? 8 : 4) + (hasGoodStructure ? 8 : Math.min(bulletPoints * 1.5, 6)) + (properSentenceStructure ? 4 : 0);

    // 3. ATS COMPLIANCE (20 points)
    const hasEmail = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/.test(resumeContent);
    const hasPhone = /(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/.test(resumeContent);
    const noATSBlockers = !/(?:table|image|graphic|chart|column)/i.test(resumeContent) && !/\t/.test(resumeContent);
    const standardSections = /(?:experience|education|skills|summary)/gi.test(resumeContent);
    const simpleFormatting = !resumeContent.includes('|') && !resumeContent.includes('─');
    const atsScore = (hasEmail ? 5 : 0) + (hasPhone ? 4 : 0) + (noATSBlockers ? 4 : 0) + (standardSections ? 4 : 0) + (simpleFormatting ? 3 : 0);

    // 4. STRUCTURE/LAYOUT (15 points)
    const hasSections = {
      summary: /(?:summary|objective|profile|about)/i.test(resumeContent),
      experience: /(?:experience|work|employment|career|professional)/i.test(resumeContent),
      education: /(?:education|degree|university|college|school|academic)/i.test(resumeContent),
      skills: /(?:skills|technical|competencies|technologies|tools)/i.test(resumeContent),
      contact: hasEmail || hasPhone
    };
    const sectionCount = Object.values(hasSections).filter(Boolean).length;
    const hasLogicalOrder = /summary.*experience.*education|experience.*education.*skills/i.test(resumeContent);
    const structureScore = Math.min(15, (sectionCount * 2.5) + (hasLogicalOrder ? 3 : 0));

    // 5. ACHIEVEMENT LANGUAGE (20 points)
    const quantifiableResults = (resumeContent.match(/\d+%|\$[\d,]+|\d+\+|[0-9]+(?:,\d{3})*(?:\.\d+)?[kKmM]?|\d+(?:\.\d+)?[xX]|increased.*\d+|reduced.*\d+|improved.*\d+/g) || []).length;
    const impactWords = ['increased', 'reduced', 'improved', 'generated', 'saved', 'grew', 'exceeded', 'delivered', 'accelerated', 'enhanced', 'maximized'];
    const impactMatches = impactWords.filter(word => new RegExp(`\\b${word}`, 'i').test(resumeContent)).length;
    const resultOriented = /(?:resulted in|led to|achieved|accomplished|delivered)/gi.test(resumeContent);
    const achievementScore = Math.min(20, (quantifiableResults * 2.5) + (impactMatches * 1.5) + (resultOriented ? 3 : 0));

    // BONUS SCORES
    // Template Fit (5 points)
    const hasProperCapitalization = /[A-Z][a-z]/.test(resumeContent) && !/[a-z][A-Z]/.test(resumeContent);
    const hasConsistentFormatting = /^#{1,3}\s/.test(resumeContent) && lines.length >= 8;
    const templateFitBonus = Math.min(5, (hasProperCapitalization ? 2 : 0) + (hasConsistentFormatting ? 3 : 0));

    // Formatting Consistency (5 points)
    const hasConsistentDates = /(19|20)\d{2}/.test(resumeContent);
    const hasLinkedIn = /linkedin\.com|LinkedIn/.test(resumeContent);
    const consistentBullets = /^[\s]*[-*•]\s/gm.test(resumeContent);
    const formattingBonus = Math.min(5, (hasConsistentDates ? 2 : 0) + (hasLinkedIn ? 2 : 0) + (consistentBullets ? 1 : 0));

    return [
      {
        id: 'relevance',
        name: 'Role Relevance',
        score: Math.round(roleRelevanceScore),
        maxScore: 25,
        status: roleRelevanceScore >= 20 ? 'excellent' : roleRelevanceScore >= 15 ? 'good' : roleRelevanceScore >= 10 ? 'needs-improvement' : 'critical',
        description: 'Professional keywords and action verbs',
        suggestions: [
          actionVerbMatches < 5 ? 'Use more strong action verbs (achieved, managed, developed, etc.)' : '',
          keywordMatches < 8 ? 'Include relevant industry keywords and terminology' : '',
          'Focus on accomplishments rather than job duties'
        ].filter(s => s.length > 0),
        icon: <Target className="w-4 h-4" />
      },
      {
        id: 'readability',
        name: 'Readability',
        score: Math.round(readabilityScore),
        maxScore: 20,
        status: readabilityScore >= 16 ? 'excellent' : readabilityScore >= 12 ? 'good' : readabilityScore >= 8 ? 'needs-improvement' : 'critical',
        description: 'Clear structure and easy scanning',
        suggestions: [
          !optimalReadability ? 'Keep lines concise with 5-12 words for better readability' : '',
          bulletPoints < 5 ? 'Use bullet points to organize achievements and responsibilities' : '',
          !properSentenceStructure ? 'End statements with proper punctuation' : ''
        ].filter(s => s.length > 0),
        icon: <FileText className="w-4 h-4" />
      },
      {
        id: 'ats',
        name: 'ATS Compliance',
        score: Math.round(atsScore),
        maxScore: 20,
        status: atsScore >= 16 ? 'excellent' : atsScore >= 12 ? 'good' : atsScore >= 8 ? 'needs-improvement' : 'critical',
        description: 'Applicant Tracking System compatibility',
        suggestions: [
          !hasEmail ? 'Add a professional email address' : '',
          !hasPhone ? 'Include your phone number' : '',
          !noATSBlockers ? 'Avoid tables, images, or complex formatting that ATS cannot read' : '',
          !simpleFormatting ? 'Use simple formatting without special characters or tables' : ''
        ].filter(s => s.length > 0),
        icon: <Zap className="w-4 h-4" />
      },
      {
        id: 'structure',
        name: 'Structure & Layout',
        score: Math.round(structureScore),
        maxScore: 15,
        status: structureScore >= 12 ? 'excellent' : structureScore >= 9 ? 'good' : structureScore >= 6 ? 'needs-improvement' : 'critical',
        description: 'Logical organization and essential sections',
        suggestions: [
          !hasSections.summary ? 'Add a professional summary or objective' : '',
          !hasSections.experience ? 'Include work experience section' : '',
          !hasSections.education ? 'Add education background' : '',
          !hasSections.skills ? 'Include relevant skills section' : ''
        ].filter(s => s.length > 0),
        icon: <Eye className="w-4 h-4" />
      },
      {
        id: 'achievements',
        name: 'Achievement Language',
        score: Math.round(achievementScore),
        maxScore: 20,
        status: achievementScore >= 16 ? 'excellent' : achievementScore >= 12 ? 'good' : achievementScore >= 8 ? 'needs-improvement' : 'critical',
        description: 'Quantifiable results and impact',
        suggestions: [
          quantifiableResults < 3 ? 'Add specific numbers, percentages, and metrics to show impact' : '',
          impactMatches < 3 ? 'Use result-oriented language (increased, reduced, improved, etc.)' : '',
          !resultOriented ? 'Focus on what you accomplished, not just what you did' : ''
        ].filter(s => s.length > 0),
        icon: <Clock className="w-4 h-4" />
      }
    ];
  };

  useEffect(() => {
    const calculatedMetrics = analyzeResume(content, title);
    setMetrics(calculatedMetrics);
    
    // Calculate base score (100 points) + bonus points (up to 10)
    const baseScore = calculatedMetrics.reduce((sum, metric) => sum + metric.score, 0);
    
    // Add bonus scoring calculations
    const lines = content.trim().split('\n').filter(line => line.trim().length > 0);
    const hasProperCapitalization = /[A-Z][a-z]/.test(content) && !/[a-z][A-Z]/.test(content);
    const hasConsistentFormatting = /^#{1,3}\s/.test(content) && lines.length >= 8;
    const templateFitBonus = Math.min(5, (hasProperCapitalization ? 2 : 0) + (hasConsistentFormatting ? 3 : 0));
    
    const hasConsistentDates = /(19|20)\d{2}/.test(content);
    const hasLinkedIn = /linkedin\.com|LinkedIn/.test(content);
    const consistentBullets = /^[\s]*[-*•]\s/gm.test(content);
    const formattingBonus = Math.min(5, (hasConsistentDates ? 2 : 0) + (hasLinkedIn ? 2 : 0) + (consistentBullets ? 1 : 0));
    
    const finalScore = Math.min(110, baseScore + templateFitBonus + formattingBonus);
    
    // Animate score from 0 to final score
    let currentScore = 0;
    const increment = finalScore / 30; // 30 steps animation
    const timer = setInterval(() => {
      currentScore += increment;
      if (currentScore >= finalScore) {
        currentScore = finalScore;
        clearInterval(timer);
      }
      setAnimatedScore(Math.round(currentScore));
    }, 50);

    return () => clearInterval(timer);
  }, [content, title]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    if (score >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreStatus = (score: number) => {
    if (score >= 90) return { label: "Excellent", color: "bg-green-500" };
    if (score >= 75) return { label: "Good", color: "bg-yellow-500" };
    if (score >= 60) return { label: "Needs Improvement", color: "bg-orange-500" };
    return { label: "Critical", color: "bg-red-500" };
  };

  const getMetricIcon = (status: string) => {
    switch (status) {
      case 'excellent': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'good': return <CheckCircle className="w-4 h-4 text-yellow-600" />;
      case 'needs-improvement': return <AlertCircle className="w-4 h-4 text-orange-600" />;
      case 'critical': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const scoreStatus = getScoreStatus(animatedScore);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Resume Health Score</span>
          <Badge variant="outline" className={scoreStatus.color + " text-white"}>
            {scoreStatus.label}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Score Display */}
        <div className="text-center space-y-4">
          <div className={`text-6xl font-bold ${getScoreColor(animatedScore)}`}>
            {animatedScore}
            <span className="text-2xl text-gray-500">/100</span>
          </div>
          <Progress value={animatedScore} className="h-3" />
          <p className="text-sm text-gray-600">
            {animatedScore >= 80 && "Your resume is in excellent shape! 🎉"}
            {animatedScore >= 60 && animatedScore < 80 && "Good foundation with room for improvement"}
            {animatedScore >= 40 && animatedScore < 60 && "Several areas need attention"}
            {animatedScore < 40 && "Significant improvements needed"}
          </p>
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {metrics.map((metric) => (
            <div key={metric.id} className="flex items-center space-x-3 p-3 rounded-lg border">
              <div className="flex items-center space-x-2">
                {metric.icon}
                {getMetricIcon(metric.status)}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-sm">{metric.name}</span>
                  <span className="text-sm text-gray-600">
                    {metric.score}/{metric.maxScore}
                  </span>
                </div>
                <Progress value={(metric.score / metric.maxScore) * 100} className="h-1 mt-1" />
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons - Less Prominent for New Users */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setShowDetails(!showDetails)}
            className="flex-1"
          >
            {showDetails ? 'Hide Details' : 'View Details'}
          </Button>
          {onImprove && animatedScore < 70 && (
            <Button onClick={onImprove} variant="outline" className="flex-1">
              Get AI Suggestions
            </Button>
          )}
        </div>

        {/* Detailed Suggestions */}
        {showDetails && (
          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-semibold">Improvement Suggestions</h4>
            {metrics.map((metric) => (
              metric.suggestions.length > 0 && (
                <div key={metric.id} className="space-y-2">
                  <div className="flex items-center space-x-2">
                    {metric.icon}
                    <span className="font-medium">{metric.name}</span>
                    {getMetricIcon(metric.status)}
                  </div>
                  <p className="text-sm text-gray-600">{metric.description}</p>
                  <ul className="text-sm text-gray-700 space-y-1 ml-6">
                    {metric.suggestions.map((suggestion, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>{suggestion}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}