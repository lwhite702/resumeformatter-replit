import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileText, Copy, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ResumeImporterProps {
  onImport: (content: string) => void;
  onClose: () => void;
}

export default function ResumeImporter({ onImport, onClose }: ResumeImporterProps) {
  const [isConverting, setIsConverting] = useState(false);
  const [pastedContent, setPastedContent] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Check file type
    const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'text/markdown'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Unsupported file type",
        description: "Please upload a PDF, DOCX, TXT, or MD file.",
        variant: "destructive",
      });
      return;
    }

    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    setIsConverting(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/resume/convert', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (result.success) {
        onImport(result.content);
        toast({
          title: "Resume imported successfully",
          description: "Your resume has been converted to markdown format.",
        });
        onClose();
      } else {
        throw new Error(result.error || 'Failed to convert resume');
      }
    } catch (error) {
      toast({
        title: "Import failed",
        description: error instanceof Error ? error.message : "Failed to import resume. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsConverting(false);
    }
  };

  const handlePastedContentImport = async () => {
    if (!pastedContent.trim()) {
      toast({
        title: "No content to import",
        description: "Please paste your resume content first.",
        variant: "destructive",
      });
      return;
    }

    setIsConverting(true);

    try {
      const response = await fetch('/api/resume/convert-text', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: pastedContent }),
      });

      const result = await response.json();

      if (result.success) {
        onImport(result.content);
        toast({
          title: "Content imported successfully",
          description: "Your content has been converted to markdown format.",
        });
        onClose();
      } else {
        throw new Error(result.error || 'Failed to convert content');
      }
    } catch (error) {
      toast({
        title: "Import failed",
        description: error instanceof Error ? error.message : "Failed to import content. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsConverting(false);
    }
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle>Import Your Resume</CardTitle>
          <CardDescription>
            Upload a file or paste your existing resume content to convert it to markdown format
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* File Upload Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Upload File</h3>
            <div
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
              onClick={handleFileSelect}
            >
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-900 mb-2">
                Click to upload or drag and drop
              </p>
              <p className="text-sm text-gray-500">
                Supports PDF, DOCX, TXT, and MD files (up to 5MB)
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt,.md"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="hidden"
              />
            </div>
          </div>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="bg-white px-2 text-gray-500">or</span>
            </div>
          </div>

          {/* Copy/Paste Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Paste Content</h3>
            <div className="space-y-3">
              <Textarea
                placeholder="Paste your resume content here (plain text, markdown, or formatted text)..."
                value={pastedContent}
                onChange={(e) => setPastedContent(e.target.value)}
                className="min-h-[200px] resize-y"
              />
              <Button
                onClick={handlePastedContentImport}
                disabled={!pastedContent.trim() || isConverting}
                className="w-full"
              >
                {isConverting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Converting...
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Import Pasted Content
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={isConverting}>
              Cancel
            </Button>
          </div>

          {/* Loading Overlay */}
          {isConverting && (
            <div className="absolute inset-0 bg-white/80 flex items-center justify-center rounded-lg">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
                <p className="text-sm text-gray-600">Converting your resume...</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}