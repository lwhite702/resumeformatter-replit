import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileDown, FileText, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import ReactMarkdown from "react-markdown";

interface ResumePreviewProps {
  resume: any;
  templateId: number;
  showExportOptions?: boolean;
}

export default function ResumePreview({ 
  resume, 
  templateId, 
  showExportOptions = false 
}: ResumePreviewProps) {
  // Fetch template
  const { data: template } = useQuery({
    queryKey: [`/api/templates/${templateId}`],
    enabled: !!templateId,
  });

  // Mock ATS score (would be calculated from AI analysis)
  const atsScore = 92;

  const handleExport = (format: string) => {
    // Implementation would generate and download file
    console.log(`Exporting as ${format}`);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "bg-green-100 text-green-800";
    if (score >= 75) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold text-gray-900">Preview</h2>
          
          {/* ATS Score */}
          <Badge className={cn("text-xs font-medium", getScoreColor(atsScore))}>
            <div className="w-2 h-2 rounded-full bg-current mr-1"></div>
            ATS Score: {atsScore}
          </Badge>
        </div>

        {/* Export Actions */}
        {!showExportOptions && (
          <div className="hidden sm:flex items-center space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleExport("pdf")}
            >
              <FileText className="h-4 w-4 mr-1 text-red-500" />
              PDF
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleExport("docx")}
            >
              <FileDown className="h-4 w-4 mr-1 text-blue-500" />
              DOCX
            </Button>
          </div>
        )}
      </div>

      {/* Export Options (Mobile) */}
      {showExportOptions && (
        <div className="p-4 bg-white border-b space-y-3">
          <h3 className="font-medium text-gray-900">Export Options</h3>
          <div className="grid grid-cols-1 gap-2">
            <Button
              variant="outline"
              onClick={() => handleExport("pdf")}
              className="justify-start"
            >
              <FileText className="h-4 w-4 mr-2 text-red-500" />
              Export as PDF
              <Badge variant="secondary" className="ml-auto">Free</Badge>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleExport("docx")}
              className="justify-start"
            >
              <FileDown className="h-4 w-4 mr-2 text-blue-500" />
              Export as DOCX
              <Badge variant="secondary" className="ml-auto">Pro</Badge>
            </Button>
            <Button
              variant="outline"
              onClick={() => handleExport("html")}
              className="justify-start"
            >
              <Globe className="h-4 w-4 mr-2 text-green-500" />
              Export as HTML
              <Badge variant="secondary" className="ml-auto">Pro</Badge>
            </Button>
          </div>
        </div>
      )}

      {/* Preview Content */}
      <ScrollArea className="flex-1">
        <div className="p-4">
          <Card className="max-w-2xl mx-auto shadow-lg">
            <CardContent className="p-8">
              {resume?.markdown ? (
                <div className="prose prose-sm max-w-none">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => (
                        <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center border-b-2 border-primary pb-4">
                          {children}
                        </h1>
                      ),
                      h2: ({ children }) => (
                        <h2 className="text-xl font-medium text-primary mb-4 text-center">
                          {children}
                        </h2>
                      ),
                      h3: ({ children }) => (
                        <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-200 pb-1 mb-3 mt-6">
                          {children}
                        </h3>
                      ),
                      p: ({ children }) => (
                        <p className="text-gray-700 leading-relaxed mb-4">
                          {children}
                        </p>
                      ),
                      ul: ({ children }) => (
                        <ul className="space-y-2 mb-4 ml-4">
                          {children}
                        </ul>
                      ),
                      li: ({ children }) => (
                        <li className="flex items-start space-x-2">
                          <span className="text-primary mt-1.5 text-xs">•</span>
                          <span className="text-gray-700">{children}</span>
                        </li>
                      ),
                      strong: ({ children }) => (
                        <strong className="font-semibold text-gray-900">
                          {children}
                        </strong>
                      ),
                      hr: () => (
                        <hr className="border-gray-200 my-6" />
                      ),
                    }}
                  >
                    {resume.markdown}
                  </ReactMarkdown>
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Start writing your resume to see the preview</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    </div>
  );
}
