import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { History, Save, RotateCcw, X, Clock, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VersionModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeId: number;
  currentContent: string;
  onRestore: (content: string) => void;
}

export default function SimpleVersionModal({
  isOpen,
  onClose,
  resumeId,
  currentContent,
  onRestore
}: VersionModalProps) {
  const [versionName, setVersionName] = useState("");
  const [savedVersions, setSavedVersions] = useState<Array<{
    id: number;
    name: string;
    content: string;
    createdAt: string;
  }>>([]);
  const { toast } = useToast();

  const handleSaveVersion = () => {
    if (!versionName.trim()) {
      toast({
        title: "Version Name Required",
        description: "Please enter a name for this version.",
        variant: "destructive",
      });
      return;
    }

    // For demo purposes, save locally since authentication is required for API
    const newVersion = {
      id: Date.now(),
      name: versionName.trim(),
      content: currentContent,
      createdAt: new Date().toISOString(),
    };

    setSavedVersions(prev => [newVersion, ...prev]);
    setVersionName("");
    
    toast({
      title: "Version Saved",
      description: `Version "${newVersion.name}" has been saved locally.`,
    });
  };

  const handleRestoreVersion = (version: any) => {
    onRestore(version.content);
    toast({
      title: "Version Restored",
      description: `Restored to "${version.name}".`,
    });
    onClose();
  };

  const handleClose = () => {
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <History className="h-5 w-5 text-primary" />
              <span>Resume Versions</span>
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="h-8 w-8 p-0 hover:bg-gray-100"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Save Current Version */}
          <div>
            <h3 className="font-medium mb-3">Save Current Version</h3>
            <div className="flex space-x-2">
              <Input
                placeholder="Enter version name..."
                value={versionName}
                onChange={(e) => setVersionName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSaveVersion()}
                className="flex-1"
              />
              <Button onClick={handleSaveVersion} className="shrink-0">
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
            </div>
          </div>

          {/* Saved Versions */}
          <div>
            <h3 className="font-medium mb-3">Saved Versions</h3>
            <ScrollArea className="max-h-60">
              {savedVersions.length === 0 ? (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-4">
                      <FileText className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No versions saved yet</p>
                      <p className="text-xs text-muted-foreground">Save your first version above</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-2">
                  {savedVersions.map((version) => (
                    <Card key={version.id} className="hover:shadow-sm transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                              <History className="h-4 w-4 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium text-sm">{version.name}</h4>
                              <p className="text-xs text-muted-foreground flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {new Date(version.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRestoreVersion(version)}
                          >
                            <RotateCcw className="h-3 w-3 mr-1" />
                            Restore
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-4 border-t">
          <Button variant="outline" onClick={handleClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}