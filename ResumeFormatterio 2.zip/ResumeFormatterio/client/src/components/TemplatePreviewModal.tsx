import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Download, FileText } from "lucide-react";

interface TemplatePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  template: {
    id: number;
    name: string;
    category: string;
    description: string;
  } | null;
}

export default function TemplatePreviewModal({ isOpen, onClose, template }: TemplatePreviewModalProps) {
  if (!template) return null;

  const getTemplatePreview = (templateId: number) => {
    const templatePreviews = {
      1: (
        <div className="bg-white border border-gray-200 rounded-lg p-8 max-w-2xl mx-auto shadow-sm">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-blue-600 mb-2">JOHN SMITH</h1>
            <h2 className="text-lg text-gray-700 mb-4">Senior Software Engineer</h2>
            <div className="flex justify-center items-center space-x-4 text-sm text-gray-600">
              <span>john.smith@email.com</span>
              <span>•</span>
              <span>(555) 123-4567</span>
              <span>•</span>
              <span>LinkedIn</span>
            </div>
          </div>
          
          <div className="space-y-6">
            <section>
              <h3 className="text-lg font-semibold text-blue-600 border-b-2 border-blue-600 pb-1 mb-3">PROFESSIONAL SUMMARY</h3>
              <p className="text-gray-700 leading-relaxed">
                Experienced software engineer with 8+ years developing scalable web applications. 
                Expertise in React, Node.js, and cloud technologies with proven track record of 
                leading cross-functional teams and delivering high-impact solutions.
              </p>
            </section>
            
            <section>
              <h3 className="text-lg font-semibold text-blue-600 border-b-2 border-blue-600 pb-1 mb-3">EXPERIENCE</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-semibold text-gray-800">Senior Software Engineer</h4>
                    <span className="text-gray-600">2020 - Present</span>
                  </div>
                  <p className="text-blue-600 mb-2">TechCorp Inc.</p>
                  <ul className="text-gray-700 space-y-1 list-disc list-inside">
                    <li>Led development of microservices architecture serving 1M+ users</li>
                    <li>Improved application performance by 40% through optimization</li>
                  </ul>
                </div>
              </div>
            </section>
            
            <section>
              <h3 className="text-lg font-semibold text-blue-600 border-b-2 border-blue-600 pb-1 mb-3">SKILLS</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-medium text-gray-800">Languages:</p>
                  <p className="text-gray-700">JavaScript, TypeScript, Python</p>
                </div>
                <div>
                  <p className="font-medium text-gray-800">Frameworks:</p>
                  <p className="text-gray-700">React, Node.js, Express</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      ),
      2: (
        <div className="bg-white border border-gray-300 rounded-lg p-8 max-w-2xl mx-auto shadow-sm">
          <div className="text-center border-b-2 border-gray-800 pb-6 mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">SARAH JOHNSON</h1>
            <h2 className="text-xl text-gray-600 mb-4">Financial Analyst</h2>
            <div className="text-sm text-gray-600">
              sarah.johnson@email.com | (555) 987-6543 | New York, NY
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-6">
              <section>
                <h3 className="text-lg font-bold text-gray-800 uppercase tracking-wide mb-3">Experience</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-800">Senior Financial Analyst</h4>
                    <p className="text-gray-600 italic">Goldman Sachs | 2019-Present</p>
                    <ul className="text-sm text-gray-700 mt-2 space-y-1">
                      <li>• Managed $50M+ investment portfolio</li>
                      <li>• Increased client returns by 15%</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Financial Analyst</h4>
                    <p className="text-gray-600 italic">JP Morgan | 2017-2019</p>
                  </div>
                </div>
              </section>
              
              <section>
                <h3 className="text-lg font-bold text-gray-800 uppercase tracking-wide mb-3">Education</h3>
                <div>
                  <h4 className="font-semibold text-gray-800">MBA, Finance</h4>
                  <p className="text-gray-600 italic">Harvard Business School | 2017</p>
                </div>
              </section>
            </div>
            
            <div className="space-y-6">
              <section>
                <h3 className="text-lg font-bold text-gray-800 uppercase tracking-wide mb-3">Skills</h3>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Financial Modeling</li>
                  <li>• Risk Assessment</li>
                  <li>• Excel & Bloomberg</li>
                  <li>• Portfolio Management</li>
                </ul>
              </section>
              
              <section>
                <h3 className="text-lg font-bold text-gray-800 uppercase tracking-wide mb-3">Certifications</h3>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• CFA Charter</li>
                  <li>• FRM Certification</li>
                </ul>
              </section>
            </div>
          </div>
        </div>
      ),
      3: (
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-8 max-w-2xl mx-auto shadow-lg">
          <div className="flex items-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mr-6"></div>
            <div>
              <h1 className="text-3xl font-bold text-purple-800 mb-1">ALEX CHEN</h1>
              <h2 className="text-xl text-purple-600">UX/UI Designer</h2>
              <p className="text-purple-600 mt-2">alex.chen@email.com | Portfolio: alexchen.design</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-2 mb-8">
            <div className="h-2 bg-purple-400 rounded-full"></div>
            <div className="h-2 bg-pink-400 rounded-full"></div>
            <div className="h-2 bg-purple-300 rounded-full"></div>
          </div>
          
          <div className="space-y-6">
            <section className="bg-white/70 rounded-lg p-4">
              <h3 className="text-lg font-bold text-purple-800 mb-3">CREATIVE SUMMARY</h3>
              <p className="text-gray-700">
                Passionate designer with 5+ years creating user-centered digital experiences. 
                Specialized in mobile-first design and design systems for tech startups.
              </p>
            </section>
            
            <section className="bg-white/70 rounded-lg p-4">
              <h3 className="text-lg font-bold text-purple-800 mb-3">FEATURED PROJECTS</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-purple-200 rounded-lg h-20 flex items-center justify-center">
                  <span className="text-xs text-purple-800 font-medium">E-commerce App</span>
                </div>
                <div className="bg-pink-200 rounded-lg h-20 flex items-center justify-center">
                  <span className="text-xs text-purple-800 font-medium">Dashboard UI</span>
                </div>
                <div className="bg-purple-100 rounded-lg h-20 flex items-center justify-center">
                  <span className="text-xs text-purple-800 font-medium">Brand Identity</span>
                </div>
              </div>
            </section>
            
            <div className="grid grid-cols-2 gap-4">
              <section className="bg-white/70 rounded-lg p-4">
                <h3 className="text-lg font-bold text-purple-800 mb-3">EXPERIENCE</h3>
                <div className="space-y-2">
                  <div>
                    <h4 className="font-semibold text-gray-800">Senior UX Designer</h4>
                    <p className="text-purple-600 text-sm">Spotify | 2021-Present</p>
                  </div>
                </div>
              </section>
              
              <section className="bg-white/70 rounded-lg p-4">
                <h3 className="text-lg font-bold text-purple-800 mb-3">SKILLS</h3>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-purple-300 text-purple-800 text-xs px-2 py-1 rounded">Figma</span>
                  <span className="bg-pink-300 text-purple-800 text-xs px-2 py-1 rounded">Sketch</span>
                  <span className="bg-purple-200 text-purple-800 text-xs px-2 py-1 rounded">Prototyping</span>
                </div>
              </section>
            </div>
          </div>
        </div>
      ),
      4: (
        <div className="bg-white border border-gray-100 rounded-lg p-8 max-w-2xl mx-auto shadow-sm">
          <div className="mb-8">
            <h1 className="text-2xl font-light text-gray-900 mb-1">Maria Rodriguez</h1>
            <h2 className="text-lg text-gray-600 mb-4">Product Manager</h2>
            <p className="text-sm text-gray-500">maria.rodriguez@email.com | (555) 234-5678</p>
          </div>
          
          <div className="space-y-8">
            <section className="border-l-4 border-gray-300 pl-6">
              <h3 className="text-lg font-medium text-gray-800 mb-4">Experience</h3>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-gray-900">Senior Product Manager</h4>
                    <span className="text-gray-500 text-sm">2020 — Present</span>
                  </div>
                  <p className="text-gray-600 mb-3">Google</p>
                  <ul className="text-gray-700 space-y-1 text-sm leading-relaxed">
                    <li>Led product strategy for Gmail with 1.5B active users</li>
                    <li>Increased user engagement by 25% through data-driven features</li>
                    <li>Collaborated with engineering teams across 3 time zones</li>
                  </ul>
                </div>
                
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-gray-900">Product Manager</h4>
                    <span className="text-gray-500 text-sm">2018 — 2020</span>
                  </div>
                  <p className="text-gray-600 mb-3">Airbnb</p>
                  <ul className="text-gray-700 space-y-1 text-sm leading-relaxed">
                    <li>Managed host onboarding experience improvements</li>
                    <li>Reduced time-to-first-booking by 30%</li>
                  </ul>
                </div>
              </div>
            </section>
            
            <section className="border-l-4 border-gray-300 pl-6">
              <h3 className="text-lg font-medium text-gray-800 mb-4">Education</h3>
              <div>
                <h4 className="font-medium text-gray-900">Master of Business Administration</h4>
                <p className="text-gray-600">Stanford Graduate School of Business</p>
                <p className="text-gray-500 text-sm">2018</p>
              </div>
            </section>
            
            <section className="border-l-4 border-gray-300 pl-6">
              <h3 className="text-lg font-medium text-gray-800 mb-4">Core Competencies</h3>
              <div className="grid grid-cols-2 gap-4 text-sm text-gray-700">
                <div>
                  <p>Product Strategy</p>
                  <p>User Research</p>
                  <p>A/B Testing</p>
                </div>
                <div>
                  <p>Cross-functional Leadership</p>
                  <p>Data Analysis</p>
                  <p>Agile Development</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      )
    };

    const preview = templatePreviews[templateId as keyof typeof templatePreviews];
    
    if (!preview) {
      return <div className="text-center text-gray-500 py-8">Template preview not available</div>;
    }

    return (
      <div className="max-w-4xl mx-auto">
        {preview}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{template.name} - {template.category}</span>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription>
            Preview of the {template.name} resume template showing layout and formatting
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          {getTemplatePreview(template.id)}
          
          <div className="flex gap-3 mt-6 justify-center">
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <FileText className="w-4 h-4 mr-2" />
              Use This Template
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}