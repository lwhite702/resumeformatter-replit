import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Check, Crown, Lock } from "lucide-react";
import { resumeTemplates, getFreeTemplates, getProTemplates } from "@/lib/templates";
import { useAuth } from "@/hooks/useAuth";

interface TemplateSelectorProps {
  selectedTemplate: string;
  onTemplateChange: (templateId: string) => void;
}

export default function TemplateSelector({ selectedTemplate, onTemplateChange }: TemplateSelectorProps) {
  const { user } = useAuth();
  const isPro = (user as any)?.plan === 'pro';
  
  const freeTemplates = getFreeTemplates();
  const proTemplates = getProTemplates();

  const handleTemplateSelect = (templateId: string, requiresPro: boolean) => {
    if (requiresPro && (user as any)?.plan !== 'pro') {
      // Show upgrade modal or redirect to pricing
      window.location.href = '/pricing';
      return;
    }
    onTemplateChange(templateId);
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-6">
        <div className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
          Templates
        </div>

        {/* Free Templates */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <h3 className="font-medium text-sm">Free Templates</h3>
            <Badge variant="secondary" className="text-xs">Free</Badge>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            {freeTemplates.map((template) => (
              <Card 
                key={template.id} 
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedTemplate === template.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => onTemplateChange(template.id)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-sm">{template.name}</h4>
                      <p className="text-xs text-gray-600">{template.description}</p>
                    </div>
                    {selectedTemplate === template.id && (
                      <Check className="h-4 w-4 text-blue-500" />
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Pro Templates */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <h3 className="font-medium text-sm">Pro Templates</h3>
            <Badge className="text-xs bg-gradient-to-r from-yellow-400 to-orange-500">
              <Crown className="h-3 w-3 mr-1" />
              Pro
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            {proTemplates.map((template) => (
              <Card 
                key={template.id} 
                className={`cursor-pointer transition-all ${
                  isPro ? 'hover:shadow-md' : 'opacity-60'
                } ${
                  selectedTemplate === template.id && isPro ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => handleTemplateSelect(template.id, true)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-sm flex items-center">
                        {template.name}
                        {!isPro && <Lock className="h-3 w-3 ml-1 text-gray-400" />}
                      </h4>
                      <p className="text-xs text-gray-600">{template.description}</p>
                    </div>
                    {selectedTemplate === template.id && isPro && (
                      <Check className="h-4 w-4 text-blue-500" />
                    )}
                    {!isPro && (
                      <Crown className="h-4 w-4 text-yellow-500" />
                    )}
                  </div>
                  {!isPro && (
                    <Button size="sm" variant="outline" className="mt-2 w-full text-xs">
                      Upgrade to Pro
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </ScrollArea>
  );
}