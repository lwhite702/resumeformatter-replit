import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Eye } from "lucide-react";
import { useState } from "react";
import TemplatePreviewModal from "./TemplatePreviewModal";

export default function TemplateShowcase() {
  const [selectedTemplate, setSelectedTemplate] = useState<{
    id: number;
    name: string;
    category: string;
    description: string;
  } | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const handlePreviewClick = (template: { id: number; name: string; category: string; description: string }) => {
    setSelectedTemplate(template);
    setIsPreviewOpen(true);
  };
  const templates = [
    {
      id: 1,
      name: "Modern Professional",
      category: "Executive",
      description: "Clean, contemporary design perfect for senior roles and tech positions",
      features: ["ATS Optimized", "Clean Layout", "Professional"],
      preview: (
        <div className="bg-white rounded-lg p-3 h-32 border border-gray-200 overflow-hidden">
          <div className="text-xs font-bold text-blue-600 mb-2">John Smith</div>
          <div className="text-[8px] text-gray-600 mb-1">Software Engineer</div>
          <div className="space-y-1">
            <div className="h-1 bg-blue-100 rounded w-full"></div>
            <div className="h-1 bg-gray-200 rounded w-4/5"></div>
            <div className="h-1 bg-gray-200 rounded w-3/5"></div>
          </div>
          <div className="mt-2 pt-1 border-t border-gray-100">
            <div className="text-[6px] font-semibold text-gray-700 mb-1">EXPERIENCE</div>
            <div className="space-y-1">
              <div className="h-[2px] bg-gray-300 rounded w-3/4"></div>
              <div className="h-[2px] bg-gray-200 rounded w-2/3"></div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 2,
      name: "Classic Traditional",
      category: "Traditional",
      description: "Timeless design ideal for finance, law, and traditional industries",
      features: ["Traditional", "Conservative", "Trusted"],
      preview: (
        <div className="bg-white rounded-lg p-3 h-32 border border-gray-200 overflow-hidden">
          <div className="text-center border-b border-gray-300 pb-1 mb-2">
            <div className="text-xs font-bold text-gray-800">SARAH JOHNSON</div>
            <div className="text-[8px] text-gray-600">Financial Analyst</div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[6px]">
            <div>
              <div className="font-semibold text-gray-700 mb-1">EXPERIENCE</div>
              <div className="space-y-[2px]">
                <div className="h-[2px] bg-gray-400 rounded w-full"></div>
                <div className="h-[2px] bg-gray-300 rounded w-4/5"></div>
                <div className="h-[2px] bg-gray-300 rounded w-3/5"></div>
              </div>
            </div>
            <div>
              <div className="font-semibold text-gray-700 mb-1">SKILLS</div>
              <div className="space-y-[2px]">
                <div className="h-[2px] bg-gray-400 rounded w-3/4"></div>
                <div className="h-[2px] bg-gray-300 rounded w-2/3"></div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 3,
      name: "Creative Designer",
      category: "Creative",
      description: "Eye-catching layout for designers, marketers, and creative professionals",
      features: ["Creative", "Visual", "Stand Out"],
      preview: (
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-3 h-32 border border-purple-200 overflow-hidden">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-4 h-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
            <div className="text-xs font-bold text-purple-800">Alex Chen</div>
          </div>
          <div className="text-[8px] text-purple-600 mb-2">UX/UI Designer</div>
          <div className="grid grid-cols-3 gap-1 mb-2">
            <div className="h-1 bg-purple-300 rounded"></div>
            <div className="h-1 bg-pink-300 rounded"></div>
            <div className="h-1 bg-purple-200 rounded"></div>
          </div>
          <div className="text-[6px] font-semibold text-purple-700 mb-1">PORTFOLIO</div>
          <div className="flex gap-1">
            <div className="w-3 h-3 bg-purple-300 rounded"></div>
            <div className="w-3 h-3 bg-pink-300 rounded"></div>
            <div className="w-3 h-3 bg-purple-200 rounded"></div>
          </div>
        </div>
      )
    },
    {
      id: 4,
      name: "Minimalist Clean",
      category: "Minimal",
      description: "Ultra-clean design focusing on content over decoration",
      features: ["Minimal", "Focus", "Elegant"],
      preview: (
        <div className="bg-white rounded-lg p-3 h-32 border border-gray-100 overflow-hidden">
          <div className="text-sm font-light text-gray-900 mb-1">Maria Rodriguez</div>
          <div className="text-[8px] text-gray-500 mb-3">Product Manager</div>
          <div className="space-y-2">
            <div className="border-l-2 border-gray-300 pl-2">
              <div className="text-[6px] font-medium text-gray-700">EXPERIENCE</div>
              <div className="space-y-1 mt-1">
                <div className="h-[1px] bg-gray-400 rounded w-full"></div>
                <div className="h-[1px] bg-gray-300 rounded w-4/5"></div>
                <div className="h-[1px] bg-gray-300 rounded w-3/5"></div>
              </div>
            </div>
            <div className="border-l-2 border-gray-300 pl-2">
              <div className="text-[6px] font-medium text-gray-700">EDUCATION</div>
              <div className="h-[1px] bg-gray-300 rounded w-2/3 mt-1"></div>
            </div>
          </div>
        </div>
      )
    }
  ];

  return (
    <section className="py-20 bg-blue-600">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Professional Templates for Every Industry
          </h2>
          <p className="text-lg text-blue-100 max-w-2xl mx-auto">
            Choose from our collection of ATS-optimized templates designed by industry experts
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {templates.map((template) => (
            <Card key={template.id} className="bg-white border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4">
                  {template.preview}
                </div>
                
                <div className="space-y-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{template.name}</h3>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {template.category}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-gray-600">{template.description}</p>
                  
                  <div className="flex flex-wrap gap-1">
                    {template.features.map((feature) => (
                      <Badge key={feature} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => handlePreviewClick(template)}
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Preview
                    </Button>
                    <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                      <FileText className="w-3 h-3 mr-1" />
                      Use
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center">
          <Button size="lg" variant="outline" className="bg-white text-blue-600 hover:bg-blue-50 border-white">
            View All Templates
          </Button>
        </div>
      </div>
      
      <TemplatePreviewModal
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        template={selectedTemplate}
      />
    </section>
  );
}