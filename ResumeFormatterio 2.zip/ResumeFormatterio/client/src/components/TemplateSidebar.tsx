import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Palette, 
  History, 
  Sparkles, 
  FileText, 
  X,
  Crown,
  Check 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

interface TemplateSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTemplate: number;
  onTemplateSelect: (id: number) => void;
  currentResume: any;
  onResumeSelect: (resume: any) => void;
  onShowVersions: () => void;
  onOptimizeResume: () => void;
  onGenerateCoverLetter: () => void;
}

export default function TemplateSidebar({
  isOpen,
  onClose,
  selectedTemplate,
  onTemplateSelect,
  currentResume,
  onResumeSelect,
  onShowVersions,
  onOptimizeResume,
  onGenerateCoverLetter,
}: TemplateSidebarProps) {
  const { user } = useAuth();

  // Fetch templates
  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  // Fetch user's resumes
  const { data: resumes } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: !!user,
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  // Template categories
  const templateCategories = [
    {
      name: "Tech & Engineering",
      templates: templates?.filter((t: any) => t.category === "tech") || [],
    },
    {
      name: "Creative & Design",
      templates: templates?.filter((t: any) => t.category === "creative") || [],
    },
    {
      name: "Business & Corporate",
      templates: templates?.filter((t: any) => t.category === "corporate") || [],
    },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-80 bg-white border-r border-gray-200 transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              {currentResume?.title || "New Resume"}
            </h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="lg:hidden"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation Tabs */}
        <Tabs defaultValue="templates" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2 rounded-none border-b">
            <TabsTrigger value="templates" className="flex items-center space-x-2">
              <Palette className="h-4 w-4" />
              <span>Templates</span>
            </TabsTrigger>
            <TabsTrigger value="versions" className="flex items-center space-x-2">
              <History className="h-4 w-4" />
              <span>Versions</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="flex-1 m-0">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="p-4 space-y-6">
                {templateCategories.map((category) => (
                  <div key={category.name}>
                    <h3 className="text-sm font-medium text-gray-900 mb-3">
                      {category.name}
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      {category.templates.map((template: any) => (
                        <div
                          key={template.id}
                          className="cursor-pointer group"
                          onClick={() => onTemplateSelect(template.id)}
                        >
                          <Card className={cn(
                            "aspect-[3/4] relative overflow-hidden transition-all duration-200 hover:shadow-md",
                            selectedTemplate === template.id 
                              ? "ring-2 ring-primary border-primary" 
                              : "border-gray-200"
                          )}>
                            <CardContent className="p-3 h-full">
                              {/* Template Preview */}
                              <div className="h-full bg-gradient-to-br from-white to-gray-50 rounded border relative">
                                <div className="p-2 space-y-1">
                                  <div className="h-1.5 bg-primary rounded w-3/4"></div>
                                  <div className="h-1 bg-gray-200 rounded w-1/2"></div>
                                  <div className="h-1 bg-gray-200 rounded w-2/3"></div>
                                  <div className="h-0.5 bg-gray-100 rounded w-full mt-2"></div>
                                  <div className="space-y-0.5 mt-1">
                                    <div className="h-0.5 bg-gray-200 rounded w-3/4"></div>
                                    <div className="h-0.5 bg-gray-200 rounded w-1/2"></div>
                                    <div className="h-0.5 bg-gray-200 rounded w-2/3"></div>
                                  </div>
                                </div>
                                
                                {/* Premium Badge */}
                                {template.isPremium && (
                                  <div className="absolute top-1 right-1">
                                    <Crown className="h-3 w-3 text-amber-500" />
                                  </div>
                                )}

                                {/* Selected Indicator */}
                                {selectedTemplate === template.id && (
                                  <div className="absolute top-1 left-1">
                                    <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                                      <Check className="h-2.5 w-2.5 text-white" />
                                    </div>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                          <div className="mt-2 text-center">
                            <div className="text-xs font-medium text-gray-900">
                              {template.name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {template.description}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="versions" className="flex-1 m-0">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="p-4">
                <Button
                  onClick={onShowVersions}
                  variant="outline"
                  className="w-full mb-4"
                >
                  <History className="h-4 w-4 mr-2" />
                  Manage Versions
                </Button>
                
                {/* Recent Resumes */}
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-3">
                    Recent Resumes
                  </h3>
                  <div className="space-y-2">
                    {resumes?.slice(0, 5).map((resume: any) => (
                      <Card
                        key={resume.id}
                        className={cn(
                          "cursor-pointer transition-colors hover:bg-gray-50",
                          currentResume?.id === resume.id && "bg-primary/5 border-primary"
                        )}
                        onClick={() => onResumeSelect(resume)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded flex items-center justify-center">
                              <FileText className="h-4 w-4 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {resume.title}
                              </p>
                              <p className="text-xs text-gray-500">
                                {new Date(resume.updatedAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* AI Tools Section */}
        <div className="border-t border-gray-200 p-4 space-y-3">
          <Button
            onClick={onOptimizeResume}
            className="w-full"
            disabled={!currentResume || (user?.credits || 0) < 1}
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Optimize Resume
            {user?.plan !== "pro" && (
              <Badge variant="secondary" className="ml-2">
                1 credit
              </Badge>
            )}
          </Button>
          
          <Button
            onClick={onGenerateCoverLetter}
            variant="outline"
            className="w-full"
            disabled={!currentResume || (user?.credits || 0) < 1}
          >
            <FileText className="h-4 w-4 mr-2" />
            Generate Cover Letter
            {user?.plan !== "pro" && (
              <Badge variant="secondary" className="ml-2">
                1 credit
              </Badge>
            )}
          </Button>
        </div>
      </aside>
    </>
  );
}
