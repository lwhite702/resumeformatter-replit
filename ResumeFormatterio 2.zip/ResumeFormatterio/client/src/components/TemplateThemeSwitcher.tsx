
import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Palette, Check } from 'lucide-react';

interface TemplateThemeSwitcherProps {
  currentTheme: string;
  onThemeChange: (theme: string) => void;
}

export default function TemplateThemeSwitcher({ currentTheme, onThemeChange }: TemplateThemeSwitcherProps) {
  const themes = [
    { id: 'modern', name: 'Modern', color: 'bg-blue-500' },
    { id: 'creative', name: 'Creative', color: 'bg-purple-500' },
    { id: 'minimalist', name: 'Minimalist', color: 'bg-gray-500' },
    { id: 'classic', name: 'Classic', color: 'bg-green-500' }
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center space-x-2">
        <Palette className="h-4 w-4" />
        <span className="text-sm font-medium">Color Theme</span>
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        {themes.map((theme) => (
          <Button
            key={theme.id}
            variant={currentTheme === theme.id ? "default" : "outline"}
            size="sm"
            onClick={() => onThemeChange(theme.id)}
            className="justify-start"
          >
            <div className={`w-3 h-3 rounded-full ${theme.color} mr-2`} />
            {theme.name}
            {currentTheme === theme.id && (
              <Check className="h-3 w-3 ml-auto" />
            )}
          </Button>
        ))}
      </div>
      
      <div className="text-xs text-muted-foreground">
        Preview updates automatically when you change themes
      </div>
    </div>
  );
}
