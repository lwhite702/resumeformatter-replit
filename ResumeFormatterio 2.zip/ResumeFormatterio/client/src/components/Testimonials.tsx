import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Software Developer",
      company: "Denver Tech Solutions",
      content: "Clean templates and helpful AI suggestions. The resume builder made updating my resume much easier than starting from scratch.",
      rating: 5
    },
    {
      name: "Michael Rodriguez",
      role: "Marketing Coordinator",
      company: "Portland Creative Agency",
      content: "Great selection of professional templates. The export quality is excellent and the ATS optimization tips were useful.",
      rating: 5
    },
    {
      name: "Emily Thompson",
      role: "Business Analyst",
      company: "Austin Financial Group",
      content: "Simple interface and good template variety. I was able to create a polished resume quickly for my job search.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Trusted by Growing Professionals
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            See what early users are saying about their experience
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                <blockquote className="text-gray-700 mb-6 leading-relaxed">
                  "{testimonial.content}"
                </blockquote>
                
                <div className="border-t pt-4">
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.role}</div>
                  <div className="text-sm font-medium text-blue-600">{testimonial.company}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <div className="bg-blue-600 rounded-lg p-8 inline-block">
            <div className="text-white text-lg font-semibold mb-2">
              Ready to create your professional resume?
            </div>
            <div className="text-blue-100 text-sm">
              Join our growing community of professionals
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}