import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Save, Bookmark, Clock, RotateCcw, GitCompare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface VersionHistoryModalProps {
  resume: any;
  onClose: () => void;
  onVersionRestore: (resume: any) => void;
}

export default function VersionHistoryModal({ 
  resume, 
  onClose, 
  onVersionRestore 
}: VersionHistoryModalProps) {
  const [versionName, setVersionName] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch resume versions
  const { data: versions, isLoading } = useQuery({
    queryKey: [`/api/resumes/${resume?.id}/versions`],
    enabled: !!resume?.id,
  });

  // Create new version
  const createVersionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/resumes/${resume.id}/versions`, {
        versionName: versionName.trim(),
        markdown: resume.markdown,
        templateId: resume.templateId,
        description: `Snapshot saved on ${new Date().toLocaleDateString()}`,
      });
      return res.json();
    },
    onSuccess: () => {
      setVersionName("");
      queryClient.invalidateQueries({ 
        queryKey: [`/api/resumes/${resume.id}/versions`] 
      });
      toast({
        title: "Version Saved",
        description: "Resume version has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save resume version. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveVersion = () => {
    if (!versionName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for this version.",
        variant: "destructive",
      });
      return;
    }
    createVersionMutation.mutate();
  };

  const handleRestoreVersion = (version: any) => {
    // Update current resume with version content
    const updatedResume = {
      ...resume,
      markdown: version.markdown,
      templateId: version.templateId,
    };
    onVersionRestore(updatedResume);
    
    toast({
      title: "Version Restored",
      description: `Restored to "${version.versionName}"`,
    });
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Bookmark className="h-5 w-5 text-primary" />
            <span>Resume Versions</span>
          </DialogTitle>
          <p className="text-sm text-gray-600">
            Save snapshots and compare different versions
          </p>
        </DialogHeader>

        <div className="space-y-6">
          {/* Create New Version */}
          <Card className="bg-gray-50">
            <CardContent className="p-4">
              <h3 className="font-medium text-gray-900 mb-3">
                Save Current Version
              </h3>
              <div className="flex items-center space-x-3">
                <Input
                  placeholder="Version name (e.g., 'Google Application')"
                  value={versionName}
                  onChange={(e) => setVersionName(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleSaveVersion();
                    }
                  }}
                />
                <Button
                  onClick={handleSaveVersion}
                  disabled={createVersionMutation.isPending || !versionName.trim()}
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save Snapshot
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Version History */}
          <div>
            <h3 className="font-medium text-gray-900 mb-4">Saved Versions</h3>
            <ScrollArea className="h-64">
              {isLoading ? (
                <div className="text-center py-8 text-gray-500">
                  Loading versions...
                </div>
              ) : versions && versions.length > 0 ? (
                <div className="space-y-3">
                  {versions.map((version: any) => (
                    <Card
                      key={version.id}
                      className="hover:shadow-md transition-shadow cursor-pointer"
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                              <Bookmark className="h-4 w-4 text-primary" />
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {version.versionName}
                              </h4>
                              <p className="text-sm text-gray-500 flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatDistanceToNow(new Date(version.createdAt), { 
                                  addSuffix: true 
                                })}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRestoreVersion(version)}
                            >
                              <RotateCcw className="h-3 w-3 mr-1" />
                              Restore
                            </Button>
                          </div>
                        </div>
                        {version.description && (
                          <p className="text-sm text-gray-700">
                            {version.description}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Bookmark className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                  <p>No versions saved yet</p>
                  <p className="text-sm">Save your first version above</p>
                </div>
              )}
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
