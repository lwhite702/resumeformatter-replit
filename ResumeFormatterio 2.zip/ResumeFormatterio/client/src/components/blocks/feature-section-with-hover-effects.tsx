import { cn } from "@/lib/utils";
import {
  FileText,
  Upload,
  Sparkles,
  Eye,
  Download,
  History,
  Zap,
  Users
} from "lucide-react";

export function FeaturesSectionWithHoverEffects() {
  const features = [
    {
      title: "Smart Resume Import",
      description:
        "Upload PDF, DOCX, or paste text. AI converts to clean markdown automatically.",
      icon: <Upload className="w-6 h-6" />,
    },
    {
      title: "AI-Powered Optimization",
      description:
        "Get ATS score analysis and intelligent suggestions to improve your resume.",
      icon: <Sparkles className="w-6 h-6" />,
    },
    {
      title: "Live Preview",
      description:
        "See changes instantly with multiple professional templates to choose from.",
      icon: <Eye className="w-6 h-6" />,
    },
    {
      title: "One-Click Export",
      description: "Export to PDF, DOCX, or directly to PrepPair.me and LinkedIn.",
      icon: <Download className="w-6 h-6" />,
    },
    {
      title: "Version History",
      description: "Track changes and restore previous versions of your resume anytime.",
      icon: <History className="w-6 h-6" />,
    },
    {
      title: "Professional Templates",
      description:
        "Choose from modern, ATS-friendly templates designed by industry experts.",
      icon: <FileText className="w-6 h-6" />,
    },
    {
      title: "Lightning Fast",
      description:
        "Create a professional resume in under 3 clicks with our streamlined workflow.",
      icon: <Zap className="w-6 h-6" />,
    },
    {
      title: "Used by Professionals",
      description: "Trusted by job seekers at top companies worldwide for career success.",
      icon: <Users className="w-6 h-6" />,
    },
  ];
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 relative z-10 py-10 max-w-7xl mx-auto">
      {features.map((feature, index) => (
        <Feature key={feature.title} {...feature} index={index} />
      ))}
    </div>
  );
}

const Feature = ({
  title,
  description,
  icon,
  index,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  index: number;
}) => {
  return (
    <div
      className={cn(
        "flex flex-col lg:border-r py-10 relative group/feature dark:border-neutral-800 border-neutral-200",
        (index === 0 || index === 4) && "lg:border-l dark:border-neutral-800 border-neutral-200",
        index < 4 && "lg:border-b dark:border-neutral-800 border-neutral-200"
      )}
    >
      {index < 4 && (
        <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-t from-blue-50 dark:from-neutral-800 to-transparent pointer-events-none" />
      )}
      {index >= 4 && (
        <div className="opacity-0 group-hover/feature:opacity-100 transition duration-200 absolute inset-0 h-full w-full bg-gradient-to-b from-blue-50 dark:from-neutral-800 to-transparent pointer-events-none" />
      )}
      <div className="mb-4 relative z-10 px-10 text-blue-600 dark:text-blue-400">
        {icon}
      </div>
      <div className="text-lg font-bold mb-2 relative z-10 px-10">
        <div className="absolute left-0 inset-y-0 h-6 group-hover/feature:h-8 w-1 rounded-tr-full rounded-br-full bg-neutral-300 dark:bg-neutral-700 group-hover/feature:bg-blue-500 transition-all duration-200 origin-center" />
        <span className="group-hover/feature:translate-x-2 transition duration-200 inline-block text-neutral-800 dark:text-neutral-100">
          {title}
        </span>
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-xs relative z-10 px-10">
        {description}
      </p>
    </div>
  );
};