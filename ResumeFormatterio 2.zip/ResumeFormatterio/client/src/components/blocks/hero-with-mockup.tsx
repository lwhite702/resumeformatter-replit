import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Glow } from "@/components/ui/glow";
import { cn } from "@/lib/utils";
import DemoEditor from "@/components/demo-editor";

interface HeroWithMockupProps {
  title: string;
  description: string;
  primaryCta: {
    text: string;
    href?: string;
    onClick?: () => void;
  };
  secondaryCta?: {
    text: string;
    href?: string;
    onClick?: () => void;
  };
  mockupImage: {
    src: string;
    alt: string;
    width: number;
    height: number;
  };
  badge?: string;
  className?: string;
}

export function HeroWithMockup({
  title,
  description,
  primaryCta,
  secondaryCta,
  mockupImage,
  badge,
  className,
}: HeroWithMockupProps) {
  const handlePrimaryClick = () => {
    if (primaryCta.onClick) {
      primaryCta.onClick();
    } else if (primaryCta.href) {
      window.location.href = primaryCta.href;
    }
  };

  const handleSecondaryClick = () => {
    if (secondaryCta?.onClick) {
      secondaryCta.onClick();
    } else if (secondaryCta?.href) {
      window.location.href = secondaryCta.href;
    }
  };

  return (
    <section className={cn("relative overflow-hidden py-24 lg:py-32", className)}>
      {/* Background Glow Effects */}
      <Glow variant="above" className="opacity-30" />
      <Glow variant="center" className="opacity-20" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            {badge && (
              <Badge className="mb-6 text-sm font-medium bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border-blue-200">
                {badge}
              </Badge>
            )}
            
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl mb-6">
              <span className="text-gradient">{title}</span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl lg:max-w-none">
              {description}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                onClick={handlePrimaryClick}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-200"
              >
                {primaryCta.text}
              </Button>
              
              {secondaryCta && (
                <Button
                  onClick={handleSecondaryClick}
                  variant="outline"
                  size="lg"
                  className="border-2 border-gray-300 hover:border-blue-400 px-8 py-4 text-lg font-semibold hover:bg-blue-50 transition-all duration-200"
                >
                  {secondaryCta.text}
                </Button>
              )}
            </div>
          </div>
          
          {/* Interactive Demo */}
          <div className="relative">
            <div className="relative mx-auto max-w-4xl">
              {/* Demo Editor Component */}
              <DemoEditor />
              
              {/* Decorative elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full opacity-20 blur-xl" />
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-20 blur-xl" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}