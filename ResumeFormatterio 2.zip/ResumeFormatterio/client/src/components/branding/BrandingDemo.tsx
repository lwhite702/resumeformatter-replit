import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Copy, Check } from "lucide-react";
import ResumeSlogan, { useRandomSlogan, getRandomMetaDescription, SOCIAL_ALT, META_DESCRIPTIONS } from "./ResumeSlogan";
import { BRAND_TAGLINES, SEO_CONSTANTS, buildPageTitle, buildCanonicalUrl } from "@/lib/marketing-constants";

export default function BrandingDemo() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  
  const randomSlogan = useRandomSlogan("random");
  const alternateSlogan = useRandomSlogan("alternate");
  const randomMetaDescription = getRandomMetaDescription();

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const handleCopy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedItem(label);
      setTimeout(() => setCopiedItem(null), 2000);
    } catch (err) {
      console.error("Failed to copy text");
    }
  };

  const CopyButton = ({ text, label }: { text: string; label: string }) => (
    <Button
      variant="outline"
      size="sm"
      onClick={() => handleCopy(text, label)}
      className="ml-2"
    >
      {copiedItem === label ? (
        <Check className="h-4 w-4" />
      ) : (
        <Copy className="h-4 w-4" />
      )}
    </Button>
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Brand Slogan & Marketing Demo</h1>
          <p className="text-muted-foreground">
            Interactive demonstration of ResumeFormatter.io's dynamic branding components
          </p>
        </div>

        {/* Dynamic Slogans */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Dynamic Slogan Rotation</CardTitle>
              <CardDescription>
                Slogans loaded from JSON and randomly selected using useMemo
              </CardDescription>
            </div>
            <Button onClick={handleRefresh} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div className="p-4 border rounded-lg bg-blue-50">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge variant="outline" className="mb-2">Primary</Badge>
                    <p className="text-lg font-semibold">
                      <ResumeSlogan key={`primary-${refreshKey}`} variant="primary" />
                    </p>
                  </div>
                  <CopyButton 
                    text={BRAND_TAGLINES.primary}
                    label="primary"
                  />
                </div>
              </div>

              <div className="p-4 border rounded-lg bg-green-50">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge variant="outline" className="mb-2">Random Alternate</Badge>
                    <p className="text-lg font-semibold">
                      <ResumeSlogan key={`alternate-${refreshKey}`} variant="alternate" />
                    </p>
                  </div>
                  <CopyButton 
                    text={alternateSlogan}
                    label="alternate"
                  />
                </div>
              </div>

              <div className="p-4 border rounded-lg bg-purple-50">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge variant="outline" className="mb-2">Random (Any)</Badge>
                    <p className="text-lg font-semibold">
                      <ResumeSlogan key={`random-${refreshKey}`} variant="random" />
                    </p>
                  </div>
                  <CopyButton 
                    text={randomSlogan}
                    label="random"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Marketing Constants */}
        <Card>
          <CardHeader>
            <CardTitle>Marketing Metadata</CardTitle>
            <CardDescription>
              SEO and social sharing constants for consistent branding
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <Badge variant="outline" className="mb-1">Social Alt Text</Badge>
                  <p className="text-sm">{SOCIAL_ALT}</p>
                </div>
                <CopyButton text={SOCIAL_ALT} label="social-alt" />
              </div>

              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <Badge variant="outline" className="mb-1">Random Meta Description</Badge>
                  <p className="text-sm">{randomMetaDescription}</p>
                </div>
                <CopyButton text={randomMetaDescription} label="meta-desc" />
              </div>

              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <Badge variant="outline" className="mb-1">Site Title</Badge>
                  <p className="text-sm">{buildPageTitle("Demo Page")}</p>
                </div>
                <CopyButton text={buildPageTitle("Demo Page")} label="page-title" />
              </div>

              <div className="flex items-center justify-between p-3 border rounded">
                <div>
                  <Badge variant="outline" className="mb-1">Canonical URL</Badge>
                  <p className="text-sm">{buildCanonicalUrl("/branding-demo")}</p>
                </div>
                <CopyButton text={buildCanonicalUrl("/branding-demo")} label="canonical" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Brand Taglines */}
        <Card>
          <CardHeader>
            <CardTitle>Brand Taglines Collection</CardTitle>
            <CardDescription>
              Static branded messaging for different contexts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {Object.entries(BRAND_TAGLINES).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <Badge variant="outline" className="mb-1 capitalize">{key}</Badge>
                    <p className="text-sm">{value}</p>
                  </div>
                  <CopyButton text={value} label={`tagline-${key}`} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Available Meta Descriptions */}
        <Card>
          <CardHeader>
            <CardTitle>Meta Descriptions Pool</CardTitle>
            <CardDescription>
              Available descriptions for random selection
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {META_DESCRIPTIONS.map((description, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <Badge variant="outline" className="mb-1">Option {index + 1}</Badge>
                    <p className="text-sm">{description}</p>
                  </div>
                  <CopyButton text={description} label={`meta-${index}`} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* SEO Constants */}
        <Card>
          <CardHeader>
            <CardTitle>SEO Configuration</CardTitle>
            <CardDescription>
              Site-wide SEO and social sharing settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {Object.entries(SEO_CONSTANTS).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between p-3 border rounded">
                  <div>
                    <Badge variant="outline" className="mb-1 capitalize">{key.replace(/([A-Z])/g, ' $1')}</Badge>
                    <p className="text-sm font-mono">{value}</p>
                  </div>
                  <CopyButton text={value} label={`seo-${key}`} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}