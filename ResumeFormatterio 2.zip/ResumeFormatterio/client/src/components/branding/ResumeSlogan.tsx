import { useMemo, useState, useEffect } from "react";
import { SOCIAL_ALT, META_DESCRIPTIONS } from "@/lib/marketing-constants";

interface SloganData {
  primary: string;
  alternate: string[];
}

interface ResumeSloganProps {
  variant?: "primary" | "random" | "alternate";
  className?: string;
}

// Export marketing constants for use in other components
export { SOCIAL_ALT, META_DESCRIPTIONS };

// Hook to load slogans from JSON file
function useSlogans(): SloganData {
  const [slogans, setSlogans] = useState<SloganData>({
    primary: "Beautiful resumes. Markdown simple.",
    alternate: [
      "Your resume. Markdown simple. Professionally powerful.",
      "Customize your layout. Not your credibility.",
      "Effortless formatting, serious results.",
      "Developer-ready. Recruiter-approved.",
      "Modern resume design without the drag-and-drop.",
      "Clear, ATS-friendly, and always in your control."
    ]
  });

  useEffect(() => {
    fetch('/slogans/resumeformatter_slogans.json')
      .then(response => response.json())
      .then((data: SloganData) => setSlogans(data))
      .catch(() => {
        // Keep default slogans if fetch fails
        console.log("Using default slogans");
      });
  }, []);

  return slogans;
}

export function ResumeSlogan({ variant = "random", className = "" }: ResumeSloganProps) {
  const slogans = useSlogans();
  
  const selectedSlogan = useMemo(() => {
    switch (variant) {
      case "primary":
        return slogans.primary;
      
      case "alternate":
        // Select random alternate slogan
        const randomIndex = Math.floor(Math.random() * slogans.alternate.length);
        return slogans.alternate[randomIndex];
      
      case "random":
      default:
        // Randomly choose between primary and alternate slogans
        const allSlogans = [slogans.primary, ...slogans.alternate];
        const randomSloganIndex = Math.floor(Math.random() * allSlogans.length);
        return allSlogans[randomSloganIndex];
    }
  }, [variant, slogans]);

  return (
    <span className={className}>
      {selectedSlogan}
    </span>
  );
}

// Hook for accessing slogans programmatically
export function useRandomSlogan(variant: "primary" | "random" | "alternate" = "random"): string {
  const slogans = useSlogans();
  
  return useMemo(() => {
    switch (variant) {
      case "primary":
        return slogans.primary;
      
      case "alternate":
        const randomIndex = Math.floor(Math.random() * slogans.alternate.length);
        return slogans.alternate[randomIndex];
      
      case "random":
      default:
        const allSlogans = [slogans.primary, ...slogans.alternate];
        const randomSloganIndex = Math.floor(Math.random() * allSlogans.length);
        return allSlogans[randomSloganIndex];
    }
  }, [variant, slogans]);
}

// Utility function to get random meta description
export function getRandomMetaDescription(): string {
  const randomIndex = Math.floor(Math.random() * META_DESCRIPTIONS.length);
  return META_DESCRIPTIONS[randomIndex];
}

export default ResumeSlogan;