import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, 
  Sparkles, 
  Download, 
  Copy,
  Coins,
  Crown,
  Plus,
  Edit,
  Trash2
} from "lucide-react";
import { CoverLetter } from "@/types/resume";

interface CoverLetterModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeContent: string;
  userPlan: string;
  userCredits: number;
}

export default function CoverLetterModal({ 
  isOpen, 
  onClose, 
  resumeContent,
  userPlan,
  userCredits
}: CoverLetterModalProps) {
  const [jobTitle, setJobTitle] = useState("");
  const [company, setCompany] = useState("");
  const [tone, setTone] = useState<'formal' | 'friendly' | 'executive'>('formal');
  const [generatedContent, setGeneratedContent] = useState("");
  const [activeTab, setActiveTab] = useState("generate");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing cover letters
  const { data: coverLetters = [], isLoading } = useQuery({
    queryKey: ["/api/cover-letters"],
    enabled: isOpen,
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  // Generate cover letter mutation
  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/cover-letters/generate", {
        resumeContent,
        jobTitle: jobTitle.trim() || undefined,
        company: company.trim() || undefined,
        tone,
      });
      return response.json();
    },
    onSuccess: (coverLetter) => {
      setGeneratedContent(coverLetter.content);
      queryClient.invalidateQueries({ queryKey: ["/api/cover-letters"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Cover Letter Generated",
        description: "Your personalized cover letter has been created successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      const errorMessage = (error as Error).message;
      if (errorMessage.includes("Insufficient credits")) {
        toast({
          title: "Insufficient Credits",
          description: "You need 1 credit to generate a cover letter. Upgrade to Pro for unlimited access.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Generation Failed",
          description: "Failed to generate cover letter. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleGenerate = () => {
    if (userPlan === 'free' && userCredits < 1) {
      toast({
        title: "Insufficient Credits",
        description: "You need 1 credit to generate a cover letter. Upgrade to Pro for unlimited access.",
        variant: "destructive",
      });
      return;
    }
    
    generateMutation.mutate();
  };

  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent);
    toast({
      title: "Copied to Clipboard",
      description: "Cover letter content has been copied to your clipboard.",
    });
  };

  const handleDownload = () => {
    const blob = new Blob([generatedContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cover-letter-${jobTitle || 'general'}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const toneDescriptions = {
    formal: "Professional and traditional business language",
    friendly: "Warm and personable while maintaining professionalism",
    executive: "Confident and leadership-focused for senior positions"
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-primary" />
            <span>AI Cover Letter Generator</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="generate">Generate New</TabsTrigger>
            <TabsTrigger value="saved">Saved Letters</TabsTrigger>
          </TabsList>

          {/* Generate Tab */}
          <TabsContent value="generate" className="flex-1 mt-4">
            <ScrollArea className="max-h-[60vh] custom-scrollbar">
              <div className="space-y-6">
                {/* Form */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Job Title (Optional)
                    </label>
                    <Input
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      placeholder="e.g., Senior Software Engineer"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Company (Optional)
                    </label>
                    <Input
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      placeholder="e.g., Google"
                    />
                  </div>
                </div>

                {/* Tone Selection */}
                <div>
                  <label className="block text-sm font-medium mb-3">
                    Tone & Style
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {(['formal', 'friendly', 'executive'] as const).map((toneOption) => (
                      <Card
                        key={toneOption}
                        className={`cursor-pointer transition-all ${
                          tone === toneOption ? 'border-primary bg-primary/5' : 'hover:border-muted-foreground/50'
                        }`}
                        onClick={() => setTone(toneOption)}
                      >
                        <CardContent className="pt-4">
                          <div className="flex items-center space-x-2 mb-2">
                            <div className={`w-3 h-3 rounded-full ${
                              tone === toneOption ? 'bg-primary' : 'bg-muted-foreground/30'
                            }`} />
                            <h4 className="font-medium capitalize">{toneOption}</h4>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {toneDescriptions[toneOption]}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Generated Content */}
                {generatedContent && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium">Generated Cover Letter</h3>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleCopyToClipboard}
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copy
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleDownload}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </div>
                    
                    <Card>
                      <CardContent className="pt-4">
                        <div className="max-h-64 overflow-y-auto custom-scrollbar">
                          <pre className="whitespace-pre-wrap text-sm leading-relaxed">
                            {generatedContent}
                          </pre>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Tips */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-4">
                    <h4 className="font-medium mb-2">💡 Pro Tips</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Adding job title and company creates more targeted content</li>
                      <li>• Choose tone based on company culture and position level</li>
                      <li>• Review and customize the generated content before sending</li>
                      <li>• Save multiple versions for different types of applications</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Saved Letters Tab */}
          <TabsContent value="saved" className="flex-1 mt-4">
            <ScrollArea className="max-h-[60vh] custom-scrollbar">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
                </div>
              ) : coverLetters.length === 0 ? (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-6">
                      <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h4 className="font-medium mb-2">No Saved Cover Letters</h4>
                      <p className="text-sm text-muted-foreground mb-4">
                        Generate your first cover letter to see it saved here.
                      </p>
                      <Button onClick={() => setActiveTab("generate")} variant="outline">
                        <Plus className="h-4 w-4 mr-2" />
                        Generate First Letter
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {coverLetters.map((letter: CoverLetter) => (
                    <Card key={letter.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-medium text-foreground">{letter.title}</h4>
                            <div className="flex items-center space-x-2 mt-1">
                              {letter.jobTitle && (
                                <Badge variant="outline" className="text-xs">
                                  {letter.jobTitle}
                                </Badge>
                              )}
                              {letter.company && (
                                <Badge variant="outline" className="text-xs">
                                  {letter.company}
                                </Badge>
                              )}
                              <Badge variant="outline" className="text-xs capitalize">
                                {letter.tone}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              Created {new Date(letter.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setGeneratedContent(letter.content);
                                setActiveTab("generate");
                              }}
                            >
                              <Edit className="h-3 w-3 mr-1" />
                              Edit
                            </Button>
                          </div>
                        </div>
                        
                        <div className="bg-muted/50 p-3 rounded-lg">
                          <p className="text-sm text-muted-foreground line-clamp-3">
                            {letter.content.substring(0, 200)}...
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            {userPlan === 'free' ? (
              <>
                <Coins className="h-4 w-4 text-secondary" />
                <span>This will use 1 credit</span>
              </>
            ) : (
              <>
                <Crown className="h-4 w-4 text-primary" />
                <span>Unlimited generation with Pro</span>
              </>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            
            {activeTab === "generate" && (
              <Button 
                onClick={handleGenerate}
                disabled={generateMutation.isPending}
              >
                {generateMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Cover Letter
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
