import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Eye, FileText } from "lucide-react";

const demoContent = `# John Doe
## Senior Software Engineer

**Email:** john@example.com  
**Phone:** (555) 123-4567  
**Location:** San Francisco, CA  
**LinkedIn:** linkedin.com/in/johndoe  

## Summary

Experienced software engineer with 8+ years developing scalable web applications. Expert in React, Node.js, and cloud technologies. Led multiple cross-functional teams to deliver high-impact products.

## Experience

### Senior Software Engineer | Google
*January 2021 - Present*

- Led development of microservices architecture serving 10M+ users
- Improved application performance by 40% through optimization
- Mentored 5 junior developers and established best practices
- Technologies: React, TypeScript, Node.js, Kubernetes, GCP

### Software Engineer | Meta
*June 2019 - December 2020*

- Built real-time messaging features for Facebook Messenger
- Implemented CI/CD pipelines reducing deployment time by 60%
- Collaborated with design team on user experience improvements
- Technologies: React, GraphQL, Python, Docker, AWS

## Skills

**Languages:** JavaScript, TypeScript, Python, Java  
**Frontend:** React, Vue.js, HTML5, CSS3, Tailwind CSS  
**Backend:** Node.js, Express, Django, PostgreSQL, MongoDB  
**Tools:** Git, Docker, Kubernetes, AWS, CI/CD  

## Education

### Bachelor of Computer Science | Stanford University
*2015 - 2019*

- Graduated Summa Cum Laude (GPA: 3.9/4.0)
- Relevant Coursework: Data Structures, Algorithms, Software Engineering`;

export default function DemoEditor() {
  const [content, setContent] = useState(demoContent);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [hasUserEdited, setHasUserEdited] = useState(false);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    setHasUserEdited(true);
  };

  const renderPreview = () => {
    const lines = content.split('\n');
    const elements: JSX.Element[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      if (line.startsWith('# ')) {
        elements.push(
          <h1 key={i} className="text-2xl font-bold text-gray-900 mb-2">
            {line.substring(2)}
          </h1>
        );
      } else if (line.startsWith('## ')) {
        elements.push(
          <h2 key={i} className="text-lg font-semibold text-blue-600 mb-3 border-b border-gray-200 pb-1">
            {line.substring(3)}
          </h2>
        );
      } else if (line.startsWith('### ')) {
        elements.push(
          <h3 key={i} className="text-base font-medium text-gray-900 mb-1">
            {line.substring(4)}
          </h3>
        );
      } else if (line.startsWith('**') && line.endsWith('**')) {
        elements.push(
          <div key={i} className="text-sm text-gray-600 mb-1">
            <strong>{line.substring(2, line.length - 2)}</strong>
          </div>
        );
      } else if (line.startsWith('*') && line.endsWith('*')) {
        elements.push(
          <div key={i} className="text-sm text-gray-500 italic mb-2">
            {line.substring(1, line.length - 1)}
          </div>
        );
      } else if (line.startsWith('- ')) {
        elements.push(
          <li key={i} className="text-sm text-gray-700 ml-4 mb-1">
            {line.substring(2)}
          </li>
        );
      } else if (line.trim()) {
        elements.push(
          <p key={i} className="text-sm text-gray-700 mb-2">
            {line}
          </p>
        );
      } else {
        elements.push(<div key={i} className="mb-2"></div>);
      }
    }
    
    return elements;
  };

  return (
    <div className="space-y-4">
      {/* Demo Callout */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-xl text-center">
        <h3 className="text-lg font-bold mb-2">👇 Try Editing the Resume Below!</h3>
        <p className="text-blue-100">
          This is a fully functional demo. Click in the editor and start typing to see your changes appear instantly in the preview.
          {hasUserEdited && <span className="block mt-1 text-yellow-200 font-semibold">Great job! You're editing in real-time!</span>}
        </p>
      </div>
      
      <div className="relative bg-white rounded-2xl shadow-2xl p-4 border border-gray-200 overflow-hidden">
        {/* Mobile Tab Switcher */}
        <div className="md:hidden mb-4">
          <div className="flex rounded-lg bg-gray-100 p-1">
            <button
              onClick={() => setActiveTab('editor')}
              className={`flex-1 flex items-center justify-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'editor'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <FileText className="w-4 h-4 mr-2" />
              Editor
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex-1 flex items-center justify-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'preview'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </button>
          </div>
        </div>

        {/* Desktop Two-Panel Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-[500px]">
          {/* Editor Panel */}
          <div className={`space-y-4 ${activeTab === 'editor' ? 'block' : 'hidden md:block'}`}>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              <span className="text-sm text-gray-500 ml-4">Markdown Editor</span>
            </div>
            <textarea
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              className="w-full h-full bg-gray-50 rounded-lg p-4 font-mono text-sm border-none resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              style={{ minHeight: '450px' }}
              placeholder="Start typing your resume in Markdown..."
            />
          </div>
          
          {/* Preview Panel */}
          <div className={`space-y-4 ${activeTab === 'preview' ? 'block' : 'hidden md:block'}`}>
            <div className="flex items-center space-x-2 mb-4">
              <Eye className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-gray-500">Live Preview</span>
              <Badge className="bg-green-100 text-green-800 text-xs">ATS Score: 92</Badge>
            </div>
            <div className="bg-white border-2 border-gray-200 rounded-lg p-6 h-full overflow-y-auto relative" style={{ minHeight: '450px' }}>
              {renderPreview()}
              {/* Watermark for free version */}
              <div className="absolute bottom-4 right-4 text-xs text-gray-400 bg-white px-2 py-1 rounded border">
                ResumeFormatter.io
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}