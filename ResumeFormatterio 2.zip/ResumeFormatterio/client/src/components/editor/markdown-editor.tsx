import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Bold, 
  Italic, 
  List, 
  Link, 
  Save, 
  Eye,
  Type,
  Hash
} from "lucide-react";

interface MarkdownEditorProps {
  content: string;
  onContentChange: (content: string) => void;
  onPreview?: () => void;
}

export default function MarkdownEditor({ 
  content, 
  onContentChange, 
  onPreview 
}: MarkdownEditorProps) {
  const [lastSaved, setLastSaved] = useState<Date>(new Date());

  const insertMarkdown = useCallback((before: string, after: string = '') => {
    const textarea = document.querySelector('textarea') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    
    const newText = content.substring(0, start) + 
                   before + selectedText + after + 
                   content.substring(end);
    
    onContentChange(newText);
    
    // Restore cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(
        start + before.length, 
        start + before.length + selectedText.length
      );
    }, 0);
  }, [content, onContentChange]);

  const formatBold = () => insertMarkdown('**', '**');
  const formatItalic = () => insertMarkdown('*', '*');
  const formatHeading = () => insertMarkdown('### ');
  const formatList = () => insertMarkdown('- ');
  const formatLink = () => insertMarkdown('[', '](url)');

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onContentChange(e.target.value);
    setLastSaved(new Date());
  };

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Editor Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold">Editor</h2>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Save className="h-4 w-4 text-green-500" />
            <span>Auto-saved {Math.floor((Date.now() - lastSaved.getTime()) / 1000 / 60)} min ago</span>
          </div>
        </div>
        
        {/* Formatting Toolbar */}
        <div className="hidden sm:flex items-center space-x-1 bg-muted p-1 rounded-lg">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={formatBold}
            className="btn-ripple h-8 w-8 p-0"
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={formatItalic}
            className="btn-ripple h-8 w-8 p-0"
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={formatHeading}
            className="btn-ripple h-8 w-8 p-0"
            title="Heading"
          >
            <Hash className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={formatList}
            className="btn-ripple h-8 w-8 p-0"
            title="Bullet List"
          >
            <List className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={formatLink}
            className="btn-ripple h-8 w-8 p-0"
            title="Add Link"
          >
            <Link className="h-4 w-4" />
          </Button>
        </div>

        {/* Mobile Preview Button */}
        {onPreview && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onPreview}
            className="sm:hidden btn-ripple"
          >
            <Eye className="h-4 w-4 mr-1" />
            Preview
          </Button>
        )}
      </div>

      {/* Editor Content */}
      <div className="flex-1 relative">
        <Textarea
          value={content}
          onChange={handleContentChange}
          placeholder="Start writing your resume in Markdown..."
          className="w-full h-full border-none outline-none resize-none font-mono text-sm leading-relaxed p-4 bg-transparent custom-scrollbar"
          style={{ minHeight: '100%' }}
        />
      </div>

      {/* Mobile Formatting Bar */}
      <div className="sm:hidden border-t border-border p-2">
        <div className="flex items-center space-x-1 overflow-x-auto">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={formatBold}
            className="btn-ripple flex-shrink-0"
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={formatItalic}
            className="btn-ripple flex-shrink-0"
          >
            <Italic className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={formatHeading}
            className="btn-ripple flex-shrink-0"
          >
            <Type className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={formatList}
            className="btn-ripple flex-shrink-0"
          >
            <List className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={formatLink}
            className="btn-ripple flex-shrink-0"
          >
            <Link className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
