import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Edit, FileText, FileImage } from "lucide-react";
import { parseResumeMarkdown } from "@/lib/resume-parser";
import ResumeTemplates from "@/components/templates/resume-templates";

interface ResumePreviewProps {
  content: string;
  templateId: string;
  onEdit?: () => void;
}

export default function ResumePreview({ 
  content, 
  templateId, 
  onEdit 
}: ResumePreviewProps) {
  const parsedResume = useMemo(() => {
    return parseResumeMarkdown(content);
  }, [content]);

  // Mock ATS score calculation
  const atsScore = useMemo(() => {
    const wordCount = content.split(/\s+/).length;
    const hasContact = !!(parsedResume.email && parsedResume.phone);
    const hasExperience = (parsedResume.experience?.length || 0) > 0;
    const hasSkills = (parsedResume.skills?.length || 0) > 0;
    
    let score = 60;
    if (wordCount > 200) score += 10;
    if (wordCount > 400) score += 10;
    if (hasContact) score += 15;
    if (hasExperience) score += 15;
    if (hasSkills) score += 10;
    
    return Math.min(100, score);
  }, [content, parsedResume]);

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'ats-score-excellent';
    if (score >= 75) return 'ats-score-good';
    if (score >= 60) return 'ats-score-fair';
    return 'ats-score-poor';
  };

  const handleExport = (format: 'pdf' | 'docx' | 'html') => {
    // In a real implementation, this would trigger the export API
    console.log(`Exporting as ${format.toUpperCase()}`);
  };

  return (
    <div className="flex flex-col h-full bg-muted/30">
      {/* Preview Header */}
      <div className="flex items-center justify-between p-4 bg-card border-b border-border">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold">Preview</h2>
          <Badge className={`${getScoreColor(atsScore)} border-0`}>
            ATS Score: {atsScore}
          </Badge>
        </div>
        
        {/* Export Actions */}
        <div className="flex items-center space-x-2">
          {onEdit && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onEdit}
              className="sm:hidden btn-ripple"
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
          )}
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleExport('pdf')}
            className="btn-ripple hidden sm:flex"
          >
            <FileText className="h-4 w-4 mr-1 text-red-500" />
            PDF
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleExport('docx')}
            className="btn-ripple hidden sm:flex"
          >
            <FileImage className="h-4 w-4 mr-1 text-blue-500" />
            DOCX
          </Button>
        </div>
      </div>

      {/* Resume Preview */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        <div className="max-w-2xl mx-auto">
          <ResumeTemplates
            templateId={templateId}
            resumeData={parsedResume}
            content={content}
          />
        </div>
      </div>

      {/* Mobile Export Actions */}
      <div className="sm:hidden border-t border-border p-4 bg-card">
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex-1 btn-ripple"
            onClick={() => handleExport('pdf')}
          >
            <Download className="h-4 w-4 mr-1" />
            PDF
          </Button>
          <Button 
            variant="outline" 
            className="flex-1 btn-ripple"
            onClick={() => handleExport('docx')}
          >
            <Download className="h-4 w-4 mr-1" />
            DOCX
          </Button>
        </div>
      </div>
    </div>
  );
}
