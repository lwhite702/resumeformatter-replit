import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ExternalLink, Settings, Check, X, Loader2, Globe } from "lucide-react";

interface ExportIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeId: number;
  resumeTitle: string;
}

interface ApiIntegration {
  id: number;
  platform: string;
  isActive: boolean;
  lastSync: string | null;
  createdAt: string;
}

interface ExportHistory {
  id: number;
  platform: string;
  exportFormat: string;
  status: string;
  externalId: string | null;
  exportUrl: string | null;
  errorMessage: string | null;
  createdAt: string;
}

export default function ExportIntegrationModal({ 
  isOpen, 
  onClose, 
  resumeId, 
  resumeTitle 
}: ExportIntegrationModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [apiKey, setApiKey] = useState("");
  const [customEndpoint, setCustomEndpoint] = useState("https://api.preppair.me");
  const [showSetup, setShowSetup] = useState(false);

  // Fetch user's API integrations
  const { data: integrations = [], isLoading: integrationsLoading } = useQuery({
    queryKey: ["/api/integrations"],
    enabled: isOpen,
  });

  // Fetch export history for this resume
  const { data: exportHistory = [], isLoading: historyLoading } = useQuery({
    queryKey: ["/api/exports/resume", resumeId],
    enabled: isOpen,
  });

  // Export to PrepPair.me mutation
  const exportMutation = useMutation({
    mutationFn: async (data: { apiKey?: string; customEndpoint?: string }) => {
      return await apiRequest("POST", `/api/export/preppair/${resumeId}`, data);
    },
    onSuccess: (data) => {
      toast({
        title: "Export Successful",
        description: `Resume "${resumeTitle}" exported to PrepPair.me successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/exports/resume", resumeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      setApiKey("");
      setShowSetup(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Setup integration mutation
  const setupMutation = useMutation({
    mutationFn: async (data: { platform: string; apiKey: string; endpoint?: string }) => {
      return await apiRequest("POST", "/api/integrations", data);
    },
    onSuccess: () => {
      toast({
        title: "Integration Setup",
        description: "PrepPair.me integration configured successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      setShowSetup(false);
      setApiKey("");
    },
    onError: (error: Error) => {
      toast({
        title: "Setup Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const prepPairIntegration = integrations.find((int: ApiIntegration) => int.platform === 'preppair');
  const recentExports = exportHistory.filter((exp: ExportHistory) => exp.platform === 'preppair');

  const handleExport = () => {
    if (prepPairIntegration) {
      // Use existing integration
      exportMutation.mutate({});
    } else if (apiKey) {
      // Export with new API key
      exportMutation.mutate({ 
        apiKey, 
        customEndpoint: customEndpoint || "https://api.preppair.me" 
      });
    } else {
      setShowSetup(true);
    }
  };

  const handleSetupIntegration = () => {
    if (!apiKey) {
      toast({
        title: "API Key Required",
        description: "Please enter your PrepPair.me API key",
        variant: "destructive",
      });
      return;
    }

    setupMutation.mutate({
      platform: 'preppair',
      apiKey,
      endpoint: customEndpoint || "https://api.preppair.me"
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Export to PrepPair.me</DialogTitle>
          <DialogDescription>
            Export "{resumeTitle}" to your PrepPair.me account for interview preparation
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Integration Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Globe className="h-5 w-5" />
                PrepPair.me Integration
              </CardTitle>
              <CardDescription>
                Connect your PrepPair.me account to enable seamless resume exports
              </CardDescription>
            </CardHeader>
            <CardContent>
              {integrationsLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Loading integration status...</span>
                </div>
              ) : prepPairIntegration ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="text-green-600 border-green-200">
                      <Check className="h-3 w-3 mr-1" />
                      Connected
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      Last synced: {prepPairIntegration.lastSync 
                        ? new Date(prepPairIntegration.lastSync).toLocaleDateString()
                        : 'Never'
                      }
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowSetup(true)}
                  >
                    <Settings className="h-4 w-4 mr-1" />
                    Configure
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="text-amber-600 border-amber-200">
                      <X className="h-3 w-3 mr-1" />
                      Not Connected
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      Setup required to export resumes
                    </span>
                  </div>
                  
                  {!showSetup && (
                    <Button onClick={() => setShowSetup(true)} variant="outline">
                      Setup Integration
                    </Button>
                  )}
                </div>
              )}

              {/* Setup Form */}
              {showSetup && (
                <div className="mt-4 p-4 border rounded-lg space-y-4">
                  <div>
                    <Label htmlFor="apiKey">PrepPair.me API Key</Label>
                    <Input
                      id="apiKey"
                      type="password"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      placeholder="Enter your PrepPair.me API key"
                      className="mt-1"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Get your API key from PrepPair.me settings → API Access
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="endpoint">API Endpoint (Optional)</Label>
                    <Input
                      id="endpoint"
                      value={customEndpoint}
                      onChange={(e) => setCustomEndpoint(e.target.value)}
                      placeholder="https://api.preppair.me"
                      className="mt-1"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Use custom endpoint if you have a self-hosted instance
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={handleSetupIntegration}
                      disabled={setupMutation.isPending}
                      size="sm"
                    >
                      {setupMutation.isPending && (
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      )}
                      Save Integration
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setShowSetup(false)}
                      size="sm"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Separator />

          {/* Export Action */}
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold">Export Resume</h3>
              <p className="text-sm text-muted-foreground">
                Export your resume to PrepPair.me for interview preparation and practice
              </p>
            </div>

            {!prepPairIntegration && !showSetup && (
              <div className="space-y-3">
                <div>
                  <Label htmlFor="quickApiKey">PrepPair.me API Key</Label>
                  <Input
                    id="quickApiKey"
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Enter API key for one-time export"
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            <Button 
              onClick={handleExport}
              disabled={exportMutation.isPending || (!prepPairIntegration && !apiKey)}
              className="w-full"
            >
              {exportMutation.isPending && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              Export to PrepPair.me
            </Button>
          </div>

          <Separator />

          {/* Export History */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Export History</h3>
            
            {historyLoading ? (
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Loading export history...</span>
              </div>
            ) : recentExports.length > 0 ? (
              <div className="space-y-2">
                {recentExports.slice(0, 5).map((exportItem: ExportHistory) => (
                  <div 
                    key={exportItem.id} 
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Badge 
                        variant="outline" 
                        className={
                          exportItem.status === 'success' 
                            ? "text-green-600 border-green-200"
                            : exportItem.status === 'failed'
                            ? "text-red-600 border-red-200"
                            : "text-amber-600 border-amber-200"
                        }
                      >
                        {exportItem.status === 'success' && <Check className="h-3 w-3 mr-1" />}
                        {exportItem.status === 'failed' && <X className="h-3 w-3 mr-1" />}
                        {exportItem.status === 'pending' && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                        {exportItem.status}
                      </Badge>
                      <span className="text-sm">
                        {new Date(exportItem.createdAt).toLocaleDateString()}
                      </span>
                      {exportItem.errorMessage && (
                        <span className="text-xs text-red-600">
                          {exportItem.errorMessage}
                        </span>
                      )}
                    </div>
                    {exportItem.exportUrl && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => window.open(exportItem.exportUrl!, '_blank')}
                      >
                        <ExternalLink className="h-3 w-3 mr-1" />
                        View
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                No exports to PrepPair.me yet
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}