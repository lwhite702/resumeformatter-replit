import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Download, 
  FileText, 
  Share2,
  Crown,
  CheckCircle,
  Globe
} from "lucide-react";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeId: number;
  resumeTitle: string;
  userPlan: string;
}

export default function ExportModal({ 
  isOpen, 
  onClose, 
  resumeId, 
  resumeTitle,
  userPlan
}: ExportModalProps) {
  const [exportingFormat, setExportingFormat] = useState<string | null>(null);
  const [exportProgress, setExportProgress] = useState(0);
  
  const { toast } = useToast();

  const handleExport = async (format: 'pdf' | 'docx' | 'html') => {
    if (format === 'docx' && userPlan !== 'pro') {
      toast({
        title: "Pro Feature",
        description: "DOCX export is available with Pro subscription. Upgrade to access this feature.",
        variant: "destructive",
      });
      return;
    }

    if (format === 'html' && userPlan !== 'pro') {
      toast({
        title: "Pro Feature",
        description: "HTML export is available with Pro subscription. Upgrade to access this feature.",
        variant: "destructive",
      });
      return;
    }

    setExportingFormat(format);
    setExportProgress(0);

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setExportProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Make API request
      const response = await fetch(`/api/resumes/${resumeId}/export/${format}`, {
        credentials: 'include',
      });

      clearInterval(progressInterval);
      setExportProgress(100);

      if (!response.ok) {
        throw new Error(`Export failed: ${response.statusText}`);
      }

      // Download file
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resumeTitle}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: `Your resume has been exported as ${format.toUpperCase()}.`,
      });

      setTimeout(() => {
        setExportingFormat(null);
        setExportProgress(0);
      }, 1000);

    } catch (error) {
      clearInterval(progressInterval!);
      setExportingFormat(null);
      setExportProgress(0);
      
      toast({
        title: "Export Failed",
        description: (error as Error).message || "Failed to export resume. Please try again.",
        variant: "destructive",
      });
    }
  };

  const exportFormats = [
    {
      id: 'pdf',
      name: 'PDF',
      description: 'Universal format for job applications',
      icon: '📄',
      color: 'bg-red-100 text-red-600',
      isPro: false,
      features: ['ATS-friendly', 'Print-ready', 'Universal compatibility']
    },
    {
      id: 'docx',
      name: 'DOCX',
      description: 'Editable Microsoft Word document',
      icon: '📝',
      color: 'bg-blue-100 text-blue-600',
      isPro: true,
      features: ['Fully editable', 'Track changes', 'Comment support']
    },
    {
      id: 'html',
      name: 'HTML',
      description: 'Web-ready format for online portfolios',
      icon: '🌐',
      color: 'bg-green-100 text-green-600',
      isPro: true,
      features: ['Web-ready', 'Responsive design', 'Online sharing']
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5 text-primary" />
            <span>Export Resume</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Export Progress */}
          {exportingFormat && (
            <Card className="border-primary">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    <span className="font-medium">
                      Exporting as {exportingFormat.toUpperCase()}...
                    </span>
                  </div>
                  
                  <Progress value={exportProgress} className="w-full" />
                  
                  <p className="text-sm text-muted-foreground">
                    {exportProgress < 30 && "Preparing document..."}
                    {exportProgress >= 30 && exportProgress < 60 && "Applying formatting..."}
                    {exportProgress >= 60 && exportProgress < 90 && "Optimizing layout..."}
                    {exportProgress >= 90 && exportProgress < 100 && "Finalizing export..."}
                    {exportProgress === 100 && "Export complete!"}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Export Formats */}
          <div className="grid grid-cols-1 gap-4">
            {exportFormats.map((format) => (
              <Card
                key={format.id}
                className={`
                  transition-all hover:shadow-md cursor-pointer
                  ${format.isPro && userPlan !== 'pro' ? 'opacity-75' : 'hover:border-primary/50'}
                `}
                onClick={() => !exportingFormat && handleExport(format.id as 'pdf' | 'docx' | 'html')}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${format.color}`}>
                        <span className="text-2xl">{format.icon}</span>
                      </div>
                      
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold">{format.name}</h3>
                          {format.isPro && (
                            <Badge variant="secondary" className="text-xs">
                              <Crown className="h-3 w-3 mr-1" />
                              Pro
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{format.description}</p>
                        
                        <div className="flex items-center space-x-2 mt-2">
                          {format.features.map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {format.isPro && userPlan !== 'pro' ? (
                        <Button variant="outline" size="sm" disabled>
                          Upgrade Required
                        </Button>
                      ) : (
                        <Button 
                          variant="outline" 
                          size="sm"
                          disabled={!!exportingFormat}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Export
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Export Tips */}
          <Card className="bg-muted/50">
            <CardContent className="pt-6">
              <h4 className="font-medium mb-3 flex items-center">
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                Export Tips
              </h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• <strong>PDF:</strong> Best for job applications - universally compatible and ATS-friendly</li>
                <li>• <strong>DOCX:</strong> Use when employers specifically request Word format</li>
                <li>• <strong>HTML:</strong> Perfect for online portfolios and web-based applications</li>
                <li>• Always review your exported resume before submitting</li>
              </ul>
            </CardContent>
          </Card>

          {/* Upgrade CTA for free users */}
          {userPlan !== 'pro' && (
            <Card className="border-primary bg-primary/5">
              <CardContent className="pt-6">
                <div className="text-center space-y-3">
                  <Crown className="h-8 w-8 text-primary mx-auto" />
                  <h4 className="font-semibold">Unlock All Export Formats</h4>
                  <p className="text-sm text-muted-foreground">
                    Upgrade to Pro to export in DOCX and HTML formats, plus get unlimited AI optimizations.
                  </p>
                  <Button className="w-full">
                    Upgrade to Pro
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
