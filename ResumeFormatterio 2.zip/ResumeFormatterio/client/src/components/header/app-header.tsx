import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { FileText, Coins, Menu, Settings, LogOut, CreditCard } from "lucide-react";
import type { User } from "@shared/schema";

interface AppHeaderProps {
  user: User;
  onOptimize: () => void;
  onGenerateCoverLetter: () => void;
}

export default function AppHeader({ user, onOptimize, onGenerateCoverLetter }: AppHeaderProps) {
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const userInitials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U';

  return (
    <header className="bg-card shadow-sm border-b border-border sticky top-0 z-50 elevation-1">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <FileText className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-semibold">ResumeFormatter.io</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Button variant="ghost" size="sm">Templates</Button>
            <Button variant="ghost" size="sm">Help</Button>
          </nav>

          {/* User Actions */}
          <div className="flex items-center space-x-2">
            {/* Credits Display */}
            <div className="flex items-center space-x-1 bg-secondary/10 px-2 sm:px-3 py-1 rounded-full">
              <Coins className="h-3 w-3 sm:h-4 sm:w-4 text-secondary" />
              <span className="text-xs sm:text-sm font-medium text-secondary">{user.credits}</span>
            </div>
            
            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                      {userInitials}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden sm:block">{user.firstName || 'User'}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                  <p className="text-xs text-muted-foreground">{user.email}</p>
                  <Badge variant={user.plan === 'pro' ? 'default' : 'secondary'} className="mt-1">
                    {user.plan === 'pro' ? 'Pro' : 'Free'} Plan
                  </Badge>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onOptimize}>
                  <FileText className="h-4 w-4 mr-2" />
                  Optimize Resume
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onGenerateCoverLetter}>
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Cover Letter
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <CreditCard className="h-4 w-4 mr-2" />
                  {user.plan === 'pro' ? 'Manage Subscription' : 'Upgrade to Pro'}
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => window.location.href = '/api/logout'}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu Toggle */}
            <Button 
              variant="ghost" 
              size="sm" 
              className="md:hidden"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
