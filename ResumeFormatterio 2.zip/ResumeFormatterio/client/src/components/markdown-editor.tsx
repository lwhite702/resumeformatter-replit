import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Bold, 
  Italic, 
  List, 
  Link, 
  Heading1, 
  Heading2,
  Eye,
  Sparkles,
  Save
} from "lucide-react";

interface MarkdownEditorProps {
  content: string;
  onChange: (content: string) => void;
  onOptimize: () => void;
}

export default function MarkdownEditor({ content, onChange, onOptimize }: MarkdownEditorProps) {
  const [cursorPosition, setCursorPosition] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const insertMarkdown = (before: string, after: string = '') => {
    if (!textareaRef.current) return;

    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    
    const newText = content.substring(0, start) + before + selectedText + after + content.substring(end);
    onChange(newText);
    
    // Set cursor position after insertion
    const newCursorPos = start + before.length + selectedText.length + after.length;
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Handle common shortcuts
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 'b':
          e.preventDefault();
          insertMarkdown('**', '**');
          break;
        case 'i':
          e.preventDefault();
          insertMarkdown('*', '*');
          break;
        case 's':
          e.preventDefault();
          // Save trigger is handled by parent component
          break;
      }
    }
    
    // Auto-indent for lists
    if (e.key === 'Enter') {
      const lines = content.split('\n');
      const currentLineIndex = content.substring(0, cursorPosition).split('\n').length - 1;
      const currentLine = lines[currentLineIndex];
      
      if (currentLine.match(/^[\s]*[\-\*\+]\s/)) {
        e.preventDefault();
        const indent = currentLine.match(/^[\s]*/)?.[0] || '';
        const bullet = currentLine.match(/[\-\*\+]/)?.[0] || '-';
        insertMarkdown('\n' + indent + bullet + ' ');
      }
    }
  };

  const formatButtons = [
    { icon: Bold, action: () => insertMarkdown('**', '**'), tooltip: 'Bold (Ctrl+B)' },
    { icon: Italic, action: () => insertMarkdown('*', '*'), tooltip: 'Italic (Ctrl+I)' },
    { icon: Heading1, action: () => insertMarkdown('# '), tooltip: 'Heading 1' },
    { icon: Heading2, action: () => insertMarkdown('## '), tooltip: 'Heading 2' },
    { icon: List, action: () => insertMarkdown('- '), tooltip: 'Bullet List' },
    { icon: Link, action: () => insertMarkdown('[', '](url)'), tooltip: 'Add Link' },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Editor Header */}
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold">Editor</h2>
          <Badge variant="secondary" className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span className="text-xs">Auto-saving</span>
          </Badge>
        </div>
        
        {/* Formatting Toolbar */}
        <div className="hidden sm:flex items-center space-x-1 bg-muted p-1 rounded-lg">
          {formatButtons.map((button, index) => (
            <Button
              key={index}
              variant="ghost"
              size="sm"
              onClick={button.action}
              className="h-8 w-8 p-0 hover:bg-background transition-colors"
              title={button.tooltip}
            >
              <button.icon className="h-4 w-4" />
            </Button>
          ))}
        </div>

        {/* Mobile actions */}
        <div className="flex sm:hidden items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onOptimize}
          >
            <Sparkles className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Mobile Formatting Toolbar */}
      <div className="sm:hidden flex items-center space-x-2 p-2 border-b bg-muted/50 overflow-x-auto">
        {formatButtons.map((button, index) => (
          <Button
            key={index}
            variant="ghost"
            size="sm"
            onClick={button.action}
            className="h-8 w-8 p-0 flex-shrink-0"
          >
            <button.icon className="h-3.5 w-3.5" />
          </Button>
        ))}
      </div>

      {/* Editor */}
      <div className="flex-1 relative">
        <Textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => {
            onChange(e.target.value);
            setCursorPosition(e.target.selectionStart);
          }}
          onKeyDown={handleKeyDown}
          onSelect={(e) => setCursorPosition((e.target as HTMLTextAreaElement).selectionStart)}
          placeholder="Start writing your resume in Markdown...

Example:
# Your Name
## Your Title

**Email:** your@email.com
**Phone:** (555) 123-4567

## Summary
Write a compelling summary of your experience...

## Experience
### **Job Title** | Company Name | 2020 - Present
- Accomplished achievement with quantified results
- Led initiative that improved efficiency by 25%

## Skills
**Programming:** JavaScript, Python, React
**Tools:** Git, Docker, AWS"
          className="w-full h-full border-none resize-none focus:ring-0 focus:border-none font-mono text-sm leading-relaxed p-4 custom-scrollbar"
          style={{ minHeight: '100%' }}
        />
        
        {/* Floating action button for mobile */}
        <div className="absolute bottom-4 right-4 lg:hidden">
          <Button
            onClick={onOptimize}
            size="sm"
            className="rounded-full shadow-lg elevation-2"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Optimize
          </Button>
        </div>
      </div>

      {/* Word count and tips */}
      <div className="flex items-center justify-between p-2 border-t bg-muted/50 text-xs text-muted-foreground">
        <div className="flex items-center space-x-4">
          <span>{content.split(/\s+/).filter(word => word.length > 0).length} words</span>
          <span>{content.length} characters</span>
        </div>
        
        <div className="hidden sm:flex items-center space-x-2">
          <span>Tip: Use ** for bold, * for italic</span>
        </div>
      </div>
    </div>
  );
}
