
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  Eye, 
  Download, 
  Sparkles,
  History,
  FileText,
  ChevronDown,
  Check
} from "lucide-react";
import { useState } from "react";

interface MobileNavigationProps {
  activeView: 'editor' | 'preview' | 'export';
  onViewChange: (view: 'editor' | 'preview' | 'export') => void;
  onOptimize: () => void;
  onVersions: () => void;
  onExport: () => void;
  onCoverLetter: () => void;
  userPlan?: string;
  autoSaveStatus?: "saved" | "saving" | "unsaved";
}

export default function MobileNavigation({
  activeView,
  onViewChange,
  onOptimize,
  onVersions,
  onExport,
  onCoverLetter,
  userPlan = "free",
  autoSaveStatus = "saved"
}: MobileNavigationProps) {
  const [showExportOptions, setShowExportOptions] = useState(false);

  const tabs = [
    {
      id: 'editor' as const,
      label: 'Edit',
      icon: Edit,
      onClick: () => onViewChange('editor')
    },
    {
      id: 'preview' as const,
      label: 'Preview',
      icon: Eye,
      onClick: () => onViewChange('preview')
    },
    {
      id: 'export' as const,
      label: 'Export',
      icon: Download,
      onClick: () => onViewChange('export')
    }
  ];

  const actions = [
    {
      label: 'Optimize Resume',
      icon: Sparkles,
      onClick: onOptimize,
      variant: 'default' as const,
      isPro: true,
      description: 'AI-powered ATS optimization'
    },
    {
      label: 'Version History',
      icon: History,
      onClick: onVersions,
      variant: 'outline' as const,
      isPro: true,
      description: 'Save and manage versions'
    },
    {
      label: 'Cover Letter',
      icon: FileText,
      onClick: onCoverLetter,
      variant: 'outline' as const,
      isPro: true,
      description: 'Generate personalized letters'
    }
  ];

  const exportFormats = [
    {
      format: 'PDF',
      description: 'Perfect for applications',
      color: 'red',
      recommended: true,
      onClick: () => onExport()
    },
    {
      format: 'DOCX',
      description: 'Editable format',
      color: 'blue',
      isPro: true,
      onClick: () => onExport()
    }
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 safe-area-pb">
      {/* Main Navigation Tabs */}
      <div className="flex bg-white">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={tab.onClick}
            className={`
              flex-1 flex flex-col items-center justify-center py-3 px-2 text-xs font-medium transition-all duration-200 min-h-[60px] touch-manipulation
              ${activeView === tab.id 
                ? 'text-primary bg-primary/5 border-t-2 border-primary' 
                : 'text-gray-500 hover:text-gray-700 active:bg-gray-50'
              }
            `}
          >
            <tab.icon className="h-5 w-5 mb-1" />
            <span>{tab.label}</span>
            {tab.id === 'editor' && autoSaveStatus === 'saving' && (
              <div className="w-1 h-1 bg-blue-500 rounded-full animate-pulse mt-0.5" />
            )}
          </button>
        ))}
      </div>

      {/* Export View Content */}
      {activeView === 'export' && (
        <div className="max-h-[50vh] overflow-y-auto bg-gray-50">
          <div className="p-4 space-y-4">
            {/* Quick Export */}
            <div>
              <h3 className="text-base font-semibold mb-3 text-gray-900">Quick Export</h3>
              <div className="grid grid-cols-2 gap-3">
                {exportFormats.map((format) => (
                  <Button
                    key={format.format}
                    onClick={format.onClick}
                    className="h-auto p-4 flex flex-col items-center space-y-2 touch-manipulation"
                    variant="outline"
                    disabled={format.isPro && userPlan === 'free'}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold bg-${format.color}-500`}>
                      {format.format}
                    </div>
                    <div className="text-center">
                      <div className="font-medium text-sm">{format.format}</div>
                      <div className="text-xs text-muted-foreground">
                        {format.description}
                        {format.isPro && userPlan === 'free' && (
                          <Badge variant="secondary" className="ml-1 text-xs">Pro</Badge>
                        )}
                      </div>
                    </div>
                    {format.recommended && (
                      <Badge variant="default" className="text-xs">Recommended</Badge>
                    )}
                  </Button>
                ))}
              </div>
            </div>

            {/* AI Tools */}
            <div>
              <h3 className="text-base font-semibold mb-3 text-gray-900">AI Tools</h3>
              <div className="space-y-3">
                {actions.map((action, index) => (
                  <Button
                    key={index}
                    onClick={action.onClick}
                    variant={action.variant}
                    disabled={action.isPro && userPlan === 'free'}
                    className="w-full justify-start h-auto p-4 touch-manipulation active:scale-95 transition-transform"
                  >
                    <div className="flex items-center space-x-3 w-full">
                      <div className={`
                        w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0
                        ${action.variant === 'default' 
                          ? 'bg-primary text-white' 
                          : 'bg-gray-100 text-gray-600'
                        }
                      `}>
                        <action.icon className="h-5 w-5" />
                      </div>
                      <div className="text-left flex-1">
                        <div className="font-medium text-sm">{action.label}</div>
                        <div className="text-xs text-muted-foreground flex items-center">
                          {action.description}
                          {action.isPro && userPlan === 'free' && (
                            <Badge variant="secondary" className="ml-2 text-xs">Pro</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>

            {/* Mobile Tips */}
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium mb-2 text-sm text-blue-900">💡 Mobile Tips</h4>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• Swipe left/right to switch between Edit and Preview</li>
                <li>• Use landscape mode for better editing experience</li>
                <li>• Tap and hold for context menus</li>
                <li>• Double-tap to zoom in editor</li>
                <li>• Auto-save keeps your work safe</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
