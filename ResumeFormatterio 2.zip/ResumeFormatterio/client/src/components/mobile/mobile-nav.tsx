import { Button } from "@/components/ui/button";
import { Edit, Eye, Download, Zap, FileText } from "lucide-react";

interface MobileNavProps {
  activeTab: 'edit' | 'preview' | 'export';
  onTabChange: (tab: 'edit' | 'preview' | 'export') => void;
  onOptimize: () => void;
  onGenerateCoverLetter: () => void;
}

export default function MobileNav({ 
  activeTab, 
  onTabChange, 
  onOptimize, 
  onGenerateCoverLetter 
}: MobileNavProps) {
  return (
    <>
      {/* Main Navigation Tabs */}
      <div className="bg-card border-b border-border sticky top-0 z-40">
        <div className="flex">
          <Button
          variant={activeTab === 'edit' ? 'default' : 'ghost'}
          onClick={() => onTabChange('edit')}
          className="flex-1 flex items-center justify-center gap-2 h-14 min-h-[44px] text-sm"
        >
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <Button
          variant={activeTab === 'preview' ? 'default' : 'ghost'}
          onClick={() => onTabChange('preview')}
          className="flex-1 flex items-center justify-center gap-2 h-14 min-h-[44px] text-sm"
        >
          <Eye className="h-4 w-4" />
          <span>Preview</span>
        </Button>

        <Button
          variant={activeTab === 'export' ? 'default' : 'ghost'}
          onClick={() => onTabChange('export')}
          className="flex-1 flex items-center justify-center gap-2 h-14 min-h-[44px] text-sm"
        >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Export Tab Content */}
      {activeTab === 'export' && (
        <div className="p-4 bg-card border-b border-border">
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Export & AI Tools</h3>

            {/* AI Tools */}
            <div className="space-y-2">
              <Button 
                onClick={onOptimize}
                className="w-full justify-start btn-ripple"
                variant="default"
              >
                <Zap className="h-4 w-4 mr-2" />
                Optimize Resume
              </Button>
              <Button 
                onClick={onGenerateCoverLetter}
                className="w-full justify-start btn-ripple"
                variant="outline"
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Cover Letter
              </Button>
            </div>

            {/* Export Options */}
            <div className="space-y-2 pt-2 border-t border-border">
              <h4 className="font-medium text-sm text-muted-foreground">Export Formats</h4>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="btn-ripple">
                  <Download className="h-4 w-4 mr-1" />
                  PDF
                </Button>
                <Button variant="outline" size="sm" className="btn-ripple">
                  <Download className="h-4 w-4 mr-1" />
                  DOCX
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}