import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Sparkles, 
  CheckCircle, 
  AlertTriangle, 
  TrendingUp,
  Coins,
  Crown,
  X
} from "lucide-react";
import { OptimizationResult, OptimizationSuggestion } from "@/types/resume";

interface OptimizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeId?: number | string;
  resumeContent: string;
  userPlan?: string;
  userCredits?: number;
}

export default function OptimizationModal({ 
  isOpen, 
  onClose, 
  resumeId, 
  resumeContent,
  userPlan = 'free',
  userCredits = 0
}: OptimizationModalProps) {
  const [jobDescription, setJobDescription] = useState("");
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if in demo mode (no resumeId)
  const isDemoMode = !resumeId;

  // Analyze resume mutation
  const analyzeMutation = useMutation({
    mutationFn: async () => {
      if (isDemoMode) {
        // Return mock analysis for demo mode
        return {
          score: 75,
          suggestions: [
            {
              type: 'medium',
              title: 'Add quantified achievements',
              description: 'Include specific numbers and percentages to show impact',
              category: 'content'
            },
            {
              type: 'low', 
              title: 'Improve keyword optimization',
              description: 'Add more industry-relevant keywords for ATS compatibility',
              category: 'ats'
            }
          ]
        };
      }
      
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/optimize`, {
        jobDescription: jobDescription.trim() || undefined
      });
      return response.json();
    },
    onSuccess: (result) => {
      setOptimizationResult(result);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Analysis Complete",
        description: `Your resume scored ${result.atsScore}/100 for ATS compatibility.`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      const errorMessage = (error as Error).message;
      if (errorMessage.includes("Insufficient credits")) {
        toast({
          title: "Insufficient Credits",
          description: "You need 3 credits to run an optimization analysis. Upgrade to Pro for unlimited access.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Analysis Failed",
          description: "Failed to analyze your resume. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  // Apply optimizations mutation (Pro feature)
  const applyOptimizationsMutation = useMutation({
    mutationFn: async (suggestions: OptimizationSuggestion[]) => {
      if (isDemoMode) {
        // In demo mode, show sign-up prompt instead of applying
        toast({
          title: "Sign up to apply optimizations",
          description: "Create a free account to save your optimized resume",
          variant: "default"
        });
        return;
      }
      
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/optimize-content`, {
        suggestions: suggestions
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Optimizations Applied",
        description: "Your resume has been updated with AI suggestions.",
      });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      const errorMessage = (error as Error).message;
      if (errorMessage.includes("Pro subscription required")) {
        toast({
          title: "Pro Feature",
          description: "Auto-apply optimizations is a Pro feature. Upgrade to access this functionality.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Optimization Failed",
          description: "Failed to apply optimizations. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleAnalyze = () => {
    if (userPlan === 'free' && userCredits < 3) {
      toast({
        title: "Insufficient Credits",
        description: "You need 3 credits to run an optimization analysis. Upgrade to Pro for unlimited access.",
        variant: "destructive",
      });
      return;
    }
    
    setIsAnalyzing(true);
    analyzeMutation.mutate();
    setIsAnalyzing(false);
  };

  const handleApplyOptimizations = () => {
    if (!optimizationResult) return;
    
    if (userPlan !== 'pro') {
      toast({
        title: "Pro Feature",
        description: "Auto-apply optimizations is a Pro feature. Upgrade to access this functionality.",
        variant: "destructive",
      });
      return;
    }
    
    applyOptimizationsMutation.mutate(optimizationResult.suggestions);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'medium':
        return <TrendingUp className="h-5 w-5 text-yellow-500" />;
      case 'low':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      default:
        return <CheckCircle className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <span>AI Resume Optimization</span>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[70vh] custom-scrollbar">
          <div className="space-y-6">
            {/* Quick Start - Skip Job Description */}
            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
              <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Quick Analysis</h3>
              <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
                Get instant feedback on your resume without providing a job description. You can always run a targeted analysis later.
              </p>
              <Button 
                onClick={handleAnalyze}
                disabled={isAnalyzing || analyzeMutation.isPending}
                className="w-full"
              >
                {isAnalyzing || analyzeMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Quick Analysis
                  </>
                )}
              </Button>
            </div>

            {/* Optional Job Description - Collapsed by default */}
            <div>
              <details className="group">
                <summary className="cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
                  + Add job description for targeted suggestions (optional)
                </summary>
                <div className="mt-3">
                  <Textarea
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Paste the job description here to get tailored suggestions..."
                    className="h-32 resize-none"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Adding a job description will provide more targeted optimization suggestions.
                  </p>
                </div>
              </details>
            </div>

            {/* Analysis Results */}
            {optimizationResult && (
              <div className="space-y-6">
                {/* ATS Score */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">ATS Analysis</h3>
                      <Badge className={`${getScoreColor(optimizationResult.atsScore)} border-0`}>
                        Score: {optimizationResult.atsScore}/100
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Matched Keywords */}
                      {optimizationResult.matchedKeywords.length > 0 && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center text-green-600">
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Matched Keywords ({optimizationResult.matchedKeywords.length})
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {optimizationResult.matchedKeywords.map((keyword, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                                {keyword}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Missing Keywords */}
                      {optimizationResult.missingKeywords.length > 0 && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center text-amber-600">
                            <AlertTriangle className="h-4 w-4 mr-2" />
                            Missing Keywords ({optimizationResult.missingKeywords.length})
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {optimizationResult.missingKeywords.map((keyword, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                                {keyword}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Improvement Suggestions */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">
                    Top {optimizationResult.suggestions.length} Improvements
                  </h3>
                  <div className="space-y-4">
                    {optimizationResult.suggestions.map((suggestion, index) => (
                      <Card key={index} className="border">
                        <CardContent className="pt-4">
                          <div className="flex items-start space-x-3">
                            <div className="flex items-center justify-center w-8 h-8 bg-primary/10 text-primary rounded-full text-sm font-medium flex-shrink-0">
                              {index + 1}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                {getPriorityIcon(suggestion.priority)}
                                <h4 className="font-medium">{suggestion.title}</h4>
                                <Badge variant="outline" className="text-xs">
                                  {suggestion.priority} priority
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-3">
                                {suggestion.description}
                              </p>
                              {suggestion.example && (
                                <div className="bg-muted p-3 rounded-lg text-sm">
                                  <p className="font-medium mb-1">Example:</p>
                                  <p className="text-muted-foreground">{suggestion.example}</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* No results state */}
            {!optimizationResult && !isAnalyzing && (
              <div className="text-center py-8">
                <Sparkles className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Ready to Optimize</h3>
                <p className="text-muted-foreground">
                  Click "Analyze Resume" to get AI-powered suggestions for improving your resume's ATS compatibility.
                </p>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            {userPlan === 'free' ? (
              <>
                <Coins className="h-4 w-4 text-secondary" />
                <span>This will use 3 credits</span>
              </>
            ) : (
              <>
                <Crown className="h-4 w-4 text-primary" />
                <span>Unlimited optimizations with Pro</span>
              </>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            
            {!optimizationResult ? (
              <Button 
                onClick={handleAnalyze}
                disabled={isAnalyzing || analyzeMutation.isPending}
              >
                {isAnalyzing || analyzeMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Analyze Resume
                  </>
                )}
              </Button>
            ) : (
              <Button 
                onClick={handleApplyOptimizations}
                disabled={applyOptimizationsMutation.isPending || userPlan !== 'pro'}
              >
                {applyOptimizationsMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Applying...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    {userPlan === 'pro' ? 'Apply Suggestions' : 'Upgrade to Apply'}
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
