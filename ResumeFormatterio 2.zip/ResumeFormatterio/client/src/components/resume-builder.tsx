import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { ResumeData, Template } from "@/types/resume";
import { getDefaultTemplate, sampleResumeContent, resumeTemplates } from "@/lib/templates";
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar";
import MarkdownEditor from "./markdown-editor";
import ResumePreview from "./resume-preview";
import MobileNavigation from "./mobile-navigation";
import OptimizationModal from "./optimization-modal";
import VersionHistoryModal from "./version-history-modal";
import CoverLetterModal from "./cover-letter-modal";
import ExportModal from "./export-modal";
import UpgradeModal from "./upgrade-modal";
import ExportIntegrationModal from "./export-integration-modal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Coins, 
  User, 
  ChevronDown, 
  Menu,
  Settings,
  LogOut,
  Layout,
  Sparkles,
  Plus,
  History,
  Download
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ResumeBuilderProps {
  user: any;
}

export default function ResumeBuilder({ user }: ResumeBuilderProps) {
  const [currentResume, setCurrentResume] = useState<ResumeData | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<Template>(getDefaultTemplate());
  const [mobileView, setMobileView] = useState<'editor' | 'preview' | 'export'>('editor');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  const [showExportIntegration, setShowExportIntegration] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user's resumes
  const { data: resumes = [], isLoading: resumesLoading } = useQuery<ResumeData[]>({
    queryKey: ["/api/resumes"],
  });

  // Create resume mutation
  const createResumeMutation = useMutation({
    mutationFn: async (resumeData: Partial<ResumeData>) => {
      const response = await apiRequest("POST", "/api/resumes", resumeData);
      return response.json();
    },
    onSuccess: (newResume) => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      setCurrentResume(newResume);
      toast({
        title: "Resume Created",
        description: "Your new resume has been created successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update resume mutation
  const updateResumeMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<ResumeData> }) => {
      const response = await apiRequest("PUT", `/api/resumes/${id}`, updates);
      return response.json();
    },
    onSuccess: (updatedResume) => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      setCurrentResume(updatedResume);
      setAutoSaveStatus('saved');
    },
    onError: (error) => {
      setAutoSaveStatus('error');
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  // Initialize with first resume or create default
  useEffect(() => {
    if (!resumesLoading && resumes.length > 0 && !currentResume) {
      setCurrentResume(resumes[0]);
    } else if (!resumesLoading && resumes.length === 0 && !currentResume) {
      // Create initial resume
      createResumeMutation.mutate({
        title: "My Resume",
        content: sampleResumeContent,
        templateId: selectedTemplate.id,
      });
    }
  }, [resumes, resumesLoading, currentResume]);

  // Auto-save functionality
  useEffect(() => {
    if (!currentResume) return;
    
    const timeoutId = setTimeout(() => {
      if (currentResume.id) {
        setAutoSaveStatus('saving');
        updateResumeMutation.mutate({
          id: currentResume.id,
          updates: {
            content: currentResume.content,
            templateId: selectedTemplate.id,
          },
        });
      }
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, [currentResume?.content, selectedTemplate.id]);

  const handleContentChange = (content: string) => {
    if (currentResume) {
      setCurrentResume({ ...currentResume, content });
      setAutoSaveStatus('saving');
    }
  };

  const handleTemplateChange = (template: Template) => {
    setSelectedTemplate(template);
    if (currentResume) {
      setCurrentResume({ ...currentResume, templateId: template.id });
      setAutoSaveStatus('saving');
    }
  };

  const handleCreateNewResume = () => {
    createResumeMutation.mutate({
      title: "New Resume",
      content: sampleResumeContent,
      templateId: selectedTemplate.id,
    });
  };

  const handleExportToPrepPair = () => {
    if (currentResume) {
      setShowExportIntegration(true);
    }
  };

  const getAutoSaveText = () => {
    switch (autoSaveStatus) {
      case 'saving':
        return 'Saving...';
      case 'saved':
        return 'All changes saved';
      case 'error':
        return 'Save failed';
      default:
        return 'All changes saved';
    }
  };

  const getAutoSaveIcon = () => {
    switch (autoSaveStatus) {
      case 'saving':
        return <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin" />;
      case 'saved':
        return <div className="w-3 h-3 bg-green-500 rounded-full" />;
      case 'error':
        return <div className="w-3 h-3 bg-red-500 rounded-full" />;
      default:
        return <div className="w-3 h-3 bg-green-500 rounded-full" />;
    }
  };

  if (resumesLoading || !currentResume) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 elevation-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Brand */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <Menu className="h-5 w-5" />
              </button>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-semibold">ResumeFormatter.io</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setActiveModal('optimization')}
                className="hidden sm:flex items-center space-x-2"
              >
                <Sparkles className="h-4 w-4" />
                <span>Optimize</span>
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setActiveModal('versions')}
                className="hidden sm:flex items-center space-x-2"
              >
                <History className="h-4 w-4" />
                <span>Versions</span>
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setActiveModal('export')}
                className="hidden sm:flex items-center space-x-2"
              >
                <Download className="h-4 w-4" />
                <span>Export</span>
              </Button>

              {/* Auto-save status */}
              <div className="hidden lg:flex items-center space-x-2 text-sm text-muted-foreground">
                {getAutoSaveIcon()}
                <span>{getAutoSaveText()}</span>
              </div>
            </div>

            {/* User menu */}
            <div className="flex items-center space-x-4">
              {/* Credits display */}
              {user.plan === 'free' && (
                <div className="flex items-center space-x-2 bg-secondary/10 px-3 py-1.5 rounded-full">
                  <Coins className="h-4 w-4 text-secondary" />
                  <span className="text-sm font-medium text-secondary">{user.credits} credits</span>
                </div>
              )}

              {/* User dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <User className="h-4 w-4 text-white" />
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5 text-sm">
                    <div className="font-medium">{user.firstName || 'User'}</div>
                    <div className="text-muted-foreground">{user.email}</div>
                    <Badge variant="secondary" className="mt-1">
                      {user.plan === 'pro' ? 'Pro Plan' : 'Free Plan'}
                    </Badge>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setActiveModal('upgrade')}>
                    <Settings className="mr-2 h-4 w-4" />
                    {user.plan === 'free' ? 'Upgrade to Pro' : 'Manage Subscription'}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = "/api/logout"}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <MobileNavigation
        activeView={mobileView}
        onViewChange={setMobileView}
        onOptimize={() => setActiveModal('optimization')}
        onVersions={() => setActiveModal('versions')}
        onExport={() => setActiveModal('export')}
        onCoverLetter={() => setActiveModal('cover-letter')}
      />

      {/* Main Layout */}
      <div className="flex h-[calc(100vh-4rem)]">
        {/* Collapsible Template Sidebar */}
        <Sidebar open={sidebarOpen} setOpen={setSidebarOpen}>
          <SidebarBody className="justify-between gap-4">
            <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
              {/* Sidebar Header */}
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Templates</h3>
              </div>
              
              {/* Templates List */}
              <div className="space-y-2">
                {resumeTemplates.map((template) => (
                  <SidebarLink
                    key={template.id}
                    link={{
                      label: template.name,
                      href: "#",
                      icon: <Layout className="h-5 w-5" />
                    }}
                    onClick={() => handleTemplateChange(template)}
                    className={selectedTemplate.id === template.id ? "bg-primary/10 text-primary" : ""}
                  />
                ))}
              </div>

              {/* Resumes Section */}
              <div className="mt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">My Resumes</h3>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleCreateNewResume}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="space-y-2">
                  {resumes.map((resume) => (
                    <SidebarLink
                      key={resume.id}
                      link={{
                        label: resume.title,
                        href: "#",
                        icon: <FileText className="h-5 w-5" />
                      }}
                      onClick={() => setCurrentResume(resume)}
                      className={currentResume?.id === resume.id ? "bg-primary/10 text-primary" : ""}
                    />
                  ))}
                </div>
              </div>
            </div>
          </SidebarBody>
        </Sidebar>

        {/* Main Content */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Editor */}
          <div className={`flex-1 ${mobileView !== 'editor' ? 'hidden lg:flex' : 'flex'} flex-col`}>
            <MarkdownEditor
              content={currentResume.content}
              onChange={handleContentChange}
              onOptimize={() => setActiveModal('optimization')}
            />
          </div>

          {/* Preview */}
          <div className={`flex-1 ${mobileView !== 'preview' ? 'hidden lg:flex' : 'flex'} flex-col border-l`}>
            <ResumePreview
              content={currentResume.content}
              template={selectedTemplate}
              onExport={() => setActiveModal('export')}
              resumeId={currentResume.id}
            />
          </div>
        </div>
      </div>

      {/* Modals */}
      {activeModal === 'optimization' && (
        <OptimizationModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          resumeId={currentResume.id!}
          resumeContent={currentResume.content}
          userPlan={user.plan}
          userCredits={user.credits}
        />
      )}

      {activeModal === 'versions' && (
        <VersionHistoryModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          resumeId={currentResume.id!}
          currentContent={currentResume.content}
          onRestore={(content) => {
            setCurrentResume({ ...currentResume, content });
            setActiveModal(null);
          }}
        />
      )}

      {activeModal === 'cover-letter' && (
        <CoverLetterModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          resumeContent={currentResume.content}
          userPlan={user.plan}
          userCredits={user.credits}
        />
      )}

      {activeModal === 'export' && (
        <ExportModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          resumeId={currentResume.id!}
          resumeTitle={currentResume.title}
          userPlan={user.plan}
        />
      )}

      {activeModal === 'upgrade' && (
        <UpgradeModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          userPlan={user.plan}
        />
      )}

      {showExportIntegration && currentResume && (
        <ExportIntegrationModal
          isOpen={true}
          onClose={() => setShowExportIntegration(false)}
          resumeId={currentResume.id!}
          resumeTitle={currentResume.title}
        />
      )}
    </div>
  );
}
