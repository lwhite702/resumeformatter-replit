import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  FileText, 
  Download, 
  Eye,
  Share2,
  Printer
} from "lucide-react";
import { Template } from "@/types/resume";
import { convertMarkdownToHTML, calculateAtsScore, parseMarkdownResume } from "@/lib/markdown-utils";

interface ResumePreviewProps {
  content: string;
  template: Template;
  onExport: () => void;
  resumeId?: number;
}

export default function ResumePreview({ content, template, onExport, resumeId }: ResumePreviewProps) {
  const parsedResume = useMemo(() => parseMarkdownResume(content), [content]);
  const atsScore = useMemo(() => calculateAtsScore(content), [content]);
  
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800 border-green-200';
    if (score >= 60) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-red-100 text-red-800 border-red-200';
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return '🟢';
    if (score >= 60) return '🟡';
    return '🔴';
  };

  const renderResumeContent = () => {
    switch (template.id) {
      case 'modern-tech':
        return (
          <div className="p-8 font-sans bg-white">
            {/* Header */}
            <div className="text-center border-b-2 border-blue-600 pb-6 mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {parsedResume.name || 'Your Name'}
              </h1>
              <h2 className="text-xl font-medium text-blue-600 mb-4">
                {parsedResume.title || 'Your Title'}
              </h2>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-600">
                {parsedResume.email && <span>{parsedResume.email}</span>}
                {parsedResume.phone && <span>{parsedResume.phone}</span>}
                {parsedResume.location && <span>{parsedResume.location}</span>}
                {parsedResume.linkedin && <span>{parsedResume.linkedin}</span>}
                {parsedResume.github && <span>{parsedResume.github}</span>}
              </div>
            </div>

            {/* Summary */}
            {parsedResume.summary && (
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 border-b border-gray-300 pb-1 mb-3">
                  Summary
                </h3>
                <p className="text-gray-700 leading-relaxed">
                  {parsedResume.summary}
                </p>
              </section>
            )}

            {/* Experience */}
            {parsedResume.experience && parsedResume.experience.length > 0 && (
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-foreground border-b border-border pb-1 mb-4">
                  Experience
                </h3>
                <div className="space-y-4">
                  {parsedResume.experience.map((exp, index) => (
                    <div key={index}>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-foreground">{exp.title}</h4>
                          <p className="text-primary font-medium">{exp.company}</p>
                        </div>
                        <div className="text-sm text-muted-foreground mt-1 sm:mt-0">
                          {exp.duration}
                        </div>
                      </div>
                      {exp.description && exp.description.length > 0 && (
                        <ul className="space-y-1 text-muted-foreground ml-4">
                          {exp.description.map((desc, descIndex) => (
                            <li key={descIndex} className="flex items-start space-x-2">
                              <span className="text-primary mt-1.5 text-xs">•</span>
                              <span>{desc}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                      {exp.technologies && (
                        <div className="mt-2">
                          <span className="text-xs font-medium text-muted-foreground">Technologies: </span>
                          <span className="text-xs text-muted-foreground">{exp.technologies}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Skills */}
            {parsedResume.skills && Object.keys(parsedResume.skills).length > 0 && (
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-foreground border-b border-border pb-1 mb-4">
                  Skills
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {Object.entries(parsedResume.skills).map(([category, skills]) => (
                    <div key={category}>
                      <h4 className="font-medium text-foreground mb-1">{category}</h4>
                      <p className="text-sm text-muted-foreground">{skills}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {parsedResume.education && parsedResume.education.length > 0 && (
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-foreground border-b border-border pb-1 mb-4">
                  Education
                </h3>
                <div className="space-y-3">
                  {parsedResume.education.map((edu, index) => (
                    <div key={index} className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground">{edu.degree}</h4>
                        <p className="text-muted-foreground">{edu.institution}</p>
                        {edu.gpa && (
                          <p className="text-sm text-muted-foreground">{edu.gpa}</p>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground mt-1 sm:mt-0">
                        {edu.year}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Projects */}
            {parsedResume.projects && parsedResume.projects.length > 0 && (
              <section>
                <h3 className="text-lg font-semibold text-foreground border-b border-border pb-1 mb-4">
                  Projects
                </h3>
                <div className="space-y-4">
                  {parsedResume.projects.map((project, index) => (
                    <div key={index}>
                      <h4 className="font-semibold text-foreground">{project.name}</h4>
                      {project.description && (
                        <p className="text-muted-foreground mt-1">{project.description.trim()}</p>
                      )}
                      {project.technologies && (
                        <p className="text-sm text-muted-foreground mt-1">
                          <span className="font-medium">Technologies: </span>
                          {project.technologies}
                        </p>
                      )}
                      {project.link && (
                        <p className="text-sm text-primary mt-1">
                          <span className="font-medium">Link: </span>
                          {project.link}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        );

      case 'minimal-dev':
        return (
          <div className="p-8 font-mono bg-white max-w-4xl">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-light text-gray-900 mb-2">
                {parsedResume.name || 'Your Name'}
              </h1>
              <h2 className="text-xl text-gray-600 mb-4">
                {parsedResume.title || 'Your Title'}
              </h2>
              <div className="text-sm text-gray-500 space-y-1">
                {parsedResume.email && <div>{parsedResume.email}</div>}
                {parsedResume.phone && <div>{parsedResume.phone}</div>}
                {parsedResume.location && <div>{parsedResume.location}</div>}
                {parsedResume.linkedin && <div>{parsedResume.linkedin}</div>}
                {parsedResume.github && <div>{parsedResume.github}</div>}
              </div>
            </div>

            {/* Summary */}
            {parsedResume.summary && (
              <section className="mb-8">
                <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-3">
                  Summary
                </h3>
                <p className="text-gray-700 leading-relaxed font-sans">
                  {parsedResume.summary}
                </p>
              </section>
            )}

            {/* Experience */}
            {parsedResume.experience && parsedResume.experience.length > 0 && (
              <section className="mb-8">
                <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-4">
                  Experience
                </h3>
                <div className="space-y-6">
                  {parsedResume.experience.map((exp, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-medium text-gray-900">{exp.title}</h4>
                          <p className="text-gray-600">{exp.company}</p>
                        </div>
                        <span className="text-sm text-gray-500">{exp.duration}</span>
                      </div>
                      <ul className="text-sm text-gray-700 space-y-1 font-sans">
                        {exp.description.map((item, idx) => (
                          <li key={idx} className="before:content-['-'] before:mr-2">
                            {item}
                          </li>
                        ))}
                      </ul>
                      {exp.technologies && (
                        <p className="text-xs text-gray-500 mt-2">
                          {exp.technologies}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Skills */}
            {parsedResume.skills && Object.keys(parsedResume.skills).length > 0 && (
              <section className="mb-8">
                <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-3">
                  Skills
                </h3>
                <div className="space-y-2">
                  {Object.entries(parsedResume.skills).map(([category, skills]) => (
                    <div key={category} className="text-sm">
                      <span className="font-medium text-gray-700">{category}: </span>
                      <span className="text-gray-600 font-sans">{skills}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {parsedResume.education && parsedResume.education.length > 0 && (
              <section className="mb-8">
                <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-3">
                  Education
                </h3>
                <div className="space-y-3">
                  {parsedResume.education.map((edu, index) => (
                    <div key={index} className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-gray-900">{edu.degree}</h4>
                        <p className="text-gray-600">{edu.institution}</p>
                        {edu.gpa && <p className="text-sm text-gray-500">{edu.gpa}</p>}
                      </div>
                      <span className="text-sm text-gray-500">{edu.year}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Projects */}
            {parsedResume.projects && parsedResume.projects.length > 0 && (
              <section>
                <h3 className="text-sm uppercase tracking-wide text-gray-500 mb-4">
                  Projects
                </h3>
                <div className="space-y-4">
                  {parsedResume.projects.map((project, index) => (
                    <div key={index}>
                      <h4 className="font-medium text-gray-900">{project.name}</h4>
                      {project.description && (
                        <p className="text-gray-700 mt-1 font-sans text-sm">
                          {project.description.trim()}
                        </p>
                      )}
                      {project.technologies && (
                        <p className="text-xs text-gray-500 mt-1">
                          {project.technologies}
                        </p>
                      )}
                      {project.link && (
                        <p className="text-xs text-gray-600 mt-1">
                          {project.link}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        );

      case 'creative-portfolio':
        return (
          <div className="p-8 font-sans bg-gradient-to-br from-purple-50 to-pink-50">
            {/* Header */}
            <div className="text-center mb-8 relative">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 rounded-lg">
                <h1 className="text-3xl font-bold mb-2">
                  {parsedResume.name || 'Your Name'}
                </h1>
                <h2 className="text-xl font-light mb-4">
                  {parsedResume.title || 'Your Title'}
                </h2>
                <div className="flex flex-wrap justify-center gap-4 text-sm">
                  {parsedResume.email && <span>{parsedResume.email}</span>}
                  {parsedResume.phone && <span>{parsedResume.phone}</span>}
                  {parsedResume.location && <span>{parsedResume.location}</span>}
                  {parsedResume.linkedin && <span>{parsedResume.linkedin}</span>}
                  {parsedResume.github && <span>{parsedResume.github}</span>}
                </div>
              </div>
            </div>

            {/* Summary */}
            {parsedResume.summary && (
              <section className="mb-8 bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-purple-600 mb-3 flex items-center">
                  <div className="w-3 h-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mr-3"></div>
                  About Me
                </h3>
                <p className="text-gray-700 leading-relaxed">
                  {parsedResume.summary}
                </p>
              </section>
            )}

            {/* Experience */}
            {parsedResume.experience && parsedResume.experience.length > 0 && (
              <section className="mb-8 bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-purple-600 mb-4 flex items-center">
                  <div className="w-3 h-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mr-3"></div>
                  Experience
                </h3>
                <div className="space-y-6">
                  {parsedResume.experience.map((exp, index) => (
                    <div key={index} className="border-l-4 border-purple-200 pl-4">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <div>
                          <h4 className="font-bold text-gray-900">{exp.title}</h4>
                          <p className="text-purple-600 font-medium">{exp.company}</p>
                        </div>
                        <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded">
                          {exp.duration}
                        </span>
                      </div>
                      <ul className="text-gray-700 space-y-1">
                        {exp.description.map((item, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="text-purple-400 mr-2">▸</span>
                            {item}
                          </li>
                        ))}
                      </ul>
                      {exp.technologies && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {exp.technologies.split(',').map((tech, idx) => (
                            <span key={idx} className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs">
                              {tech.trim()}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Skills */}
            {parsedResume.skills && Object.keys(parsedResume.skills).length > 0 && (
              <section className="mb-8 bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-purple-600 mb-4 flex items-center">
                  <div className="w-3 h-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mr-3"></div>
                  Skills
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(parsedResume.skills).map(([category, skills]) => (
                    <div key={category} className="bg-purple-50 p-4 rounded-lg">
                      <h4 className="font-bold text-purple-700 mb-2">{category}</h4>
                      <p className="text-gray-700">{skills}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education & Projects in a grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Education */}
              {parsedResume.education && parsedResume.education.length > 0 && (
                <section className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-bold text-purple-600 mb-4 flex items-center">
                    <div className="w-3 h-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mr-3"></div>
                    Education
                  </h3>
                  <div className="space-y-4">
                    {parsedResume.education.map((edu, index) => (
                      <div key={index} className="border-l-4 border-pink-200 pl-4">
                        <h4 className="font-bold text-gray-900">{edu.degree}</h4>
                        <p className="text-purple-600">{edu.institution}</p>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm text-gray-500">{edu.year}</span>
                          {edu.gpa && (
                            <span className="text-sm bg-pink-100 text-pink-700 px-2 py-1 rounded">
                              {edu.gpa}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Projects */}
              {parsedResume.projects && parsedResume.projects.length > 0 && (
                <section className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-bold text-purple-600 mb-4 flex items-center">
                    <div className="w-3 h-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mr-3"></div>
                    Projects
                  </h3>
                  <div className="space-y-4">
                    {parsedResume.projects.map((project, index) => (
                      <div key={index} className="border-l-4 border-pink-200 pl-4">
                        <h4 className="font-bold text-gray-900">{project.name}</h4>
                        {project.description && (
                          <p className="text-gray-700 mt-1 text-sm">
                            {project.description.trim()}
                          </p>
                        )}
                        {project.technologies && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {project.technologies.split(',').map((tech, idx) => (
                              <span key={idx} className="bg-pink-100 text-pink-700 px-2 py-1 rounded-full text-xs">
                                {tech.trim()}
                              </span>
                            ))}
                          </div>
                        )}
                        {project.link && (
                          <p className="text-sm text-purple-600 mt-1 font-medium">
                            {project.link}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              )}
            </div>
          </div>
        );

      default:
        // Fallback to modern-tech style
        return renderResumeContent();
    }
  };

  return (
    <div className="flex flex-col h-full bg-muted/30">
      {/* Preview Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b">
        <div className="flex items-center space-x-4">
          <h2 className="text-lg font-semibold">Preview</h2>
          
          {/* ATS Score Badge */}
          <div className={`
            flex items-center space-x-2 px-3 py-1.5 rounded-full border text-sm font-medium
            ${getScoreColor(atsScore)}
          `}>
            <span>{getScoreIcon(atsScore)}</span>
            <span>ATS Score: {atsScore}</span>
          </div>
        </div>
        
        {/* Export Actions */}
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
            className="hidden sm:flex items-center space-x-2"
          >
            <Printer className="h-4 w-4" />
            <span>Print</span>
          </Button>
          
          <Button
            onClick={onExport}
            size="sm"
            className="flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
          </Button>
        </div>
      </div>

      {/* Resume Preview */}
      <ScrollArea className="flex-1 custom-scrollbar">
        <div className="p-4">
          <div className="max-w-2xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden print-full-width">
            {renderResumeContent()}
          </div>
        </div>
      </ScrollArea>

      {/* Tips for mobile */}
      <div className="lg:hidden p-3 bg-white border-t">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Tip: Tap Export to download your resume</span>
          <Badge variant="outline" className="text-xs">
            {template.name}
          </Badge>
        </div>
      </div>
    </div>
  );
}
