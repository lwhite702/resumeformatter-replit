import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Crown, Check } from "lucide-react";
import type { Template } from "@/types/resume";

interface TemplateSidebarProps {
  selectedTemplate: string;
  onTemplateSelect: (templateId: string) => void;
  userPlan: string;
}

export default function TemplateSidebar({ 
  selectedTemplate, 
  onTemplateSelect, 
  userPlan 
}: TemplateSidebarProps) {
  const { data: templates, isLoading } = useQuery<Template[]>({
    queryKey: ["/api/templates"],
  });

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!templates?.length) {
    return (
      <div className="p-4 text-center">
        <p className="text-muted-foreground">No templates available</p>
      </div>
    );
  }

  // Group templates by category
  const categorizedTemplates = templates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {} as Record<string, Template[]>);

  const canUseTemplate = (template: Template) => {
    return !template.isPro || userPlan === 'pro';
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
      <div className="space-y-6">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
          Templates
        </div>
        
        {Object.entries(categorizedTemplates).map(([category, categoryTemplates]) => (
          <div key={category}>
            <h3 className="text-sm font-medium mb-3">{category}</h3>
            <div className="grid grid-cols-2 gap-3">
              {categoryTemplates.map((template) => (
                <div key={template.id} className="group cursor-pointer">
                  <Card 
                    className={`aspect-[3/4] p-3 relative overflow-hidden transition-all duration-200 hover:elevation-2 ${
                      selectedTemplate === template.id 
                        ? 'border-2 border-primary elevation-2' 
                        : 'border border-border elevation-1'
                    } ${!canUseTemplate(template) ? 'opacity-60' : ''}`}
                    onClick={() => canUseTemplate(template) && onTemplateSelect(template.id)}
                  >
                    {/* Template Preview */}
                    <div 
                      className="absolute inset-0 bg-gradient-to-br from-background to-muted/50"
                      style={{ 
                        background: `linear-gradient(135deg, ${template.config.primaryColor}10, white)` 
                      }}
                    />
                    <div className="relative z-10">
                      <div 
                        className="h-2 rounded mb-2"
                        style={{ backgroundColor: template.config.primaryColor }}
                      />
                      <div className="space-y-1">
                        <div className="h-1 bg-muted-foreground/30 rounded w-3/4" />
                        <div className="h-1 bg-muted-foreground/30 rounded w-1/2" />
                        <div className="h-1 bg-muted-foreground/30 rounded w-2/3" />
                      </div>
                    </div>
                    
                    {/* Selected Indicator */}
                    {selectedTemplate === template.id && (
                      <div className="absolute top-2 right-2">
                        <Check className="h-4 w-4 text-primary" />
                      </div>
                    )}
                    
                    {/* Pro Badge */}
                    {template.isPro && (
                      <div className="absolute top-2 left-2">
                        <Badge variant="secondary" className="text-xs px-1 py-0">
                          <Crown className="h-3 w-3 mr-1" />
                          Pro
                        </Badge>
                      </div>
                    )}
                  </Card>
                  
                  <div className="mt-2 text-center">
                    <div className="text-xs font-medium">{template.name}</div>
                    <div className="text-xs text-muted-foreground">{template.description}</div>
                  </div>
                  
                  {/* Upgrade prompt for pro templates */}
                  {template.isPro && userPlan !== 'pro' && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-2 text-xs btn-ripple"
                    >
                      Upgrade to Use
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
