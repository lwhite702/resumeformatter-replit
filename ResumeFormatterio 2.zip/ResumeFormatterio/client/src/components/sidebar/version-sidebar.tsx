import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Save, History, Diff, RotateCcw } from "lucide-react";
import { useState } from "react";
import type { ResumeVersion } from "@/types/resume";

interface VersionSidebarProps {
  resumeId?: number;
  onVersionSelect: () => void;
}

export default function VersionSidebar({ resumeId, onVersionSelect }: VersionSidebarProps) {
  const [versionName, setVersionName] = useState('');

  const { data: versions, isLoading } = useQuery<ResumeVersion[]>({
    queryKey: ["/api/resumes", resumeId, "versions"],
    enabled: !!resumeId,
  });

  const handleSaveSnapshot = () => {
    if (!versionName.trim()) return;
    // Implementation would save the snapshot
    console.log('Saving snapshot:', versionName);
    setVersionName('');
  };

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
      <div className="space-y-6">
        {/* Create New Snapshot */}
        <div className="bg-muted/50 rounded-lg p-3">
          <h3 className="font-medium mb-3 text-sm">Save Current Version</h3>
          <div className="space-y-2">
            <Input
              placeholder="Version name (e.g., 'Google Application')"
              value={versionName}
              onChange={(e) => setVersionName(e.target.value)}
              className="text-sm"
            />
            <Button 
              onClick={handleSaveSnapshot}
              disabled={!versionName.trim()}
              size="sm"
              className="w-full btn-ripple"
            >
              <Save className="h-4 w-4 mr-1" />
              Save Snapshot
            </Button>
          </div>
        </div>

        {/* Version History */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-sm">Saved Versions</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onVersionSelect}
              className="text-xs btn-ripple"
            >
              View All
            </Button>
          </div>
          
          <div className="space-y-3">
            {versions?.length ? (
              versions.slice(0, 5).map((version) => (
                <Card key={version.id} className="p-3 hover:elevation-2 transition-all duration-200">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                        <History className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="font-medium text-sm truncate">{version.name}</h4>
                        <p className="text-xs text-muted-foreground">
                          {new Date(version.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {version.description && (
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {version.description}
                    </p>
                  )}
                  
                  <div className="flex items-center space-x-1">
                    <Button variant="outline" size="sm" className="flex-1 text-xs btn-ripple">
                      <Diff className="h-3 w-3 mr-1" />
                      Diff
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 text-xs btn-ripple">
                      <RotateCcw className="h-3 w-3 mr-1" />
                      Restore
                    </Button>
                  </div>
                </Card>
              ))
            ) : (
              <div className="text-center py-8">
                <History className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-2">No saved versions yet</p>
                <p className="text-xs text-muted-foreground">
                  Save snapshots to track changes and compare versions
                </p>
              </div>
            )}
          </div>
          
          {versions && versions.length > 5 && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onVersionSelect}
              className="w-full mt-3 text-xs btn-ripple"
            >
              View All {versions.length} Versions
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
