import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { 
  Palette, 
  History, 
  Sparkles, 
  FileText, 
  Plus, 
  Check,
  Crown,
  X,
  ExternalLink
} from "lucide-react";
import { Template, ResumeData } from "@/types/resume";
import { resumeTemplates, templateCategories, getTemplatesByCategory } from "@/lib/templates";

interface TemplateSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTemplate: Template;
  onTemplateChange: (template: Template) => void;
  onOptimize: () => void;
  onVersions: () => void;
  onCoverLetter: () => void;
  onCreateNew: () => void;
  onExportToPrepPair: () => void;
  userPlan: string;
  resumes: ResumeData[];
  currentResume: ResumeData | null;
  onResumeChange: (resume: ResumeData) => void;
}

export default function TemplateSidebar({
  isOpen,
  onClose,
  selectedTemplate,
  onTemplateChange,
  onOptimize,
  onVersions,
  onCoverLetter,
  onCreateNew,
  onExportToPrepPair,
  userPlan,
  resumes,
  currentResume,
  onResumeChange
}: TemplateSidebarProps) {
  const [activeTab, setActiveTab] = useState("templates");
  const [resumeTitle, setResumeTitle] = useState(currentResume?.title || "");

  const handleTemplateSelect = (template: Template) => {
    if (template.isPro && userPlan !== 'pro') {
      // Show upgrade prompt
      return;
    }
    onTemplateChange(template);
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">My Resume</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="lg:hidden"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Resume Title */}
        <Input
          value={resumeTitle}
          onChange={(e) => setResumeTitle(e.target.value)}
          onBlur={() => {
            if (currentResume && resumeTitle !== currentResume.title) {
              // Update resume title - you might want to add this mutation
              console.log("Update resume title:", resumeTitle);
            }
          }}
          className="font-medium"
          placeholder="Resume title..."
        />
      </div>

      {/* Navigation Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-2 m-4 mb-0">
          <TabsTrigger value="templates" className="flex items-center space-x-2">
            <Palette className="h-4 w-4" />
            <span>Templates</span>
          </TabsTrigger>
          <TabsTrigger value="versions" className="flex items-center space-x-2">
            <History className="h-4 w-4" />
            <span>Versions</span>
          </TabsTrigger>
        </TabsList>

        {/* Templates Tab */}
        <TabsContent value="templates" className="flex-1 mt-0">
          <ScrollArea className="h-full custom-scrollbar">
            <div className="p-4 space-y-6">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Templates
              </div>
              
              {templateCategories.map((category) => {
                const templates = getTemplatesByCategory(category);
                return (
                  <div key={category}>
                    <h3 className="text-sm font-medium text-foreground mb-3">{category}</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {templates.map((template) => (
                        <div
                          key={template.id}
                          className="group cursor-pointer"
                          onClick={() => handleTemplateSelect(template)}
                        >
                          <Card className={`
                            relative overflow-hidden transition-all duration-200 hover:elevation-2
                            ${selectedTemplate.id === template.id ? 'border-primary border-2' : 'border'}
                            ${template.isPro && userPlan !== 'pro' ? 'opacity-75' : ''}
                          `}>
                            <CardContent className="p-3">
                              <div className="aspect-[3/4] relative">
                                {/* Template Preview */}
                                <div className={`
                                  absolute inset-0 rounded-md p-2 text-xs
                                  ${template.category === 'Tech & Engineering' ? 'bg-gradient-to-br from-white to-blue-50' : ''}
                                  ${template.category === 'Creative & Design' ? 'bg-gradient-to-br from-purple-50 to-white' : ''}
                                  ${template.category === 'Corporate & Business' ? 'bg-gradient-to-br from-gray-50 to-white' : ''}
                                  ${template.category === 'Academic & Research' ? 'bg-gradient-to-br from-green-50 to-white' : ''}
                                `}>
                                  {/* Header bar */}
                                  <div className={`
                                    h-1 rounded mb-2
                                    ${template.category === 'Tech & Engineering' ? 'bg-primary' : ''}
                                    ${template.category === 'Creative & Design' ? 'bg-purple-500' : ''}
                                    ${template.category === 'Corporate & Business' ? 'bg-gray-600' : ''}
                                    ${template.category === 'Academic & Research' ? 'bg-green-500' : ''}
                                  `} />
                                  
                                  {/* Content lines */}
                                  <div className="space-y-1">
                                    <div className="h-0.5 bg-gray-300 rounded w-3/4" />
                                    <div className="h-0.5 bg-gray-300 rounded w-1/2" />
                                    <div className="h-0.5 bg-gray-300 rounded w-2/3" />
                                  </div>
                                </div>
                                
                                {/* Selected indicator */}
                                {selectedTemplate.id === template.id && (
                                  <div className="absolute top-1 right-1">
                                    <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                      <Check className="h-3 w-3 text-white" />
                                    </div>
                                  </div>
                                )}
                                
                                {/* Pro badge */}
                                {template.isPro && (
                                  <div className="absolute top-1 left-1">
                                    <Badge variant="secondary" className="text-xs px-1.5 py-0.5">
                                      <Crown className="h-2.5 w-2.5 mr-1" />
                                      Pro
                                    </Badge>
                                  </div>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                          
                          {/* Template info */}
                          <div className="mt-2 text-center">
                            <div className="text-xs font-medium text-foreground">{template.name}</div>
                            <div className="text-xs text-muted-foreground">{template.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Versions Tab */}
        <TabsContent value="versions" className="flex-1 mt-0">
          <ScrollArea className="h-full custom-scrollbar">
            <div className="p-4 space-y-4">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Resume Versions
              </div>
              
              {/* Resume selector */}
              <div className="space-y-2">
                <div className="text-sm font-medium text-foreground">Current Resume</div>
                <div className="space-y-2">
                  {resumes.map((resume) => (
                    <Card
                      key={resume.id}
                      className={`
                        cursor-pointer transition-all duration-200 hover:elevation-1
                        ${currentResume?.id === resume.id ? 'border-primary' : 'border'}
                      `}
                      onClick={() => onResumeChange(resume)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">{resume.title}</div>
                            <div className="text-xs text-muted-foreground">
                              {new Date(resume.updatedAt || '').toLocaleDateString()}
                            </div>
                          </div>
                          {currentResume?.id === resume.id && (
                            <Check className="h-4 w-4 text-primary" />
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
              
              {/* Create new resume */}
              <Button
                onClick={onCreateNew}
                variant="outline"
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create New Resume
              </Button>
              
              {/* Version history */}
              <Button
                onClick={onVersions}
                variant="outline"
                className="w-full"
              >
                <History className="h-4 w-4 mr-2" />
                View Version History
              </Button>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>

      {/* AI Tools Section */}
      <div className="border-t p-4 space-y-3">
        <Button
          onClick={onOptimize}
          className="w-full ripple"
        >
          <Sparkles className="h-4 w-4 mr-2" />
          Optimize Resume
        </Button>
        
        <Button
          onClick={onCoverLetter}
          variant="outline"
          className="w-full"
        >
          <FileText className="h-4 w-4 mr-2" />
          Generate Cover Letter
        </Button>
        
        <Button
          onClick={onExportToPrepPair}
          variant="outline"
          className="w-full"
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          Export to PrepPair.me
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-80 bg-white border-r flex-col elevation-1">
        <SidebarContent />
      </aside>

      {/* Mobile Sheet */}
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="left" className="w-80 p-0">
          <SheetHeader className="sr-only">
            <SheetTitle>Resume Templates</SheetTitle>
          </SheetHeader>
          <SidebarContent />
        </SheetContent>
      </Sheet>
    </>
  );
}
