import React from "react";

interface CurlyBraceIconProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
}

export function CurlyBraceIcon({ className = "", size = "md" }: CurlyBraceIconProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-6 h-6", 
    lg: "w-8 h-8",
    xl: "w-12 h-12"
  };

  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={`${sizeClasses[size]} ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8 3C6.89543 3 6 3.89543 6 5V8C6 9.10457 5.10457 10 4 10H3C2.44772 10 2 10.4477 2 11V13C2 13.5523 2.44772 14 3 14H4C5.10457 14 6 14.8954 6 16V19C6 20.1046 6.89543 21 8 21H9C9.55228 21 10 20.5523 10 20C10 19.4477 9.55228 19 9 19H8V16C8 14.3431 6.65685 13 5 13H4V11H5C6.65685 11 8 9.65685 8 8V5H9C9.55228 5 10 4.55228 10 4C10 3.44772 9.55228 3 9 3H8Z"
        fillRule="evenodd"
        clipRule="evenodd"
      />
      <path
        d="M16 3C17.1046 3 18 3.89543 18 5V8C18 9.10457 18.8954 10 20 10H21C21.5523 10 22 10.4477 22 11V13C22 13.5523 21.5523 14 21 14H20C18.8954 14 18 14.8954 18 16V19C18 20.1046 17.1046 21 16 21H15C14.4477 21 14 20.5523 14 20C14 19.4477 14.4477 19 15 19H16V16C16 14.3431 17.3431 13 19 13H20V11H19C17.3431 11 16 9.65685 16 8V5H15C14.4477 5 14 4.55228 14 4C14 3.44772 14.4477 3 15 3H16Z"
        fillRule="evenodd"
        clipRule="evenodd"
      />
    </svg>
  );
}