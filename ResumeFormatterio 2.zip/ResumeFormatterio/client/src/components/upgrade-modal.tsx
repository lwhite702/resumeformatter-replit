import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Crown, 
  Check, 
  Sparkles,
  FileText,
  Download,
  History,
  Zap,
  X
} from "lucide-react";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  userPlan: string;
}

export default function UpgradeModal({ isOpen, onClose, userPlan }: UpgradeModalProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleUpgrade = async () => {
    if (userPlan === 'pro') {
      // Redirect to billing portal for existing Pro users
      window.open('https://billing.stripe.com/p/login/test_000000000000', '_blank');
      return;
    }

    setIsLoading(true);
    
    try {
      // Create subscription
      const response = await fetch('/api/get-or-create-subscription', {
        method: 'POST',
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to create subscription');
      }
      
      const { clientSecret } = await response.json();
      
      // Redirect to Stripe Checkout or handle payment
      // For now, simulate success
      setTimeout(() => {
        setIsLoading(false);
        window.location.reload(); // Refresh to update user plan
      }, 2000);
      
    } catch (error) {
      console.error('Upgrade failed:', error);
      setIsLoading(false);
    }
  };

  const features = {
    free: [
      'Markdown editor with live preview',
      '3 professional templates',
      'PDF export',
      '2 AI optimization credits',
      'Basic version control'
    ],
    pro: [
      'Everything in Free',
      '12+ premium templates',
      'DOCX & HTML export',
      'Unlimited AI optimization',
      'AI cover letter generation',
      'Advanced version control',
      'Priority support',
      'No watermarks'
    ]
  };

  const benefits = [
    {
      icon: Sparkles,
      title: 'Unlimited AI Features',
      description: 'Get unlimited resume optimizations and cover letter generations'
    },
    {
      icon: FileText,
      title: 'Premium Templates',
      description: 'Access 12+ professionally designed templates for every industry'
    },
    {
      icon: Download,
      title: 'All Export Formats',
      description: 'Export in PDF, DOCX, and HTML formats'
    },
    {
      icon: History,
      title: 'Advanced Versioning',
      description: 'Unlimited snapshots and detailed version comparisons'
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Crown className="h-5 w-5 text-primary" />
              <span>{userPlan === 'pro' ? 'Manage Subscription' : 'Upgrade to Pro'}</span>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {userPlan === 'pro' ? (
          /* Pro User - Subscription Management */
          <div className="space-y-6">
            <Card className="border-primary bg-primary/5">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <Crown className="h-12 w-12 text-primary mx-auto" />
                  <h3 className="text-xl font-semibold">You're a Pro Member!</h3>
                  <p className="text-muted-foreground">
                    You have access to all premium features and unlimited AI tools.
                  </p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    <div className="text-center">
                      <Sparkles className="h-8 w-8 text-primary mx-auto mb-2" />
                      <div className="text-sm font-medium">Unlimited</div>
                      <div className="text-xs text-muted-foreground">AI Features</div>
                    </div>
                    <div className="text-center">
                      <FileText className="h-8 w-8 text-primary mx-auto mb-2" />
                      <div className="text-sm font-medium">12+</div>
                      <div className="text-xs text-muted-foreground">Templates</div>
                    </div>
                    <div className="text-center">
                      <Download className="h-8 w-8 text-primary mx-auto mb-2" />
                      <div className="text-sm font-medium">All</div>
                      <div className="text-xs text-muted-foreground">Export Formats</div>
                    </div>
                    <div className="text-center">
                      <Zap className="h-8 w-8 text-primary mx-auto mb-2" />
                      <div className="text-sm font-medium">Priority</div>
                      <div className="text-xs text-muted-foreground">Support</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-center space-x-4">
              <Button onClick={handleUpgrade} variant="outline">
                Manage Billing
              </Button>
              <Button onClick={onClose}>
                Continue Using Pro
              </Button>
            </div>
          </div>
        ) : (
          /* Free User - Upgrade Flow */
          <div className="space-y-6">
            {/* Hero Section */}
            <div className="text-center space-y-4">
              <Crown className="h-16 w-16 text-primary mx-auto" />
              <h2 className="text-2xl font-bold">Unlock Your Career Potential</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Get unlimited access to AI-powered resume optimization, premium templates, 
                and advanced export options. Take your job search to the next level.
              </p>
            </div>

            {/* Benefits Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {benefits.map((benefit, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <benefit.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">{benefit.title}</h4>
                        <p className="text-sm text-muted-foreground">{benefit.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pricing Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Free Plan */}
              <Card>
                <CardHeader>
                  <div className="text-center">
                    <h3 className="text-xl font-semibold">Free</h3>
                    <div className="text-3xl font-bold mt-2">$0</div>
                    <p className="text-muted-foreground">Current plan</p>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {features.free.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Pro Plan */}
              <Card className="border-primary relative">
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <Badge className="bg-primary text-white">Most Popular</Badge>
                </div>
                
                <CardHeader>
                  <div className="text-center">
                    <h3 className="text-xl font-semibold">Pro</h3>
                    <div className="text-3xl font-bold text-primary mt-2">$9.99</div>
                    <p className="text-muted-foreground">per month</p>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {features.pro.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Social Proof */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex justify-center space-x-8">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">10,000+</div>
                      <div className="text-sm text-muted-foreground">Resumes Created</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">95%</div>
                      <div className="text-sm text-muted-foreground">Success Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">4.9/5</div>
                      <div className="text-sm text-muted-foreground">User Rating</div>
                    </div>
                  </div>
                  
                  <blockquote className="text-sm italic text-muted-foreground">
                    "ResumeFormatter.io helped me land my dream job at Google. The AI optimization was a game-changer!"
                  </blockquote>
                </div>
              </CardContent>
            </Card>

            {/* CTA */}
            <div className="text-center space-y-4">
              <Button 
                onClick={handleUpgrade}
                size="lg"
                className="w-full sm:w-auto px-8"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Setting up your Pro account...
                  </>
                ) : (
                  <>
                    <Crown className="h-5 w-5 mr-2" />
                    Start Pro Trial - $9.99/month
                  </>
                )}
              </Button>
              
              <p className="text-xs text-muted-foreground">
                Cancel anytime. No hidden fees. 7-day free trial.
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
