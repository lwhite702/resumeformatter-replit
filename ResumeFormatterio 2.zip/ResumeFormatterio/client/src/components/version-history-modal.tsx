import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  History, 
  Save, 
  RotateCcw, 
  GitCompare,
  Bookmark,
  Star,
  Clock,
  FileText,
  X
} from "lucide-react";
import { ResumeVersion } from "@/types/resume";
import { formatDistanceToNow } from "date-fns";

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeId: number;
  currentContent: string;
  onRestore: (content: string) => void;
}

export default function VersionHistoryModal({ 
  isOpen, 
  onClose, 
  resumeId, 
  currentContent,
  onRestore
}: VersionHistoryModalProps) {
  const [versionName, setVersionName] = useState("");
  const [selectedVersion, setSelectedVersion] = useState<ResumeVersion | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch versions
  const { data: versions = [], isLoading } = useQuery<ResumeVersion[]>({
    queryKey: [`/api/resumes/${resumeId}/versions`],
    enabled: isOpen && resumeId > 0,
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  // Save version mutation
  const saveVersionMutation = useMutation({
    mutationFn: async () => {
      if (!versionName.trim()) {
        throw new Error("Version name is required");
      }
      
      const response = await apiRequest("POST", `/api/resumes/${resumeId}/versions`, {
        name: versionName.trim(),
        content: currentContent,
        description: `Saved on ${new Date().toLocaleDateString()}`,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/resumes/${resumeId}/versions`] });
      setVersionName("");
      toast({
        title: "Version Saved",
        description: "Your resume version has been saved successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Save Failed",
        description: (error as Error).message || "Failed to save version. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveVersion = () => {
    saveVersionMutation.mutate();
  };

  const handleRestoreVersion = (version: ResumeVersion) => {
    onRestore(version.content);
    toast({
      title: "Version Restored",
      description: `Restored version "${version.name}" successfully.`,
    });
    onClose();
  };

  const handleCompareVersion = (version: ResumeVersion) => {
    setSelectedVersion(version);
    setShowComparison(true);
  };

  const getVersionIcon = (index: number) => {
    if (index === 0) return <Star className="h-4 w-4 text-yellow-500" />;
    return <Bookmark className="h-4 w-4 text-primary" />;
  };

  const renderComparison = () => {
    if (!selectedVersion) return null;

    const currentLines = currentContent.split('\n');
    const versionLines = selectedVersion.content.split('\n');
    const maxLines = Math.max(currentLines.length, versionLines.length);

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Comparing Versions</h3>
          <Button variant="outline" onClick={() => setShowComparison(false)}>
            Back to List
          </Button>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-medium mb-2 text-green-600">Current Version</h4>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 max-h-64 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-xs">{currentContent}</pre>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-2 text-blue-600">{selectedVersion.name}</h4>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 max-h-64 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-xs">{selectedVersion.content}</pre>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-2">
          <Button
            variant="outline"
            onClick={() => handleRestoreVersion(selectedVersion)}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Restore This Version
          </Button>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center space-x-2">
              <History className="h-5 w-5 text-primary" />
              <span>Resume Versions</span>
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[70vh] custom-scrollbar">
          {showComparison ? renderComparison() : (
            <div className="space-y-6">
              {/* Save Current Version */}
              <Card className="bg-muted/50">
                <CardContent className="pt-6">
                  <h3 className="font-medium mb-3">Save Current Version</h3>
                  <div className="flex items-center space-x-3">
                    <Input
                      value={versionName}
                      onChange={(e) => setVersionName(e.target.value)}
                      placeholder="Version name (e.g., 'Google Application')"
                      className="flex-1"
                    />
                    <Button 
                      onClick={handleSaveVersion}
                      disabled={!versionName.trim() || saveVersionMutation.isPending}
                    >
                      {saveVersionMutation.isPending ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save Snapshot
                        </>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Save a snapshot of your current resume to compare and restore later.
                  </p>
                </CardContent>
              </Card>

              {/* Version History */}
              <div>
                <h3 className="font-medium mb-4">Saved Versions</h3>
                
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
                  </div>
                ) : versions.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center py-6">
                        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h4 className="font-medium mb-2">No Saved Versions</h4>
                        <p className="text-sm text-muted-foreground">
                          Save your first version above to start tracking changes.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-3">
                    {versions.map((version, index) => (
                      <Card key={version.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                {getVersionIcon(index)}
                              </div>
                              <div>
                                <h4 className="font-medium text-foreground">{version.name}</h4>
                                <p className="text-sm text-muted-foreground">
                                  Saved {formatDistanceToNow(new Date(version.createdAt), { addSuffix: true })}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleCompareVersion(version)}
                              >
                                <GitCompare className="h-3 w-3 mr-1" />
                                Compare
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRestoreVersion(version)}
                              >
                                <RotateCcw className="h-3 w-3 mr-1" />
                                Restore
                              </Button>
                            </div>
                          </div>
                          
                          {version.description && (
                            <p className="text-sm text-muted-foreground">
                              {version.description}
                            </p>
                          )}
                          
                          {/* Version preview */}
                          <div className="mt-3 p-3 bg-muted/50 rounded-lg">
                            <p className="text-xs text-muted-foreground line-clamp-2">
                              {version.content.split('\n').slice(0, 3).join(' ').substring(0, 150)}...
                            </p>
                          </div>
                          
                          {index === 0 && (
                            <Badge variant="secondary" className="mt-2">
                              Latest
                            </Badge>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        {!showComparison && (
          <div className="flex justify-end pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
