import { useUser } from "@clerk/clerk-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useEffect } from "react";

export function useAuth() {
  const { user: clerkUser, isLoaded, isSignedIn } = useUser();
  const queryClient = useQueryClient();
  
  // Sync user with backend when Clerk user is available
  const syncUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      return apiRequest('/api/users', {
        method: 'POST',
        body: userData,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
  });

  // Automatically sync user when Clerk user loads
  useEffect(() => {
    if (clerkUser && isLoaded && isSignedIn) {
      const userData = {
        userId: clerkUser.id,
        email: clerkUser.primaryEmailAddress?.emailAddress || null,
        firstName: clerkUser.firstName,
        lastName: clerkUser.lastName,
        profileImageUrl: clerkUser.imageUrl,
      };
      
      syncUserMutation.mutate(userData);
    }
  }, [clerkUser?.id, isLoaded, isSignedIn]);

  // Transform Clerk user to match existing app structure
  const user = clerkUser ? {
    id: clerkUser.id,
    email: clerkUser.primaryEmailAddress?.emailAddress,
    firstName: clerkUser.firstName,
    lastName: clerkUser.lastName,
    profileImageUrl: clerkUser.imageUrl,
    createdAt: clerkUser.createdAt,
    updatedAt: clerkUser.updatedAt,
  } : null;

  return {
    user,
    isLoading: !isLoaded,
    isAuthenticated: !!isSignedIn && !!user,
  };
}
