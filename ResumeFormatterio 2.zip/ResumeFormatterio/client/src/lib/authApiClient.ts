import { useAuth } from "@clerk/clerk-react";

// Authenticated API client that automatically includes session tokens
export async function authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
  try {
    // Get session token from Clerk
    const { getToken } = useAuth();
    const token = await getToken();

    // Prepare headers with authentication
    const headers = new Headers(options.headers);
    
    // Add required headers for Clerk authentication
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    
    headers.set('Accept', 'application/json');
    headers.set('Content-Type', 'application/json');

    // Make the authenticated request
    const response = await fetch(url, {
      ...options,
      headers,
    });

    return response;
  } catch (error) {
    console.error('Authenticated fetch error:', error);
    throw error;
  }
}

// Hook for making authenticated API requests
export function useAuthenticatedApi() {
  const { getToken, isSignedIn } = useAuth();

  const apiCall = async (url: string, options: RequestInit = {}) => {
    if (!isSignedIn) {
      throw new Error('User not authenticated');
    }

    try {
      const token = await getToken();
      
      const headers = new Headers(options.headers);
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      headers.set('Accept', 'application/json');
      headers.set('Content-Type', 'application/json');

      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('401: Unauthorized - Please log in again');
        }
        throw new Error(`${response.status}: ${response.statusText}`);
      }

      return response.json();
    } catch (error) {
      console.error('API call error:', error);
      throw error;
    }
  };

  return { apiCall, isSignedIn };
}