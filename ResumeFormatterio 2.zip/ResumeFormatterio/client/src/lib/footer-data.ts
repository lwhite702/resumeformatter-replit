import { FileText } from "lucide-react";

export const getFooterData = () => ({
  logo: null,
  brandName: "ResumeFormatter.io",
  socialLinks: [],
  mainLinks: [
    { href: "/features", label: "Features" },
    { href: "/pricing", label: "Pricing" },
    { href: "/templates", label: "Templates" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" }
  ],
  legalLinks: [
    { href: "/legal", label: "Privacy Policy" },
    { href: "/legal", label: "Terms of Service" },
    { href: "/legal", label: "Cookie Policy" },
    { href: "/legal", label: "Data Retention" }
  ],
  copyright: {
    text: "© 2024 ResumeFormatter.io. All rights reserved.",
    license: "A Wrelik Brands, LLC product."
  }
});