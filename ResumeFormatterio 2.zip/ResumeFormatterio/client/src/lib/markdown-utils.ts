import { ParsedResume } from "@/types/resume";

export function parseMarkdownResume(content: string): ParsedResume {
  const lines = content.split('\n');
  const resume: ParsedResume = {};
  let currentSection = '';
  let currentExperience: any = null;
  let currentEducation: any = null;
  let currentProject: any = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Parse headers
    if (line.startsWith('# ')) {
      resume.name = line.substring(2).trim();
    } else if (line.startsWith('## ')) {
      const header = line.substring(3).trim();
      if (!resume.title && i < 5) { // Title is usually the first h2
        resume.title = header;
      }
      currentSection = header.toLowerCase();
    }
    
    // Parse contact information
    if (line.includes('**Email:**')) {
      resume.email = extractValue(line);
    } else if (line.includes('**Phone:**')) {
      resume.phone = extractValue(line);
    } else if (line.includes('**Location:**')) {
      resume.location = extractValue(line);
    } else if (line.includes('**LinkedIn:**')) {
      resume.linkedin = extractValue(line);
    } else if (line.includes('**GitHub:**')) {
      resume.github = extractValue(line);
    }
    
    // Parse sections
    if (currentSection === 'summary' && line && !line.startsWith('#')) {
      resume.summary = (resume.summary || '') + line + ' ';
    }
    
    // Parse experience
    if (currentSection === 'experience') {
      if (line.startsWith('### **')) {
        if (currentExperience) {
          if (!resume.experience) resume.experience = [];
          resume.experience.push(currentExperience);
        }
        
        const match = line.match(/### \*\*(.*?)\*\* \| (.*?) \| (.*?)$/);
        if (match) {
          currentExperience = {
            title: match[1],
            company: match[2],
            duration: match[3],
            description: [],
          };
        }
      } else if (line.startsWith('- ') && currentExperience) {
        currentExperience.description.push(line.substring(2));
      } else if (line.includes('**Technologies:**') && currentExperience) {
        currentExperience.technologies = extractValue(line);
      }
    }
    
    // Parse education
    if (currentSection === 'education') {
      if (line.startsWith('### **')) {
        if (currentEducation) {
          if (!resume.education) resume.education = [];
          resume.education.push(currentEducation);
        }
        
        const degree = line.substring(4, line.lastIndexOf('**'));
        currentEducation = { degree, institution: '', year: '' };
      } else if (currentEducation && line && !line.startsWith('#')) {
        const parts = line.split(' | ');
        if (parts.length >= 2) {
          currentEducation.institution = parts[0];
          currentEducation.year = parts[1];
          if (parts.length > 2 && parts[2].includes('GPA')) {
            currentEducation.gpa = parts[2];
          }
        }
      }
    }
    
    // Parse skills
    if (currentSection === 'skills') {
      if (line.startsWith('**') && line.includes(':**')) {
        const category = line.substring(2, line.indexOf(':**'));
        const skills = line.substring(line.indexOf(':**') + 3).trim();
        if (!resume.skills) resume.skills = {};
        resume.skills[category] = skills;
      }
    }
    
    // Parse projects
    if (currentSection === 'projects') {
      if (line.startsWith('### **')) {
        if (currentProject) {
          if (!resume.projects) resume.projects = [];
          resume.projects.push(currentProject);
        }
        
        const name = line.substring(4, line.lastIndexOf('**'));
        currentProject = { name, description: '', technologies: '' };
      } else if (line.startsWith('- ') && currentProject) {
        currentProject.description += line.substring(2) + ' ';
      } else if (line.includes('**Technologies:**') && currentProject) {
        currentProject.technologies = extractValue(line);
      } else if (line.includes('**Link:**') && currentProject) {
        currentProject.link = extractValue(line);
      }
    }
  }
  
  // Add final items
  if (currentExperience) {
    if (!resume.experience) resume.experience = [];
    resume.experience.push(currentExperience);
  }
  if (currentEducation) {
    if (!resume.education) resume.education = [];
    resume.education.push(currentEducation);
  }
  if (currentProject) {
    if (!resume.projects) resume.projects = [];
    resume.projects.push(currentProject);
  }
  
  // Clean up
  if (resume.summary) {
    resume.summary = resume.summary.trim();
  }
  
  return resume;
}

function extractValue(line: string): string {
  const colonIndex = line.indexOf(':');
  if (colonIndex === -1) return '';
  return line.substring(colonIndex + 1).trim().replace(/\*\*/g, '');
}

export function formatMarkdownFromParsed(resume: ParsedResume): string {
  let markdown = '';
  
  // Name and title
  if (resume.name) {
    markdown += `# ${resume.name}\n`;
  }
  if (resume.title) {
    markdown += `## ${resume.title}\n\n`;
  }
  
  // Contact information
  const contacts = [];
  if (resume.email) contacts.push(`**Email:** ${resume.email}`);
  if (resume.phone) contacts.push(`**Phone:** ${resume.phone}`);
  if (resume.location) contacts.push(`**Location:** ${resume.location}`);
  if (resume.linkedin) contacts.push(`**LinkedIn:** ${resume.linkedin}`);
  if (resume.github) contacts.push(`**GitHub:** ${resume.github}`);
  
  if (contacts.length > 0) {
    markdown += contacts.join('  \n') + '\n\n---\n\n';
  }
  
  // Summary
  if (resume.summary) {
    markdown += `## Summary\n\n${resume.summary}\n\n---\n\n`;
  }
  
  // Experience
  if (resume.experience && resume.experience.length > 0) {
    markdown += `## Experience\n\n`;
    resume.experience.forEach(exp => {
      markdown += `### **${exp.title}** | ${exp.company} | ${exp.duration}\n`;
      if (exp.description && exp.description.length > 0) {
        exp.description.forEach(desc => {
          markdown += `- ${desc}\n`;
        });
      }
      if (exp.technologies) {
        markdown += `- **Technologies:** ${exp.technologies}\n`;
      }
      markdown += '\n';
    });
    markdown += '---\n\n';
  }
  
  // Skills
  if (resume.skills && Object.keys(resume.skills).length > 0) {
    markdown += `## Skills\n\n`;
    Object.entries(resume.skills).forEach(([category, skills]) => {
      markdown += `**${category}:** ${skills}  \n`;
    });
    markdown += '\n---\n\n';
  }
  
  // Education
  if (resume.education && resume.education.length > 0) {
    markdown += `## Education\n\n`;
    resume.education.forEach(edu => {
      markdown += `### **${edu.degree}**\n`;
      markdown += `${edu.institution} | ${edu.year}`;
      if (edu.gpa) {
        markdown += ` | ${edu.gpa}`;
      }
      markdown += '\n\n';
    });
    markdown += '---\n\n';
  }
  
  // Projects
  if (resume.projects && resume.projects.length > 0) {
    markdown += `## Projects\n\n`;
    resume.projects.forEach(project => {
      markdown += `### **${project.name}**\n`;
      if (project.description) {
        markdown += `- ${project.description.trim()}\n`;
      }
      if (project.technologies) {
        markdown += `- **Technologies:** ${project.technologies}\n`;
      }
      if (project.link) {
        markdown += `- **Link:** ${project.link}\n`;
      }
      markdown += '\n';
    });
  }
  
  return markdown;
}

export function convertMarkdownToHTML(content: string): string {
  return content
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/gim, '<em>$1</em>')
    .replace(/^\- (.*$)/gim, '<li>$1</li>')
    .replace(/^---$/gim, '<hr>')
    .replace(/\n/gim, '<br>');
}

export function calculateAtsScore(content: string): number {
  let score = 50; // Base score
  
  // Check for contact information
  if (content.includes('@')) score += 5; // Email
  if (content.match(/\(\d{3}\)/)) score += 5; // Phone
  if (content.toLowerCase().includes('linkedin')) score += 5;
  
  // Check for sections
  if (content.toLowerCase().includes('## experience')) score += 10;
  if (content.toLowerCase().includes('## education')) score += 5;
  if (content.toLowerCase().includes('## skills')) score += 10;
  if (content.toLowerCase().includes('## summary')) score += 5;
  
  // Check for quantified achievements
  const numberMatches = content.match(/\d+[%+]/g);
  if (numberMatches) score += Math.min(numberMatches.length * 2, 10);
  
  // Check for action verbs
  const actionVerbs = [
    'led', 'managed', 'developed', 'implemented', 'designed', 'created',
    'improved', 'increased', 'reduced', 'optimized', 'delivered', 'built'
  ];
  const actionVerbCount = actionVerbs.filter(verb => 
    content.toLowerCase().includes(verb)
  ).length;
  score += Math.min(actionVerbCount, 10);
  
  return Math.min(score, 100);
}
