// Marketing metadata and branding constants for ResumeFormatter.io

export const SOCIAL_ALT = "Create clean, modern resumes with ResumeFormatter.io — built for tech-savvy professionals.";

export const META_DESCRIPTIONS = [
  "Markdown-powered resumes for developers and creatives.",
  "ATS-friendly, beautiful resume templates — no design skills required."
] as const;

// Brand messaging
export const BRAND_TAGLINES = {
  primary: "Beautiful resumes. Markdown simple.",
  secondary: "Professional resumes made simple with Markdown",
  developer: "Developer-ready. Recruiter-approved.",
  ats: "ATS-friendly, beautiful resume templates"
} as const;

// SEO and social sharing
export const SEO_CONSTANTS = {
  siteName: "ResumeFormatter.io",
  siteUrl: "https://resumeformatter.io",
  twitterHandle: "@resumeformatter",
  defaultTitle: "ResumeFormatter.io - Professional Resume Builder",
  titleSuffix: " | ResumeFormatter.io"
} as const;

// Open Graph defaults
export const OG_DEFAULTS = {
  type: "website",
  locale: "en_US",
  image: "/og-image.png",
  imageAlt: SOCIAL_ALT,
  imageWidth: 1200,
  imageHeight: 630
} as const;

// Twitter Card defaults
export const TWITTER_DEFAULTS = {
  card: "summary_large_image",
  site: SEO_CONSTANTS.twitterHandle,
  creator: SEO_CONSTANTS.twitterHandle
} as const;

// Utility functions
export function getRandomMetaDescription(): string {
  const randomIndex = Math.floor(Math.random() * META_DESCRIPTIONS.length);
  return META_DESCRIPTIONS[randomIndex];
}

export function buildPageTitle(pageTitle?: string): string {
  return pageTitle 
    ? `${pageTitle}${SEO_CONSTANTS.titleSuffix}`
    : SEO_CONSTANTS.defaultTitle;
}

export function buildCanonicalUrl(path: string = ""): string {
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  return `${SEO_CONSTANTS.siteUrl}${cleanPath}`;
}