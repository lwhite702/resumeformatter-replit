import { Template } from "@/types/resume";

export const resumeTemplates: Template[] = [
  // Tech & Engineering - Free Templates
  {
    id: 'modern-tech',
    name: 'Modern Tech',
    description: 'Clean borders, tech-focused layout',
    category: 'Tech & Engineering',
    isPro: false,
    preview: '/api/template-preview/modern-tech.png'
  },
  {
    id: 'minimal-dev',
    name: 'Minimal Dev',
    description: 'Typography-focused, no borders',
    category: 'Tech & Engineering',
    isPro: false,
    preview: '/api/template-preview/minimal-dev.png'
  },
  {
    id: 'classic-professional',
    name: 'Classic Professional',
    description: 'Traditional layout suitable for all industries',
    category: 'Professional',
    isPro: false,
    preview: '/api/template-preview/classic-professional.png'
  },
  
  // Pro Templates
  {
    id: 'senior-engineer',
    name: 'Senior Engineer',
    description: 'Executive style with leadership sections',
    category: 'Tech & Engineering',
    isPro: true,
    preview: '/api/template-preview/senior-engineer.png'
  },
  {
    id: 'full-stack',
    name: 'Full Stack',
    description: 'Two-column layout for diverse skills',
    category: 'Tech & Engineering',
    isPro: true,
    preview: '/api/template-preview/full-stack.png'
  },

  // Creative & Design
  {
    id: 'creative-portfolio',
    name: 'Creative Portfolio',
    description: 'Colorful headers with portfolio emphasis',
    category: 'Creative & Design',
    isPro: false,
    preview: '/api/template-preview/creative-portfolio.png'
  },
  {
    id: 'design-focused',
    name: 'Design Focused',
    description: 'Visual hierarchy with design metrics',
    category: 'Creative & Design',
    isPro: true,
    preview: '/api/template-preview/design-focused.png'
  },
  {
    id: 'ux-designer',
    name: 'UX Designer',
    description: 'User-centered layout with case studies',
    category: 'Creative & Design',
    isPro: true,
    preview: '/api/template-preview/ux-designer.png'
  },

  // Corporate & Business
  {
    id: 'executive',
    name: 'Executive',
    description: 'Professional layout for leadership roles',
    category: 'Corporate & Business',
    isPro: true,
    preview: '/api/template-preview/executive.png'
  },
  {
    id: 'consultant',
    name: 'Consultant',
    description: 'Results-focused with client impact',
    category: 'Corporate & Business',
    isPro: true,
    preview: '/api/template-preview/consultant.png'
  },
  {
    id: 'sales-professional',
    name: 'Sales Professional',
    description: 'Metrics-driven with achievements',
    category: 'Corporate & Business',
    isPro: true,
    preview: '/api/template-preview/sales-professional.png'
  },

  // Academic & Research
  {
    id: 'academic',
    name: 'Academic',
    description: 'Publications and research focused',
    category: 'Academic & Research',
    isPro: true,
    preview: '/api/template-preview/academic.png'
  },
  {
    id: 'researcher',
    name: 'Researcher',
    description: 'Scientific format with methodology',
    category: 'Academic & Research',
    isPro: true,
    preview: '/api/template-preview/researcher.png'
  }
];

export const templateCategories = [
  'Tech & Engineering',
  'Creative & Design', 
  'Corporate & Business',
  'Academic & Research'
];

export function getTemplatesByCategory(category: string): Template[] {
  return resumeTemplates.filter(template => template.category === category);
}

export function getFreeTemplates(): Template[] {
  return resumeTemplates.filter(template => !template.isPro);
}

export function getProTemplates(): Template[] {
  return resumeTemplates.filter(template => template.isPro);
}

export function getTemplate(id: string): Template | undefined {
  return resumeTemplates.find(template => template.id === id);
}

export function getDefaultTemplate(): Template {
  return resumeTemplates[0]; // modern-tech
}

export const sampleResumeContent = `# John Doe
## Senior Software Engineer

**Email:** john.doe@email.com  
**Phone:** (555) 123-4567  
**Location:** San Francisco, CA  
**LinkedIn:** linkedin.com/in/johndoe  
**GitHub:** github.com/johndoe

---

## Summary

Experienced full-stack software engineer with 8+ years developing scalable web applications. Proven track record of leading engineering teams and delivering high-impact products that serve millions of users. Expertise in React, Node.js, Python, and cloud architecture.

---

## Experience

### **Senior Software Engineer** | Google | 2021 - Present
- Led development of core user authentication system serving 100M+ users
- Architected microservices infrastructure reducing API response time by 40%
- Mentored 5 junior engineers and established code review best practices
- **Technologies:** React, TypeScript, Node.js, PostgreSQL, Kubernetes

### **Software Engineer** | Stripe | 2019 - 2021  
- Built payment processing features handling $2B+ in annual transactions
- Developed fraud detection algorithms reducing false positives by 25%
- Collaborated with product teams to deliver 15+ customer-facing features
- **Technologies:** Python, Django, Redis, AWS, React

### **Junior Software Engineer** | Airbnb | 2017 - 2019
- Implemented booking flow optimizations increasing conversion by 12%
- Built internal tools for customer support team used by 200+ agents
- Participated in on-call rotation maintaining 99.9% uptime SLA
- **Technologies:** Ruby on Rails, JavaScript, MySQL, ElasticSearch

---

## Skills

**Programming Languages:** JavaScript, TypeScript, Python, Java, Go  
**Frontend:** React, Vue.js, HTML5, CSS3, Sass, Tailwind CSS  
**Backend:** Node.js, Django, Ruby on Rails, Express.js  
**Databases:** PostgreSQL, MySQL, MongoDB, Redis  
**Cloud & DevOps:** AWS, Docker, Kubernetes, CI/CD, Terraform  
**Tools:** Git, Jira, Figma, Postman, DataDog

---

## Education

### **Bachelor of Science in Computer Science**
University of California, Berkeley | 2013 - 2017  
**GPA:** 3.8/4.0 | **Relevant Coursework:** Data Structures, Algorithms, Database Systems

---

## Projects

### **Open Source Contribution - React Query**
- Contributed 12 PRs to popular data fetching library with 25k+ GitHub stars
- Implemented TypeScript improvements and documentation updates
- **Link:** github.com/tannerlinsley/react-query

### **Personal Finance App**
- Built full-stack web application for expense tracking and budgeting
- Deployed on AWS with 1000+ active users and 4.8/5 App Store rating
- **Technologies:** React Native, Node.js, PostgreSQL, Stripe API
`;
