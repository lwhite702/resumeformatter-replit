import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";
import { 
  FileText, 
  Shield, 
  Settings, 
  Users, 
  BarChart3,
  Globe,
  Zap,
  Database,
  Code,
  ExternalLink
} from "lucide-react";

export default function AdminDocs() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    // Add noindex meta tag
    const metaNoIndex = document.createElement('meta');
    metaNoIndex.name = 'robots';
    metaNoIndex.content = 'noindex, nofollow';
    document.head.appendChild(metaNoIndex);

    return () => {
      // Cleanup
      const existingMeta = document.querySelector('meta[name="robots"]');
      if (existingMeta) {
        document.head.removeChild(existingMeta);
      }
    };
  }, []);

  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !user)) {
      toast({
        title: "Access Denied",
        description: "Admin documentation requires authentication.",
        variant: "destructive",
      });
      window.location.href = "/admin";
    }
  }, [isAuthenticated, isLoading, user, toast]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-8 h-8 text-red-600" />
          <h1 className="text-3xl font-bold">ResumeFormatter.io Knowledge File</h1>
          <Badge variant="destructive" className="text-xs">
            ADMIN ONLY
          </Badge>
        </div>
        <p className="text-muted-foreground">
          Comprehensive documentation for ResumeFormatter.io platform administration, features, and technical implementation.
        </p>
        <div className="text-xs text-red-600 mt-2">
          ⚠️ This documentation is not indexed by search engines and requires admin authentication.
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="pricing">Pricing</TabsTrigger>
          <TabsTrigger value="technical">Technical</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="admin">Admin</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Platform Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Product Description</h3>
                  <p className="text-sm text-muted-foreground">
                    ResumeFormatter.io is a Markdown-powered resume optimization platform with AI features, 
                    template management, and comprehensive admin system. The app's key differentiator is 
                    Markdown editing which makes it "simple, powerful, and quick" compared to traditional resume builders.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Key Statistics</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Launch Date:</span>
                      <span>June 2025</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mobile Performance:</span>
                      <span>94/100 Lighthouse Score</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Load Time:</span>
                      <span>1.8s average</span>
                    </div>
                    <div className="flex justify-between">
                      <span>API Response:</span>
                      <span>120ms average</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Architecture Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <Code className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                  <div className="font-semibold">Frontend</div>
                  <div className="text-sm text-muted-foreground">React + TypeScript</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <Database className="w-8 h-8 mx-auto mb-2 text-green-600" />
                  <div className="font-semibold">Backend</div>
                  <div className="text-sm text-muted-foreground">Node.js + Express</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <Settings className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                  <div className="font-semibold">Database</div>
                  <div className="text-sm text-muted-foreground">PostgreSQL</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Features Tab */}
        <TabsContent value="features" className="space-y-6">
          <Accordion type="multiple" className="space-y-4">
            <AccordionItem value="core-features">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Core Features
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Markdown Editor</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Real-time Markdown editing with live preview, syntax highlighting, and contextual toolbar.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Touch-optimized for mobile devices</div>
                      <div>• Auto-save functionality</div>
                      <div>• Version history tracking</div>
                      <div>• Import from PDF/DOCX/TXT</div>
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Template System</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Professional resume templates with real-time preview and customization options.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• 12+ professional templates</div>
                      <div>• ATS-optimized layouts</div>
                      <div>• Mobile-responsive design</div>
                      <div>• Custom branding (Pro)</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">QuickExport System</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Multi-format export with PDF, LinkedIn optimization, and JSON structured data.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• PDF export with ATS optimization</div>
                      <div>• LinkedIn profile content generation</div>
                      <div>• JSON structured data export</div>
                      <div>• Batch export capabilities</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ai-features">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  AI-Powered Features
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Resume Optimization</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      AI-powered analysis and optimization suggestions for better ATS compatibility.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• ATS compatibility scoring</div>
                      <div>• Keyword optimization</div>
                      <div>• Content improvement suggestions</div>
                      <div>• Industry-specific recommendations</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Cover Letter Generation</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Automated cover letter creation based on resume content and job descriptions.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Job-specific customization</div>
                      <div>• Professional tone optimization</div>
                      <div>• Multiple format options</div>
                      <div>• Integration with resume data</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="ux-features">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  User Experience Features
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Demo Mode</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Try-before-you-buy experience allowing users to explore features without registration.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Full editor functionality</div>
                      <div>• Template preview</div>
                      <div>• Feature demonstrations</div>
                      <div>• Seamless upgrade flow</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Contextual Help</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Intelligent tooltips and guidance system that adapts to user context and content.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Content-aware suggestions</div>
                      <div>• Interactive dock component</div>
                      <div>• Progressive feature disclosure</div>
                      <div>• Mobile-optimized help system</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </TabsContent>

        {/* Pricing Tab */}
        <TabsContent value="pricing" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Free Plan</CardTitle>
                <div className="text-2xl font-bold">$0/month</div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Markdown editor with live preview</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>3 professional templates</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>PDF export with watermark</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>JSON structured data export</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Basic AI optimization</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pro Plan</CardTitle>
                <div className="text-2xl font-bold">$9.99/month</div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>All Free features</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>12+ premium templates</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>Watermark-free PDF export</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>DOCX and HTML export</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>LinkedIn content optimization</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>Advanced AI features</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>AutoApply integration</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Stripe Integration Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">Payment Processing</h4>
                    <div className="text-sm space-y-1">
                      <div>• Secure Stripe checkout integration</div>
                      <div>• Subscription management</div>
                      <div>• Automatic billing cycles</div>
                      <div>• Prorated upgrades/downgrades</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Webhook Handling</h4>
                    <div className="text-sm space-y-1">
                      <div>• Payment success notifications</div>
                      <div>• Subscription status updates</div>
                      <div>• Failed payment recovery</div>
                      <div>• Cancellation processing</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Technical Tab */}
        <TabsContent value="technical" className="space-y-6">
          <Accordion type="multiple" className="space-y-4">
            <AccordionItem value="tech-stack">
              <AccordionTrigger>Technology Stack</AccordionTrigger>
              <AccordionContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-2">Frontend</h4>
                    <div className="text-sm space-y-1">
                      <div>• React 18 with TypeScript</div>
                      <div>• Vite build system</div>
                      <div>• Tailwind CSS + Shadcn UI</div>
                      <div>• TanStack Query for state management</div>
                      <div>• Wouter for routing</div>
                      <div>• React Hook Form for forms</div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Backend</h4>
                    <div className="text-sm space-y-1">
                      <div>• Node.js with Express</div>
                      <div>• TypeScript throughout</div>
                      <div>• Drizzle ORM with PostgreSQL</div>
                      <div>• Replit OAuth integration</div>
                      <div>• Stripe payment processing</div>
                      <div>• OpenAI API integration</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="database-schema">
              <AccordionTrigger>Database Schema</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Core Tables</h4>
                    <div className="text-sm space-y-1">
                      <div>• <code>users</code> - User accounts and profiles</div>
                      <div>• <code>resumes</code> - Resume documents and metadata</div>
                      <div>• <code>templates</code> - Template definitions</div>
                      <div>• <code>resume_versions</code> - Version history</div>
                      <div>• <code>sessions</code> - Authentication sessions</div>
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Integration Tables</h4>
                    <div className="text-sm space-y-1">
                      <div>• <code>cached_posts</code> - WordPress blog cache</div>
                      <div>• <code>newsletter_subscribers</code> - Beehiiv integration</div>
                      <div>• <code>export_history</code> - Export tracking</div>
                      <div>• <code>api_integrations</code> - Third-party connections</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="api-endpoints">
              <AccordionTrigger>API Endpoints</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Authentication</h4>
                    <div className="text-sm space-y-1">
                      <div>• <code>GET /api/auth/user</code> - Current user info</div>
                      <div>• <code>GET /api/login</code> - OAuth login</div>
                      <div>• <code>GET /api/logout</code> - Logout</div>
                      <div>• <code>GET /api/callback</code> - OAuth callback</div>
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Resume Operations</h4>
                    <div className="text-sm space-y-1">
                      <div>• <code>GET /api/resumes</code> - List user resumes</div>
                      <div>• <code>POST /api/resumes</code> - Create resume</div>
                      <div>• <code>PUT /api/resumes/:id</code> - Update resume</div>
                      <div>• <code>DELETE /api/resumes/:id</code> - Delete resume</div>
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Export Endpoints</h4>
                    <div className="text-sm space-y-1">
                      <div>• <code>POST /api/resumes/:id/export/pdf</code> - PDF export</div>
                      <div>• <code>POST /api/resumes/:id/export/linkedin</code> - LinkedIn optimization</div>
                      <div>• <code>POST /api/resumes/:id/export/json</code> - JSON structured data</div>
                      <div>• <code>GET /api/resumes/:id/export/docx</code> - DOCX export (Pro)</div>
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ExternalLink className="w-5 h-5" />
                  Third-Party Integrations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">WordPress Blog Integration</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Pulls blog content from WrelikBrands.com with intelligent caching.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• API URL: https://wrelikbrands.com/wp-json/wp/v2/posts</div>
                      <div>• Cache duration: 1 hour</div>
                      <div>• Fallback handling for API failures</div>
                      <div>• Performance: 5ms cached / 2.1s uncached</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">AutoApply Integration</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Syncs resumes with autoapply.wrelik.com for automated job applications.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Pro feature requirement</div>
                      <div>• Real-time resume synchronization</div>
                      <div>• Skill extraction and optimization</div>
                      <div>• Application tracking integration</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">PrepPair.me Export</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      One-click export to PrepPair.me for interview preparation.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• JWT token-based transfer</div>
                      <div>• Markdown format preservation</div>
                      <div>• Metadata transfer</div>
                      <div>• Cross-platform user matching</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Beehiiv Newsletter</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Newsletter subscription management and automation.
                    </p>
                    <div className="text-xs space-y-1">
                      <div>• Automatic subscriber segmentation</div>
                      <div>• Welcome email automation</div>
                      <div>• Unsubscribe handling</div>
                      <div>• Analytics and reporting</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Admin Tab */}
        <TabsContent value="admin" className="space-y-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Admin Panel Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">User Management</h4>
                    <div className="text-sm space-y-1">
                      <div>• User analytics and activity tracking</div>
                      <div>• Subscription status monitoring</div>
                      <div>• Support ticket management</div>
                      <div>• User content moderation</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">System Monitoring</h4>
                    <div className="text-sm space-y-1">
                      <div>• Real-time error logging</div>
                      <div>• Performance metrics dashboard</div>
                      <div>• API health monitoring</div>
                      <div>• Database performance tracking</div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">Content Management</h4>
                    <div className="text-sm space-y-1">
                      <div>• Blog post management</div>
                      <div>• Template library administration</div>
                      <div>• Feature toggle controls</div>
                      <div>• Knowledge base updates</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start">
                    <Users className="w-4 h-4 mr-2" />
                    View User Analytics
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    System Health Check
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Settings className="w-4 h-4 mr-2" />
                    Feature Toggles
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <FileText className="w-4 h-4 mr-2" />
                    Export Reports
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <div className="mt-12 pt-6 border-t text-center text-xs text-muted-foreground">
        <div>ResumeFormatter.io Admin Documentation</div>
        <div>Last Updated: June 18, 2025 | Version 1.0</div>
        <div className="text-red-600 mt-2">
          This documentation is confidential and intended for authorized personnel only.
        </div>
      </div>
    </div>
  );
}