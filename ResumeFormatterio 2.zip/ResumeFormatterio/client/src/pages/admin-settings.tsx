import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth, useUser } from "@clerk/clerk-react";
import { useAuthenticatedApi } from "@/lib/authApiClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Settings, 
  Flag, 
  CreditCard, 
  Plus, 
  Edit, 
  Save, 
  X, 
  AlertTriangle,
  CheckCircle,
  DollarSign,
  Users,
  Activity
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface FeatureFlag {
  id: number;
  app: string;
  name: string;
  description: string | null;
  enabled: boolean;
  planRequired: string | null;
  createdAt: string;
  updatedAt: string;
}

interface BillingPlan {
  id: number;
  app: string;
  planKey: string;
  stripePriceId: string | null;
  displayName: string;
  description: string | null;
  price: number | null;
  currency: string;
  interval: string | null;
  featuresIncluded: string[] | null;
  isVisible: boolean;
  sortOrder: number;
}

interface StripePrice {
  id: string;
  unit_amount: number;
  currency: string;
  recurring?: {
    interval: string;
  };
  product: {
    name: string;
    metadata: Record<string, string>;
  };
}

export default function AdminSettings() {
  const { isSignedIn, isLoaded } = useAuth();
  const { user } = useUser();
  const { apiCall } = useAuthenticatedApi();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newFlagOpen, setNewFlagOpen] = useState(false);
  const [editingFlag, setEditingFlag] = useState<FeatureFlag | null>(null);
  const [newPlanOpen, setNewPlanOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<BillingPlan | null>(null);

  useEffect(() => {
    if (isLoaded && !isSignedIn) {
      toast({
        title: "Access Denied",
        description: "Admin settings require authentication.",
        variant: "destructive",
      });
      window.location.href = "/sign-in";
    }
  }, [isSignedIn, isLoaded, toast]);

  // Fetch feature flags
  const { data: featureFlags, isLoading: flagsLoading } = useQuery<FeatureFlag[]>({
    queryKey: ["/api/admin/feature-flags"],
    enabled: isSignedIn,
    queryFn: () => apiCall("/api/admin/feature-flags"),
  });

  // Fetch billing plans
  const { data: billingPlans, isLoading: plansLoading } = useQuery<BillingPlan[]>({
    queryKey: ["/api/admin/billing-plans"],
    enabled: isSignedIn,
    queryFn: () => apiCall("/api/admin/billing-plans"),
  });

  // Fetch Stripe prices
  const { data: stripePrices, isLoading: stripePricesLoading } = useQuery<StripePrice[]>({
    queryKey: ["/api/admin/stripe/prices"],
    enabled: isSignedIn,
    queryFn: () => apiCall("/api/admin/stripe/prices"),
  });

  // Feature flag mutations
  const createFlagMutation = useMutation({
    mutationFn: async (data: Partial<FeatureFlag>) => {
      return await apiCall("/api/admin/feature-flags", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      setNewFlagOpen(false);
      toast({ title: "Feature flag created successfully" });
    },
  });

  const updateFlagMutation = useMutation({
    mutationFn: async ({ id, ...data }: Partial<FeatureFlag> & { id: number }) => {
      return await apiCall(`/api/admin/feature-flags/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      setEditingFlag(null);
      toast({ title: "Feature flag updated successfully" });
    },
  });

  const deleteFlagMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiCall(`/api/admin/feature-flags/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feature-flags"] });
      toast({ title: "Feature flag deleted successfully" });
    },
  });

  // Billing plan mutations
  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, ...data }: Partial<BillingPlan> & { id: number }) => {
      return await apiCall(`/api/admin/billing-plans/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/billing-plans"] });
      setEditingPlan(null);
      toast({ title: "Billing plan updated successfully" });
    },
  });

  const syncStripePricesMutation = useMutation({
    mutationFn: async () => {
      return await apiCall("/api/admin/stripe/prices");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/billing-plans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stripe/prices"] });
      toast({ title: "Stripe prices fetched successfully" });
    },
  });

  if (!isLoaded || !isSignedIn) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  const formatPrice = (amount: number | null, currency: string = "usd") => {
    if (!amount) return "Free";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency.toUpperCase(),
    }).format(amount / 100);
  };

  const getStripePriceDetails = (stripePriceId: string | null) => {
    if (!stripePriceId || !stripePrices) return null;
    return stripePrices.find(price => price.id === stripePriceId);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Settings className="w-8 h-8 text-blue-600" />
          <h1 className="text-3xl font-bold">Admin Settings</h1>
          <Badge variant="destructive" className="text-xs">
            ADMIN ONLY
          </Badge>
        </div>
        <p className="text-muted-foreground">
          Manage feature flags, billing plans, and system configurations across all Wrelik Brands apps.
        </p>
      </div>

      <Tabs defaultValue="feature-flags" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="feature-flags" className="flex items-center gap-2">
            <Flag className="w-4 h-4" />
            Feature Flags
          </TabsTrigger>
          <TabsTrigger value="billing-plans" className="flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            Billing Plans
          </TabsTrigger>
          <TabsTrigger value="system-health" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            System Health
          </TabsTrigger>
        </TabsList>

        {/* Feature Flags Tab */}
        <TabsContent value="feature-flags" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Flag className="w-5 h-5" />
                  Feature Flags
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  Control feature availability across apps with real-time toggles
                </p>
              </div>
              <Dialog open={newFlagOpen} onOpenChange={setNewFlagOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Flag
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Feature Flag</DialogTitle>
                  </DialogHeader>
                  <NewFeatureFlagForm 
                    onSubmit={(data) => createFlagMutation.mutate(data)}
                    isLoading={createFlagMutation.isPending}
                  />
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {flagsLoading ? (
                <div className="text-center py-8">Loading feature flags...</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>App</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Plan Required</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {featureFlags?.map((flag) => (
                        <TableRow key={flag.id}>
                          <TableCell className="font-medium">{flag.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{flag.app}</Badge>
                          </TableCell>
                          <TableCell className="max-w-xs truncate">
                            {flag.description || "No description"}
                          </TableCell>
                          <TableCell>
                            {flag.planRequired ? (
                              <Badge variant="secondary">{flag.planRequired}</Badge>
                            ) : (
                              <Badge variant="outline">All Plans</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={flag.enabled}
                                onCheckedChange={(enabled) =>
                                  updateFlagMutation.mutate({ id: flag.id, enabled })
                                }
                              />
                              {flag.enabled ? (
                                <CheckCircle className="w-4 h-4 text-green-600" />
                              ) : (
                                <AlertTriangle className="w-4 h-4 text-gray-400" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setEditingFlag(flag)}
                              >
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteFlagMutation.mutate(flag.id)}
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Billing Plans Tab */}
        <TabsContent value="billing-plans" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Billing Plans
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  Manage pricing plans and Stripe integration across all apps
                </p>
              </div>
              <Button
                onClick={() => syncStripePricesMutation.mutate()}
                disabled={syncStripePricesMutation.isPending}
              >
                <DollarSign className="w-4 h-4 mr-2" />
                Sync Stripe
              </Button>
            </CardHeader>
            <CardContent>
              {plansLoading ? (
                <div className="text-center py-8">Loading billing plans...</div>
              ) : (
                <div className="space-y-6">
                  {/* Plans by App */}
                  {["ResumeFormatter.io", "PrepPair.me", "NameDrop.cv", "ApplyCaptain"].map((app) => {
                    const appPlans = billingPlans?.filter(plan => plan.app === app) || [];
                    
                    return (
                      <div key={app} className="border rounded-lg p-6">
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          {app}
                          <Badge variant="outline">{appPlans.length} plans</Badge>
                        </h3>
                        
                        <div className="grid md:grid-cols-3 gap-4">
                          {appPlans.map((plan) => {
                            const stripeDetails = getStripePriceDetails(plan.stripePriceId);
                            
                            return (
                              <Card key={plan.id} className={`${!plan.isVisible ? 'opacity-60' : ''}`}>
                                <CardHeader className="pb-3">
                                  <div className="flex items-center justify-between">
                                    <CardTitle className="text-base">{plan.displayName}</CardTitle>
                                    <div className="flex items-center gap-2">
                                      {stripeDetails ? (
                                        <CheckCircle className="w-4 h-4 text-green-600" />
                                      ) : (
                                        <AlertTriangle className="w-4 h-4 text-yellow-600" />
                                      )}
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => setEditingPlan(plan)}
                                      >
                                        <Edit className="w-3 h-3" />
                                      </Button>
                                    </div>
                                  </div>
                                  <div className="text-2xl font-bold">
                                    {formatPrice(plan.price, plan.currency)}
                                    {plan.interval && (
                                      <span className="text-sm font-normal text-muted-foreground">
                                        /{plan.interval}
                                      </span>
                                    )}
                                  </div>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                  <p className="text-sm text-muted-foreground">
                                    {plan.description || "No description"}
                                  </p>
                                  
                                  {plan.featuresIncluded && plan.featuresIncluded.length > 0 && (
                                    <div>
                                      <div className="text-xs font-medium mb-1">Features:</div>
                                      <div className="flex flex-wrap gap-1">
                                        {plan.featuresIncluded.map((feature, idx) => (
                                          <Badge key={idx} variant="secondary" className="text-xs">
                                            {feature}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                  
                                  {stripeDetails && (
                                    <div className="text-xs text-muted-foreground">
                                      Stripe ID: {plan.stripePriceId}
                                    </div>
                                  )}
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Health Tab */}
        <TabsContent value="system-health" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  User Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,247</div>
                <div className="text-sm text-muted-foreground">Total Users</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$12,456</div>
                <div className="text-sm text-muted-foreground">Monthly Recurring Revenue</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  API Health
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">99.9%</div>
                <div className="text-sm text-muted-foreground">Uptime</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Feature Flag Dialog */}
      {editingFlag && (
        <Dialog open={!!editingFlag} onOpenChange={() => setEditingFlag(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Feature Flag</DialogTitle>
            </DialogHeader>
            <EditFeatureFlagForm 
              flag={editingFlag}
              onSubmit={(data) => updateFlagMutation.mutate({ id: editingFlag.id, ...data })}
              isLoading={updateFlagMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Billing Plan Dialog */}
      {editingPlan && (
        <Dialog open={!!editingPlan} onOpenChange={() => setEditingPlan(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Billing Plan</DialogTitle>
            </DialogHeader>
            <EditBillingPlanForm 
              plan={editingPlan}
              onSubmit={(data) => updatePlanMutation.mutate({ id: editingPlan.id, ...data })}
              isLoading={updatePlanMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Form Components
function NewFeatureFlagForm({ onSubmit, isLoading }: { onSubmit: (data: any) => void; isLoading: boolean }) {
  const [formData, setFormData] = useState({
    app: "ResumeFormatter.io",
    name: "",
    description: "",
    enabled: false,
    planRequired: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      planRequired: formData.planRequired || null,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="app">App</Label>
        <Select value={formData.app} onValueChange={(value) => setFormData(prev => ({ ...prev, app: value }))}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ResumeFormatter.io">ResumeFormatter.io</SelectItem>
            <SelectItem value="PrepPair.me">PrepPair.me</SelectItem>
            <SelectItem value="NameDrop.cv">NameDrop.cv</SelectItem>
            <SelectItem value="ApplyCaptain">ApplyCaptain</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="name">Feature Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="e.g., AI_OPTIMIZATION"
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Brief description of the feature"
        />
      </div>

      <div>
        <Label htmlFor="planRequired">Plan Required</Label>
        <Select value={formData.planRequired} onValueChange={(value) => setFormData(prev => ({ ...prev, planRequired: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select plan requirement" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Plans</SelectItem>
            <SelectItem value="pro_monthly">Pro Monthly</SelectItem>
            <SelectItem value="pro_quarterly">Pro Quarterly</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="enabled"
          checked={formData.enabled}
          onCheckedChange={(enabled) => setFormData(prev => ({ ...prev, enabled }))}
        />
        <Label htmlFor="enabled">Enable by default</Label>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Creating..." : "Create Flag"}
        </Button>
      </div>
    </form>
  );
}

function EditFeatureFlagForm({ flag, onSubmit, isLoading }: { flag: FeatureFlag; onSubmit: (data: any) => void; isLoading: boolean }) {
  const [formData, setFormData] = useState({
    name: flag.name,
    description: flag.description || "",
    planRequired: flag.planRequired || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      planRequired: formData.planRequired || null,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Feature Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div>
        <Label htmlFor="planRequired">Plan Required</Label>
        <Select value={formData.planRequired} onValueChange={(value) => setFormData(prev => ({ ...prev, planRequired: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select plan requirement" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Plans</SelectItem>
            <SelectItem value="pro_monthly">Pro Monthly</SelectItem>
            <SelectItem value="pro_quarterly">Pro Quarterly</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Updating..." : "Update Flag"}
        </Button>
      </div>
    </form>
  );
}

function EditBillingPlanForm({ plan, onSubmit, isLoading }: { plan: BillingPlan; onSubmit: (data: any) => void; isLoading: boolean }) {
  const [formData, setFormData] = useState({
    displayName: plan.displayName,
    description: plan.description || "",
    featuresIncluded: plan.featuresIncluded?.join(", ") || "",
    isVisible: plan.isVisible,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      featuresIncluded: formData.featuresIncluded ? formData.featuresIncluded.split(",").map(f => f.trim()) : [],
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="displayName">Display Name</Label>
        <Input
          id="displayName"
          value={formData.displayName}
          onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div>
        <Label htmlFor="featuresIncluded">Features Included (comma-separated)</Label>
        <Textarea
          id="featuresIncluded"
          value={formData.featuresIncluded}
          onChange={(e) => setFormData(prev => ({ ...prev, featuresIncluded: e.target.value }))}
          placeholder="AI Optimization, Premium Templates, Priority Support"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="isVisible"
          checked={formData.isVisible}
          onCheckedChange={(isVisible) => setFormData(prev => ({ ...prev, isVisible }))}
        />
        <Label htmlFor="isVisible">Visible to users</Label>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Updating..." : "Update Plan"}
        </Button>
      </div>
    </form>
  );
}