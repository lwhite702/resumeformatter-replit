import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { 
  Users, FileText, Sparkles, CreditCard, TrendingUp, Download, 
  Calendar, Activity, DollarSign, Globe, Zap, Shield 
} from "lucide-react";
import { Gauge } from "@/components/ui/gauge";

// Mock analytics data - in production this would come from your API
const generateAnalyticsData = () => {
  const userGrowthData = [
    { month: 'Jan', users: 1250, proUsers: 156 },
    { month: 'Feb', users: 1680, proUsers: 234 },
    { month: 'Mar', users: 2100, proUsers: 312 },
    { month: 'Apr', users: 2850, proUsers: 428 },
    { month: 'May', users: 3420, proUsers: 567 },
    { month: 'Jun', users: 4100, proUsers: 698 }
  ];

  const revenueData = [
    { month: 'Jan', revenue: 624, subscriptions: 156 },
    { month: 'Feb', revenue: 936, subscriptions: 234 },
    { month: 'Mar', revenue: 1248, subscriptions: 312 },
    { month: 'Apr', revenue: 1712, subscriptions: 428 },
    { month: 'May', revenue: 2268, subscriptions: 567 },
    { month: 'Jun', revenue: 2792, subscriptions: 698 }
  ];

  const planDistribution = [
    { name: 'Free', value: 3402, color: '#8884d8' },
    { name: 'Pro Monthly', value: 523, color: '#82ca9d' },
    { name: 'Pro Quarterly', value: 175, color: '#ffc658' }
  ];

  const templateUsage = [
    { template: 'Modern', usage: 1850 },
    { template: 'Classic', usage: 1420 },
    { template: 'Creative', usage: 980 },
    { template: 'Executive', usage: 750 },
    { template: 'Technical', usage: 620 }
  ];

  const dailyActivity = Array.from({ length: 30 }, (_, i) => ({
    day: i + 1,
    resumes: Math.floor(Math.random() * 50) + 20,
    optimizations: Math.floor(Math.random() * 80) + 30,
    exports: Math.floor(Math.random() * 40) + 15
  }));

  return {
    userGrowthData,
    revenueData,
    planDistribution,
    templateUsage,
    dailyActivity
  };
};

export default function Admin() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState("30d");
  const analytics = generateAnalyticsData();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: adminData, isLoading: adminLoading } = useQuery({
    queryKey: ["/api/admin/analytics", timeRange],
    enabled: isAuthenticated && !!user,
  });

  const { data: userStats, isLoading: userStatsLoading } = useQuery({
    queryKey: ["/api/admin/user-stats"],
    enabled: isAuthenticated && !!user,
  });

  const { data: revenueStats, isLoading: revenueStatsLoading } = useQuery({
    queryKey: ["/api/admin/revenue-stats", timeRange],
    enabled: isAuthenticated && !!user,
  });

  if (isLoading || adminLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null; // Will redirect to login
  }

  // Simple admin check - in production you'd want proper role-based access
  if (!user?.email?.includes('admin')) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground mb-4">Access Denied</h1>
              <p className="text-muted-foreground">
                You don't have permission to access the admin panel.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <FileText className="h-4 w-4 text-white" />
              </div>
              <span className="text-xl font-semibold">ResumeFormatter.io Admin</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="secondary">Admin</Badge>
              <button 
                onClick={() => window.location.href = "/api/logout"}
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Admin Dashboard */}
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Monitor platform activity and user engagement
          </p>
        </div>

        {/* Time Range Selector */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{userStats?.totalUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {userStats?.activeUsers || 0} active this month
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pro Users</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{userStats?.proUsers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {userStats?.freeUsers || 0} free users
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${((userStats?.proUsers || 0) * 3.99).toFixed(2)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Estimated recurring revenue
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">AI Usage</CardTitle>
                  <Sparkles className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{adminData?.optimizations?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    Optimizations this period
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Growth Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    User Growth
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={analytics.userGrowthData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Area 
                          type="monotone" 
                          dataKey="users" 
                          stroke="#8884d8" 
                          fill="#8884d8" 
                          fillOpacity={0.6}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="proUsers" 
                          stroke="#82ca9d" 
                          fill="#82ca9d" 
                          fillOpacity={0.6}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Daily Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={analytics.dailyActivity}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="resumes" 
                          stroke="#8884d8" 
                          strokeWidth={2}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="optimizations" 
                          stroke="#82ca9d" 
                          strokeWidth={2}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="exports" 
                          stroke="#ffc658" 
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics.planDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={(entry) => `${entry.name}: ${entry.value}`}
                        >
                          {analytics.planDistribution.map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Activity Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between py-3 border-b">
                      <div className="flex items-center space-x-3">
                        <Activity className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">Active Users (24h)</span>
                      </div>
                      <Badge variant="secondary">{userStats?.activeUsers || 0}</Badge>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b">
                      <div className="flex items-center space-x-3">
                        <Users className="h-5 w-5 text-green-500" />
                        <span className="font-medium">New Signups (7d)</span>
                      </div>
                      <Badge variant="secondary">43</Badge>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b">
                      <div className="flex items-center space-x-3">
                        <Globe className="h-5 w-5 text-purple-500" />
                        <span className="font-medium">Conversion Rate</span>
                      </div>
                      <Badge variant="secondary">12.5%</Badge>
                    </div>
                    <div className="flex items-center justify-between py-3">
                      <div className="flex items-center space-x-3">
                        <Zap className="h-5 w-5 text-amber-500" />
                        <span className="font-medium">Retention Rate</span>
                      </div>
                      <Badge variant="secondary">78%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Growth</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={analytics.revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Area 
                          type="monotone" 
                          dataKey="revenue" 
                          stroke="#82ca9d" 
                          fill="#82ca9d" 
                          fillOpacity={0.6}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Template Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics.templateUsage}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="template" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="usage" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Shield className="h-5 w-5 text-green-500" />
                        <span className="font-medium">API Response Time</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Gauge 
                          value={85} 
                          size="small" 
                          showValue
                          colors={{
                            primary: "#00ac3a",
                            secondary: "#f0f0f0"
                          }}
                        />
                        <Badge variant="outline" className="text-green-600 border-green-200">125ms</Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Activity className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">Database Performance</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Gauge 
                          value={92} 
                          size="small" 
                          showValue
                          colors={{
                            primary: "#006efe",
                            secondary: "#f0f0f0"
                          }}
                        />
                        <Badge variant="outline" className="text-blue-600 border-blue-200">Excellent</Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Sparkles className="h-5 w-5 text-purple-500" />
                        <span className="font-medium">AI Service Status</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Gauge 
                          value={78} 
                          size="small" 
                          showValue
                          colors={{
                            primary: "#a000f8",
                            secondary: "#f0f0f0"
                          }}
                        />
                        <Badge variant="outline" className="text-purple-600 border-purple-200">Operational</Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <CreditCard className="h-5 w-5 text-amber-500" />
                        <span className="font-medium">Payment Processing</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Gauge 
                          value={96} 
                          size="small" 
                          showValue
                          colors={{
                            primary: "#ffae00",
                            secondary: "#f0f0f0"
                          }}
                        />
                        <Badge variant="outline" className="text-amber-600 border-amber-200">Active</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">User created resume - 2 minutes ago</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">AI optimization completed - 5 minutes ago</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-sm">New user signup - 8 minutes ago</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                      <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                      <span className="text-sm">Pro subscription activated - 12 minutes ago</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* API Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    API Configuration
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Manage external service integrations and API credentials
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Beehiiv Settings */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Beehiiv Newsletter API</h4>
                        <p className="text-sm text-muted-foreground">
                          Manage "The Resume Refresh" newsletter subscriptions
                        </p>
                      </div>
                      <Badge variant="secondary">Required</Badge>
                    </div>
                    
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <div className="w-4 h-4 bg-yellow-400 rounded-full mt-0.5"></div>
                        <div className="flex-1">
                          <h5 className="font-medium text-yellow-800">API Credentials Required</h5>
                          <p className="text-sm text-yellow-700 mt-1">
                            To enable full newsletter functionality, add these secrets in your Replit environment:
                          </p>
                          <div className="mt-3 space-y-2">
                            <div className="flex items-center space-x-2">
                              <code className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                                BEEHIIV_API_KEY
                              </code>
                              <span className="text-xs text-yellow-600">Your Beehiiv API key</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <code className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">
                                BEEHIIV_PUBLICATION_ID
                              </code>
                              <span className="text-xs text-yellow-600">Your publication ID</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h5 className="font-medium">How to get your credentials:</h5>
                      <ol className="text-sm text-muted-foreground space-y-2 list-decimal list-inside">
                        <li>Log into your Beehiiv account</li>
                        <li>Go to Settings → Integrations → API</li>
                        <li>Generate a new API key and copy it</li>
                        <li>Find your Publication ID in your dashboard URL</li>
                        <li>Add both values to your Replit Secrets tab</li>
                      </ol>
                    </div>

                    <Button 
                      onClick={() => window.open('https://app.beehiiv.com', '_blank')}
                      variant="outline" 
                      className="w-full"
                    >
                      Open Beehiiv Dashboard
                    </Button>
                  </div>

                  {/* OpenAI Settings */}
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">OpenAI API</h4>
                        <p className="text-sm text-muted-foreground">
                          AI-powered resume optimization and analysis
                        </p>
                      </div>
                      <Badge variant="default">Active</Badge>
                    </div>
                    
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-green-700 font-medium">Connected</span>
                      </div>
                      <p className="text-xs text-green-600 mt-1">
                        AI features are operational and ready to use
                      </p>
                    </div>
                  </div>

                  {/* Stripe Settings */}
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Stripe Payments</h4>
                        <p className="text-sm text-muted-foreground">
                          Payment processing for Pro subscriptions
                        </p>
                      </div>
                      <Badge variant="default">Active</Badge>
                    </div>
                    
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-green-700 font-medium">Connected</span>
                      </div>
                      <p className="text-xs text-green-600 mt-1">
                        Payment processing is active and secure
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Newsletter Management */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Newsletter Management
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Test and monitor "The Resume Refresh" newsletter
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Test Subscription */}
                  <div className="space-y-4">
                    <h4 className="font-medium">Test Newsletter Subscription</h4>
                    <div className="space-y-3">
                      <input
                        type="email"
                        placeholder="test@example.com"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <input
                        type="text"
                        placeholder="Test User Name (optional)"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <Button className="w-full">
                        Test Subscribe
                      </Button>
                    </div>
                  </div>

                  {/* Newsletter Stats */}
                  <div className="space-y-4 pt-4 border-t">
                    <h4 className="font-medium">Newsletter Statistics</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-700">0</div>
                        <div className="text-xs text-blue-600">Total Subscribers</div>
                      </div>
                      <div className="p-3 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-700">0</div>
                        <div className="text-xs text-green-600">This Week</div>
                      </div>
                    </div>
                  </div>

                  {/* Integration Status */}
                  <div className="space-y-4 pt-4 border-t">
                    <h4 className="font-medium">Integration Status</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Local Database</span>
                        <Badge variant="default">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Beehiiv API</span>
                        <Badge variant="secondary">Setup Required</Badge>
                      </div>
                    </div>
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => window.open('/admin', '_blank')}
                  >
                    View Full Newsletter Admin
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* System Health */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  System Health & Monitoring
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-medium">Database</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm">PostgreSQL Connected</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      All database operations functioning normally
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Authentication</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Replit Auth Active</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      User authentication and sessions working
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Content</h4>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm">WordPress API Connected</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Blog content loading from Wrelikbrands.com
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
