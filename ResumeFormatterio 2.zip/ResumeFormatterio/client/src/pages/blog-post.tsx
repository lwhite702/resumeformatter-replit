import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar, 
  Clock, 
  ArrowLeft, 
  Share2, 
  BookOpen, 
  Mail,
  User,
  ExternalLink,
  Tag
} from "lucide-react";
import Header from "@/components/Header";
import { useState } from "react";

interface BlogPost {
  id: number;
  date: string;
  slug: string;
  title: { rendered: string };
  content: { rendered: string };
  excerpt: { rendered: string };
  featured_media: number;
  categories: number[];
  tags: number[];
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string;
      alt_text: string;
    }>;
  };
}

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:slug");
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [subscriptionStatus, setSubscriptionStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const { data: post, isLoading } = useQuery({
    queryKey: ["/api/blog/posts", params?.slug],
    select: (data) => {
      const posts = data as BlogPost[];
      return posts.find(p => p.slug === params?.slug);
    }
  });

  const { data: relatedPosts } = useQuery({
    queryKey: ["/api/blog/posts"],
    select: (data) => {
      const posts = data as BlogPost[];
      return posts.filter(p => p.slug !== params?.slug).slice(0, 3);
    }
  });

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubscriptionStatus("loading");

    try {
      const response = await fetch("/api/newsletter/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: newsletterEmail })
      });

      if (response.ok) {
        setSubscriptionStatus("success");
        setNewsletterEmail("");
      } else {
        setSubscriptionStatus("error");
      }
    } catch (error) {
      setSubscriptionStatus("error");
    }

    setTimeout(() => setSubscriptionStatus("idle"), 3000);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, "").trim();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: post ? stripHtml(post.title.rendered) : "",
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="h-12 bg-gray-200 rounded mb-6"></div>
            <div className="h-4 bg-gray-200 rounded w-1/3 mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              <div className="h-4 bg-gray-200 rounded w-4/6"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Article Not Found</h1>
          <p className="text-gray-600 mb-8">The article you're looking for doesn't exist or has been moved.</p>
          <Link href="/blog">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-600/20 via-transparent to-transparent"></div>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 relative">
          <Link href="/blog">
            <Button variant="ghost" size="sm" className="text-blue-200 hover:text-white hover:bg-white/10 mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
          
          <div className="max-w-4xl">
            <div className="flex items-center space-x-4 mb-6 text-blue-200">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">{formatDate(post.date)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span className="text-sm">8 min read</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span className="text-sm">ResumeFormatter Team</span>
              </div>
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-display font-bold mb-6 bg-gradient-to-r from-white via-blue-100 to-blue-200 bg-clip-text text-transparent leading-tight">
              {stripHtml(post.title.rendered)}
            </h1>
            
            <p className="text-xl text-blue-100 leading-relaxed mb-8">
              {stripHtml(post.excerpt.rendered)}
            </p>
            
            <div className="flex items-center space-x-4">
              <Badge className="bg-blue-600/20 text-blue-200 border-blue-400/30">
                Featured Article
              </Badge>
              <Button
                onClick={handleShare}
                variant="ghost"
                size="sm"
                className="text-blue-200 hover:text-white hover:bg-white/10"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-3">
              <article className="prose prose-lg prose-blue max-w-none">
                <div 
                  className="text-gray-700 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: post.content.rendered }}
                />
              </article>

              {/* Article Footer */}
              <div className="mt-12 pt-8 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-500">Share this article:</span>
                    <Button
                      onClick={handleShare}
                      variant="outline"
                      size="sm"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Tag className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-500">Resume Tips</span>
                  </div>
                </div>
              </div>

              {/* Related Articles */}
              {relatedPosts && relatedPosts.length > 0 && (
                <div className="mt-16">
                  <h3 className="text-2xl font-display font-bold text-gray-900 mb-8">
                    Related Articles
                  </h3>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {relatedPosts.map((relatedPost) => (
                      <Card key={relatedPost.id} className="group hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center space-x-2 text-xs text-gray-500 mb-3">
                            <Calendar className="w-3 h-3" />
                            <span>{formatDate(relatedPost.date)}</span>
                          </div>
                          <Link href={`/blog/${relatedPost.slug}`}>
                            <h4 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors mb-2 line-clamp-2">
                              {stripHtml(relatedPost.title.rendered)}
                            </h4>
                          </Link>
                          <p className="text-sm text-gray-600 line-clamp-3">
                            {stripHtml(relatedPost.excerpt.rendered).slice(0, 100)}...
                          </p>
                          <Link href={`/blog/${relatedPost.slug}`}>
                            <Button variant="ghost" size="sm" className="mt-3 p-0 h-auto text-blue-600">
                              Read More
                              <ExternalLink className="w-3 h-3 ml-1" />
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-8 space-y-8">
                {/* Newsletter Signup */}
                <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                  <div className="mb-4">
                    <h3 className="text-xl font-display font-bold text-gray-900 flex items-center mb-2">
                      <Mail className="w-5 h-5 mr-2 text-blue-600" />
                      The Resume Refresh
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      Get weekly resume tips, formatting tricks, and career insights delivered to your inbox.
                    </p>
                  </div>
                  <form onSubmit={handleNewsletterSubmit} className="space-y-3">
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      required
                      className="text-sm"
                    />
                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-sm font-medium"
                      disabled={subscriptionStatus === "loading"}
                    >
                      {subscriptionStatus === "loading" ? "Subscribing..." : "Subscribe"}
                    </Button>
                  </form>
                  {subscriptionStatus === "success" && (
                    <p className="text-green-600 text-sm mt-2 font-medium">Successfully subscribed!</p>
                  )}
                  {subscriptionStatus === "error" && (
                    <p className="text-red-600 text-sm mt-2">Subscription failed. Please try again.</p>
                  )}
                </Card>

                {/* About The Formatting Desk */}
                <Card className="p-6">
                  <h3 className="text-lg font-display font-bold text-gray-900 mb-4">
                    About The Formatting Desk
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    Your comprehensive resource for resume mastery, powered by ResumeFormatter.io. 
                    We provide expert insights, proven strategies, and AI-driven tools to help you create 
                    resumes that stand out in today's competitive job market.
                  </p>
                  <Link href="/blog">
                    <Button variant="outline" size="sm" className="w-full">
                      View All Articles
                    </Button>
                  </Link>
                </Card>

                {/* Quick Actions */}
                <Card className="p-6">
                  <h3 className="text-lg font-display font-bold text-gray-900 mb-4">
                    Start Building
                  </h3>
                  <div className="space-y-3">
                    <Link href="/editor">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        Create Resume
                      </Button>
                    </Link>
                    <Link href="/templates">
                      <Button variant="outline" className="w-full">
                        Browse Templates
                      </Button>
                    </Link>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}