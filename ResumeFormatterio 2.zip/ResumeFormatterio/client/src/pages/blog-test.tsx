import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, CheckCircle, Clock, Database } from "lucide-react";

interface BlogPost {
  id: number;
  title: { rendered: string };
  slug: string;
  excerpt: { rendered: string };
  content: { rendered: string };
  date: string;
}

interface HealthStatus {
  status: string;
  timestamp: string;
  services: {
    cache: string;
    wordpress: string;
  };
  statistics: {
    cachedPosts: number;
    lastCacheUpdate: string | null;
  };
}

export default function BlogTest() {
  const { data: posts, isLoading: postsLoading, error: postsError } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog/posts"],
    retry: 1
  });

  const { data: health, isLoading: healthLoading } = useQuery<HealthStatus>({
    queryKey: ["/api/blog/health"],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const stripHtml = (html: string) => {
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'degraded': return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'degraded': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'error': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">WordPress Blog API Test</h1>
        <p className="text-muted-foreground">
          Testing integration with wrelikbrands.com WordPress endpoint
        </p>
      </div>

      {/* Health Status */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            API Health Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          {healthLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-48" />
            </div>
          ) : health ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                {getStatusIcon(health.status)}
                <span className="font-medium">Overall Status:</span>
                <Badge className={getStatusColor(health.status)}>
                  {health.status.toUpperCase()}
                </Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  {getStatusIcon(health.services.cache)}
                  <span>Cache Service:</span>
                  <Badge className={getStatusColor(health.services.cache)}>
                    {health.services.cache.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-2">
                  {getStatusIcon(health.services.wordpress)}
                  <span>WordPress API:</span>
                  <Badge className={getStatusColor(health.services.wordpress)}>
                    {health.services.wordpress.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground">
                Last checked: {new Date(health.timestamp).toLocaleString()}
              </div>
            </div>
          ) : (
            <div className="text-red-500">Failed to load health status</div>
          )}
        </CardContent>
      </Card>

      {/* Blog Posts */}
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold">Latest Blog Posts</h2>
        
        {postsLoading ? (
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-5/6" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : postsError ? (
          <Card className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertCircle className="w-5 h-5" />
                <span className="font-medium">Error loading blog posts</span>
              </div>
              <p className="text-sm text-red-600 dark:text-red-400 mt-2">
                {postsError instanceof Error ? postsError.message : 'Unknown error occurred'}
              </p>
            </CardContent>
          </Card>
        ) : posts && posts.length > 0 ? (
          <div className="grid gap-6">
            {posts.map((post) => (
              <Card key={post.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl">
                    {stripHtml(post.title.rendered)}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <span>{formatDate(post.date)}</span>
                    <Badge variant="outline">ID: {post.id}</Badge>
                    <Badge variant="outline">{post.slug}</Badge>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground line-clamp-3">
                    {stripHtml(post.excerpt.rendered)}
                  </p>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Content length: {stripHtml(post.content.rendered).length} characters
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground">No blog posts found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}