import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Clock,
  ArrowRight,
  BookOpen,
  Mail,
  User,
  Search,
  Filter,
} from "lucide-react";
import Header from "@/components/Header";

interface BlogPost {
  id: number;
  date: string;
  slug: string;
  title: { rendered: string };
  content: { rendered: string };
  excerpt: { rendered: string };
  featured_media: number;
  categories: number[];
  tags: number[];
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string;
      alt_text: string;
    }>;
  };
}

export default function BlogPage() {
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [subscriptionStatus, setSubscriptionStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");

  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/blog/posts", page],
    queryFn: async () => {
      const response = await fetch(`/api/blog/posts?page=${page}`);
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    },
    select: (data) => data as BlogPost[],
  });

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubscriptionStatus("loading");

    try {
      const response = await fetch("/api/newsletter/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: newsletterEmail }),
      });

      if (response.ok) {
        setSubscriptionStatus("success");
        setNewsletterEmail("");
      } else {
        setSubscriptionStatus("error");
      }
    } catch (error) {
      setSubscriptionStatus("error");
    }

    setTimeout(() => setSubscriptionStatus("idle"), 3000);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, "").trim();
  };

  const filteredPosts =
    posts?.filter(
      (post) =>
        post.title.rendered.toLowerCase().includes(searchQuery.toLowerCase()) ||
        stripHtml(post.excerpt.rendered)
          .toLowerCase()
          .includes(searchQuery.toLowerCase()),
    ) || [];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-600/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 relative">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600/20 backdrop-blur-sm rounded-3xl mb-8 border border-blue-400/30">
              <BookOpen className="w-10 h-10 text-blue-300" />
            </div>
            <h1 className="text-5xl lg:text-7xl font-display font-bold mb-6 bg-gradient-to-r from-white via-blue-100 to-blue-200 bg-clip-text text-transparent leading-tight">
              The Formatting Desk
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 max-w-4xl mx-auto leading-relaxed mb-12">
              Master the art of resume formatting with expert insights, proven
              strategies, and cutting-edge AI tools. Your definitive resource
              for career advancement.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-8 text-blue-200 mb-8">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span className="font-medium">Expert Guidance</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span className="font-medium">AI Insights</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span className="font-medium">Career Growth</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-12 bg-gray-50 border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search articles, guides, and insights..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-4 text-lg rounded-xl border-gray-200 focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </section>

      {/* Articles Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-3">
              <div className="mb-8">
                <h2 className="text-3xl lg:text-4xl font-display font-bold text-gray-900 mb-4">
                  {searchQuery
                    ? `Search Results (${filteredPosts.length})`
                    : "Latest Articles"}
                </h2>
                <p className="text-xl text-gray-600">
                  {searchQuery
                    ? `Results for "${searchQuery}"`
                    : "Discover proven strategies and expert insights to elevate your resume game"}
                </p>
              </div>

              {isLoading ? (
                <div className="grid gap-8">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="p-6">
                      <div className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                        <div className="h-8 bg-gray-200 rounded mb-4"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="grid gap-8">
                  {filteredPosts.map((post) => (
                    <Card
                      key={post.id}
                      className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden"
                    >
                      <CardContent className="p-8">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Calendar className="w-4 h-4" />
                              <span>{formatDate(post.date)}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>5 min read</span>
                            </div>
                          </div>
                          <Badge
                            variant="secondary"
                            className="bg-blue-100 text-blue-700 font-medium"
                          >
                            Featured
                          </Badge>
                        </div>

                        <Link href={`/blog/${post.slug}`}>
                          <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors cursor-pointer leading-tight">
                            {stripHtml(post.title.rendered)}
                          </h3>
                        </Link>

                        <p className="text-gray-600 text-lg leading-relaxed mb-6 line-clamp-3">
                          {stripHtml(post.excerpt.rendered).slice(0, 200)}...
                        </p>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 text-sm text-gray-500">
                            <User className="w-4 h-4" />
                            <span>ResumeFormatter Team</span>
                          </div>
                          <Link href={`/blog/${post.slug}`}>
                            <Button
                              variant="outline"
                              className="group-hover:bg-blue-600 group-hover:text-white transition-colors"
                            >
                              Read More
                              <ArrowRight className="ml-2 w-4 h-4" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {!isLoading && filteredPosts.length === 0 && (
                <div className="text-center py-16">
                  <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No articles found
                  </h3>
                  <p className="text-gray-600">
                    Try adjusting your search terms or browse all articles.
                  </p>
                  <Button
                    onClick={() => setSearchQuery("")}
                    variant="outline"
                    className="mt-4"
                  >
                    View All Articles
                  </Button>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-8 space-y-8">
                {/* Newsletter Signup */}
                <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                  <CardHeader className="p-0 mb-4">
                    <CardTitle className="text-xl font-display font-bold text-gray-900 flex items-center">
                      <Mail className="w-5 h-5 mr-2 text-blue-600" />
                      The Resume Refresh
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                      Get weekly resume tips, formatting tricks, and career
                      insights delivered to your inbox.
                    </p>
                    <form
                      onSubmit={handleNewsletterSubmit}
                      className="space-y-3"
                    >
                      <Input
                        type="email"
                        placeholder="Enter your email"
                        value={newsletterEmail}
                        onChange={(e) => setNewsletterEmail(e.target.value)}
                        required
                        className="text-sm"
                      />
                      <Button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-sm font-medium"
                        disabled={subscriptionStatus === "loading"}
                      >
                        {subscriptionStatus === "loading"
                          ? "Subscribing..."
                          : "Subscribe"}
                      </Button>
                    </form>
                    {subscriptionStatus === "success" && (
                      <p className="text-green-600 text-sm mt-2 font-medium">
                        Successfully subscribed!
                      </p>
                    )}
                    {subscriptionStatus === "error" && (
                      <p className="text-red-600 text-sm mt-2">
                        Subscription failed. Please try again.
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Categories */}
                <Card className="p-6">
                  <CardHeader className="p-0 mb-4">
                    <CardTitle className="text-lg font-display font-bold text-gray-900">
                      Popular Topics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="space-y-3">
                      {[
                        "Resume Formatting",
                        "ATS Optimization",
                        "Cover Letters",
                        "Interview Prep",
                        "Career Strategy",
                      ].map((topic) => (
                        <button
                          key={topic}
                          onClick={() => setSearchQuery(topic)}
                          className="block w-full text-left px-3 py-2 text-sm text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          {topic}
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Posts */}
                <Card className="p-6">
                  <CardHeader className="p-0 mb-4">
                    <CardTitle className="text-lg font-display font-bold text-gray-900">
                      Trending Now
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="space-y-4">
                      {posts?.slice(0, 3).map((post) => (
                        <Link key={post.id} href={`/blog/${post.slug}`}>
                          <div className="group cursor-pointer">
                            <h4 className="text-sm font-medium text-gray-900 group-hover:text-blue-600 transition-colors leading-tight mb-1">
                              {stripHtml(post.title.rendered)}
                            </h4>
                            <p className="text-xs text-gray-500">
                              {formatDate(post.date)}
                            </p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
