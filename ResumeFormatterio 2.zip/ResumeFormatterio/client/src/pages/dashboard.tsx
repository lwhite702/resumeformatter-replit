import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, FileText, History, Zap, Crown } from "lucide-react";
import { CurlyBraceIcon } from "@/components/ui/curly-brace-icon";
import { Link } from "wouter";

export default function Dashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ["/api/resumes"],
    enabled: !!user && !isLoading,
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="mb-12">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome back, {user?.firstName || 'there'}
              </h1>
              <p className="text-lg text-gray-600">
                Build and optimize your resume with AI-powered tools
              </p>
            </div>
            <div className="mt-6 sm:mt-0 flex items-center space-x-4">
              {user?.plan === "free" && (
                <Link href="/subscribe">
                  <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 px-6 py-2.5 rounded-lg font-medium">
                    <Crown className="h-4 w-4 mr-2" />
                    <span>Upgrade to Pro</span>
                  </Button>
                </Link>
              )}
              <Link href="/editor">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg font-medium shadow-sm">
                  <Plus className="h-4 w-4 mr-2" />
                  <span>New Resume</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Current Plan</CardTitle>
                <Crown className="h-5 w-5 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900 capitalize">{user?.plan || 'Free'}</div>
              <p className="text-sm text-gray-500 mt-1">
                {user?.plan === "pro" ? "All features unlocked" : "Limited features"}
              </p>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Credits</CardTitle>
                <Zap className="h-5 w-5 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">
                {user?.plan === "pro" ? "Unlimited" : user?.credits || 0}
              </div>
              <p className="text-sm text-gray-500 mt-1">
                {user?.plan === "pro" ? "No usage limits" : "AI optimizations available"}
              </p>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Resumes</CardTitle>
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{resumes?.length || 0}</div>
              <p className="text-sm text-gray-500 mt-1">
                Documents created
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Resumes */}
        <Card className="border border-gray-200 shadow-sm">
          <CardHeader className="border-b border-gray-100 bg-gray-50/50">
            <CardTitle className="text-xl text-gray-900">Your Resumes</CardTitle>
            <CardDescription className="text-gray-600">
              Manage and edit your resume documents
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {resumesLoading ? (
              <div className="p-6 space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-20 bg-gray-100 rounded-lg animate-pulse" />
                ))}
              </div>
            ) : resumes && resumes.length > 0 ? (
              <div className="divide-y divide-gray-100">
                {resumes.map((resume: any) => (
                  <div key={resume.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <CurlyBraceIcon className="text-blue-600" size="md" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg text-gray-900">{resume.title}</h3>
                          <p className="text-sm text-gray-500">
                            Updated {new Date(resume.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge variant="outline" className="capitalize text-xs px-2 py-1">
                          {resume.templateId.replace('-', ' ')}
                        </Badge>
                        <Link href={`/editor/${resume.id}`}>
                          <Button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                            Edit
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CurlyBraceIcon className="text-gray-400" size="lg" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No resumes yet</h3>
                <p className="text-gray-600 mb-8">
                  Create your first professional resume to get started
                </p>
                <Link href="/editor">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium">
                    <Plus className="h-5 w-5 mr-2" />
                    Create Your First Resume
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-blue-600" />
                <span>AI Optimization</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="mb-4">
                Improve your resume with AI-powered suggestions and ATS scoring
              </CardDescription>
              <Button variant="outline" className="w-full">
                Learn More
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <History className="h-5 w-5 text-blue-600" />
                <span>Version Control</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="mb-4">
                Save snapshots and track changes to tailor your resume for different jobs
              </CardDescription>
              <Button variant="outline" className="w-full">
                View Guide
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-blue-600" />
                <span>Cover Letters</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="mb-4">
                Generate personalized cover letters that match your resume
              </CardDescription>
              <Button variant="outline" className="w-full">
                Get Started
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
