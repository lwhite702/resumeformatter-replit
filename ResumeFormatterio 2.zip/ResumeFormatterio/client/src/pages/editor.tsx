import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  FileText, 
  Save, 
  Eye, 
  Download, 
  Menu, 
  LogOut, 
  Coins,
  Sparkles,
  History,
  File,
  Upload,
  BarChart3,
  Lightbulb
} from "lucide-react";
import { CurlyBraceIcon } from "@/components/ui/curly-brace-icon";
import MarkdownEditor from "@/components/MarkdownEditor";
import ResumePreview from "@/components/ResumePreview";
import TemplateSidebar from "@/components/TemplateSidebar";
import OptimizationModal from "@/components/OptimizationModal";
import SimpleVersionModal from "@/components/SimpleVersionModal";
import CoverLetterModal from "@/components/CoverLetterModal";
import ExportModal from "@/components/ExportModal";
import DemoExportModal from "@/components/DemoExportModal";
import MobileExportTab from "@/components/MobileExportTab";
import MobileNavigation from "@/components/MobileNavigation";
import OnboardingTour from "@/components/OnboardingTour";
import QuickStartButton from "@/components/QuickStartButton";
import ResumeImporter from "@/components/ResumeImporter";
import ResumeHealthScore from "@/components/ResumeHealthScore";
import PrepPairTransfer from "@/components/PrepPairTransfer";
import ContextualTooltips from "@/components/ContextualTooltips";

interface Resume {
  id: string;
  title: string;
  content: string;
  templateId: number | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function Editor() {
  const [match, params] = useRoute("/editor/:id?");
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [mobileTab, setMobileTab] = useState<"edit" | "preview" | "export">("edit");
  const [resumeContent, setResumeContent] = useState("");
  const [resumeTitle, setResumeTitle] = useState("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<"saved" | "saving" | "unsaved">("saved");
  const [showImporter, setShowImporter] = useState(false);
  const [showHealthScore, setShowHealthScore] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showVersions, setShowVersions] = useState(false);
  const [showOptimization, setShowOptimization] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showCoverLetter, setShowCoverLetter] = useState(false);
  const [demoMode, setDemoMode] = useState(!isAuthenticated);
  const [showTips, setShowTips] = useState(true);

  // Update demo mode when authentication changes
  useEffect(() => {
    setDemoMode(!isAuthenticated);
  }, [isAuthenticated]);

  // Touch gesture handling for mobile
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    // const isMobile = window.innerWidth < 768; // Simplified mobile check
    const isMobile = window.innerWidth < 768;

    if (isMobile) {
      if (isLeftSwipe && !showPreview) {
        setShowPreview(true);
      }
      if (isRightSwipe && showPreview) {
        setShowPreview(false);
      }
    }
  };

  const resumeId = params?.id;

  // Fetch resume data if editing existing resume (only when authenticated)
  const { data: resume, isLoading: resumeLoading, error: resumeError } = useQuery({
    queryKey: ["/api/resumes", resumeId],
    enabled: !!resumeId && !!user && !authLoading,
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  // Update local state when resume loads
  useEffect(() => {
    if (resume && typeof resume === 'object') {
      const resumeData = resume as any;
      setResumeContent(resumeData.content || '');
      setResumeTitle(resumeData.title || '');
      setSelectedTemplateId(resumeData.templateId || null);
    }
  }, [resume]);

  // Initialize with default content for new resume
  useEffect(() => {
    if (!resumeId && !resumeContent) {
      // Check for QuickStart content from localStorage
      const quickStartContent = localStorage.getItem('quickStartContent');
      
      if (quickStartContent) {
        setResumeContent(quickStartContent);
        setResumeTitle("Quick Start Resume");
        // Clear localStorage to prevent re-triggering
        localStorage.removeItem('quickStartContent');
      } else {
        setResumeContent(`# Your Name
## Your Title

**Email:** your.email@example.com  
**Phone:** (555) 123-4567  
**Location:** Your City, State  
**LinkedIn:** linkedin.com/in/yourprofile  
**GitHub:** github.com/yourusername

---

## Summary

Write a compelling summary of your experience and skills...

---

## Experience

### **Job Title** | Company Name | Date Range
- Bullet point describing an achievement
- Another bullet point with quantified results
- Third bullet point showing impact

---

## Skills

**Programming Languages:** List your programming languages  
**Frameworks:** List frameworks and libraries  
**Tools:** List tools and technologies  

---

## Education

### **Degree** | University Name | Year
Brief description or relevant coursework

---

## Projects

### **Project Name**
Brief description of the project and your role
- Key technologies used
- **Link:** github.com/yourproject`);
        setResumeTitle("New Resume");
      }
    }
  }, [resumeId, resumeContent]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleImportResume = (content: string) => {
    setResumeContent(content);
    setResumeTitle("Imported Resume");
    setAutoSaveStatus("unsaved");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (resumeId && resumeLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        {/* Header Skeleton */}
        <div className="border-b border-border bg-card h-16 flex items-center px-4">
          <Skeleton className="h-8 w-48" />
        </div>

        {/* Content Skeleton */}
        <div className="flex-1 flex">
          <div className="w-80 border-r border-border p-4 space-y-4">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-10 w-full" />
            <div className="space-y-2">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          </div>
          <div className="flex-1 p-4">
            <Skeleton className="h-full w-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Demo Mode Banner */}
      {demoMode && (
        <div className="bg-blue-600 text-white px-4 py-2 text-center">
          <span className="text-sm">
            You're in demo mode. 
            <button 
              onClick={() => window.location.href = '/?sign-up=true'}
              className="ml-2 underline hover:text-blue-200 font-medium"
            >
              Sign up free
            </button>
            {" "}to save and download your resume.
          </span>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center justify-between h-14 sm:h-16 px-3 sm:px-6">
          <div className="flex items-center space-x-2 sm:space-x-6 min-w-0 flex-1">
            {/* Mobile menu toggle */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden hover:bg-gray-100 p-2 flex-shrink-0"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-4 w-4 sm:h-5 sm:w-5" />
            </Button>

            {/* Logo */}
            <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
              <div className="w-7 h-7 sm:w-9 sm:h-9 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-md flex-shrink-0">
                <CurlyBraceIcon className="text-white" size="sm" />
              </div>
              <span className="text-base sm:text-xl font-semibold text-gray-900 truncate">ResumeFormatter.io</span>
            </div>

            {/* Resume title */}
            <div className="hidden md:flex items-center space-x-3 min-w-0">
              <div className="w-1 h-1 bg-gray-300 rounded-full flex-shrink-0"></div>
              <span className="text-sm text-gray-600 font-medium truncate">{resumeTitle || "Untitled Resume"}</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Auto-save status */}
            <div className="hidden md:flex items-center space-x-2 text-sm">
              <Save className={`h-4 w-4 ${demoMode ? 'text-blue-500' : autoSaveStatus === 'saved' ? 'text-green-500' : 'text-gray-400'}`} />
              <span className={`text-sm ${demoMode ? 'text-blue-600' : autoSaveStatus === 'saved' ? 'text-green-600' : 'text-gray-500'}`}>
                {demoMode && 'Demo Mode'}
                {!demoMode && autoSaveStatus === 'saved' && 'Saved'}
                {!demoMode && autoSaveStatus === 'saving' && 'Saving...'}
                {!demoMode && autoSaveStatus === 'unsaved' && 'Unsaved'}
              </span>
            </div>

            {/* Credits */}
            {user && (user as any).plan === 'free' && (
              <div className="hidden lg:flex items-center space-x-2 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200">
                <Coins className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">{(user as any).credits || 0} credits</span>
              </div>
            )}

            {/* Import button - mobile friendly */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowImporter(true)}
              className="text-blue-600 border-blue-300 hover:bg-blue-50 px-2 sm:px-3"
            >
              <Upload className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Import</span>
            </Button>

            {/* Health Score Toggle */}
            <Button
              variant={showHealthScore ? "default" : "outline"}
              size="sm"
              onClick={() => setShowHealthScore(!showHealthScore)}
              className="hidden lg:flex"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Score
            </Button>

            {/* User menu */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {user && (
                <>
                  <div className="w-7 h-7 sm:w-8 sm:h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-xs sm:text-sm font-medium">
                      {user.firstName?.[0] || user.email?.[0] || "U"}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleLogout} className="hover:bg-gray-100 p-2">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      {/* Checking if window is defined before using window.innerWidth */}
      {typeof window !== 'undefined' && (
        <MobileNavigation
          activeView={window.innerWidth < 768 ? (showPreview ? "preview" : "editor") : "editor"}
          onViewChange={(view) => {
            if (view === "preview") setShowPreview(true);
            else if (view === "editor") setShowPreview(false);
            // Export view is handled within the component
          }}
          onOptimize={() => setShowOptimization(true)}
          onVersions={() => setShowVersions(true)}
          onExport={() => setShowExport(true)}
          onCoverLetter={() => setShowCoverLetter(true)}
          userPlan={user?.plan || "free"}
          autoSaveStatus={autoSaveStatus}
        />
      )}

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden pb-16 lg:pb-0">
        {/* Sidebar */}
        <TemplateSidebar
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          selectedTemplateId={selectedTemplateId}
          onTemplateSelect={setSelectedTemplateId}
          onOptimize={() => setActiveModal("optimization")}
          onVersionHistory={() => setActiveModal("versions")}
          onCoverLetter={() => setActiveModal("cover-letter")}
        />

        {/* Editor and Preview */}
        <div className="flex-1 flex flex-col lg:flex-row min-w-0">
          {/* Mobile layout - single view with tabs */}
          <div className="lg:hidden flex-1 flex flex-col min-h-0">
            {showPreview ? (
              <div className="flex-1 flex flex-col min-h-0">
                <div className="border-b border-border p-3 bg-background flex-shrink-0">
                  <ResumeHealthScore
                    content={resumeContent}
                    title={resumeTitle}
                    onImprove={() => setActiveModal("optimization")}
                  />
                </div>
                <div className="flex-1 overflow-auto">
                  <ResumePreview
                    content={resumeContent}
                    templateId={selectedTemplateId}
                    title={resumeTitle}
                    onExport={() => setActiveModal("export")}
                  />
                </div>
              </div>
            ) : (
              <div className="flex-1 min-h-0">
                <MarkdownEditor
                  content={resumeContent}
                  onChange={setResumeContent}
                  onTitleChange={setResumeTitle}
                  title={resumeTitle}
                  resumeId={resumeId}
                  onAutoSaveStatusChange={setAutoSaveStatus}
                />
              </div>
            )}
          </div>

          {/* Desktop layout */}
          <div className="hidden lg:flex flex-1">
            {/* Editor */}
            <div className="flex-1 border-r border-border">
              <MarkdownEditor
                content={resumeContent}
                onChange={setResumeContent}
                onTitleChange={setResumeTitle}
                title={resumeTitle}
                resumeId={resumeId}
                onAutoSaveStatusChange={setAutoSaveStatus}
              />
            </div>

            {/* Preview Panel */}
            <div className="flex-1 flex flex-col">
              {/* Resume Health Score */}
              {showHealthScore && (
                <div className="border-b border-border p-4">
                  <ResumeHealthScore
                    content={resumeContent}
                    title={resumeTitle}
                    onImprove={() => setActiveModal("optimization")}
                  />
                </div>
              )}

              {/* Contextual Tips */}
              {showTips && (
                <div className="border-b border-border p-4 bg-blue-50/50">
                  <ContextualTooltips
                    content={resumeContent}
                    onClose={() => setShowTips(false)}
                    compact={true}
                    onAction={(action) => {
                      switch (action) {
                        case 'templates':
                          setSidebarOpen(true);
                          break;
                        case 'tips':
                          setShowTips(!showTips);
                          break;
                        case 'health':
                          setShowHealthScore(!showHealthScore);
                          break;
                        case 'optimize':
                          setActiveModal("optimization");
                          break;
                        case 'preview':
                          setShowPreview(!showPreview);
                          break;
                        case 'versions':
                          setActiveModal("versions");
                          break;
                        case 'export':
                          setActiveModal("export");
                          break;
                      }
                    }}
                  />
                </div>
              )}

              {/* Resume Preview */}
              <div className="flex-1 flex flex-col">
                <div className="flex-1">
                  <ResumePreview
                    content={resumeContent}
                    templateId={selectedTemplateId}
                    title={resumeTitle}
                    onExport={() => setActiveModal("export")}
                  />
                </div>

                {/* PrepPair Transfer Section */}
                <div className="border-t border-border p-4 bg-gradient-to-r from-purple-50 to-blue-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-purple-900">Ready to ace your interview?</h3>
                      <p className="text-sm text-purple-700">Send your resume to PrepPair.me for AI-powered interview prep</p>
                    </div>
                    <PrepPairTransfer
                      resumeId={resumeId}
                      resumeTitle={resumeTitle}
                      onSuccess={(url) => window.open(url, '_blank')}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Action Button (Mobile) */}
      <div className="lg:hidden fixed bottom-4 right-4 z-30">
        <Button
          size="lg"
          className="w-14 h-14 rounded-full elevation-3"
          onClick={() => setActiveModal("optimization")}
        >
          <Sparkles className="h-6 w-6" />
        </Button>
      </div>

      {/* Modals */}
      {(activeModal === "optimization") && (
        <OptimizationModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          resumeContent={resumeContent}
          resumeId={resumeId}
          userPlan={(user as any)?.plan || 'free'}
          userCredits={(user as any)?.credits || 0}
        />
      )}

      <SimpleVersionModal
        isOpen={activeModal === "versions"}
        onClose={() => setActiveModal(null)}
        resumeId={parseInt(resumeId || "0")}
        currentContent={resumeContent}
        onRestore={setResumeContent}
      />

      <CoverLetterModal
        isOpen={activeModal === "cover-letter"}
        onClose={() => setActiveModal(null)}
        resumeId={resumeId}
        resumeContent={resumeContent}
      />

      {demoMode ? (
        <DemoExportModal
          isOpen={activeModal === "export"}
          onClose={() => setActiveModal(null)}
          resumeTitle={resumeTitle}
        />
      ) : (
        <ExportModal
          isOpen={activeModal === "export"}
          onClose={() => setActiveModal(null)}
          content={resumeContent}
          templateId={selectedTemplateId}
          title={resumeTitle}
        />
      )}

      {/* Resume Importer Modal */}
      {showImporter && (
        <ResumeImporter
          onImport={handleImportResume}
          onClose={() => setShowImporter(false)}
        />
      )}
    </div>
  );
}