import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Search, 
  FileText, 
  Layout, 
  Download, 
  Sparkles, 
  GitBranch, 
  Mail,
  Smartphone,
  HelpCircle,
  BookOpen,
  ArrowRight,
  Clock,
  Users,
  Star,
  ExternalLink
} from "lucide-react";

interface KnowledgeArticle {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: React.ReactNode;
  route: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  readTime: string;
  featured?: boolean;
}

const knowledgeArticles: KnowledgeArticle[] = [
  {
    id: "markdown-editor",
    title: "Markdown Resume Editor",
    description: "Learn how to write and format your resume using Markdown syntax for professional results.",
    category: "Editing",
    icon: <FileText className="w-5 h-5" />,
    route: "/knowledge-base/markdown-editor",
    difficulty: "Beginner",
    readTime: "3 min",
    featured: true
  },
  {
    id: "template-gallery",
    title: "Professional Templates",
    description: "Browse and apply ATS-friendly templates optimized for different industries and roles.",
    category: "Design",
    icon: <Layout className="w-5 h-5" />,
    route: "/knowledge-base/template-gallery",
    difficulty: "Beginner",
    readTime: "2 min",
    featured: true
  },
  {
    id: "exporting-resumes",
    title: "Export & Download Options",
    description: "Download your resume as PDF, DOCX, or HTML. Perfect for job applications and sharing.",
    category: "Export",
    icon: <Download className="w-5 h-5" />,
    route: "/knowledge-base/exporting",
    difficulty: "Beginner",
    readTime: "2 min"
  },
  {
    id: "resume-optimization",
    title: "AI Resume Optimization",
    description: "Use AI to improve your resume's ATS score and get personalized suggestions.",
    category: "AI Features",
    icon: <Sparkles className="w-5 h-5" />,
    route: "/knowledge-base/resume-optimization",
    difficulty: "Intermediate",
    readTime: "4 min",
    featured: true
  },
  {
    id: "cover-letter-generator",
    title: "AI Cover Letter Generator",
    description: "Generate tailored cover letters that match your resume and target job description.",
    category: "AI Features",
    icon: <Mail className="w-5 h-5" />,
    route: "/knowledge-base/cover-letter-generator",
    difficulty: "Intermediate",
    readTime: "3 min"
  },
  {
    id: "versioning-snapshots",
    title: "Resume Versioning & Snapshots",
    description: "Save multiple versions of your resume and track changes over time.",
    category: "Organization",
    icon: <GitBranch className="w-5 h-5" />,
    route: "/knowledge-base/versioning",
    difficulty: "Intermediate",
    readTime: "3 min"
  },
  {
    id: "mobile-editing",
    title: "Mobile Resume Editing",
    description: "Edit and preview your resume on mobile devices with touch-optimized controls.",
    category: "Mobile",
    icon: <Smartphone className="w-5 h-5" />,
    route: "/knowledge-base/mobile-editing",
    difficulty: "Beginner",
    readTime: "2 min"
  }
];

const categories = ["All", "Editing", "Design", "Export", "AI Features", "Organization", "Mobile", "Basics", "Formatting", "Optimization", "Templates", "Support", "Account"];

export default function KnowledgeBase() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  // Fetch articles from unified support API
  const { data: apiArticles, isLoading } = useQuery({
    queryKey: ['/api/support/articles', { search: searchQuery, category: selectedCategory === "All" ? "" : selectedCategory.toLowerCase() }],
  });

  // Combine local and API articles  
  const allArticles = [
    ...knowledgeArticles,
    ...((apiArticles as any)?.data || []).map((article: any) => ({
      id: article.id,
      title: article.title,
      description: article.content.substring(0, 150) + "...",
      category: article.category.charAt(0).toUpperCase() + article.category.slice(1),
      icon: <FileText className="w-5 h-5" />,
      route: `/knowledge-base/${article.id}`,
      difficulty: article.difficulty || "Beginner",
      readTime: article.readTime || "3 min",
      featured: article.featured || false,
      views: article.views,
      helpful: article.helpful
    }))
  ];

  const filteredArticles = allArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredArticles = allArticles.filter(article => article.featured);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <BookOpen className="w-8 h-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">Knowledge Base</h1>
            </div>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Everything you need to know about building professional resumes with ResumeFormatter.io
            </p>
          </div>

          {/* Search */}
          <div className="max-w-md mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Featured Articles */}
        {selectedCategory === "All" && searchQuery === "" && (
          <div className="mb-12">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-yellow-500" />
              Featured Guides
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredArticles.map((article) => (
                <Link key={article.id} href={article.route}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2 text-blue-600">
                          {article.icon}
                          <Badge variant="secondary" className="text-xs">
                            {article.category}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {article.readTime}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                        {article.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4">{article.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge 
                          variant={article.difficulty === "Beginner" ? "default" : 
                                 article.difficulty === "Intermediate" ? "secondary" : "destructive"}
                          className="text-xs"
                        >
                          {article.difficulty}
                        </Badge>
                        <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* All Articles */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            {selectedCategory === "All" ? "All Articles" : `${selectedCategory} Articles`}
            <span className="text-gray-500 text-sm ml-2">({filteredArticles.length})</span>
          </h2>

          {filteredArticles.length === 0 ? (
            <div className="text-center py-12">
              <HelpCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
              <p className="text-gray-600">Try adjusting your search or category filter.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredArticles.map((article) => (
                <Link key={article.id} href={article.route}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2 text-blue-600">
                          {article.icon}
                          <Badge variant="secondary" className="text-xs">
                            {article.category}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {article.readTime}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                        {article.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4">{article.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge 
                          variant={article.difficulty === "Beginner" ? "default" : 
                                 article.difficulty === "Intermediate" ? "secondary" : "destructive"}
                          className="text-xs"
                        >
                          {article.difficulty}
                        </Badge>
                        <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Quick Help */}
        <div className="mt-12 text-center">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Need More Help?</h3>
              <p className="text-gray-600 mb-4">
                Can't find what you're looking for? Our support team is here to help.
              </p>
              <Button variant="outline" size="sm">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}