import { Link } from "wouter";
import { SignedIn, SignedOut, SignInButton, SignUpButton, UserButton } from "@clerk/clerk-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Footer } from "@/components/ui/footer";
import { HeroWithMockup } from "@/components/blocks/hero-with-mockup";
import { AnimatedTestimonials } from "@/components/blocks/animated-testimonials";
import { getFooterData } from "@/lib/footer-data";
import DemoEditor from "@/components/demo-editor";
import ResumeFeatures from "@/components/ResumeFeatures";
import TemplateShowcase from "@/components/TemplateShowcase";
import Testimonials from "@/components/Testimonials";
import FAQ from "@/components/FAQ";
import { FileText, Sparkles, History, Download, Users, Trophy, ArrowRight, Check, Eye, BookOpen, Play } from "lucide-react";
import { CurlyBraceIcon } from "@/components/ui/curly-brace-icon";
import BlogPreview from "@/components/BlogPreview";
import QuickStartButton from "@/components/QuickStartButton";
import { sampleResumeMarkdown } from "@/components/OnboardingTour";
import ResumeSlogan from "@/components/branding/ResumeSlogan";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/editor";
  };

  const handleQuickStart = (content: string) => {
    // Store sample content in localStorage for the editor
    localStorage.setItem('quickStartContent', content);
    localStorage.setItem('showOnboarding', 'true');
    // Redirect directly to editor for demo experience
    window.location.href = "/editor";
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-100 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            <div className="flex items-center space-x-2 sm:space-x-3 min-w-0 flex-1">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-md flex-shrink-0">
                <CurlyBraceIcon className="text-white" size="sm" />
              </div>
              <span className="text-lg sm:text-2xl font-bold text-gray-900 truncate">ResumeFormatter.io</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-10">
              <a href="#features" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">Pricing</a>
              <a href="#templates" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">Templates</a>
            </nav>

            <div className="flex items-center space-x-4">
              <SignedOut>
                <SignInButton mode="modal">
                  <Button variant="ghost" className="text-gray-600 hover:text-gray-900 font-medium">
                    Sign In
                  </Button>
                </SignInButton>
                <SignUpButton mode="modal">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white px-3 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium shadow-sm hover:shadow-md transition-all duration-200 text-sm sm:text-base flex-shrink-0">
                    <span className="hidden sm:inline">Get Started Free</span>
                    <span className="sm:hidden">Start</span>
                    <ArrowRight className="ml-1 sm:ml-2 h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                </SignUpButton>
              </SignedOut>
              <SignedIn>
                <Link href="/dashboard">
                  <Button variant="ghost" className="text-gray-600 hover:text-gray-900 font-medium">
                    Dashboard
                  </Button>
                </Link>
                <UserButton afterSignOutUrl="/" />
              </SignedIn>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-8 sm:py-16 lg:py-24 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-2xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 leading-tight px-2">
              <ResumeSlogan variant="primary" className="block mb-2" />
              <span className="text-blue-600 block text-lg sm:text-2xl lg:text-3xl font-medium text-gray-700">
                <ResumeSlogan variant="alternate" />
              </span>
            </h1>
            
            <p className="text-base sm:text-xl text-gray-600 mb-6 sm:mb-8 leading-relaxed max-w-3xl mx-auto px-2">
              Build an impressive resume with our AI-powered editor. Choose from professional templates and get hired faster.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-8 sm:mb-12 px-4">
              <SignedOut>
                <SignUpButton mode="modal">
                  <Button 
                    size="lg" 
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 w-full sm:w-auto"
                  >
                    Create Resume Free
                    <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                  </Button>
                </SignUpButton>
                <QuickStartButton
                  onQuickStart={handleQuickStart}
                  variant="outline"
                  size="lg"
                  className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-200 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-lg w-full sm:w-auto"
                />
              </SignedOut>
              <SignedIn>
                <Link href="/editor">
                  <Button 
                    size="lg" 
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 w-full sm:w-auto"
                  >
                    Create New Resume
                    <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button 
                    variant="outline"
                    size="lg"
                    className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-200 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-lg w-full sm:w-auto"
                  >
                    View Dashboard
                  </Button>
                </Link>
              </SignedIn>
            </div>

            {/* Trust Indicators */}
            <div className="relative px-2">
              <div className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-8 mb-8 sm:mb-12">
                <div className="group flex items-center gap-3 bg-white/90 backdrop-blur-sm px-4 sm:px-6 py-3 sm:py-4 rounded-2xl border border-green-100 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 hover:-translate-y-1 relative overflow-hidden w-full sm:w-auto max-w-xs">
                  <div className="absolute inset-0 bg-gradient-to-r from-green-50 to-emerald-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 relative z-10 flex-shrink-0">
                    <Check className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-left relative z-10 min-w-0">
                    <div className="font-semibold text-gray-900 text-sm">No Credit Card</div>
                    <div className="text-xs text-gray-600">Start building instantly</div>
                  </div>
                </div>
                
                <div className="group flex items-center gap-3 bg-white/90 backdrop-blur-sm px-4 sm:px-6 py-3 sm:py-4 rounded-2xl border border-blue-100 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 hover:-translate-y-1 relative overflow-hidden w-full sm:w-auto max-w-xs">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 relative z-10 flex-shrink-0">
                    <FileText className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  </div>
                  <div className="text-left relative z-10 min-w-0">
                    <div className="font-semibold text-gray-900 text-sm">Professional Templates</div>
                    <div className="text-xs text-gray-600">16+ expert designs included</div>
                  </div>
                </div>
                
                <div className="group flex items-center gap-3 bg-white/90 backdrop-blur-sm px-4 sm:px-6 py-3 sm:py-4 rounded-2xl border border-purple-100 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 hover:-translate-y-1 relative overflow-hidden w-full sm:w-auto max-w-xs">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-50 to-violet-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 relative z-10 flex-shrink-0">
                    <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-white animate-pulse" />
                  </div>
                  <div className="text-left relative z-10 min-w-0">
                    <div className="font-semibold text-gray-900 text-sm">AI Optimization</div>
                    <div className="text-xs text-gray-600">Boost your ATS score</div>
                  </div>
                </div>
              </div>
              

            </div>
          </div>
          
          {/* Demo Editor */}
          <div className="max-w-6xl mx-auto">
            <DemoEditor />
          </div>
        </div>
      </section>



      {/* Features Section */}
      <ResumeFeatures />

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-muted-foreground">
              Start free, upgrade when you need more features
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Free Plan */}
            <Card className="elevation-1">
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Free</h3>
                  <div className="text-4xl font-bold text-primary mb-2">$0</div>
                  <p className="text-muted-foreground">Perfect for getting started</p>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Markdown editor with live preview</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>3 professional templates</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>PDF export with watermark</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>2 AI optimization credits</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Basic version control</span>
                  </li>
                </ul>

                <Button onClick={handleLogin} className="w-full ripple" variant="outline">
                  Get Started Free
                </Button>
              </CardContent>
            </Card>

            {/* Watermark Removal */}
            <Card className="elevation-1">
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Clean Export</h3>
                  <div className="text-4xl font-bold text-primary mb-2">$3.99</div>
                  <p className="text-muted-foreground">one-time purchase</p>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Everything in Free</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Remove ResumeFormatter.io watermark</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Clean, professional exports</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Lifetime watermark removal</span>
                  </li>
                </ul>

                <Button onClick={handleLogin} className="w-full ripple" variant="outline">
                  Remove Watermark
                </Button>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="elevation-2 border-primary relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <Badge className="bg-primary text-white">Most Popular</Badge>
              </div>
              
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Pro</h3>
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="text-4xl font-bold text-primary">$9.99</div>
                    <div className="text-sm text-muted-foreground">
                      <div className="line-through">$29.97</div>
                      <div className="text-green-600 font-semibold">Save 25%</div>
                    </div>
                  </div>
                  <p className="text-muted-foreground">per month (quarterly: $22.47)</p>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Everything in Free + Clean Export</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>12+ premium templates</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>DOCX & HTML export</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Unlimited AI optimization</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>AI cover letter generation</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Advanced version control</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>Priority support</span>
                  </li>
                </ul>

                <Button onClick={handleLogin} className="w-full ripple">
                  Start Pro Trial
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* AI Credits Add-on */}
          <div className="mt-12 max-w-2xl mx-auto">
            <Card className="elevation-1 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
              <CardContent className="pt-6 text-center">
                <h3 className="text-xl font-bold text-foreground mb-2">Need More AI Credits?</h3>
                <p className="text-muted-foreground mb-4">
                  Get 2 additional AI optimization credits for just $1.50
                </p>
                <div className="flex items-center justify-center space-x-4">
                  <div className="text-2xl font-bold text-primary">$1.50</div>
                  <div className="text-muted-foreground">for 2 AI credits</div>
                </div>
                <Button onClick={handleLogin} className="mt-4 ripple" variant="outline">
                  Buy AI Credits
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Template Showcase */}
      <TemplateShowcase />

      {/* Testimonials Section */}
      <Testimonials />

      {/* FAQ Section */}
      <FAQ />

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-blue-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4 text-white">
            Ready to Build Your Perfect Resume?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of professionals who've already transformed their careers with ResumeFormatter.io
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            className="bg-white text-blue-800 hover:bg-blue-50 px-8 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
          >
            Get Started Now - It's Free
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Blog Preview Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <BookOpen className="text-white w-6 h-6" />
              </div>
              <h2 className="text-4xl font-bold text-gray-900">The Formatting Desk</h2>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Your home base for resume mastery. Get practical guides, formatting tricks, and AI-driven insights 
              to help you build resumes that stand out.
            </p>
          </div>

          <BlogPreview />

          <div className="text-center mt-12">
            <Link href="/blog">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                Visit The Formatting Desk
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <FileText className="h-4 w-4 text-white" />
              </div>
              <span className="text-xl font-semibold text-foreground">ResumeFormatter.io</span>
            </div>
            
            <nav className="flex items-center space-x-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-primary transition-colors">Support</a>
            </nav>
          </div>
          
          <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
            © 2024 ResumeFormatter.io. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}