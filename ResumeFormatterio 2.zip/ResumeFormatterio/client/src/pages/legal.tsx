import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  FileText, 
  ArrowRight, 
  Shield, 
  Cookie, 
  Database, 
  Scale,
  FileCheck,
  Clock,
  Loader2
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface LegalPage {
  slug: string;
  title: string;
  content: string;
}

interface LegalVariables {
  appName: string;
  appUrl: string;
  supportEmail: string;
  supportCenterUrl: string;
  knowledgeBaseUrl: string;
  appFeatures: string[];
  legalPages: Array<{ name: string; route: string }>;
}

export default function Legal() {
  const handleGetStarted = () => {
    window.location.href = "/";
  };

  // SEO Meta Tags
  useEffect(() => {
    document.title = "Legal Policies & Terms | ResumeFormatter.io";

    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', 'Review ResumeFormatter.io\'s comprehensive legal policies including Privacy Policy, Cookie Policy, Terms of Service, and Data Retention Policy.');

    return () => {
      document.title = "ResumeFormatter.io";
    };
  }, []);

  // Fetch legal pages from WordPress
  const { data: legalPages, isLoading: pagesLoading } = useQuery<LegalPage[]>({
    queryKey: ["/api/legal/pages"],
    queryFn: async () => {
      const response = await fetch("/api/legal/pages");
      if (!response.ok) {
        throw new Error("Failed to fetch legal pages");
      }
      const data = await response.json();
      return data.data;
    }
  });

  // Fetch legal variables
  const { data: variables } = useQuery<LegalVariables>({
    queryKey: ["/api/legal/variables"],
    queryFn: async () => {
      const response = await fetch("/api/legal/variables");
      if (!response.ok) {
        throw new Error("Failed to fetch legal variables");
      }
      const data = await response.json();
      return data.data;
    }
  });

  const legalSections = [
    {
      id: "privacy",
      title: "Privacy Policy",
      icon: <Shield className="h-5 w-5" />,
      lastUpdated: "December 2024",
      description: "How we collect, use, and protect your personal information"
    },
    {
      id: "cookies",
      title: "Cookie Policy", 
      icon: <Cookie className="h-5 w-5" />,
      lastUpdated: "December 2024",
      description: "Our use of cookies and similar tracking technologies"
    },
    {
      id: "terms",
      title: "Terms of Service",
      icon: <FileCheck className="h-5 w-5" />,
      lastUpdated: "December 2024", 
      description: "Terms and conditions for using ResumeFormatter.io"
    },
    {
      id: "data-retention",
      title: "Data Retention Policy",
      icon: <Database className="h-5 w-5" />,
      lastUpdated: "December 2024",
      description: "How long we keep your data and when we delete it"
    }
  ];

  if (pagesLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading legal content...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {variables?.appName || "ResumeFormatter.io"}
              </span>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
              <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="/pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
              <a href="/templates" className="text-muted-foreground hover:text-primary transition-colors">Templates</a>
              <a href="/legal" className="text-primary font-medium">Legal</a>
            </nav>

            <Button onClick={handleGetStarted} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200">
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-700 border-blue-200">
            Legal Information
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Legal Policies & Terms
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Transparency and trust are fundamental to our relationship with you. 
            Review our comprehensive legal policies to understand your rights and our commitments.
          </p>
        </div>
      </section>

      {/* Legal Policies Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {legalSections.map((section) => (
              <Card key={section.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4 text-blue-600">
                    {section.icon}
                  </div>
                  <h3 className="font-semibold mb-2">{section.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{section.description}</p>
                  <div className="flex items-center justify-center space-x-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>Updated {section.lastUpdated}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Legal Documents from WordPress */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {legalPages && legalPages.length > 0 ? (
            <Accordion type="single" collapsible className="space-y-4">
              {legalPages.map((page, index) => (
                <AccordionItem key={page.slug} value={page.slug} className="bg-white rounded-lg shadow-sm border-0">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline">
                    <div className="flex items-center space-x-3">
                      {index === 0 && <Shield className="h-5 w-5 text-blue-600" />}
                      {index === 1 && <Cookie className="h-5 w-5 text-orange-600" />}
                      {index === 2 && <FileCheck className="h-5 w-5 text-green-600" />}
                      {index === 3 && <Database className="h-5 w-5 text-purple-600" />}
                      {index > 3 && <Scale className="h-5 w-5 text-gray-600" />}
                      <div className="text-left">
                        <div className="font-semibold">{page.title}</div>
                        <div className="text-sm text-muted-foreground">Content from WordPress</div>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6">
                    <div 
                      className="prose prose-sm max-w-none text-muted-foreground"
                      dangerouslySetInnerHTML={{ __html: page.content }}
                    />
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                Legal content is being loaded from WordPress. Please check back shortly.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Questions About Our Policies?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            We're committed to transparency. If you have any questions about our legal policies, please don't hesitate to reach out.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={() => window.location.href = variables?.supportCenterUrl || "/contact"} 
              variant="outline" 
              size="lg"
            >
              Contact Support
            </Button>
            <Button onClick={handleGetStarted} size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">{variables?.appName || "ResumeFormatter.io"}</span>
              </div>
              <p className="text-gray-400 max-w-md">
                The most powerful resume builder for modern professionals. Create ATS-compliant resumes that get you hired.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="/pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/templates" className="hover:text-white transition-colors">Templates</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                {variables?.legalPages?.map((page) => (
                  <li key={page.route}>
                    <a href={page.route} className="hover:text-white transition-colors">
                      {page.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 {variables?.appName || "ResumeFormatter.io"}. All rights reserved. A Wrelik Brands, LLC product.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}