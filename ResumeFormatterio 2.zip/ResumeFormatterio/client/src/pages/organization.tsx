import { useOrganization, useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { OrganizationProfileRedirect, CreateOrganizationRedirect } from "@/components/AuthRedirects";
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Users, Building, Settings, Plus, Crown, Shield } from "lucide-react";

export default function Organization() {
  const { organization, isLoaded: orgLoaded } = useOrganization();
  const { user, isLoaded: userLoaded } = useUser();
  const [showOrgEditor, setShowOrgEditor] = useState(false);
  const [showCreateOrg, setShowCreateOrg] = useState(false);

  if (!orgLoaded || !userLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (showCreateOrg) {
    return <CreateOrganizationRedirect />;
  }

  if (showOrgEditor) {
    return <OrganizationProfileRedirect />;
  }

  if (!organization) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="text-center p-12">
            <CardContent>
              <Building className="h-16 w-16 mx-auto text-gray-400 mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                No Organization Found
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-md mx-auto">
                Create or join an organization to collaborate with team members on resume projects and manage shared resources.
              </p>
              <Button 
                onClick={() => setShowCreateOrg(true)}
                className="flex items-center gap-2 mx-auto"
              >
                <Plus className="h-4 w-4" />
                Create Organization
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const userRole = organization.membersCount ? "Admin" : "Member";
  const isAdmin = userRole === "Admin";

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Organization Header */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border p-8 mb-6">
          <div className="flex items-center space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={organization.imageUrl} alt={organization.name} />
              <AvatarFallback className="text-xl">
                {organization.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {organization.name}
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                {organization.slug}
              </p>
              <div className="flex items-center gap-2 mt-3">
                <Badge variant="secondary" className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {organization.membersCount} members
                </Badge>
                <Badge variant={isAdmin ? "default" : "outline"} className="flex items-center gap-1">
                  {isAdmin ? <Crown className="h-3 w-3" /> : <Shield className="h-3 w-3" />}
                  {userRole}
                </Badge>
              </div>
            </div>

            {isAdmin && (
              <Button 
                onClick={() => setShowOrgEditor(true)}
                className="flex items-center gap-2"
              >
                <Settings className="h-4 w-4" />
                Manage Organization
              </Button>
            )}
          </div>
        </div>

        {/* Organization Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                    Team Members
                  </p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white">
                    {organization.membersCount}
                  </p>
                </div>
                <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                    Shared Resumes
                  </p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white">
                    24
                  </p>
                </div>
                <div className="h-12 w-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
                  <Building className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                    Templates
                  </p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white">
                    8
                  </p>
                </div>
                <div className="h-12 w-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
                  <Settings className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Organization Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Organization Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Organization Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Organization Name
                </label>
                <p className="text-gray-900 dark:text-white mt-1">
                  {organization.name}
                </p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Organization ID
                </label>
                <p className="text-gray-900 dark:text-white mt-1 font-mono text-sm">
                  {organization.id}
                </p>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Slug
                </label>
                <p className="text-gray-900 dark:text-white mt-1">
                  {organization.slug}
                </p>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Created
                </label>
                <p className="text-gray-900 dark:text-white mt-1">
                  {organization.createdAt ? new Date(organization.createdAt).toLocaleDateString() : "Not available"}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Team Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Team Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Your Role
                </label>
                <div className="flex items-center gap-2 mt-1">
                  <p className="text-gray-900 dark:text-white">{userRole}</p>
                  <Badge variant={isAdmin ? "default" : "secondary"}>
                    {isAdmin ? "Administrator" : "Member"}
                  </Badge>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Total Members
                </label>
                <p className="text-gray-900 dark:text-white mt-1">
                  {organization.membersCount} active members
                </p>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Permissions
                </label>
                <div className="flex flex-wrap gap-1 mt-1">
                  <Badge variant="outline">View Resumes</Badge>
                  <Badge variant="outline">Create Resumes</Badge>
                  {isAdmin && <Badge variant="outline">Manage Team</Badge>}
                </div>
              </div>

              {isAdmin && (
                <Button 
                  variant="outline" 
                  className="w-full mt-4"
                  onClick={() => setShowOrgEditor(true)}
                >
                  Manage Members
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Organization Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <Button variant="outline" className="h-20 flex-col gap-2">
                <Users className="h-5 w-5" />
                View Members
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <Building className="h-5 w-5" />
                Shared Projects
              </Button>
              {isAdmin && (
                <>
                  <Button 
                    variant="outline" 
                    className="h-20 flex-col gap-2"
                    onClick={() => setShowOrgEditor(true)}
                  >
                    <Settings className="h-5 w-5" />
                    Organization Settings
                  </Button>
                  <Button variant="outline" className="h-20 flex-col gap-2">
                    <Plus className="h-5 w-5" />
                    Invite Members
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}