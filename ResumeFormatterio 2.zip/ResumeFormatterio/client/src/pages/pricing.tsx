import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Check, 
  ArrowRight, 
  Sparkles, 
  Crown, 
  Zap,
  Download,
  History,
  Mail
} from "lucide-react";

export default function Pricing() {
  const handleGetStarted = () => {
    window.location.href = "/";
  };

  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "forever",
      description: "Perfect for getting started with basic resume creation",
      badge: null,
      buttonText: "Start Free",
      buttonVariant: "outline" as const,
      features: [
        "Unlimited resume editing",
        "Markdown-based editor",
        "Real-time preview",
        "Basic templates",
        "Export with watermark",
        "Community support"
      ],
      limitations: [
        "Watermark on exports",
        "No AI optimization",
        "No cover letter generation",
        "Basic templates only"
      ]
    },
    {
      name: "One-Time Pro",
      price: "$3.99",
      period: "one-time",
      description: "Remove watermarks and unlock professional features",
      badge: "Most Popular",
      buttonText: "Remove Watermark",
      buttonVariant: "default" as const,
      features: [
        "Everything in Free",
        "Watermark-free exports",
        "Premium templates",
        "Priority support",
        "Professional formatting",
        "Multiple export formats"
      ],
      limitations: [
        "No AI optimization credits",
        "No cover letter generation"
      ]
    },
    {
      name: "AI Credits",
      price: "$1.50",
      period: "per 2 credits",
      description: "Unlock AI-powered resume optimization and cover letters",
      badge: "Best Value",
      buttonText: "Buy AI Credits",
      buttonVariant: "default" as const,
      features: [
        "AI resume optimization",
        "ATS compatibility scoring",
        "Keyword suggestions",
        "Cover letter generation",
        "Industry-specific tips",
        "Content enhancement"
      ],
      limitations: [
        "Credits consumed per use",
        "Requires separate purchase"
      ]
    }
  ];

  const quarterlyDiscount = {
    title: "Quarterly AI Package",
    originalPrice: "$18.00",
    discountedPrice: "$13.50",
    savings: "25% OFF",
    credits: "24 AI credits",
    description: "Perfect for job seekers who want regular AI assistance"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">ResumeFormatter.io</span>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
              <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="/pricing" className="text-primary font-medium">Pricing</a>
              <a href="/templates" className="text-muted-foreground hover:text-primary transition-colors">Templates</a>
            </nav>

            <Button onClick={handleGetStarted} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200">
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-green-100 text-green-700 border-green-200">
            Simple & Transparent Pricing
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Choose Your Perfect Plan
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Start free and upgrade only when you need advanced features. No subscriptions, no hidden fees.
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {plans.map((plan, index) => (
              <Card key={index} className={`relative border-0 shadow-lg hover:shadow-xl transition-all duration-300 ${plan.badge ? 'ring-2 ring-blue-500 scale-105' : ''}`}>
                {plan.badge && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      {plan.badge}
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-2xl font-bold mb-2">{plan.name}</CardTitle>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground ml-2">/{plan.period}</span>
                  </div>
                  <p className="text-muted-foreground">{plan.description}</p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <Button 
                    onClick={handleGetStarted}
                    variant={plan.buttonVariant}
                    className="w-full"
                    size="lg"
                  >
                    {plan.buttonText}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>

                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold mb-2 text-green-700">What's included:</h4>
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2 mb-1">
                          <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>

                    {plan.limitations.length > 0 && (
                      <div>
                        <h4 className="font-semibold mb-2 text-gray-500">Limitations:</h4>
                        {plan.limitations.map((limitation, limitationIndex) => (
                          <div key={limitationIndex} className="flex items-center space-x-2 mb-1">
                            <div className="h-4 w-4 flex-shrink-0 flex items-center justify-center">
                              <div className="h-1 w-1 bg-gray-400 rounded-full"></div>
                            </div>
                            <span className="text-sm text-gray-500">{limitation}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quarterly Discount */}
          <div className="max-w-4xl mx-auto">
            <Card className="border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50 shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-yellow-100 rounded-full">
                      <Crown className="h-8 w-8 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-yellow-800">{quarterlyDiscount.title}</h3>
                      <p className="text-yellow-700">{quarterlyDiscount.description}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-lg font-semibold text-yellow-800">{quarterlyDiscount.credits}</span>
                        <Badge className="bg-yellow-200 text-yellow-800">
                          {quarterlyDiscount.savings}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-gray-500 line-through text-lg">{quarterlyDiscount.originalPrice}</div>
                    <div className="text-3xl font-bold text-yellow-800">{quarterlyDiscount.discountedPrice}</div>
                    <Button 
                      onClick={handleGetStarted}
                      className="mt-3 bg-yellow-600 hover:bg-yellow-700 text-white"
                    >
                      Get Quarterly Package
                      <Sparkles className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Feature Comparison</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              See exactly what's included in each plan
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4 font-semibold">Feature</th>
                  <th className="text-center p-4 font-semibold">Free</th>
                  <th className="text-center p-4 font-semibold">Pro ($3.99)</th>
                  <th className="text-center p-4 font-semibold">AI Credits ($1.50)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="p-4 font-medium">Markdown Editor</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="p-4 font-medium">Real-time Preview</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="p-4 font-medium">Watermark-free Export</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                </tr>
                <tr>
                  <td className="p-4 font-medium">Premium Templates</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                </tr>
                <tr>
                  <td className="p-4 font-medium">AI Optimization</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="p-4 font-medium">Cover Letter Generation</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4 text-gray-400">✗</td>
                  <td className="text-center p-4"><Check className="h-5 w-5 text-green-500 mx-auto" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">How does the free plan work?</h3>
              <p className="text-muted-foreground">The free plan includes full access to our Markdown editor, real-time preview, and basic templates. Exports will include a small watermark.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">What happens when I run out of AI credits?</h3>
              <p className="text-muted-foreground">You can continue using all other features. To use AI optimization and cover letter generation again, simply purchase more credits.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Can I combine the Pro upgrade with AI credits?</h3>
              <p className="text-muted-foreground">Yes! The Pro upgrade and AI credits are separate purchases. You can buy both to get the complete experience.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Do AI credits expire?</h3>
              <p className="text-muted-foreground">No, AI credits never expire. Use them whenever you need AI assistance with your resume or cover letters.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Build Your Perfect Resume?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Start for free and upgrade when you need advanced features. No commitments, no subscriptions.
          </p>
          <Button 
            onClick={handleGetStarted}
            size="lg" 
            className="bg-white text-blue-600 hover:bg-gray-50 shadow-lg hover:shadow-xl transition-all duration-200"
          >
            Start Building for Free
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">ResumeFormatter.io</span>
              </div>
              <p className="text-gray-400 max-w-md">
                The most powerful resume builder for modern professionals. Create ATS-compliant resumes that get you hired.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="/pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/templates" className="hover:text-white transition-colors">Templates</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="/legal" className="hover:text-white transition-colors">Legal</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/support" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="/knowledge-base" className="hover:text-white transition-colors">Knowledge Base</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact Support</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 ResumeFormatter.io. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}