import React, { useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  ArrowRight, 
  Shield, 
  Lock, 
  Eye, 
  Database,
  UserCheck,
  Globe,
  Loader2
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Privacy() {
  const handleGetStarted = () => {
    window.location.href = "/";
  };

  // Fetch privacy policy content from WordPress
  const { data: privacyContent, isLoading } = useQuery<string>({
    queryKey: ["/api/legal/pages/privacy-policy"],
    queryFn: async () => {
      const response = await fetch("/api/legal/pages/privacy-policy");
      if (!response.ok) {
        throw new Error("Failed to fetch privacy policy");
      }
      const data = await response.json();
      return data.data.content;
    }
  });

  // Fetch legal variables
  const { data: variables } = useQuery({
    queryKey: ["/api/legal/variables"],
    queryFn: async () => {
      const response = await fetch("/api/legal/variables");
      if (!response.ok) {
        throw new Error("Failed to fetch legal variables");
      }
      const data = await response.json();
      return data.data;
    }
  });

  const principles = [
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: "Data Protection",
      description: "Your personal information is encrypted and stored securely using industry-standard protocols."
    },
    {
      icon: <Lock className="h-8 w-8 text-green-600" />,
      title: "Secure Storage",
      description: "All resume data is encrypted both in transit and at rest using AES-256 encryption."
    },
    {
      icon: <Eye className="h-8 w-8 text-purple-600" />,
      title: "Transparency",
      description: "We clearly explain what data we collect, how we use it, and who we share it with."
    },
    {
      icon: <UserCheck className="h-8 w-8 text-orange-600" />,
      title: "Your Control",
      description: "You maintain full control over your data with options to export, modify, or delete at any time."
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading privacy policy...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {variables?.appName || "ResumeFormatter.io"}
              </span>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
              <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="/pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
              <a href="/templates" className="text-muted-foreground hover:text-primary transition-colors">Templates</a>
              <a href="/privacy" className="text-primary font-medium">Privacy</a>
            </nav>

            <Button onClick={handleGetStarted} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200">
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-green-100 text-green-700 border-green-200">
            Privacy Policy
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Your Privacy Matters
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-4">
            We are committed to protecting your personal information and being transparent about how we collect, use, and share your data.
          </p>
          <p className="text-sm text-muted-foreground">
            Last updated: December 2024
          </p>
        </div>
      </section>

      {/* Privacy Principles */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Privacy Principles</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              The foundation of how we handle your personal information
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {principles.map((principle, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 text-center">
                <CardContent className="p-8">
                  <div className="flex justify-center mb-4">
                    {principle.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{principle.title}</h3>
                  <p className="text-muted-foreground">{principle.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Privacy Policy Content from WordPress */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {privacyContent ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8">
                <div 
                  className="prose prose-lg max-w-none"
                  dangerouslySetInnerHTML={{ __html: privacyContent }}
                />
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                Privacy policy content is being loaded from WordPress. Please check back shortly.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Build Your Resume Securely?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Your data is safe with us. Start creating your professional resume with confidence.
          </p>
          <Button 
            onClick={handleGetStarted}
            size="lg" 
            className="bg-white text-blue-600 hover:bg-gray-50 shadow-lg hover:shadow-xl transition-all duration-200"
          >
            Get Started Securely
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">{variables?.appName || "ResumeFormatter.io"}</span>
              </div>
              <p className="text-gray-400 max-w-md">
                The most powerful resume builder for modern professionals. Create ATS-compliant resumes that get you hired.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="/pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/templates" className="hover:text-white transition-colors">Templates</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/about" className="hover:text-white transition-colors">About</a></li>
                <li><a href={variables?.supportCenterUrl || "/contact"} className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="/legal" className="hover:text-white transition-colors">Legal</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 {variables?.appName || "ResumeFormatter.io"}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}