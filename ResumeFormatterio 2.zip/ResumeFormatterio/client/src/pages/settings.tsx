import { useUser, useClerk } from "@clerk/clerk-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserProfileRedirect } from "@/components/AuthRedirects";
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon, 
  User, 
  Shield, 
  CreditCard, 
  Bell, 
  Smartphone, 
  Mail, 
  Globe,
  Key,
  Download,
  Trash2,
  ExternalLink
} from "lucide-react";

export default function Settings() {
  const { user, isLoaded } = useUser();
  const { openUserProfile } = useClerk();
  const [showProfileEditor, setShowProfileEditor] = useState(false);

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <UserProfileRedirect />;
  }

  if (showProfileEditor) {
    return <UserProfileRedirect />;
  }

  const handleOpenProfile = () => {
    openUserProfile();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Account Settings</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Manage your account preferences, security settings, and profile information.
          </p>
        </div>

        {/* Profile Overview */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={user.imageUrl} alt={user.fullName || "User"} />
                <AvatarFallback className="text-lg">
                  {user.firstName?.[0]}{user.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {user.fullName || "Welcome"}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {user.primaryEmailAddress?.emailAddress}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="secondary">Professional Plan</Badge>
                  <Badge variant="outline">Verified</Badge>
                </div>
              </div>

              <Button onClick={handleOpenProfile} className="flex items-center gap-2">
                <SettingsIcon className="h-4 w-4" />
                Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Settings Categories */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Account Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Account Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Profile Information</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Update your personal details and profile picture
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Email Preferences</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Manage notification and communication settings
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>

              <Separator />

              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Connected Accounts</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Link social accounts and external services
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Security Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security & Privacy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Password & Authentication</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Change password and manage 2FA settings
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Active Sessions</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    View and manage your active login sessions
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>

              <Separator />

              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Privacy Settings</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Control who can see your profile and data
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleOpenProfile}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Subscription & Billing */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Subscription & Billing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Current Plan</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Professional Plan - $29/month
                  </p>
                </div>
                <Badge variant="secondary">Active</Badge>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Payment Method</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    •••• •••• •••• 4242
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Update
                </Button>
              </div>

              <Separator />

              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Billing History</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    View past invoices and payments
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Resume updates, job matches, and tips
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Configure
                </Button>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">Push Notifications</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Browser and mobile app notifications
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Configure
                </Button>
              </div>

              <Separator />

              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">SMS Notifications</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Important account and security alerts
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Configure
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button 
                variant="outline" 
                className="h-20 flex-col gap-2"
                onClick={handleOpenProfile}
              >
                <User className="h-5 w-5" />
                Edit Profile
              </Button>
              <Button 
                variant="outline" 
                className="h-20 flex-col gap-2"
                onClick={handleOpenProfile}
              >
                <Shield className="h-5 w-5" />
                Security Settings
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <Download className="h-5 w-5" />
                Export Data
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 text-red-600 hover:text-red-700">
                <Trash2 className="h-5 w-5" />
                Delete Account
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Account Portal Info */}
        <Card className="mt-8 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Globe className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                  Account Portal Integration
                </h3>
                <p className="text-blue-800 dark:text-blue-200 text-sm mb-4">
                  Your account is managed through our secure Account Portal, providing comprehensive 
                  authentication, profile management, and security features with minimal setup required.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleOpenProfile}
                  className="border-blue-200 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open Account Portal
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}