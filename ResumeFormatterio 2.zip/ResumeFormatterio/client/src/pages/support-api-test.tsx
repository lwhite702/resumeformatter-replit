import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, Database, Search, BarChart3 } from "lucide-react";

export default function SupportApiTest() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");

  // Test health endpoint
  const { data: health } = useQuery({
    queryKey: ['/api/support/health'],
  });

  // Test articles endpoint
  const { data: articles, refetch: refetchArticles } = useQuery({
    queryKey: ['/api/support/articles', { search: searchTerm, category: selectedCategory }],
    enabled: false,
  });

  // Test analytics endpoint
  const { data: analytics } = useQuery({
    queryKey: ['/api/support/analytics'],
  });

  const handleSearch = () => {
    refetchArticles();
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Support API Integration Test</h1>
          <p className="text-muted-foreground">
            Testing ResumeFormatter.io Knowledge Base & Support API for Wrelik.com Integration
          </p>
        </div>

        {/* Health Check */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              API Health Status
            </CardTitle>
            <CardDescription>
              Current status of the support API and its integrations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {health ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant={health.status === 'healthy' ? 'default' : 'destructive'}>
                    {health.status}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {health.service} v{health.version}
                  </span>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Available Features:</h4>
                  <div className="flex flex-wrap gap-1">
                    {health.features?.map((feature: string) => (
                      <Badge key={feature} variant="outline">
                        {feature.replace('_', ' ')}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Integrations:</h4>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    {Object.entries(health.integrations || {}).map(([key, status]) => (
                      <div key={key} className="flex items-center gap-2">
                        <Database className="h-4 w-4" />
                        <span className="capitalize">{key}:</span>
                        <Badge variant={status === 'connected' || status === 'configured' ? 'default' : 'secondary'}>
                          {status as string}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">Loading health status...</p>
            )}
          </CardContent>
        </Card>

        {/* Knowledge Base Search */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Knowledge Base Search
            </CardTitle>
            <CardDescription>
              Search through available support articles and documentation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 border rounded-md bg-background"
              >
                <option value="">All Categories</option>
                <option value="basics">Basics</option>
                <option value="formatting">Formatting</option>
                <option value="optimization">Optimization</option>
                <option value="templates">Templates</option>
                <option value="export">Export</option>
                <option value="ai">AI Features</option>
              </select>
              <Button onClick={handleSearch}>Search</Button>
            </div>

            {articles && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Found {articles.total} articles
                </p>
                <div className="grid gap-3">
                  {articles.data?.map((article: any) => (
                    <div key={article.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-start justify-between">
                        <h4 className="font-medium">{article.title}</h4>
                        <Badge variant="outline">{article.category}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{article.content}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>Views: {article.views}</span>
                        <span>Helpful: {article.helpful}</span>
                        <span>Updated: {article.lastUpdated}</span>
                      </div>
                      <div className="flex gap-1">
                        {article.tags?.map((tag: string) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Support Analytics
            </CardTitle>
            <CardDescription>
              Platform metrics for support team insights
            </CardDescription>
          </CardHeader>
          <CardContent>
            {analytics ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Users</h4>
                  <div className="text-2xl font-bold">{analytics.data.users.total}</div>
                  <p className="text-sm text-muted-foreground">
                    {analytics.data.users.active} active
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Resumes</h4>
                  <div className="text-2xl font-bold">{analytics.data.resumes.total}</div>
                  <p className="text-sm text-muted-foreground">
                    {analytics.data.resumes.createdThisWeek} this week
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Support</h4>
                  <div className="text-2xl font-bold">{analytics.data.support.ticketsOpen}</div>
                  <p className="text-sm text-muted-foreground">
                    open tickets
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Satisfaction</h4>
                  <div className="text-2xl font-bold">{analytics.data.support.satisfactionScore}</div>
                  <p className="text-sm text-muted-foreground">
                    out of 5.0
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-muted-foreground">Loading analytics...</p>
            )}
          </CardContent>
        </Card>

        <Separator />

        <div className="text-center space-y-2">
          <h3 className="text-lg font-medium">Integration Status</h3>
          <p className="text-sm text-muted-foreground">
            The Knowledge Base & Support API is ready for Wrelik.com unified support desk integration.
            All endpoints are functional and returning real data from the ResumeFormatter.io platform.
          </p>
        </div>
      </div>
    </div>
  );
}