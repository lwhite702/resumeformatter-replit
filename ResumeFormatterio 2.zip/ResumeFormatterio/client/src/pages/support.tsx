import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  HelpCircle, 
  FileText, 
  Download, 
  Sparkles, 
  History, 
  Mail,
  Book,
  MessageCircle,
  ExternalLink,
  ChevronRight
} from "lucide-react";
import Header from "@/components/Header";

export default function Support() {
  const helpArticles = [
    {
      category: "Getting Started",
      articles: [
        {
          title: "Creating Your First Resume",
          description: "Learn how to create and format your resume using our Markdown editor",
          readTime: "3 min read"
        },
        {
          title: "Understanding Markdown Syntax",
          description: "Complete guide to formatting your resume with Markdown",
          readTime: "5 min read"
        },
        {
          title: "Choosing the Right Template",
          description: "How to select templates that match your industry and experience level",
          readTime: "2 min read"
        }
      ]
    },
    {
      category: "Templates & Formatting",
      articles: [
        {
          title: "Template Categories Explained",
          description: "Understanding different template styles and when to use them",
          readTime: "4 min read"
        },
        {
          title: "Customizing Template Colors",
          description: "How to personalize your resume template appearance",
          readTime: "3 min read"
        },
        {
          title: "Mobile vs Desktop Templates",
          description: "Ensuring your resume looks great on all devices",
          readTime: "2 min read"
        }
      ]
    },
    {
      category: "Exporting & Sharing",
      articles: [
        {
          title: "Export Formats Guide",
          description: "Understanding PDF, DOCX, and HTML export options",
          readTime: "3 min read"
        },
        {
          title: "ATS-Friendly Exports",
          description: "Best practices for creating resumes that pass ATS systems",
          readTime: "6 min read"
        },
        {
          title: "Sharing Your Resume",
          description: "How to share your resume with employers and recruiters",
          readTime: "2 min read"
        }
      ]
    },
    {
      category: "AI Features",
      articles: [
        {
          title: "Resume Optimization",
          description: "Using AI to improve your resume for specific job postings",
          readTime: "5 min read"
        },
        {
          title: "Understanding ATS Scores",
          description: "How to interpret and improve your ATS compatibility score",
          readTime: "4 min read"
        },
        {
          title: "Cover Letter Generation",
          description: "Creating personalized cover letters with AI assistance",
          readTime: "3 min read"
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Help & Support Center
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions, learn how to use our features, and get the help you need.
          </p>
        </div>

        <Tabs defaultValue="help" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="help" className="flex items-center space-x-2">
              <Book className="h-4 w-4" />
              <span>Help Articles</span>
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center space-x-2">
              <MessageCircle className="h-4 w-4" />
              <span>Contact Support</span>
            </TabsTrigger>
            <TabsTrigger value="faq" className="flex items-center space-x-2">
              <HelpCircle className="h-4 w-4" />
              <span>FAQ</span>
            </TabsTrigger>
          </TabsList>

          {/* Help Articles */}
          <TabsContent value="help" className="space-y-8">
            {helpArticles.map((category) => (
              <div key={category.category} className="space-y-4">
                <h2 className="text-xl font-semibold text-gray-900">
                  {category.category}
                </h2>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {category.articles.map((article) => (
                    <Card key={article.title} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <FileText className="h-5 w-5 text-blue-600 flex-shrink-0" />
                          <Badge variant="secondary" className="text-xs">
                            {article.readTime}
                          </Badge>
                        </div>
                        <h3 className="font-medium text-gray-900 mb-2">
                          {article.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-3">
                          {article.description}
                        </p>
                        <div className="flex items-center text-blue-600 text-sm font-medium">
                          Read article
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          {/* Contact Support */}
          <TabsContent value="contact" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="h-5 w-5" />
                  <span>Contact Our Support Team</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name
                    </label>
                    <Input placeholder="Your full name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email
                    </label>
                    <Input type="email" placeholder="your.email@example.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <Input placeholder="How can we help you?" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <Textarea 
                    placeholder="Please describe your question or issue in detail..."
                    rows={6}
                  />
                </div>
                <Button className="w-full">
                  Send Message
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* FAQ */}
          <TabsContent value="faq" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">General Questions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Is ResumeFormatter.io free to use?
                    </h4>
                    <p className="text-sm text-gray-600">
                      Yes! You can create and edit resumes for free. Pro features like advanced templates and AI optimization require a subscription.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      What's the difference between free and pro plans?
                    </h4>
                    <p className="text-sm text-gray-600">
                      Free users get basic templates and PDF export with watermark. Pro users get all templates, AI features, and watermark-free exports.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Technical Support</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      My resume isn't saving automatically
                    </h4>
                    <p className="text-sm text-gray-600">
                      Auto-save requires an active internet connection. Check your connection and try refreshing the page.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">
                      Can I import my existing resume?
                    </h4>
                    <p className="text-sm text-gray-600">
                      Yes! You can upload PDF or DOCX files, and we'll convert them to Markdown format for editing.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}