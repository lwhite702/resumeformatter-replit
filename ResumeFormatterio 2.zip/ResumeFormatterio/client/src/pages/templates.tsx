import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { resumeTemplates } from "@/lib/templates";
import { 
  FileText, 
  ArrowRight, 
  Eye, 
  Download, 
  Star,
  Briefcase,
  GraduationCap,
  Code,
  Palette,
  TrendingUp,
  Users
} from "lucide-react";

export default function Templates() {
  const handleGetStarted = () => {
    window.location.href = "/";
  };

  const templateCategories = [
    {
      name: "Tech & Engineering",
      icon: <Code className="h-5 w-5" />,
      description: "Structured formats ideal for developers and engineers",
      templates: resumeTemplates.filter(t => t.category === "Tech & Engineering")
    },
    {
      name: "Creative & Design",
      icon: <Palette className="h-5 w-5" />,
      description: "Modern, visually appealing layouts for creative fields",
      templates: resumeTemplates.filter(t => t.category === "Creative & Design")
    },
    {
      name: "Corporate & Business",
      icon: <Briefcase className="h-5 w-5" />,
      description: "Clean, corporate designs perfect for traditional industries",
      templates: resumeTemplates.filter(t => t.category === "Corporate & Business")
    },
    {
      name: "Academic & Research",
      icon: <GraduationCap className="h-5 w-5" />,
      description: "Comprehensive layouts for academic and research positions",
      templates: resumeTemplates.filter(t => t.category === "Academic & Research")
    }
  ];

  const features = [
    {
      icon: <Star className="h-6 w-6 text-yellow-500" />,
      title: "ATS-Optimized",
      description: "All templates are designed to pass Applicant Tracking Systems"
    },
    {
      icon: <Eye className="h-6 w-6 text-blue-500" />,
      title: "Recruiter-Approved",
      description: "Designed by HR professionals and hiring managers"
    },
    {
      icon: <Download className="h-6 w-6 text-green-500" />,
      title: "Multi-Format Export",
      description: "Download as PDF, DOCX, or HTML with perfect formatting"
    },
    {
      icon: <TrendingUp className="h-6 w-6 text-purple-500" />,
      title: "Proven Results",
      description: "Used by thousands of successful job seekers"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">ResumeFormatter.io</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="/" className="text-muted-foreground hover:text-primary transition-colors">Home</a>
              <a href="/features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="/pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
              <a href="/templates" className="text-primary font-medium">Templates</a>
            </nav>

            <Button onClick={handleGetStarted} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200">
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-purple-100 text-purple-700 border-purple-200">
            Professional Templates
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Resume Templates That Get You Hired
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Choose from our collection of professionally designed, ATS-optimized resume templates. 
            Each template is crafted by HR experts to maximize your chances of landing interviews.
          </p>
        </div>
      </section>

      {/* Template Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6 rounded-xl border hover:shadow-md transition-shadow">
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Template Categories */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {templateCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-16">
              <div className="flex items-center space-x-3 mb-8">
                <div className="p-2 bg-blue-100 rounded-lg">
                  {category.icon}
                </div>
                <div>
                  <h2 className="text-3xl font-bold">{category.name} Templates</h2>
                  <p className="text-muted-foreground">{category.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {category.templates.map((template, templateIndex) => (
                  <Card key={templateIndex} className="group border-0 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                    <CardHeader className="p-0">
                      <div className="aspect-[3/4] bg-gradient-to-br from-gray-100 to-gray-200 relative overflow-hidden">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="text-center p-8">
                            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                            <div className="space-y-2">
                              <div className="h-2 bg-gray-300 rounded w-3/4 mx-auto"></div>
                              <div className="h-2 bg-gray-300 rounded w-1/2 mx-auto"></div>
                              <div className="h-2 bg-gray-300 rounded w-2/3 mx-auto"></div>
                            </div>
                          </div>
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="absolute bottom-4 left-4 right-4">
                            <Button size="sm" className="w-full bg-white text-black hover:bg-gray-100">
                              <Eye className="h-4 w-4 mr-2" />
                              Preview Template
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-2">
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <Badge variant="secondary" className="text-xs">
                          {template.category}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm mb-4">{template.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                          <span className="text-sm text-muted-foreground ml-2">4.9</span>
                        </div>
                        <Button onClick={handleGetStarted} size="sm">
                          Use Template
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Trusted by Job Seekers Worldwide</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our templates have helped thousands of professionals land their dream jobs
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">50K+</div>
              <div className="text-muted-foreground">Resumes Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">89%</div>
              <div className="text-muted-foreground">Interview Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-600 mb-2">24</div>
              <div className="text-muted-foreground">Template Options</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-600 mb-2">4.9</div>
              <div className="text-muted-foreground">Average Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Get started with your perfect resume in just three simple steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Choose Your Template</h3>
              <p className="text-muted-foreground">
                Browse our collection and select the template that best fits your industry and style
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-purple-600">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Add Your Content</h3>
              <p className="text-muted-foreground">
                Use our intuitive Markdown editor to input your experience, skills, and achievements
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Download & Apply</h3>
              <p className="text-muted-foreground">
                Export your polished resume and start applying to your dream jobs with confidence
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Create Your Perfect Resume?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Choose from our professional templates and start building your career-winning resume today
          </p>
          <Button 
            onClick={handleGetStarted}
            size="lg" 
            className="bg-white text-blue-600 hover:bg-gray-50 shadow-lg hover:shadow-xl transition-all duration-200"
          >
            Start with a Template
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-bold">ResumeFormatter.io</span>
              </div>
              <p className="text-gray-400 max-w-md">
                The most powerful resume builder for modern professionals. Create ATS-compliant resumes that get you hired.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="/pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/templates" className="hover:text-white transition-colors">Templates</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="/legal" className="hover:text-white transition-colors">Legal</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="/support" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="/knowledge-base" className="hover:text-white transition-colors">Knowledge Base</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact Support</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 ResumeFormatter.io. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}