export interface ResumeData {
  id?: number;
  title: string;
  content: string;
  templateId: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ResumeVersion {
  id: number;
  resumeId: number;
  name: string;
  description?: string;
  content: string;
  templateId: string;
  createdAt: string;
}

export interface CoverLetter {
  id: number;
  title: string;
  content: string;
  jobTitle?: string;
  company?: string;
  tone: 'formal' | 'friendly' | 'executive';
  createdAt: string;
  updatedAt: string;
}

export interface OptimizationSuggestion {
  type: 'metrics' | 'keywords' | 'action_verbs' | 'format';
  title: string;
  description: string;
  example?: string;
  priority: 'high' | 'medium' | 'low';
}

export interface OptimizationResult {
  atsScore: number;
  matchedKeywords: string[];
  missingKeywords: string[];
  suggestions: OptimizationSuggestion[];
}

export interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  isPro: boolean;
  preview: string;
}

export interface ParsedResume {
  name?: string;
  title?: string;
  email?: string;
  phone?: string;
  location?: string;
  linkedin?: string;
  github?: string;
  summary?: string;
  experience?: Array<{
    title: string;
    company: string;
    duration: string;
    description: string[];
    technologies?: string;
  }>;
  education?: Array<{
    degree: string;
    institution: string;
    year: string;
    gpa?: string;
  }>;
  skills?: {
    [category: string]: string;
  };
  projects?: Array<{
    name: string;
    description: string;
    technologies: string;
    link?: string;
  }>;
}
