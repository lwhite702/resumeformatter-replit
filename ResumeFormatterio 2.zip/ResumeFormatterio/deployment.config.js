// Deployment Configuration for ResumeFormatter.io
// This file sets up required environment variables for production deployment

// Set production environment variables
process.env.NODE_ENV = process.env.NODE_ENV || 'production';
process.env.ISSUER_URL = process.env.ISSUER_URL || 'https://replit.com/oidc';

// Handle REPL_ID for deployment
if (!process.env.REPL_ID) {
  console.log('Setting REPL_ID from available environment variables...');
  process.env.REPL_ID = process.env.REPL_SLUG || 
                        process.env.RAILWAY_PROJECT_ID || 
                        process.env.VERCEL_PROJECT_ID ||
                        'deployment-fallback';
}

// Handle SESSION_SECRET for deployment
if (!process.env.SESSION_SECRET) {
  console.log('Setting SESSION_SECRET from available environment variables...');
  process.env.SESSION_SECRET = process.env.REPL_ID || 
                               process.env.SECRET_KEY ||
                               'deployment-session-secret-' + Date.now();
}

// Handle REPLIT_DOMAINS for deployment
if (!process.env.REPLIT_DOMAINS) {
  console.log('Setting REPLIT_DOMAINS from available environment variables...');
  process.env.REPLIT_DOMAINS = process.env.REPL_SLUG || 
                               process.env.RAILWAY_STATIC_URL ||
                               process.env.VERCEL_URL ||
                               'localhost:5000';
}

console.log('Deployment configuration loaded successfully');
console.log('Environment:', {
  NODE_ENV: process.env.NODE_ENV,
  ISSUER_URL: process.env.ISSUER_URL,
  REPL_ID: process.env.REPL_ID ? 'SET' : 'NOT SET',
  SESSION_SECRET: process.env.SESSION_SECRET ? 'SET' : 'NOT SET',
  REPLIT_DOMAINS: process.env.REPLIT_DOMAINS ? 'SET' : 'NOT SET',
  DATABASE_URL: process.env.DATABASE_URL ? 'SET' : 'NOT SET'
});

export {};