import type { Express } from "express";
import { storage } from "./storage";
import { requireAuth, requireAdmin, getUserId } from "./clerk-auth";

export function registerAdminRoutes(app: Express) {
  // Admin Feature Flags API
  app.get('/api/admin/feature-flags', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const flags = await storage.getFeatureFlags();
      res.json(flags);
    } catch (error) {
      console.error('Error fetching feature flags:', error);
      res.status(500).json({ message: 'Failed to fetch feature flags' });
    }
  });

  app.get('/api/admin/feature-flags/:app', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { app } = req.params;
      const flags = await storage.getFeatureFlagsByApp(app);
      res.json(flags);
    } catch (error) {
      console.error('Error fetching feature flags by app:', error);
      res.status(500).json({ message: 'Failed to fetch feature flags' });
    }
  });

  app.post('/api/admin/feature-flags', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const flagData = req.body;
      const flag = await storage.createFeatureFlag(flagData);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'CREATE_FEATURE_FLAG',
        entityType: 'feature_flag',
        entityId: flag.id.toString(),
        newValue: flag,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json(flag);
    } catch (error) {
      console.error('Error creating feature flag:', error);
      res.status(500).json({ message: 'Failed to create feature flag' });
    }
  });

  app.put('/api/admin/feature-flags/:id', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const flag = await storage.updateFeatureFlag(parseInt(id), updates);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'UPDATE_FEATURE_FLAG',
        entityType: 'feature_flag',
        entityId: id,
        newValue: updates,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json(flag);
    } catch (error) {
      console.error('Error updating feature flag:', error);
      res.status(500).json({ message: 'Failed to update feature flag' });
    }
  });

  app.delete('/api/admin/feature-flags/:id', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteFeatureFlag(parseInt(id));
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'DELETE_FEATURE_FLAG',
        entityType: 'feature_flag',
        entityId: id,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting feature flag:', error);
      res.status(500).json({ message: 'Failed to delete feature flag' });
    }
  });

  // Admin Billing Plans API
  app.get('/api/admin/billing-plans', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const plans = await storage.getBillingPlans();
      res.json(plans);
    } catch (error) {
      console.error('Error fetching billing plans:', error);
      res.status(500).json({ message: 'Failed to fetch billing plans' });
    }
  });

  app.get('/api/admin/billing-plans/:app', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { app } = req.params;
      const plans = await storage.getBillingPlansByApp(app);
      res.json(plans);
    } catch (error) {
      console.error('Error fetching billing plans by app:', error);
      res.status(500).json({ message: 'Failed to fetch billing plans' });
    }
  });

  app.post('/api/admin/billing-plans', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const planData = req.body;
      const plan = await storage.createBillingPlan(planData);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'CREATE_BILLING_PLAN',
        entityType: 'billing_plan',
        entityId: plan.id.toString(),
        newValue: plan,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json(plan);
    } catch (error) {
      console.error('Error creating billing plan:', error);
      res.status(500).json({ message: 'Failed to create billing plan' });
    }
  });

  app.put('/api/admin/billing-plans/:id', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const plan = await storage.updateBillingPlan(parseInt(id), updates);
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'UPDATE_BILLING_PLAN',
        entityType: 'billing_plan',
        entityId: id,
        newValue: updates,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json(plan);
    } catch (error) {
      console.error('Error updating billing plan:', error);
      res.status(500).json({ message: 'Failed to update billing plan' });
    }
  });

  app.delete('/api/admin/billing-plans/:id', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteBillingPlan(parseInt(id));
      
      // Log admin action
      await storage.createAdminLog({
        adminId: getUserId(req) || 'admin',
        action: 'DELETE_BILLING_PLAN',
        entityType: 'billing_plan',
        entityId: id,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting billing plan:', error);
      res.status(500).json({ message: 'Failed to delete billing plan' });
    }
  });

  // Stripe Prices API for billing plan management
  app.get('/api/admin/stripe/prices', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      if (!process.env.STRIPE_SECRET_KEY) {
        return res.status(400).json({ message: 'Stripe not configured' });
      }

      const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
      const prices = await stripe.prices.list({
        limit: 100,
        expand: ['data.product']
      });

      const formattedPrices = prices.data.map((price: any) => ({
        id: price.id,
        unit_amount: price.unit_amount,
        currency: price.currency,
        recurring: price.recurring,
        product: {
          name: price.product.name,
          metadata: price.product.metadata
        }
      }));

      res.json(formattedPrices);
    } catch (error) {
      console.error('Error fetching Stripe prices:', error);
      res.status(500).json({ message: 'Failed to fetch Stripe prices' });
    }
  });

  // Admin Logs API
  app.get('/api/admin/logs', requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const logs = await storage.getAdminLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error('Error fetching admin logs:', error);
      res.status(500).json({ message: 'Failed to fetch admin logs' });
    }
  });
}