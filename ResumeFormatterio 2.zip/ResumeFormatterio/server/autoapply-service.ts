import { storage } from "./storage";
import type { Resume } from "@shared/schema";

export interface AutoApplyResumeData {
  id: string;
  name: string;
  fileName: string;
  skills: string[];
  experience: string;
  focus: string;
  lastModified: string;
  downloadUrl: string;
}

export interface AutoApplyIntegrationConfig {
  apiKey?: string;
  baseUrl: string;
  enabled: boolean;
}

export class AutoApplyService {
  private config: AutoApplyIntegrationConfig;

  constructor() {
    this.config = {
      apiKey: process.env.AUTOAPPLY_API_KEY,
      baseUrl: process.env.AUTOAPPLY_BASE_URL || 'https://autoapply.wrelik.com',
      enabled: !!process.env.AUTOAPPLY_API_KEY,
    };
  }

  /**
   * Convert ResumeFormatter resume to AutoApply format
   */
  async formatResumeForAutoApply(resume: Resume): Promise<AutoApplyResumeData> {
    // Extract skills from resume content using common patterns
    const skills = this.extractSkillsFromContent(resume.content);
    
    // Extract experience level from content
    const experience = this.extractExperienceLevel(resume.content);
    
    // Determine focus area based on content analysis
    const focus = this.determineFocusArea(resume.content, resume.title);

    // Generate download URL for the resume
    const downloadUrl = `${process.env.BACKEND_URL || 'http://localhost:5000'}/api/resumes/${resume.userId}/${resume.id}/download`;

    return {
      id: resume.id.toString(),
      name: resume.title,
      fileName: `${resume.title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`,
      skills,
      experience,
      focus,
      lastModified: (resume.updatedAt || resume.createdAt || new Date()).toISOString(),
      downloadUrl,
    };
  }

  /**
   * Get all resumes for a user in AutoApply format
   */
  async getUserResumesForAutoApply(userId: string): Promise<AutoApplyResumeData[]> {
    const resumes = await storage.getUserResumes(userId);
    
    const autoApplyResumes = await Promise.all(
      resumes.map(resume => this.formatResumeForAutoApply(resume))
    );

    return autoApplyResumes;
  }

  /**
   * Extract skills from resume content using pattern matching
   */
  private extractSkillsFromContent(content: string): string[] {
    const skills: Set<string> = new Set();
    
    // Common technical skills patterns
    const technicalSkills = [
      'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'React', 'Vue',
      'Angular', 'Node.js', 'Express', 'Django', 'Flask', 'Spring', 'Laravel',
      'HTML', 'CSS', 'SASS', 'SCSS', 'SQL', 'PostgreSQL', 'MySQL', 'MongoDB',
      'Redis', 'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP', 'Git', 'GitHub',
      'GitLab', 'Jenkins', 'CI/CD', 'Agile', 'Scrum', 'REST', 'GraphQL',
      'Machine Learning', 'AI', 'Data Science', 'Analytics', 'Tableau', 'Power BI'
    ];

    // Look for skills in the content
    technicalSkills.forEach(skill => {
      const regex = new RegExp(`\\b${skill}\\b`, 'gi');
      if (regex.test(content)) {
        skills.add(skill);
      }
    });

    // Extract skills from "Skills" sections
    const skillsSection = content.match(/(?:skills?|technologies?|tools?)[:\s]*([^\n#]+)/gi);
    if (skillsSection) {
      skillsSection.forEach(section => {
        const extractedSkills = section
          .replace(/(?:skills?|technologies?|tools?)[:\s]*/gi, '')
          .split(/[,•\-\n]/)
          .map(s => s.trim())
          .filter(s => s.length > 1);
        
        extractedSkills.forEach(skill => skills.add(skill));
      });
    }

    return Array.from(skills).slice(0, 15); // Limit to 15 most relevant skills
  }

  /**
   * Determine experience level from resume content
   */
  private extractExperienceLevel(content: string): string {
    // Look for years of experience patterns
    const yearPatterns = [
      /(\d+)\+?\s*years?\s*(?:of\s*)?experience/gi,
      /(\d+)\+?\s*yrs?\s*(?:of\s*)?experience/gi,
      /experience[:\s]*(\d+)\+?\s*years?/gi,
    ];

    for (const pattern of yearPatterns) {
      const match = content.match(pattern);
      if (match) {
        const years = parseInt(match[1]);
        if (years >= 8) return 'Senior';
        if (years >= 4) return 'Mid-Level';
        if (years >= 1) return 'Junior';
        return 'Entry Level';
      }
    }

    // Analyze job titles for seniority indicators
    if (/\b(?:senior|lead|principal|staff|architect)\b/gi.test(content)) {
      return 'Senior';
    }
    if (/\b(?:junior|associate|entry|intern|graduate)\b/gi.test(content)) {
      return 'Entry Level';
    }

    // Count work experiences
    const workExperiences = content.match(/(?:20\d{2}|19\d{2})\s*-\s*(?:20\d{2}|present|current)/gi);
    const experienceCount = workExperiences ? workExperiences.length : 0;

    if (experienceCount >= 3) return 'Senior';
    if (experienceCount >= 2) return 'Mid-Level';
    if (experienceCount >= 1) return 'Junior';
    
    return 'Entry Level';
  }

  /**
   * Determine focus area based on content analysis
   */
  private determineFocusArea(content: string, title: string): string {
    const combinedContent = `${title} ${content}`.toLowerCase();

    // Define focus area patterns
    const focusAreas = {
      'Frontend Development': ['frontend', 'front-end', 'react', 'vue', 'angular', 'javascript', 'html', 'css', 'ui', 'ux'],
      'Backend Development': ['backend', 'back-end', 'server', 'api', 'database', 'node.js', 'python', 'java', 'c#'],
      'Full Stack Development': ['full stack', 'fullstack', 'full-stack', 'frontend and backend', 'front and back'],
      'Data Science': ['data scientist', 'data science', 'machine learning', 'ml', 'ai', 'analytics', 'statistics'],
      'DevOps Engineering': ['devops', 'infrastructure', 'cloud', 'aws', 'azure', 'docker', 'kubernetes', 'ci/cd'],
      'Mobile Development': ['mobile', 'ios', 'android', 'react native', 'flutter', 'swift', 'kotlin'],
      'Product Management': ['product manager', 'product management', 'pm', 'product owner', 'roadmap'],
      'UI/UX Design': ['ui designer', 'ux designer', 'user experience', 'user interface', 'design', 'figma'],
      'Software Engineering': ['software engineer', 'software developer', 'developer', 'engineer', 'programming'],
    };

    // Find the best matching focus area
    let maxMatches = 0;
    let bestFocus = 'Software Engineering'; // Default

    Object.entries(focusAreas).forEach(([area, keywords]) => {
      const matches = keywords.filter(keyword => combinedContent.includes(keyword)).length;
      if (matches > maxMatches) {
        maxMatches = matches;
        bestFocus = area;
      }
    });

    return bestFocus;
  }

  /**
   * Send resume data to AutoApply platform
   */
  async syncResumeWithAutoApply(userId: string, resumeId: number): Promise<boolean> {
    if (!this.config.enabled) {
      console.warn('AutoApply integration is not enabled - missing API key');
      return false;
    }

    try {
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        throw new Error('Resume not found or access denied');
      }

      const autoApplyData = await this.formatResumeForAutoApply(resume);
      
      // Make API call to AutoApply platform
      const response = await fetch(`${this.config.baseUrl}/api/resumes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`,
          'X-Source': 'resumeformatter.io',
        },
        body: JSON.stringify(autoApplyData),
      });

      if (!response.ok) {
        throw new Error(`AutoApply API error: ${response.status} ${response.statusText}`);
      }

      console.log(`Successfully synced resume ${resumeId} with AutoApply`);
      return true;
    } catch (error) {
      console.error('Failed to sync resume with AutoApply:', error);
      return false;
    }
  }

  /**
   * Sync all user resumes with AutoApply
   */
  async syncAllUserResumesWithAutoApply(userId: string): Promise<{ success: number; failed: number }> {
    const resumes = await storage.getUserResumes(userId);
    let success = 0;
    let failed = 0;

    for (const resume of resumes) {
      const result = await this.syncResumeWithAutoApply(userId, resume.id);
      if (result) {
        success++;
      } else {
        failed++;
      }
    }

    return { success, failed };
  }

  /**
   * Check if AutoApply integration is configured
   */
  isConfigured(): boolean {
    return this.config.enabled;
  }

  /**
   * Get integration configuration status
   */
  getConfig(): Omit<AutoApplyIntegrationConfig, 'apiKey'> {
    return {
      baseUrl: this.config.baseUrl,
      enabled: this.config.enabled,
    };
  }
}

export const autoApplyService = new AutoApplyService();