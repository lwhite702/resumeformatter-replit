export interface BeehiivSubscriber {
  email: string;
  name?: string;
  source?: string;
  tags?: string[];
  custom_fields?: Record<string, any>;
}

export interface BeehiivResponse {
  success: boolean;
  data?: any;
  error?: string;
  message?: string;
}

export class BeehiivService {
  private apiKey: string;
  private publicationId: string;
  private baseUrl = 'https://api.beehiiv.com/v2';

  constructor() {
    this.apiKey = process.env.BEEHIIV_API_KEY || '';
    this.publicationId = process.env.BEEHIIV_PUBLICATION_ID || '';
    
    if (!this.apiKey || !this.publicationId) {
      console.warn('Beehiiv API credentials not configured');
    } else {
      console.log('Beehiiv service initialized with credentials');
    }
  }

  private async makeRequest(endpoint: string, method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET', body?: any): Promise<BeehiivResponse> {
    if (!this.apiKey || !this.publicationId) {
      return {
        success: false,
        error: 'Beehiiv API credentials not configured'
      };
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        method,
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: body ? JSON.stringify(body) : undefined,
      });

      let data;
      try {
        data = await response.json();
      } catch (jsonError) {
        const textResponse = await response.text();
        console.error(`Beehiiv API ${response.status} non-JSON response:`, textResponse);
        return {
          success: false,
          error: `HTTP ${response.status}: ${textResponse}`,
          message: textResponse
        };
      }

      if (!response.ok) {
        console.error(`Beehiiv API ${response.status} response:`, JSON.stringify(data, null, 2));
        return {
          success: false,
          error: data.error || data.message || `HTTP ${response.status}`,
          message: data.message
        };
      }

      return {
        success: true,
        data
      };
    } catch (error) {
      console.error('Beehiiv API error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Subscribe a user to the newsletter
   */
  async subscribe(subscriber: BeehiivSubscriber): Promise<BeehiivResponse> {
    // Simplified payload based on Beehiiv API requirements
    const payload: any = {
      email: subscriber.email,
      reactivate_existing: true,
      send_welcome_email: true
    };

    console.log('Beehiiv subscription payload:', JSON.stringify(payload, null, 2));

    return this.makeRequest(
      `/publications/${this.publicationId}/subscriptions`,
      'POST',
      payload
    );
  }

  /**
   * Unsubscribe a user from the newsletter
   */
  async unsubscribe(email: string): Promise<BeehiivResponse> {
    return this.makeRequest(
      `/publications/${this.publicationId}/subscriptions/${encodeURIComponent(email)}`,
      'DELETE'
    );
  }

  /**
   * Get subscriber information
   */
  async getSubscriber(email: string): Promise<BeehiivResponse> {
    return this.makeRequest(
      `/publications/${this.publicationId}/subscriptions/${encodeURIComponent(email)}`
    );
  }

  /**
   * Update subscriber information
   */
  async updateSubscriber(email: string, updates: Partial<BeehiivSubscriber>): Promise<BeehiivResponse> {
    const payload = {
      custom_fields: {
        name: updates.name,
        ...updates.custom_fields
      }
    };

    return this.makeRequest(
      `/publications/${this.publicationId}/subscriptions/${encodeURIComponent(email)}`,
      'PUT',
      payload
    );
  }

  /**
   * Add subscriber to automation journey (for welcome series, etc.)
   */
  async addToAutomation(email: string, automationId: string): Promise<BeehiivResponse> {
    const payload = {
      email,
      automation_journey_id: automationId
    };

    return this.makeRequest(
      `/automations/journeys/${automationId}/trigger`,
      'POST',
      payload
    );
  }

  /**
   * Get publication stats
   */
  async getPublicationStats(): Promise<BeehiivResponse> {
    return this.makeRequest(`/publications/${this.publicationId}/stats`);
  }

  /**
   * Get list of all subscribers (with pagination)
   */
  async getSubscribers(page = 1, limit = 100): Promise<BeehiivResponse> {
    return this.makeRequest(
      `/publications/${this.publicationId}/subscriptions?page=${page}&limit=${limit}`
    );
  }

  /**
   * Validate email before subscription
   */
  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Check if API is properly configured
   */
  isConfigured(): boolean {
    return !!(this.apiKey && this.publicationId);
  }

  /**
   * Test API connection and credentials
   */
  async testConnection(): Promise<BeehiivResponse> {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'API credentials not configured'
      };
    }

    return this.makeRequest(`/publications/${this.publicationId}`, 'GET');
  }
}

export const beehiivService = new BeehiivService();