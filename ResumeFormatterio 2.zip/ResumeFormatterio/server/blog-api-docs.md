# Blog API Documentation

## Overview
The Blog API provides WordPress integration with intelligent caching, fallback handling, and health monitoring for optimal performance and reliability.

## Endpoints

### GET /api/blog/posts
Fetches blog posts with cache-first strategy and WordPress fallback.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `per_page` (optional): Posts per page (default: 10)

**Response:**
```json
[
  {
    "id": 137,
    "date": "2025-06-13T10:57:00",
    "slug": "post-slug",
    "title": { "rendered": "Post Title" },
    "content": { "rendered": "Post content..." },
    "excerpt": { "rendered": "Post excerpt..." },
    "author": 1,
    "featured_media": 0,
    "categories": [],
    "tags": []
  }
]
```

### GET /api/blog/posts/:slug
Fetches a specific blog post by slug.

### GET /api/blog/cached-posts
Returns posts directly from cache without WordPress fallback.

### GET /api/blog/health
Health check endpoint for monitoring blog service status.

**Response:**
```json
{
  "status": "healthy|degraded|unhealthy",
  "timestamp": "2025-01-18T08:05:00.000Z",
  "services": {
    "cache": "healthy|error|unknown",
    "wordpress": "healthy|degraded|error|unknown"
  },
  "statistics": {
    "cachedPosts": 0,
    "lastCacheUpdate": null
  }
}
```

### POST /api/admin/cache/wordpress/refresh
Manually triggers WordPress cache refresh.

## Caching Strategy

1. **Cache First**: Check PostgreSQL cache for posts
2. **WordPress Fallback**: If cache miss, fetch from WordPress API
3. **Error Handling**: Return appropriate errors if both fail
4. **Background Refresh**: Scheduled cache updates via cron

## Features

- **SSL Certificate Handling**: Robust handling of certificate issues in development
- **Timeout Management**: 10-second request timeouts with abort controllers
- **Error Recovery**: Graceful degradation when services are unavailable
- **Health Monitoring**: Real-time service status checking
- **Performance Optimization**: Field selection to minimize API payload

## Configuration

Environment variables:
- `DATABASE_URL`: PostgreSQL connection string
- `NODE_ENV`: Environment setting (affects SSL handling)

## Performance

- Cache hit: ~5ms response time
- WordPress API: ~2-4s response time
- Health check: ~6ms response time

## Reliability

- Dual-layer fallback (cache → WordPress → error)
- Service health monitoring
- Automatic error recovery
- Request timeout protection