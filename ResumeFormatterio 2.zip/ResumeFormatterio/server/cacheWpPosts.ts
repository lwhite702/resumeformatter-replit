import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import { cachedPosts } from '../shared/schema';
import { pool } from './db';

interface WordPressPost {
  id: number;
  title: {
    rendered: string;
  };
  slug: string;
  excerpt: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  date: string;
}

// Clean HTML content by removing tags and decoding entities
function cleanHtmlContent(html: string): string {
  return html
    .replace(/<[^>]*>/g, '') // Remove HTML tags
    .replace(/&nbsp;/g, ' ') // Replace non-breaking spaces
    .replace(/&amp;/g, '&') // Decode HTML entities
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim();
}

async function upsertPost(db: any, post: WordPressPost): Promise<void> {
  const cleanTitle = cleanHtmlContent(post.title.rendered);
  const cleanExcerpt = cleanHtmlContent(post.excerpt.rendered);
  const cleanContent = cleanHtmlContent(post.content.rendered);

  await db
    .insert(cachedPosts)
    .values({
      wpId: post.id,
      title: cleanTitle,
      slug: post.slug,
      excerpt: cleanExcerpt,
      content: cleanContent,
      publishedAt: new Date(post.date),
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: cachedPosts.wpId,
      set: {
        title: cleanTitle,
        slug: post.slug,
        excerpt: cleanExcerpt,
        content: cleanContent,
        publishedAt: new Date(post.date),
        updatedAt: new Date(),
      },
    });
}

async function cacheWordPressPosts(): Promise<void> {
  const db = drizzle(pool);

  try {
    console.log('🔄 Fetching posts from WordPress API...');
    
    const response = await fetch(
      'https://wrelikbrands.com/wp-json/wp/v2/posts?per_page=10&_fields=id,title,slug,excerpt,content,date',
      {
        headers: {
          'User-Agent': 'ResumeFormatter-Cache/1.0'
        },
        // Skip SSL verification for now due to certificate issues
        //@ts-ignore
        agent: process.env.NODE_ENV === 'development' ? { rejectUnauthorized: false } : undefined
      }
    );

    if (!response.ok) {
      throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
    }

    const posts: WordPressPost[] = await response.json();
    
    console.log(`📥 Retrieved ${posts.length} posts from WordPress`);

    let cachedCount = 0;
    
    for (const post of posts) {
      try {
        await upsertPost(db, post);
        cachedCount++;
      } catch (error) {
        console.error(`❌ Error caching post ${post.id}:`, error);
      }
    }

    console.log(`✅ Cached ${cachedCount} posts from WordPress.`);

  } catch (error) {
    console.error('❌ Error caching WordPress posts:', error);
    throw error;
  }
}

// Run the script if called directly
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

if (import.meta.url === `file://${process.argv[1]}`) {
  cacheWordPressPosts()
    .then(() => {
      console.log('🎉 WordPress post caching completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 WordPress post caching failed:', error);
      process.exit(1);
    });
}

export { cacheWordPressPosts };