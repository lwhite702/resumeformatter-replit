import { clerkClient } from "@clerk/clerk-sdk-node";
import type { Request, Response, NextFunction } from "express";

// Extend Express Request type to include user information
declare global {
  namespace Express {
    interface Request {
      auth?: {
        userId: string;
        sessionId: string;
        user?: any;
      };
    }
  }
}

// Simple authentication check for development
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    // For development, we'll use a simpler approach
    // In production, you would implement proper Clerk session verification
    
    // Check for session token in header
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        error: 'Unauthorized', 
        message: 'Authentication required' 
      });
    }

    // For now, assume valid if token is present
    // In production, verify with Clerk
    const sessionToken = authHeader.substring(7);
    
    if (sessionToken && sessionToken.length > 10) {
      // Mock user for development
      req.auth = {
        userId: 'dev-user',
        sessionId: 'dev-session',
        user: { id: 'dev-user', email: 'admin@wrelikbrands.com' }
      };
      next();
    } else {
      return res.status(401).json({ 
        error: 'Unauthorized', 
        message: 'Invalid session token' 
      });
    }
  } catch (error) {
    console.error('Authentication middleware error:', error);
    return res.status(500).json({ 
      error: 'Internal Server Error', 
      message: 'Authentication processing failed' 
    });
  }
}

// Optional middleware for routes that can work with or without authentication
export async function optionalAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const sessionToken = authHeader.substring(7);
      
      if (sessionToken && sessionToken.length > 10) {
        req.auth = {
          userId: 'dev-user',
          sessionId: 'dev-session',
          user: { id: 'dev-user', email: 'admin@wrelikbrands.com' }
        };
      }
    }

    next();
  } catch (error) {
    console.error('Optional authentication middleware error:', error);
    next(); // Continue without authentication
  }
}

// Admin-only middleware that checks for admin privileges
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  try {
    // First ensure the user is authenticated
    if (!req.auth || !req.auth.user) {
      return res.status(401).json({ 
        error: 'Unauthorized', 
        message: 'Authentication required' 
      });
    }

    const user = req.auth.user;

    // Check if user has admin privileges
    // This can be based on email domain, user metadata, or organization roles
    const isAdmin = 
      user.emailAddresses?.some((email: any) => 
        email.emailAddress?.includes('admin') || 
        email.emailAddress?.endsWith('@wrelikbrands.com')
      ) ||
      user.publicMetadata?.role === 'admin' ||
      user.privateMetadata?.isAdmin === true;

    if (!isAdmin) {
      return res.status(403).json({ 
        error: 'Forbidden', 
        message: 'Admin privileges required' 
      });
    }

    next();
  } catch (error) {
    console.error('Admin middleware error:', error);
    return res.status(500).json({ 
      error: 'Internal Server Error', 
      message: 'Admin check failed' 
    });
  }
}

// Middleware to validate specific headers required by Clerk
export function validateClerkHeaders(req: Request, res: Response, next: NextFunction) {
  const requiredHeaders = [
    'authorization',
    'accept',
    'host',
    'user-agent'
  ];

  const missingHeaders = requiredHeaders.filter(header => !req.headers[header]);

  if (missingHeaders.length > 0) {
    return res.status(400).json({
      error: 'Bad Request',
      message: `Missing required headers: ${missingHeaders.join(', ')}`,
      missingHeaders
    });
  }

  next();
}

// Helper function to get user from request
export function getAuthenticatedUser(req: Request) {
  return req.auth?.user || null;
}

// Helper function to get user ID from request
export function getUserId(req: Request): string | null {
  return req.auth?.userId || null;
}