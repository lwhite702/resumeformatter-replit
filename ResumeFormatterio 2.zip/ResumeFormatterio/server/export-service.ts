import { storage } from "./storage";
import type { Resume, ApiIntegration } from "@shared/schema";

export interface ExportResult {
  success: boolean;
  externalId?: string;
  exportUrl?: string;
  error?: string;
}

export interface PrepPairResumeData {
  title: string;
  content: string;
  format: 'markdown' | 'json';
  metadata: {
    templateId: string;
    exportedFrom: 'resumeformatter.io';
    exportedAt: string;
  };
}

export class ExportService {
  
  /**
   * Export resume to PrepPair.me platform using native integration
   */
  async exportToPrepPair(
    userId: string, 
    resumeId: number
  ): Promise<ExportResult> {
    try {
      // Get resume data
      const resume = await storage.getResume(resumeId);
      if (!resume) {
        throw new Error('Resume not found');
      }

      // Check if user owns the resume
      if (resume.userId !== userId) {
        throw new Error('Unauthorized: Resume does not belong to user');
      }

      // Use platform's native API key for seamless integration
      const PREPPAIR_API_KEY = process.env.PREPPAIR_API_KEY;
      const PREPPAIR_ENDPOINT = process.env.PREPPAIR_ENDPOINT || 'https://api.preppair.me';

      if (!PREPPAIR_API_KEY) {
        throw new Error('PrepPair.me integration is temporarily unavailable. Please try again later.');
      }

      // Create export history record
      const exportRecord = await storage.createExportHistory({
        userId,
        resumeId,
        platform: 'preppair',
        exportFormat: 'json',
        status: 'pending'
      });

      try {
        // Prepare resume data for PrepPair.me
        const exportData: PrepPairResumeData = {
          title: resume.title,
          content: resume.content,
          format: 'markdown',
          metadata: {
            templateId: resume.templateId,
            exportedFrom: 'resumeformatter.io',
            exportedAt: new Date().toISOString()
          }
        };

        // Make API call to PrepPair.me
        const response = await fetch(`${integration.apiEndpoint}/api/v1/resumes/import`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${integration.apiKey}`,
            'X-Source': 'resumeformatter.io'
          },
          body: JSON.stringify(exportData)
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(`PrepPair.me API error: ${response.status} - ${errorData.message || 'Unknown error'}`);
        }

        const result = await response.json();
        
        // Update export record with success
        await storage.updateExportStatus(
          exportRecord.id, 
          'success', 
          result.id || result.resumeId,
          undefined
        );

        // Update integration last sync time
        await storage.updateApiIntegration(integration.id, {
          lastSync: new Date()
        });

        return {
          success: true,
          externalId: result.id || result.resumeId,
          exportUrl: result.url || `${integration.apiEndpoint}/resumes/${result.id}`
        };

      } catch (error) {
        // Update export record with failure
        await storage.updateExportStatus(
          exportRecord.id,
          'failed',
          undefined,
          error instanceof Error ? error.message : 'Unknown error'
        );
        
        throw error;
      }

    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Export failed'
      };
    }
  }

  /**
   * Export resume to LinkedIn (placeholder for future implementation)
   */
  async exportToLinkedIn(userId: string, resumeId: number): Promise<ExportResult> {
    return {
      success: false,
      error: 'LinkedIn export not yet implemented'
    };
  }

  /**
   * Get export history for a user
   */
  async getUserExports(userId: string) {
    return await storage.getUserExportHistory(userId);
  }

  /**
   * Get export history for a specific resume
   */
  async getResumeExports(resumeId: number) {
    return await storage.getResumeExportHistory(resumeId);
  }

  /**
   * Get user's API integrations
   */
  async getUserIntegrations(userId: string) {
    return await storage.getUserApiIntegrations(userId);
  }

  /**
   * Create or update API integration
   */
  async setupIntegration(
    userId: string, 
    platform: string, 
    apiKey: string, 
    endpoint?: string
  ) {
    const existing = await storage.getApiIntegrationByPlatform(userId, platform);
    
    if (existing) {
      return await storage.updateApiIntegration(existing.id, {
        apiKey,
        apiEndpoint: endpoint,
        isActive: true,
        lastSync: new Date()
      });
    } else {
      return await storage.createApiIntegration({
        userId,
        platform,
        apiKey,
        apiEndpoint: endpoint,
        isActive: true
      });
    }
  }

  /**
   * Delete API integration
   */
  async removeIntegration(userId: string, integrationId: number) {
    const integration = await storage.getUserApiIntegrations(userId);
    const userIntegration = integration.find(i => i.id === integrationId);
    
    if (!userIntegration) {
      throw new Error('Integration not found or access denied');
    }

    await storage.deleteApiIntegration(integrationId);
  }
}

export const exportService = new ExportService();