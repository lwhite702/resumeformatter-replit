import { analyzeResumeATS } from "./openai";

export interface LinkedInContent {
  headline: string;
  summary: string;
  experience: Array<{
    title: string;
    company: string;
    duration: string;
    description: string;
    skills: string[];
  }>;
  skills: string[];
  education: Array<{
    degree: string;
    institution: string;
    year: string;
  }>;
  recommendations: {
    summary: string;
    experience: string;
    skills: string;
  };
}

export interface StructuredResumeData {
  metadata: {
    name: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
    website: string;
  };
  sections: {
    summary: string;
    experience: Array<{
      title: string;
      company: string;
      location: string;
      startDate: string;
      endDate: string;
      description: string;
      achievements: string[];
    }>;
    education: Array<{
      degree: string;
      institution: string;
      location: string;
      graduationDate: string;
      gpa?: string;
      honors?: string[];
    }>;
    skills: {
      technical: string[];
      soft: string[];
      languages: string[];
      certifications: string[];
    };
    projects: Array<{
      name: string;
      description: string;
      technologies: string[];
      url?: string;
    }>;
    certifications: Array<{
      name: string;
      issuer: string;
      date: string;
      url?: string;
    }>;
  };
  analytics: {
    totalExperience: number;
    skillCount: number;
    educationLevel: string;
    industryFocus: string[];
  };
}

export async function generateLinkedInContent(resumeContent: string): Promise<LinkedInContent> {
  try {
    // Parse resume content to extract key information
    const sections = parseResumeContent(resumeContent);
    
    // Generate LinkedIn-optimized headline
    const headline = generateLinkedInHeadline(sections);
    
    // Generate LinkedIn summary
    const summary = generateLinkedInSummary(sections);
    
    // Extract and format experience
    const experience = formatLinkedInExperience(sections.experience);
    
    // Extract skills
    const skills = extractSkills(resumeContent);
    
    // Extract education
    const education = formatLinkedInEducation(sections.education);
    
    // Generate optimization recommendations
    const recommendations = generateLinkedInRecommendations(sections, skills);

    return {
      headline,
      summary,
      experience,
      skills,
      education,
      recommendations
    };
  } catch (error) {
    console.error("Error generating LinkedIn content:", error);
    throw new Error("Failed to generate LinkedIn content");
  }
}

export async function parseResumeToJSON(
  content: string, 
  title: string, 
  templateId: number | null
): Promise<StructuredResumeData> {
  try {
    const sections = parseResumeContent(content);
    
    // Extract metadata from contact information
    const metadata = extractContactInfo(content);
    
    // Parse experience section
    const experience = parseExperienceSection(sections.experience);
    
    // Parse education section
    const education = parseEducationSection(sections.education);
    
    // Parse skills section
    const skills = parseSkillsSection(content);
    
    // Parse projects section
    const projects = parseProjectsSection(sections.projects || []);
    
    // Parse certifications
    const certifications = parseCertificationsSection(sections.certifications || []);
    
    // Generate analytics
    const analytics = generateResumeAnalytics(experience, skills, education);

    return {
      metadata: {
        name: metadata.name || extractNameFromContent(content) || "Unknown",
        title: title || "Resume",
        email: metadata.email || "",
        phone: metadata.phone || "",
        location: metadata.location || "",
        linkedin: metadata.linkedin || "",
        website: metadata.website || ""
      },
      sections: {
        summary: sections.summary || "",
        experience,
        education,
        skills,
        projects,
        certifications
      },
      analytics
    };
  } catch (error) {
    console.error("Error parsing resume to JSON:", error);
    throw new Error("Failed to parse resume content");
  }
}

function parseResumeContent(content: string) {
  const sections: any = {};
  const lines = content.split('\n');
  let currentSection = '';
  let currentContent: string[] = [];

  for (const line of lines) {
    const trimmedLine = line.trim();
    
    // Check if line is a section header
    if (trimmedLine.match(/^#+\s*(Experience|Education|Skills|Summary|About|Projects|Certifications)/i)) {
      // Save previous section
      if (currentSection && currentContent.length > 0) {
        sections[currentSection.toLowerCase()] = currentContent.join('\n').trim();
      }
      
      // Start new section
      currentSection = trimmedLine.replace(/^#+\s*/, '').toLowerCase();
      currentContent = [];
    } else if (currentSection && trimmedLine) {
      currentContent.push(line);
    }
  }
  
  // Save last section
  if (currentSection && currentContent.length > 0) {
    sections[currentSection.toLowerCase()] = currentContent.join('\n').trim();
  }

  return sections;
}

function generateLinkedInHeadline(sections: any): string {
  const summaryText = sections.summary || sections.about || "";
  const experienceText = sections.experience || "";
  
  // Extract job titles and key skills
  const jobTitles = extractJobTitles(experienceText);
  const keySkills = extractTopSkills(summaryText + " " + experienceText, 3);
  
  if (jobTitles.length > 0) {
    const currentTitle = jobTitles[0];
    const skillsText = keySkills.length > 0 ? ` | ${keySkills.join(', ')}` : '';
    return `${currentTitle}${skillsText}`;
  }
  
  return keySkills.length > 0 ? keySkills.join(' | ') : "Professional";
}

function generateLinkedInSummary(sections: any): string {
  const summary = sections.summary || sections.about || "";
  const experience = sections.experience || "";
  
  if (summary) {
    // Optimize existing summary for LinkedIn
    return optimizeSummaryForLinkedIn(summary);
  }
  
  // Generate summary from experience
  return generateSummaryFromExperience(experience);
}

function formatLinkedInExperience(experienceText: string) {
  const experiences: any[] = [];
  if (!experienceText) return experiences;
  
  // Split by job entries (look for patterns like "**Title** at Company")
  const jobEntries = experienceText.split(/(?=\*\*[^*]+\*\*\s+at\s+)/i);
  
  for (const entry of jobEntries) {
    if (!entry.trim()) continue;
    
    const titleMatch = entry.match(/\*\*([^*]+)\*\*\s+at\s+([^*\n]+)/i);
    if (titleMatch) {
      const title = titleMatch[1].trim();
      const company = titleMatch[2].trim();
      const duration = extractDuration(entry) || "Present";
      const description = extractJobDescription(entry);
      const skills = extractSkillsFromText(entry);
      
      experiences.push({
        title,
        company,
        duration,
        description,
        skills
      });
    }
  }
  
  return experiences;
}

function formatLinkedInEducation(educationText: string) {
  const education: any[] = [];
  if (!educationText) return education;
  
  const entries = educationText.split(/(?=\*\*[^*]+\*\*)/);
  
  for (const entry of entries) {
    if (!entry.trim()) continue;
    
    const degreeMatch = entry.match(/\*\*([^*]+)\*\*/);
    const institutionMatch = entry.match(/([A-Z][a-zA-Z\s&]+(?:University|College|Institute|School))/);
    const yearMatch = entry.match(/(\d{4})/);
    
    if (degreeMatch) {
      education.push({
        degree: degreeMatch[1].trim(),
        institution: institutionMatch ? institutionMatch[1].trim() : "Unknown Institution",
        year: yearMatch ? yearMatch[1] : "Unknown"
      });
    }
  }
  
  return education;
}

function extractSkills(content: string): string[] {
  const skillsSection = content.match(/#+\s*Skills[\s\S]*?(?=#+|$)/i);
  if (!skillsSection) return [];
  
  const skillsText = skillsSection[0];
  const skills: string[] = [];
  
  // Extract from bullet points
  const bulletPoints = skillsText.match(/[-*]\s*([^\n]+)/g) || [];
  for (const point of bulletPoints) {
    const skill = point.replace(/^[-*]\s*/, '').trim();
    if (skill) skills.push(skill);
  }
  
  // Extract from comma-separated lists
  const commaLists = skillsText.match(/:\s*([^:\n]+)/g) || [];
  for (const list of commaLists) {
    const listSkills = list.replace(/^:\s*/, '').split(',');
    skills.push(...listSkills.map(s => s.trim()).filter(s => s));
  }
  
  // Remove duplicates and limit to 20 skills
  const uniqueSkills: string[] = [];
  for (const skill of skills) {
    if (!uniqueSkills.includes(skill)) {
      uniqueSkills.push(skill);
    }
  }
  return uniqueSkills.slice(0, 20);
}

function generateLinkedInRecommendations(sections: any, skills: string[]): any {
  return {
    summary: "Consider adding specific metrics and achievements to make your summary more compelling.",
    experience: "Include quantifiable results (e.g., 'Increased sales by 25%') to demonstrate impact.",
    skills: `Top skills identified: ${skills.slice(0, 5).join(', ')}. Consider adding endorsements for these.`
  };
}

// Helper functions for JSON parsing
function extractContactInfo(content: string) {
  const emailMatch = content.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  const phoneMatch = content.match(/(\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4})/);
  const linkedinMatch = content.match(/(linkedin\.com\/in\/[a-zA-Z0-9-]+)/);
  const websiteMatch = content.match(/(https?:\/\/[^\s]+)/);
  
  return {
    email: emailMatch ? emailMatch[1] : "",
    phone: phoneMatch ? phoneMatch[1] : "",
    linkedin: linkedinMatch ? linkedinMatch[1] : "",
    website: websiteMatch ? websiteMatch[1] : "",
    name: "",
    location: ""
  };
}

function extractNameFromContent(content: string): string {
  const lines = content.split('\n');
  const firstLine = lines[0]?.trim();
  
  // Look for name in first line (usually the largest heading)
  if (firstLine && !firstLine.startsWith('#') && firstLine.length < 50) {
    return firstLine;
  }
  
  // Look for name in markdown heading
  const nameMatch = content.match(/^#\s*([^#\n]+)/);
  if (nameMatch) {
    return nameMatch[1].trim();
  }
  
  return "Unknown";
}

function parseExperienceSection(experienceText: string) {
  // Implementation similar to formatLinkedInExperience but with more detailed structure
  const experiences: any[] = [];
  if (!experienceText) return experiences;
  
  const jobEntries = experienceText.split(/(?=\*\*[^*]+\*\*)/);
  
  for (const entry of jobEntries) {
    if (!entry.trim()) continue;
    
    const titleMatch = entry.match(/\*\*([^*]+)\*\*/);
    if (titleMatch) {
      const title = titleMatch[1].trim();
      const company = extractCompanyName(entry);
      const location = extractLocation(entry);
      const { startDate, endDate } = extractDateRange(entry);
      const description = extractJobDescription(entry);
      const achievements = extractAchievements(entry);
      
      experiences.push({
        title,
        company,
        location,
        startDate,
        endDate,
        description,
        achievements
      });
    }
  }
  
  return experiences;
}

function parseEducationSection(educationText: string) {
  // Similar to formatLinkedInEducation but with more details
  const education: any[] = [];
  if (!educationText) return education;
  
  const entries = educationText.split(/(?=\*\*[^*]+\*\*)/);
  
  for (const entry of entries) {
    if (!entry.trim()) continue;
    
    const degreeMatch = entry.match(/\*\*([^*]+)\*\*/);
    if (degreeMatch) {
      education.push({
        degree: degreeMatch[1].trim(),
        institution: extractInstitutionName(entry),
        location: extractLocation(entry),
        graduationDate: extractGraduationDate(entry),
        gpa: extractGPA(entry),
        honors: extractHonors(entry)
      });
    }
  }
  
  return education;
}

function parseSkillsSection(content: string) {
  const skills = extractSkills(content);
  
  return {
    technical: skills.filter(skill => 
      skill.match(/(JavaScript|Python|React|Node|SQL|AWS|Docker|Git|API|Database|Programming|Development|Software|Technology|Framework|Library)/i)
    ),
    soft: skills.filter(skill => 
      skill.match(/(Leadership|Communication|Management|Teamwork|Problem|Analysis|Strategy|Planning|Organization)/i)
    ),
    languages: skills.filter(skill => 
      skill.match(/(English|Spanish|French|German|Chinese|Japanese|Portuguese|Italian|Russian|Arabic)/i)
    ),
    certifications: skills.filter(skill => 
      skill.match(/(Certified|Certification|AWS|Google|Microsoft|Oracle|Cisco|PMP|Scrum|Agile)/i)
    )
  };
}

function parseProjectsSection(projectsText: string) {
  const projects: any[] = [];
  if (!projectsText) return projects;
  
  const projectEntries = projectsText.split(/(?=\*\*[^*]+\*\*)/);
  
  for (const entry of projectEntries) {
    if (!entry.trim()) continue;
    
    const nameMatch = entry.match(/\*\*([^*]+)\*\*/);
    if (nameMatch) {
      projects.push({
        name: nameMatch[1].trim(),
        description: extractProjectDescription(entry),
        technologies: extractTechnologies(entry),
        url: extractProjectURL(entry)
      });
    }
  }
  
  return projects;
}

function parseCertificationsSection(certificationsText: string) {
  const certifications: any[] = [];
  if (!certificationsText) return certifications;
  
  const certEntries = certificationsText.split(/(?=\*\*[^*]+\*\*)/);
  
  for (const entry of certEntries) {
    if (!entry.trim()) continue;
    
    const nameMatch = entry.match(/\*\*([^*]+)\*\*/);
    if (nameMatch) {
      certifications.push({
        name: nameMatch[1].trim(),
        issuer: extractCertificationIssuer(entry),
        date: extractCertificationDate(entry),
        url: extractCertificationURL(entry)
      });
    }
  }
  
  return certifications;
}

function generateResumeAnalytics(experience: any[], skills: any, education: any[]) {
  const totalExperience = calculateTotalExperience(experience);
  const skillCount = Object.values(skills).flat().length;
  const educationLevel = determineEducationLevel(education);
  const industryFocus = determineIndustryFocus(experience);
  
  return {
    totalExperience,
    skillCount,
    educationLevel,
    industryFocus
  };
}

// Additional helper functions (simplified implementations)
function extractJobTitles(text: string): string[] {
  const matches = text.match(/\*\*([^*]+)\*\*/g) || [];
  return matches.map(m => m.replace(/\*\*/g, '')).slice(0, 3);
}

function extractTopSkills(text: string, count: number): string[] {
  const commonSkills = ['JavaScript', 'Python', 'React', 'Leadership', 'Management', 'Communication'];
  return commonSkills.filter(skill => 
    text.toLowerCase().includes(skill.toLowerCase())
  ).slice(0, count);
}

function optimizeSummaryForLinkedIn(summary: string): string {
  return summary.length > 300 ? summary.substring(0, 297) + '...' : summary;
}

function generateSummaryFromExperience(experience: string): string {
  return "Professional with diverse experience in various roles and industries.";
}

function extractDuration(text: string): string {
  const dateMatch = text.match(/(\d{4})\s*[-–—]\s*(\d{4}|Present|Current)/i);
  return dateMatch ? `${dateMatch[1]} - ${dateMatch[2]}` : "";
}

function extractJobDescription(text: string): string {
  const lines = text.split('\n').filter(line => 
    !line.match(/\*\*[^*]+\*\*/) && line.trim() && !line.match(/^\s*[-*]/)
  );
  return lines.join(' ').trim();
}

function extractSkillsFromText(text: string): string[] {
  const commonSkills = ['JavaScript', 'Python', 'React', 'Node.js', 'SQL', 'AWS'];
  return commonSkills.filter(skill => 
    text.toLowerCase().includes(skill.toLowerCase())
  );
}

// Placeholder implementations for additional extraction functions
function extractCompanyName(text: string): string { return "Company"; }
function extractLocation(text: string): string { return ""; }
function extractDateRange(text: string): { startDate: string; endDate: string } { 
  return { startDate: "", endDate: "" }; 
}
function extractAchievements(text: string): string[] { return []; }
function extractInstitutionName(text: string): string { return "Institution"; }
function extractGraduationDate(text: string): string { return ""; }
function extractGPA(text: string): string { return ""; }
function extractHonors(text: string): string[] { return []; }
function extractProjectDescription(text: string): string { return ""; }
function extractTechnologies(text: string): string[] { return []; }
function extractProjectURL(text: string): string { return ""; }
function extractCertificationIssuer(text: string): string { return ""; }
function extractCertificationDate(text: string): string { return ""; }
function extractCertificationURL(text: string): string { return ""; }
function calculateTotalExperience(experience: any[]): number { return experience.length; }
function determineEducationLevel(education: any[]): string { return "Bachelor's"; }
function determineIndustryFocus(experience: any[]): string[] { return ["Technology"]; }