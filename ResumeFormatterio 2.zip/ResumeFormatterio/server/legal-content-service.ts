
import { wordpressAPI } from './wordpress-api';

interface LegalPageVariables {
  appName: string;
  appUrl: string;
  supportEmail: string;
  supportCenterUrl: string;
  knowledgeBaseUrl: string;
  appFeatures: string[];
  legalPages: Array<{ name: string; route: string }>;
}

export class LegalContentService {
  private variables: LegalPageVariables = {
    appName: 'ResumeFormatter.io',
    appUrl: 'https://resumeformatter.io',
    supportEmail: 'help@resumeformatter.io',
    supportCenterUrl: 'https://resumeformatter.io/support',
    knowledgeBaseUrl: 'https://resumeformatter.io/knowledge-base',
    appFeatures: [
      'Markdown-powered resume editor',
      'ATS-optimized templates',
      'AI-powered optimization',
      'Multiple export formats (PDF, DOCX, HTML)',
      'Resume version control',
      'Real-time collaboration',
      'Custom branding options',
      'Analytics and performance tracking'
    ],
    legalPages: [
      { name: 'Privacy Policy', route: '/privacy' },
      { name: 'Terms of Service', route: '/legal#terms' },
      { name: 'Cookie Policy', route: '/legal#cookies' },
      { name: 'Data Retention Policy', route: '/legal#data-retention' }
    ]
  };

  async getLegalPageContent(slug: string): Promise<string | null> {
    try {
      const post = await wordpressAPI.getPost(slug);
      if (!post) {
        return null;
      }

      return this.substituteVariables(post.content.rendered);
    } catch (error) {
      console.error(`Error fetching legal page ${slug}:`, error);
      return null;
    }
  }

  async getAllLegalPages(): Promise<Array<{ slug: string; title: string; content: string }>> {
    try {
      // Fetch posts with legal-related categories or tags
      const posts = await wordpressAPI.getPosts(1, 20);
      const legalPosts = posts.filter(post => 
        post.title.rendered.toLowerCase().includes('privacy') ||
        post.title.rendered.toLowerCase().includes('terms') ||
        post.title.rendered.toLowerCase().includes('cookie') ||
        post.title.rendered.toLowerCase().includes('legal') ||
        post.slug.includes('privacy') ||
        post.slug.includes('terms') ||
        post.slug.includes('legal')
      );

      return legalPosts.map(post => ({
        slug: post.slug,
        title: post.title.rendered,
        content: this.substituteVariables(post.content.rendered)
      }));
    } catch (error) {
      console.error('Error fetching legal pages:', error);
      return [];
    }
  }

  private substituteVariables(content: string): string {
    let processedContent = content;

    // Replace app name
    processedContent = processedContent.replace(/\{\{App Name\}\}/g, this.variables.appName);
    
    // Replace app URL
    processedContent = processedContent.replace(/\{\{App URL\}\}/g, this.variables.appUrl);
    
    // Replace support email
    processedContent = processedContent.replace(/\{\{Support Email\}\}/g, this.variables.supportEmail);
    
    // Replace support center URL
    processedContent = processedContent.replace(/\{\{Support Center URL\}\}/g, this.variables.supportCenterUrl);
    
    // Replace knowledge base URL
    processedContent = processedContent.replace(/\{\{Knowledge Base URL\}\}/g, this.variables.knowledgeBaseUrl);
    
    // Replace app features with bulleted list
    const featuresHtml = this.variables.appFeatures
      .map(feature => `<li>${feature}</li>`)
      .join('');
    processedContent = processedContent.replace(
      /\{\{App Features\}\}/g, 
      `<ul>${featuresHtml}</ul>`
    );
    
    // Replace other legal pages with links
    const legalPagesHtml = this.variables.legalPages
      .map(page => `<li><a href="${page.route}" class="text-blue-600 hover:underline">${page.name}</a></li>`)
      .join('');
    processedContent = processedContent.replace(
      /\{\{Other Legal Pages?\}\}/g,
      `<ul>${legalPagesHtml}</ul>`
    );

    return processedContent;
  }

  updateVariables(newVariables: Partial<LegalPageVariables>): void {
    this.variables = { ...this.variables, ...newVariables };
  }

  getVariables(): LegalPageVariables {
    return { ...this.variables };
  }
}

export const legalContentService = new LegalContentService();
