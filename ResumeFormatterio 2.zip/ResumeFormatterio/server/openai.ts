import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "default_key"
});

export async function analyzeResumeATS(resumeContent: string, jobDescription?: string): Promise<{
  atsScore: number;
  matchedKeywords: string[];
  missingKeywords: string[];
  suggestions: Array<{
    type: 'metrics' | 'keywords' | 'action_verbs' | 'format';
    title: string;
    description: string;
    example?: string;
    priority: 'high' | 'medium' | 'low';
  }>;
}> {
  try {
    const prompt = `Analyze this resume for ATS compatibility and provide optimization suggestions.

Resume Content:
${resumeContent}

${jobDescription ? `Job Description:
${jobDescription}` : ''}

Please analyze the resume and provide:
1. An ATS score from 1-100
2. Keywords that match well (if job description provided)
3. Missing important keywords (if job description provided)
4. Top 3-5 improvement suggestions

Respond with JSON in this exact format:
{
  "atsScore": number,
  "matchedKeywords": ["keyword1", "keyword2"],
  "missingKeywords": ["keyword1", "keyword2"],
  "suggestions": [
    {
      "type": "metrics",
      "title": "Add Quantified Achievements",
      "description": "Include specific numbers and metrics",
      "example": "Improved system performance by 40%",
      "priority": "high"
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert ATS (Applicant Tracking System) analyzer and career coach. Provide detailed, actionable feedback for resume optimization."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      atsScore: Math.min(100, Math.max(1, result.atsScore || 75)),
      matchedKeywords: result.matchedKeywords || [],
      missingKeywords: result.missingKeywords || [],
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error("Error analyzing resume with OpenAI:", error);
    throw new Error("Failed to analyze resume: " + (error as Error).message);
  }
}

export async function optimizeResumeContent(resumeContent: string, suggestions: any[]): Promise<string> {
  try {
    const prompt = `Please optimize this resume content based on the provided suggestions. Maintain the original structure and format but improve the content according to the suggestions.

Original Resume:
${resumeContent}

Suggestions to apply:
${suggestions.map((s, i) => `${i + 1}. ${s.title}: ${s.description}`).join('\n')}

Please return the optimized resume content maintaining the original Markdown format.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert resume writer. Optimize the resume content while maintaining its structure and format. Focus on making improvements based on the specific suggestions provided."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.4,
    });

    return response.choices[0].message.content || resumeContent;
  } catch (error) {
    console.error("Error optimizing resume content:", error);
    throw new Error("Failed to optimize resume content: " + (error as Error).message);
  }
}

export async function generateCoverLetter(
  resumeContent: string, 
  jobTitle?: string, 
  company?: string, 
  tone: 'formal' | 'friendly' | 'executive' = 'formal'
): Promise<string> {
  try {
    const toneInstructions = {
      formal: "Use a professional, formal tone with traditional business language.",
      friendly: "Use a warm, personable tone while maintaining professionalism.",
      executive: "Use a confident, leadership-focused tone suitable for senior positions."
    };

    const prompt = `Generate a compelling cover letter based on this resume content.

Resume Content:
${resumeContent}

${jobTitle ? `Job Title: ${jobTitle}` : ''}
${company ? `Company: ${company}` : ''}

Tone: ${tone} - ${toneInstructions[tone]}

Please create a compelling cover letter that:
1. Highlights relevant experience from the resume
2. Shows enthusiasm for the role/company
3. Demonstrates value proposition
4. Is 3-4 paragraphs long
5. Uses the specified tone

Format as a professional cover letter without address headers.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert cover letter writer. Create compelling, personalized cover letters that highlight the candidate's strengths and match them to the role."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.6,
    });

    return response.choices[0].message.content || "Failed to generate cover letter content.";
  } catch (error) {
    console.error("Error generating cover letter:", error);
    throw new Error("Failed to generate cover letter: " + (error as Error).message);
  }
}
