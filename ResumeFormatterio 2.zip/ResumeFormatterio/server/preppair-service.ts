import jwt from "jsonwebtoken";

const SECRET_KEY = process.env.JWT_SECRET || "resumeformatter_preppair_integration_secret_2024";
const PREPPAIR_API_URL = "https://preppair.me/api/import-resume";

export interface ResumeTransferData {
  replit_id: string;
  resume_markdown: string;
  template: string;
  title?: string;
}

export interface PrepPairResponse {
  success: boolean;
  message: string;
  interview_prep_url?: string;
}

export function generateResumeTransferToken(replitId: string): string {
  const payload = {
    replit_id: replitId,
    aud: "preppair.me",
    iss: "resumeformatter.io",
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 3600, // 1 hour expiration
  };

  return jwt.sign(payload, SECRET_KEY, { algorithm: "HS256" });
}

export async function transferResumeToPrepPair(data: ResumeTransferData): Promise<PrepPairResponse> {
  try {
    const token = generateResumeTransferToken(data.replit_id);
    
    const response = await fetch(PREPPAIR_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'User-Agent': 'ResumeFormatter.io/1.0'
      },
      body: JSON.stringify({
        replit_id: data.replit_id,
        resume_markdown: data.resume_markdown,
        template: data.template,
        title: data.title,
        source: 'resumeformatter.io'
      })
    });

    if (!response.ok) {
      throw new Error(`PrepPair API error: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    return {
      success: true,
      message: "Resume successfully transferred to PrepPair.me",
      interview_prep_url: result.interview_prep_url
    };
  } catch (error) {
    console.error("PrepPair transfer error:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : "Failed to transfer resume to PrepPair.me"
    };
  }
}

export function validateResumeForTransfer(content: string): { valid: boolean; message?: string } {
  if (!content || content.trim().length < 100) {
    return { valid: false, message: "Resume content is too short for transfer" };
  }

  const hasBasicSections = /experience|education|skills/gi.test(content);
  if (!hasBasicSections) {
    return { valid: false, message: "Resume must include basic sections (experience, education, or skills)" };
  }

  const hasContactInfo = /@/.test(content) || /\d{3}/.test(content);
  if (!hasContactInfo) {
    return { valid: false, message: "Resume should include contact information" };
  }

  return { valid: true };
}