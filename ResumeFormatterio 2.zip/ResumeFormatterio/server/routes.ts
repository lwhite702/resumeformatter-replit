import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerAdminRoutes } from "./admin-routes";
import Stripe from "stripe";
import { analyzeResumeATS, generateCoverLetter, optimizeResumeContent } from "./openai";
import { generateResumePDF, generateResumeDocx } from "./pdf-utils";
import { exportService } from "./export-service";
import { wordpressAPI } from "./wordpress-api";
import { beehiivService } from "./beehiiv-service";
import { legalContentService } from "./legal-content-service";
import { transferResumeToPrepPair, validateResumeForTransfer } from "./preppair-service";
import { autoApplyService } from "./autoapply-service";
import { generateLinkedInContent, parseResumeToJSON } from "./export-utils";
import multer from "multer";
import { z } from "zod";
import { insertResumeSchema, insertResumeVersionSchema, insertCoverLetterSchema, insertNewsletterSubscriberSchema, cachedPosts } from "@shared/schema";
import { triggerWordPressCache } from "./scheduledTasks";
import { desc } from "drizzle-orm";
import OpenAI from "openai";
import puppeteer from "puppeteer";
import { promises as fs } from "fs";
import path from "path";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
});

const upload = multer({ storage: multer.memoryStorage() });

// Enhanced Resume Scoring Algorithm
function analyzeResumeScore(content: string) {
  const lines = content.trim().split('\n').filter(line => line.trim().length > 0);
  const wordCount = content.trim().split(/\s+/).length;
  
  // 1. RELEVANCE TO ROLE (25 points)
  const actionVerbs = ['achieved', 'managed', 'developed', 'created', 'implemented', 'improved', 'increased', 'reduced', 'led', 'coordinated', 'designed', 'built', 'optimized', 'delivered', 'launched', 'executed', 'streamlined', 'established'];
  const actionVerbMatches = actionVerbs.filter(verb => new RegExp(`\\b${verb}`, 'i').test(content)).length;
  const industryKeywords = /(?:project|team|client|strategy|analysis|leadership|innovation|technology|digital|business|management|operations|sales|marketing|development)/gi;
  const keywordMatches = (content.match(industryKeywords) || []).length;
  const relevance = Math.min(25, (actionVerbMatches * 1.5) + Math.min(keywordMatches * 0.8, 10));

  // 2. READABILITY (20 points)
  const avgWordsPerLine = lines.length ? wordCount / lines.length : 0;
  const optimalReadability = avgWordsPerLine >= 5 && avgWordsPerLine <= 12;
  const bulletPoints = (content.match(/^[\s]*[-*•]\s/gm) || []).length;
  const hasGoodStructure = bulletPoints >= 5;
  const properSentenceStructure = /[.!?]\s*$/.test(content.trim());
  const readability = (optimalReadability ? 8 : 4) + (hasGoodStructure ? 8 : Math.min(bulletPoints * 1.5, 6)) + (properSentenceStructure ? 4 : 0);

  // 3. ATS COMPLIANCE (20 points)
  const hasEmail = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/.test(content);
  const hasPhone = /(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/.test(content);
  const noATSBlockers = !/(?:table|image|graphic|chart|column)/i.test(content) && !/\t/.test(content);
  const standardSections = /(?:experience|education|skills|summary)/gi.test(content);
  const simpleFormatting = !content.includes('|') && !content.includes('─');
  const ats = (hasEmail ? 5 : 0) + (hasPhone ? 4 : 0) + (noATSBlockers ? 4 : 0) + (standardSections ? 4 : 0) + (simpleFormatting ? 3 : 0);

  // 4. STRUCTURE/LAYOUT (15 points)
  const hasSections = {
    summary: /(?:summary|objective|profile|about)/i.test(content),
    experience: /(?:experience|work|employment|career|professional)/i.test(content),
    education: /(?:education|degree|university|college|school|academic)/i.test(content),
    skills: /(?:skills|technical|competencies|technologies|tools)/i.test(content),
    contact: hasEmail || hasPhone
  };
  const sectionCount = Object.values(hasSections).filter(Boolean).length;
  const hasLogicalOrder = /summary.*experience.*education|experience.*education.*skills/i.test(content);
  const structure = Math.min(15, (sectionCount * 2.5) + (hasLogicalOrder ? 3 : 0));

  // 5. ACHIEVEMENT LANGUAGE (20 points)
  const quantifiableResults = (content.match(/\d+%|\$[\d,]+|\d+\+|[0-9]+(?:,\d{3})*(?:\.\d+)?[kKmM]?|\d+(?:\.\d+)?[xX]|increased.*\d+|reduced.*\d+|improved.*\d+/g) || []).length;
  const impactWords = ['increased', 'reduced', 'improved', 'generated', 'saved', 'grew', 'exceeded', 'delivered', 'accelerated', 'enhanced', 'maximized'];
  const impactMatches = impactWords.filter(word => new RegExp(`\\b${word}`, 'i').test(content)).length;
  const resultOriented = /(?:resulted in|led to|achieved|accomplished|delivered)/gi.test(content);
  const achievements = Math.min(20, (quantifiableResults * 2.5) + (impactMatches * 1.5) + (resultOriented ? 3 : 0));

  // BONUS SCORES
  const hasProperCapitalization = /[A-Z][a-z]/.test(content) && !/[a-z][A-Z]/.test(content);
  const hasConsistentFormatting = /^#{1,3}\s/.test(content) && lines.length >= 8;
  const templateFit = Math.min(5, (hasProperCapitalization ? 2 : 0) + (hasConsistentFormatting ? 3 : 0));

  const hasConsistentDates = /(19|20)\d{2}/.test(content);
  const hasLinkedIn = /linkedin\.com|LinkedIn/.test(content);
  const consistentBullets = /^[\s]*[-*•]\s/gm.test(content);
  const formatting = Math.min(5, (hasConsistentDates ? 2 : 0) + (hasLinkedIn ? 2 : 0) + (consistentBullets ? 1 : 0));

  const totalScore = Math.min(110, relevance + readability + ats + structure + achievements + templateFit + formatting);

  const suggestions = [];
  if (actionVerbMatches < 5) suggestions.push("Use more strong action verbs (achieved, managed, developed, etc.)");
  if (keywordMatches < 8) suggestions.push("Include relevant industry keywords and terminology");
  if (!optimalReadability) suggestions.push("Keep lines concise with 5-12 words for better readability");
  if (bulletPoints < 5) suggestions.push("Use bullet points to organize achievements and responsibilities");
  if (!hasEmail) suggestions.push("Add a professional email address");
  if (!hasPhone) suggestions.push("Include your phone number");
  if (!noATSBlockers) suggestions.push("Avoid tables, images, or complex formatting that ATS cannot read");
  if (quantifiableResults < 3) suggestions.push("Add specific numbers, percentages, and metrics to show impact");

  let healthSummary = "This resume needs significant improvement across multiple areas.";
  if (totalScore >= 90) healthSummary = "This resume is excellent and ready for submission to top-tier positions.";
  else if (totalScore >= 75) healthSummary = "This resume is well-structured and competitive. Minor tweaks will make it perfect.";
  else if (totalScore >= 60) healthSummary = "This resume has a solid foundation but needs targeted improvements.";

  return {
    totalScore: Math.round(totalScore),
    categoryScores: {
      relevance: Math.round(relevance),
      readability: Math.round(readability), 
      ats: Math.round(ats),
      structure: Math.round(structure),
      achievements: Math.round(achievements)
    },
    bonusScores: {
      template_fit: Math.round(templateFit),
      formatting: Math.round(formatting)
    },
    suggestions,
    healthSummary
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Simple auth middleware placeholder for Clerk integration
  const authMiddleware = (req: any, res: any, next: any) => {
    // Clerk handles authentication on the frontend
    // Backend endpoints are open for now since auth is handled client-side
    next();
  };

  // API token authentication middleware for external integrations
  const apiTokenAuth = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    const expectedToken = process.env.RESUME_FORMATTER_API_KEY;
    
    if (!expectedToken) {
      return res.status(500).json({ error: 'API authentication not configured' });
    }
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Bearer token required' });
    }
    
    const token = authHeader.substring(7);
    if (token !== expectedToken) {
      return res.status(401).json({ error: 'Invalid API token' });
    }
    
    next();
  };

  // Paid membership authentication for premium features
  const requirePaidMembership = async (req: any, res: any, next: any) => {
    try {
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
      }

      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if user has paid membership (Pro plan)
      if (user.plan !== 'pro') {
        return res.status(403).json({ 
          error: 'AutoApply integration requires Pro membership',
          userPlan: user.plan,
          upgradeRequired: true 
        });
      }

      req.user = user;
      next();
    } catch (error) {
      console.error('Error checking user membership:', error);
      res.status(500).json({ error: 'Failed to verify membership' });
    }
  };

  // AutoApply Integration API Endpoints
  app.get('/v1/resumes', apiTokenAuth, async (req: any, res) => {
    try {
      const userId = req.query.userId;
      
      if (!userId) {
        return res.status(400).json({ error: 'userId query parameter is required' });
      }

      const resumeData = await autoApplyService.getUserResumesForAutoApply(userId);
      res.json(resumeData);
    } catch (error) {
      console.error("Error fetching resumes for AutoApply:", error);
      res.status(500).json({ error: "Failed to fetch resumes" });
    }
  });

  app.get('/v1/resumes/:id/download', apiTokenAuth, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.query.userId as string;
      
      if (!userId) {
        return res.status(400).json({ error: 'userId query parameter is required' });
      }

      const resume = await storage.getResume(resumeId);
      
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ error: "Resume not found" });
      }

      // Generate PDF and return download URL
      const pdfBuffer = await generateResumePDF(resume.content, resume.templateId || 'modern');
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${resume.title}.pdf"`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error generating resume download:", error);
      res.status(500).json({ error: "Failed to generate resume download" });
    }
  });

  // AutoApply sync endpoints - require Pro membership
  app.post('/api/autoapply/sync/:resumeId', requirePaidMembership, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.resumeId);
      const userId = req.user.id;

      const success = await autoApplyService.syncResumeWithAutoApply(userId, resumeId);
      
      if (success) {
        res.json({ 
          message: "Resume synced successfully with AutoApply",
          success: true 
        });
      } else {
        res.status(500).json({ 
          message: "Failed to sync resume with AutoApply",
          success: false 
        });
      }
    } catch (error) {
      console.error("Error syncing resume with AutoApply:", error);
      res.status(500).json({ message: "Failed to sync resume" });
    }
  });

  app.post('/api/autoapply/sync-all', requirePaidMembership, async (req: any, res) => {
    try {
      const userId = req.user.id;

      const result = await autoApplyService.syncAllUserResumesWithAutoApply(userId);
      res.json({
        message: `Sync completed: ${result.success} successful, ${result.failed} failed`,
        success: result.success,
        failed: result.failed,
        total: result.success + result.failed
      });
    } catch (error) {
      console.error("Error syncing all resumes with AutoApply:", error);
      res.status(500).json({ message: "Failed to sync resumes" });
    }
  });

  // Check AutoApply integration availability for user
  app.get('/api/autoapply/status', async (req: any, res) => {
    try {
      const userId = req.query.userId as string;
      
      if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
      }

      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const isAvailable = user.plan === 'pro';
      const integrationConfig = autoApplyService.getConfig();

      res.json({
        available: isAvailable,
        userPlan: user.plan,
        requiresPro: true,
        configured: integrationConfig.enabled,
        message: isAvailable 
          ? 'AutoApply integration is available' 
          : 'Upgrade to Pro to access AutoApply integration'
      });
    } catch (error) {
      console.error("Error checking AutoApply status:", error);
      res.status(500).json({ error: "Failed to check integration status" });
    }
  });

  // User management routes - Clerk handles authentication
  app.post('/api/users', async (req: any, res) => {
    try {
      const { userId, email, firstName, lastName, profileImageUrl } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const user = await storage.upsertUser({
        id: userId,
        email,
        firstName,
        lastName,
        profileImageUrl,
      });
      
      res.json(user);
    } catch (error) {
      console.error("Error creating/updating user:", error);
      res.status(500).json({ message: "Failed to create/update user" });
    }
  });

  // Resume routes
  app.get('/api/resumes/:userId', async (req: any, res) => {
    try {
      const userId = req.params.userId;
      const resumes = await storage.getUserResumes(userId);
      res.json(resumes);
    } catch (error) {
      console.error("Error fetching resumes:", error);
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });

  app.get('/api/resumes/:userId/:id', async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.params.userId;
      const resume = await storage.getResume(resumeId);
      
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      res.json(resume);
    } catch (error) {
      console.error("Error fetching resume:", error);
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });

  app.post('/api/resumes', async (req: any, res) => {
    try {
      const { userId, title, content, templateId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const resumeData = insertResumeSchema.parse({
        ...req.body,
        userId,
      });
      
      const resume = await storage.createResume(resumeData);
      res.json(resume);
    } catch (error) {
      console.error("Error creating resume:", error);
      res.status(500).json({ message: "Failed to create resume" });
    }
  });

  app.put('/api/resumes/:id', async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const { userId } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      // Check ownership
      const existingResume = await storage.getResume(resumeId);
      if (!existingResume || existingResume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const updates = req.body;
      delete updates.userId; // Prevent userId from being updated
      
      const resume = await storage.updateResume(resumeId, updates);
      res.json(resume);
    } catch (error) {
      console.error("Error updating resume:", error);
      res.status(500).json({ message: "Failed to update resume" });
    }
  });

  app.delete('/api/resumes/:id', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const existingResume = await storage.getResume(resumeId);
      if (!existingResume || existingResume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      await storage.deleteResume(resumeId);
      res.json({ message: "Resume deleted successfully" });
    } catch (error) {
      console.error("Error deleting resume:", error);
      res.status(500).json({ message: "Failed to delete resume" });
    }
  });

  // Resume version routes
  app.get('/api/resumes/:id/versions', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const versions = await storage.getResumeVersions(resumeId);
      res.json(versions);
    } catch (error) {
      console.error("Error fetching resume versions:", error);
      res.status(500).json({ message: "Failed to fetch resume versions" });
    }
  });

  app.post('/api/resumes/:id/versions', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const versionData = insertResumeVersionSchema.parse({
        ...req.body,
        resumeId,
      });
      
      const version = await storage.createResumeVersion(versionData);
      res.json(version);
    } catch (error) {
      console.error("Error creating resume version:", error);
      res.status(500).json({ message: "Failed to create resume version" });
    }
  });

  // Cover letter routes
  app.get('/api/cover-letters', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const coverLetters = await storage.getUserCoverLetters(userId);
      res.json(coverLetters);
    } catch (error) {
      console.error("Error fetching cover letters:", error);
      res.status(500).json({ message: "Failed to fetch cover letters" });
    }
  });

  app.post('/api/cover-letters/generate', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check credits
      if (user.plan === 'free' && user.credits < 1) {
        return res.status(403).json({ message: "Insufficient credits" });
      }
      
      const { resumeContent, jobTitle, company, tone = 'formal' } = req.body;
      
      if (!resumeContent) {
        return res.status(400).json({ message: "Resume content is required" });
      }
      
      const coverLetterContent = await generateCoverLetter(resumeContent, jobTitle, company, tone);
      
      const coverLetter = await storage.createCoverLetter({
        userId,
        title: `Cover Letter - ${jobTitle || 'General'}`,
        content: coverLetterContent,
        jobTitle,
        company,
        tone,
      });
      
      // Deduct credit for free users
      if (user.plan === 'free') {
        await storage.updateUserCredits(userId, user.credits - 1);
      }
      
      res.json(coverLetter);
    } catch (error) {
      console.error("Error generating cover letter:", error);
      res.status(500).json({ message: "Failed to generate cover letter" });
    }
  });

  // Resume scoring endpoint
  app.post('/api/score/resume', authMiddleware, async (req: any, res) => {
    try {
      const { content, platform = "resumeformatter" } = req.body;
      const userId = req.user.claims.sub;
      
      if (!content) {
        return res.status(400).json({ error: "Resume content is required" });
      }

      // Enhanced scoring algorithm implementation
      const scoreResult = analyzeResumeScore(content);
      
      res.json({
        total_score: scoreResult.totalScore,
        category_scores: scoreResult.categoryScores,
        bonus_scores: scoreResult.bonusScores,
        suggestions: scoreResult.suggestions,
        resume_health_summary: scoreResult.healthSummary,
        platform
      });
    } catch (error) {
      console.error("Resume scoring error:", error);
      res.status(500).json({ error: "Failed to score resume" });
    }
  });

  // AI optimization routes
  app.post('/api/resumes/:id/optimize', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check credits
      if (user.plan === 'free' && user.credits < 3) {
        return res.status(403).json({ message: "Insufficient credits" });
      }
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const { jobDescription } = req.body;
      
      const analysis = await analyzeResumeATS(resume.content, jobDescription);
      
      // Save optimization history
      await storage.createOptimizationHistory({
        userId,
        resumeId,
        jobDescription,
        atsScore: analysis.atsScore,
        suggestions: analysis.suggestions,
        creditsUsed: 3,
      });
      
      // Deduct credits for free users
      if (user.plan === 'free') {
        await storage.updateUserCredits(userId, user.credits - 3);
      }
      
      res.json(analysis);
    } catch (error) {
      console.error("Error optimizing resume:", error);
      res.status(500).json({ message: "Failed to optimize resume" });
    }
  });

  app.post('/api/resumes/:id/optimize-content', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if Pro user
      if (user.plan !== 'pro') {
        return res.status(403).json({ message: "Pro subscription required" });
      }
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const { suggestions } = req.body;
      
      const optimizedContent = await optimizeResumeContent(resume.content, suggestions);
      
      // Update resume with optimized content
      const updatedResume = await storage.updateResume(resumeId, {
        content: optimizedContent,
      });
      
      res.json(updatedResume);
    } catch (error) {
      console.error("Error optimizing resume content:", error);
      res.status(500).json({ message: "Failed to optimize resume content" });
    }
  });

  // PrepPair transfer route
  app.post('/api/resumes/:id/send-to-preppair', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      // Validate resume content
      const validation = validateResumeForTransfer(resume.content);
      if (!validation.valid) {
        return res.status(400).json({ 
          message: validation.message,
          type: "validation_error"
        });
      }

      // Create transfer record
      const transferRecord = await storage.createPrepPairTransfer({
        userId,
        resumeId,
        transferStatus: "pending",
        transferToken: null,
        prepPairUrl: null,
        errorMessage: null,
      });

      // Determine template name
      const templateNames: Record<number, string> = {
        1: "Modern Professional",
        2: "Classic Traditional", 
        3: "Creative Designer",
        4: "Minimalist Clean"
      };
      const templateId = resume.templateId ? Number(resume.templateId) : 1;
      const templateName = templateNames[templateId] || "Modern Clean";

      // Transfer to PrepPair
      const transferResult = await transferResumeToPrepPair({
        replit_id: userId,
        resume_markdown: resume.content,
        template: templateName,
        title: resume.title
      });

      // Update transfer status
      await storage.updatePrepPairTransferStatus(
        transferRecord.id,
        transferResult.success ? "success" : "failed",
        transferResult.interview_prep_url || undefined,
        transferResult.success ? undefined : transferResult.message
      );

      if (transferResult.success) {
        res.json({
          success: true,
          message: "Your resume has been sent to PrepPair. Start your interview prep now →",
          interview_prep_url: transferResult.interview_prep_url
        });
      } else {
        res.status(500).json({
          success: false,
          message: transferResult.message,
          type: "transfer_error"
        });
      }
    } catch (error) {
      console.error("PrepPair transfer error:", error);
      res.status(500).json({ 
        success: false,
        message: "Failed to transfer resume to PrepPair.me",
        type: "server_error"
      });
    }
  });

  // Get PrepPair transfer history
  app.get('/api/preppair-transfers', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transfers = await storage.getPrepPairTransfers(userId);
      res.json(transfers);
    } catch (error) {
      console.error("Error fetching PrepPair transfers:", error);
      res.status(500).json({ message: "Failed to fetch transfer history" });
    }
  });

  // Export routes
  app.get('/api/resumes/:id/export/pdf', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const pdfBuffer = await generateResumePDF(resume.content, resume.templateId);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${resume.title}.pdf"`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error exporting PDF:", error);
      res.status(500).json({ message: "Failed to export PDF" });
    }
  });

  // QuickExport API endpoints
  app.post('/api/resumes/:id/export/pdf', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { templateId, options } = req.body;
      
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      const pdfBuffer = await generateResumePDF(
        resume.content, 
        templateId?.toString() || resume.templateId?.toString() || "1",
        options
      );
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${resume.title || 'resume'}.pdf"`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error generating PDF:", error);
      res.status(500).json({ message: "Failed to generate PDF" });
    }
  });

  // LinkedIn export route
  app.post('/api/resumes/:id/export/linkedin', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { content } = req.body;
      
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      // Check user plan for LinkedIn export
      const user = await storage.getUser(userId);
      if (!user || user.plan === 'free') {
        return res.status(403).json({ 
          message: "LinkedIn export is a Pro feature. Upgrade to access this functionality." 
        });
      }

      // Generate LinkedIn-optimized content using AI
      const linkedinContent = await generateLinkedInContent(content || resume.content);
      
      res.json({
        success: true,
        data: linkedinContent,
        message: "LinkedIn content generated successfully"
      });
    } catch (error) {
      console.error("Error generating LinkedIn content:", error);
      res.status(500).json({ message: "Failed to generate LinkedIn content" });
    }
  });

  // JSON export route
  app.post('/api/resumes/:id/export/json', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { content, title, templateId } = req.body;
      
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }

      // Generate structured JSON from resume content
      const structuredData = await parseResumeToJSON(
        content || resume.content,
        title || resume.title,
        templateId || resume.templateId
      );
      
      res.json({
        success: true,
        data: structuredData,
        exportedAt: new Date().toISOString(),
        format: "json",
        version: "1.0"
      });
    } catch (error) {
      console.error("Error generating JSON export:", error);
      res.status(500).json({ message: "Failed to generate JSON export" });
    }
  });

  app.get('/api/resumes/:id/export/docx', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if Pro user (DOCX export is Pro feature)
      if (user.plan !== 'pro') {
        return res.status(403).json({ message: "Pro subscription required for DOCX export" });
      }
      
      // Check ownership
      const resume = await storage.getResume(resumeId);
      if (!resume || resume.userId !== userId) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      const docxBuffer = await generateResumeDocx(resume.content, resume.templateId);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      res.setHeader('Content-Disposition', `attachment; filename="${resume.title}.docx"`);
      res.send(docxBuffer);
    } catch (error) {
      console.error("Error exporting DOCX:", error);
      res.status(500).json({ message: "Failed to export DOCX" });
    }
  });

  // File upload route for resume import
  app.post('/api/resumes/import', authMiddleware, upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const userId = req.user.claims.sub;
      
      // TODO: Implement file parsing logic for PDF/DOCX
      // For now, return a placeholder response
      const extractedContent = `# Imported Resume
## Please edit this content

The file has been uploaded successfully. Please edit the content below to match your resume.

---

## Contact Information
- **Name:** Your Name
- **Email:** your.email@example.com
- **Phone:** (555) 123-4567

## Summary
Please add your professional summary here.

## Experience
### Job Title | Company Name | Date Range
- Please add your work experience here

## Education
### Degree | Institution | Year
Please add your education details here.

## Skills
Please list your relevant skills here.
`;
      
      const resume = await storage.createResume({
        userId,
        title: `Imported Resume - ${req.file.originalname}`,
        content: extractedContent,
        templateId: 'modern-tech',
      });
      
      res.json(resume);
    } catch (error) {
      console.error("Error importing resume:", error);
      res.status(500).json({ message: "Failed to import resume" });
    }
  });

  // Stripe subscription routes
  app.post('/api/get-or-create-subscription', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);

        res.send({
          subscriptionId: subscription.id,
          clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        });

        return;
      }
      
      if (!user.email) {
        throw new Error('No user email on file');
      }

      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
      });

      user = await storage.updateUserStripeInfo(userId, customer.id);

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: process.env.STRIPE_PRICE_ID,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(userId, customer.id, subscription.id);
      await storage.updateUserPlan(userId, 'pro');
  
      res.send({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      return res.status(400).send({ error: { message: error.message } });
    }
  });

  // Admin routes
  app.get('/api/admin/analytics/:timeRange', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const analytics = await storage.getAnalytics(req.params.timeRange);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.get('/api/admin/user-stats', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const userStats = await storage.getUserStats();
      res.json(userStats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  app.get('/api/admin/revenue-stats/:timeRange', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const revenueStats = await storage.getRevenueStats(req.params.timeRange);
      res.json(revenueStats);
    } catch (error) {
      console.error("Error fetching revenue stats:", error);
      res.status(500).json({ message: "Failed to fetch revenue stats" });
    }
  });

  app.get('/api/admin/activity-metrics', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.email?.includes('admin')) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const activityMetrics = await storage.getActivityMetrics();
      res.json(activityMetrics);
    } catch (error) {
      console.error("Error fetching activity metrics:", error);
      res.status(500).json({ message: "Failed to fetch activity metrics" });
    }
  });

  // Export API routes
  app.post('/api/export/preppair/:resumeId', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resumeId = parseInt(req.params.resumeId);
      const { apiKey, customEndpoint } = req.body;

      if (!resumeId) {
        return res.status(400).json({ message: "Resume ID is required" });
      }

      const result = await exportService.exportToPrepPair(
        userId, 
        resumeId
      );

      if (result.success) {
        res.json({
          success: true,
          message: "Resume exported successfully to PrepPair.me",
          externalId: result.externalId,
          exportUrl: result.exportUrl
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.error
        });
      }
    } catch (error) {
      console.error("Error exporting to PrepPair:", error);
      res.status(500).json({ 
        success: false,
        message: "Failed to export resume to PrepPair.me" 
      });
    }
  });

  // Get user's API integrations
  app.get('/api/integrations', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrations = await exportService.getUserIntegrations(userId);
      res.json(integrations);
    } catch (error) {
      console.error("Error fetching integrations:", error);
      res.status(500).json({ message: "Failed to fetch integrations" });
    }
  });

  // Setup or update API integration
  app.post('/api/integrations', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { platform, apiKey, endpoint } = req.body;

      if (!platform || !apiKey) {
        return res.status(400).json({ message: "Platform and API key are required" });
      }

      const integration = await exportService.setupIntegration(
        userId, 
        platform, 
        apiKey, 
        endpoint
      );

      res.json({
        success: true,
        integration,
        message: `${platform} integration configured successfully`
      });
    } catch (error) {
      console.error("Error setting up integration:", error);
      res.status(500).json({ message: "Failed to setup integration" });
    }
  });

  // Remove API integration
  app.delete('/api/integrations/:id', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const integrationId = parseInt(req.params.id);

      await exportService.removeIntegration(userId, integrationId);
      
      res.json({
        success: true,
        message: "Integration removed successfully"
      });
    } catch (error) {
      console.error("Error removing integration:", error);
      res.status(500).json({ message: "Failed to remove integration" });
    }
  });

  // Get export history for user
  app.get('/api/exports', authMiddleware, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const exports = await exportService.getUserExports(userId);
      res.json(exports);
    } catch (error) {
      console.error("Error fetching export history:", error);
      res.status(500).json({ message: "Failed to fetch export history" });
    }
  });

  // Get export history for specific resume
  app.get('/api/exports/resume/:resumeId', authMiddleware, async (req: any, res) => {
    try {
      const resumeId = parseInt(req.params.resumeId);
      const exports = await exportService.getResumeExports(resumeId);
      res.json(exports);
    } catch (error) {
      console.error("Error fetching resume exports:", error);
      res.status(500).json({ message: "Failed to fetch resume exports" });
    }
  });

  // Resume import routes
  app.post('/api/resume/convert', upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, error: "No file uploaded" });
      }

      const file = req.file;
      let content = '';

      // Extract text based on file type
      if (file.mimetype === 'application/pdf') {
        // For PDF files, we'll use a simple text extraction
        // In production, you might want to use a more sophisticated PDF parser
        const buffer = file.buffer;
        content = buffer.toString('utf8').replace(/[^\x20-\x7E\n\r]/g, ' ');
      } else if (file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        // For DOCX files, extract text (simplified approach)
        content = file.buffer.toString('utf8').replace(/[^\x20-\x7E\n\r]/g, ' ');
      } else if (file.mimetype === 'text/plain' || file.mimetype === 'text/markdown') {
        content = file.buffer.toString('utf8');
      } else {
        return res.status(400).json({ success: false, error: "Unsupported file type" });
      }

      // Use OpenAI to convert to markdown format
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a resume formatting expert. Convert the provided resume content into clean, professional markdown format. Maintain all important information while organizing it in a clear structure with appropriate headings, bullet points, and formatting. Use standard resume sections like Summary, Experience, Skills, Education, etc."
          },
          {
            role: "user",
            content: `Please convert this resume content to markdown format:\n\n${content}`
          }
        ],
        max_tokens: 2000,
      });

      const markdownContent = response.choices[0].message.content || '';

      res.json({
        success: true,
        content: markdownContent
      });

    } catch (error) {
      console.error("Error converting file:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to convert file. Please try again." 
      });
    }
  });

  app.post('/api/resume/convert-text', async (req, res) => {
    try {
      const { content } = req.body;

      if (!content || typeof content !== 'string') {
        return res.status(400).json({ success: false, error: "Content is required" });
      }

      // Use OpenAI to convert to markdown format
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a resume formatting expert. Convert the provided resume content into clean, professional markdown format. Maintain all important information while organizing it in a clear structure with appropriate headings, bullet points, and formatting. Use standard resume sections like Summary, Experience, Skills, Education, etc. If the content is already in markdown format, clean it up and improve the structure."
          },
          {
            role: "user",
            content: `Please convert this resume content to markdown format:\n\n${content}`
          }
        ],
        max_tokens: 2000,
      });

      const markdownContent = response.choices[0].message.content || '';

      res.json({
        success: true,
        content: markdownContent
      });

    } catch (error) {
      console.error("Error converting text:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to convert content. Please try again." 
      });
    }
  });

  // Blog routes for WordPress integration
  app.get('/api/blog/posts', async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const perPage = parseInt(req.query.per_page as string) || 10;
      
      // Try to get from cache first
      try {
        const cachedPostsData = await storage.getCachedPosts(page, perPage);
        if (cachedPostsData && cachedPostsData.length > 0) {
          // Transform cached posts to WordPress API format
          const transformedPosts = cachedPostsData.map(post => ({
            id: post.wpId,
            date: post.publishedAt.toISOString(),
            slug: post.slug,
            title: { rendered: post.title },
            content: { rendered: post.content || '' },
            excerpt: { rendered: post.excerpt || '' },
            author: 1,
            featured_media: 0,
            categories: [],
            tags: [],
            _links: {}
          }));
          return res.json(transformedPosts);
        }
      } catch (cacheError) {
        console.log("Cache miss or error, falling back to WordPress API:", (cacheError as Error).message);
      }
      
      // Fallback to WordPress API
      try {
        const posts = await wordpressAPI.getPosts(page, perPage);
        res.json(posts);
      } catch (wpError) {
        console.error("WordPress API failed:", (wpError as Error).message);
        res.status(503).json({ 
          message: "Blog service temporarily unavailable",
          error: "Both cache and WordPress API are unavailable"
        });
      }
    } catch (error) {
      console.error("Error in blog posts endpoint:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // WordPress cache management endpoints
  app.post('/api/admin/cache/wordpress/refresh', async (req, res) => {
    try {
      const result = await triggerWordPressCache();
      res.json(result);
    } catch (error) {
      console.error("Error refreshing WordPress cache:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to refresh WordPress cache" 
      });
    }
  });

  app.get('/api/blog/cached-posts', async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const perPage = parseInt(req.query.per_page as string) || 10;
      const posts = await storage.getCachedPosts(page, perPage);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching cached posts:", error);
      res.status(500).json({ message: "Failed to fetch cached posts" });
    }
  });

  // Blog API health check
  app.get('/api/blog/health', async (req, res) => {
    const healthCheck = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        cache: 'unknown',
        wordpress: 'unknown'
      },
      statistics: {
        cachedPosts: 0,
        lastCacheUpdate: null
      }
    };

    try {
      // Check cache health
      const cachedPosts = await storage.getCachedPosts(1, 1);
      healthCheck.services.cache = 'healthy';
      healthCheck.statistics.cachedPosts = cachedPosts.length > 0 ? 1 : 0;
    } catch (error) {
      healthCheck.services.cache = 'error';
      healthCheck.status = 'degraded';
    }

    try {
      // Check WordPress API health
      const posts = await wordpressAPI.getPosts(1, 1);
      healthCheck.services.wordpress = posts.length > 0 ? 'healthy' : 'degraded';
    } catch (error) {
      healthCheck.services.wordpress = 'error';
      if (healthCheck.services.cache === 'error') {
        healthCheck.status = 'unhealthy';
      }
    }

    const statusCode = healthCheck.status === 'healthy' ? 200 : 
                      healthCheck.status === 'degraded' ? 200 : 503;
    
    res.status(statusCode).json(healthCheck);
  });

  app.get('/api/blog/posts/:slug', async (req, res) => {
    try {
      const slug = req.params.slug;
      const post = await wordpressAPI.getPost(slug);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      // Add heading IDs for table of contents
      const contentWithIds = wordpressAPI.addHeadingIds(post.content.rendered);
      const tableOfContents = wordpressAPI.extractTableOfContents(contentWithIds);
      
      // Get related posts
      const relatedPosts = await wordpressAPI.getRelatedPosts(post.id, post.categories, 3);

      res.json({
        ...post,
        content: { ...post.content, rendered: contentWithIds },
        tableOfContents,
        relatedPosts
      });
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.get('/api/blog/categories', async (req, res) => {
    try {
      const categories = await wordpressAPI.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching blog categories:", error);
      res.status(500).json({ message: "Failed to fetch blog categories" });
    }
  });

  // Newsletter subscription endpoint with Beehiiv integration
  app.post('/api/newsletter/subscribe', async (req, res) => {
    try {
      const validatedData = insertNewsletterSubscriberSchema.parse(req.body);
      const { email, name, source = 'website' } = validatedData;

      if (!beehiivService.isConfigured()) {
        return res.status(503).json({ 
          message: "Newsletter service is not configured. Please contact support." 
        });
      }

      if (!beehiivService.validateEmail(email)) {
        return res.status(400).json({ message: "Invalid email address" });
      }

      // Check if already subscribed in our database
      const existingSubscriber = await storage.getNewsletterSubscriber(email);
      if (existingSubscriber && existingSubscriber.status === 'active') {
        return res.json({ 
          success: true, 
          message: "You're already subscribed to The Resume Refresh!" 
        });
      }

      // Try to subscribe to Beehiiv (but don't fail if it doesn't work)
      let beehiivSuccess = false;
      if (beehiivService.isConfigured()) {
        try {
          const beehiivResult = await beehiivService.subscribe({
            email,
            name: name || undefined,
            source: source || 'website',
            tags: ['resume-refresh', 'website-signup'],
            custom_fields: {
              signup_source: 'ResumeFormatter.io',
              user_type: 'prospect'
            }
          });

          if (beehiivResult.success) {
            beehiivSuccess = true;
            console.log('Successfully subscribed to Beehiiv:', email);
          } else {
            console.warn('Beehiiv subscription failed, continuing with local storage:', beehiivResult.error);
          }
        } catch (beehiivError) {
          console.warn('Beehiiv API error, continuing with local storage:', beehiivError);
        }
      }

      // Always store in our database for backup and analytics
      try {
        if (existingSubscriber) {
          await storage.updateNewsletterSubscriber(email, {
            name: name || undefined,
            status: 'active',
            source: source || 'website'
          });
        } else {
          await storage.createNewsletterSubscriber({
            email,
            name: name || undefined,
            status: 'active',
            source: source || 'website',
            tags: ['resume-refresh', 'website-signup']
          });
        }
        console.log('Subscriber stored in local database:', email);
      } catch (dbError) {
        console.error('Database storage failed:', dbError);
        return res.status(500).json({ 
          message: "Failed to store subscription. Please try again." 
        });
      }

      res.json({ 
        success: true, 
        message: "Successfully subscribed to The Resume Refresh! Check your email for a welcome message." 
      });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid subscription data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });

  // Newsletter unsubscribe endpoint
  app.post('/api/newsletter/unsubscribe', async (req, res) => {
    try {
      const { email, token } = req.body;

      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Verify unsubscribe token if provided
      if (token) {
        const subscriber = await storage.getNewsletterSubscriber(email);
        if (!subscriber || subscriber.unsubscribeToken !== token) {
          return res.status(400).json({ message: "Invalid unsubscribe token" });
        }
      }

      // Unsubscribe from Beehiiv
      if (beehiivService.isConfigured()) {
        const beehiivResult = await beehiivService.unsubscribe(email);
        if (!beehiivResult.success) {
          console.error('Beehiiv unsubscribe failed:', beehiivResult.error);
        }
      }

      // Update status in our database
      try {
        await storage.updateNewsletterSubscriber(email, {
          status: 'unsubscribed'
        });
      } catch (dbError) {
        console.error('Database unsubscribe failed:', dbError);
      }

      res.json({ 
        success: true, 
        message: "Successfully unsubscribed from The Resume Refresh." 
      });
    } catch (error) {
      console.error("Error unsubscribing from newsletter:", error);
      res.status(500).json({ message: "Failed to unsubscribe from newsletter" });
    }
  });

  // Newsletter stats endpoint (admin only)
  app.get('/api/newsletter/stats', authMiddleware, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.email?.includes('admin@')) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getNewsletterStats();
      
      // Get Beehiiv stats if configured
      let beehiivStats = null;
      let beehiivConnection = false;
      if (beehiivService.isConfigured()) {
        const connectionTest = await beehiivService.testConnection();
        beehiivConnection = connectionTest.success;
        
        if (connectionTest.success) {
          const result = await beehiivService.getPublicationStats();
          if (result.success) {
            beehiivStats = result.data;
          }
        }
      }

      res.json({
        local: stats,
        beehiiv: beehiivStats,
        beehiivConnected: beehiivConnection,
        beehiivConfigured: beehiivService.isConfigured()
      });
    } catch (error) {
      console.error("Error fetching newsletter stats:", error);
      res.status(500).json({ message: "Failed to fetch newsletter stats" });
    }
  });

  // Beehiiv connection test endpoint (admin only)
  app.get('/api/beehiiv/test', authMiddleware, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.email?.includes('admin@')) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const result = await beehiivService.testConnection();
      res.json(result);
    } catch (error) {
      console.error("Error testing Beehiiv connection:", error);
      res.status(500).json({ message: "Failed to test Beehiiv connection" });
    }
  });

  // Legal content endpoints
  app.get('/api/legal/pages', async (req, res) => {
    try {
      const pages = await legalContentService.getAllLegalPages();
      res.json({
        success: true,
        data: pages
      });
    } catch (error) {
      console.error("Error fetching legal pages:", error);
      res.status(500).json({ message: "Failed to fetch legal pages" });
    }
  });

  app.get('/api/legal/pages/:slug', async (req, res) => {
    try {
      const slug = req.params.slug;
      const content = await legalContentService.getLegalPageContent(slug);
      
      if (!content) {
        return res.status(404).json({ message: "Legal page not found" });
      }

      res.json({
        success: true,
        data: {
          slug,
          content
        }
      });
    } catch (error) {
      console.error("Error fetching legal page:", error);
      res.status(500).json({ message: "Failed to fetch legal page" });
    }
  });

  app.get('/api/legal/variables', async (req, res) => {
    try {
      const variables = legalContentService.getVariables();
      res.json({
        success: true,
        data: variables
      });
    } catch (error) {
      console.error("Error fetching legal variables:", error);
      res.status(500).json({ message: "Failed to fetch legal variables" });
    }
  });

  app.put('/api/legal/variables', authMiddleware, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.email?.includes('admin@')) {
        return res.status(403).json({ message: "Admin access required" });
      }

      legalContentService.updateVariables(req.body);
      res.json({
        success: true,
        message: "Legal variables updated successfully"
      });
    } catch (error) {
      console.error("Error updating legal variables:", error);
      res.status(500).json({ message: "Failed to update legal variables" });
    }
  });

  // ========================================
  // KNOWLEDGE BASE & SUPPORT API
  // For Wrelik.com Unified Support Desk
  // ========================================

  // Knowledge Base Articles API
  app.get('/api/support/articles', async (req, res) => {
    try {
      const { category, search, limit = 50 } = req.query;
      
      const articles = [
        // Getting Started & Basics
        {
          id: "getting-started",
          title: "Getting Started with ResumeFormatter.io",
          content: "Learn how to create your first professional resume using our Markdown-powered editor.",
          category: "basics",
          tags: ["beginner", "setup", "markdown"],
          lastUpdated: "2025-06-14",
          views: 1500,
          helpful: 142,
          status: "published",
          difficulty: "Beginner",
          readTime: "3 min",
          featured: true
        },
        {
          id: "markdown-editor",
          title: "Markdown Resume Editor",
          content: "Learn how to write and format your resume using Markdown syntax for professional results.",
          category: "basics", 
          tags: ["markdown", "editor", "formatting", "syntax"],
          lastUpdated: "2025-06-14",
          views: 2300,
          helpful: 198,
          status: "published",
          difficulty: "Beginner",
          readTime: "3 min",
          featured: true
        },
        {
          id: "markdown-guide",
          title: "Complete Markdown Formatting Guide",
          content: "Comprehensive guide to formatting your resume using Markdown syntax for professional results.",
          category: "formatting",
          tags: ["markdown", "formatting", "syntax", "advanced"],
          lastUpdated: "2025-06-14",
          views: 2300,
          helpful: 198,
          status: "published",
          difficulty: "Intermediate",
          readTime: "5 min"
        },
        
        // Templates & Design
        {
          id: "template-gallery",
          title: "Professional Templates",
          content: "Browse and apply ATS-friendly templates optimized for different industries and roles.",
          category: "templates",
          tags: ["templates", "design", "industry", "ats"],
          lastUpdated: "2025-06-14",
          views: 1800,
          helpful: 156,
          status: "published",
          difficulty: "Beginner",
          readTime: "2 min",
          featured: true
        },
        {
          id: "template-selection",
          title: "Choosing the Right Template",
          content: "Guide to selecting the perfect resume template for your industry and career level.",
          category: "templates",
          tags: ["templates", "design", "industry", "selection"],
          lastUpdated: "2025-06-14",
          views: 1800,
          helpful: 156,
          status: "published",
          difficulty: "Beginner",
          readTime: "3 min"
        },
        
        // AI Features & Optimization
        {
          id: "resume-optimization",
          title: "AI Resume Optimization",
          content: "Use AI to improve your resume's ATS score and get personalized suggestions.",
          category: "ai",
          tags: ["ai", "optimization", "scoring", "ats"],
          lastUpdated: "2025-06-14",
          views: 2800,
          helpful: 224,
          status: "published",
          difficulty: "Intermediate",
          readTime: "4 min",
          featured: true
        },
        {
          id: "ats-optimization",
          title: "ATS-Friendly Resume Tips",
          content: "How to optimize your resume for Applicant Tracking Systems and improve your job search success.",
          category: "optimization",
          tags: ["ats", "optimization", "keywords", "applicant-tracking"],
          lastUpdated: "2025-06-14",
          views: 3200,
          helpful: 267,
          status: "published",
          difficulty: "Intermediate",
          readTime: "4 min"
        },
        {
          id: "cover-letter-generator",
          title: "AI Cover Letter Generator",
          content: "Generate tailored cover letters that match your resume and target job description.",
          category: "ai",
          tags: ["ai", "cover-letter", "generator", "tailored"],
          lastUpdated: "2025-06-14",
          views: 1950,
          helpful: 167,
          status: "published",
          difficulty: "Intermediate",
          readTime: "3 min"
        },
        
        // Export & Sharing
        {
          id: "exporting-resumes",
          title: "Export & Download Options",
          content: "Download your resume as PDF, DOCX, or HTML. Perfect for job applications and sharing.",
          category: "export",
          tags: ["export", "pdf", "docx", "html", "download"],
          lastUpdated: "2025-06-14",
          views: 1200,
          helpful: 98,
          status: "published",
          difficulty: "Beginner",
          readTime: "2 min"
        },
        {
          id: "export-options",
          title: "Advanced Export Features",
          content: "How to export your resume in multiple formats and customize export settings for different use cases.",
          category: "export",
          tags: ["export", "pdf", "docx", "html", "advanced"],
          lastUpdated: "2025-06-14",
          views: 1200,
          helpful: 98,
          status: "published",
          difficulty: "Intermediate",
          readTime: "3 min"
        },
        
        // Organization & Versioning
        {
          id: "versioning-snapshots",
          title: "Resume Versioning & Snapshots",
          content: "Save multiple versions of your resume and track changes over time.",
          category: "organization",
          tags: ["versioning", "snapshots", "history", "tracking"],
          lastUpdated: "2025-06-14",
          views: 1450,
          helpful: 123,
          status: "published",
          difficulty: "Intermediate",
          readTime: "3 min"
        },
        
        // Mobile Experience
        {
          id: "mobile-editing",
          title: "Mobile Resume Editing",
          content: "Edit and preview your resume on mobile devices with touch-optimized controls.",
          category: "mobile",
          tags: ["mobile", "editing", "touch", "responsive"],
          lastUpdated: "2025-06-14",
          views: 890,
          helpful: 76,
          status: "published",
          difficulty: "Beginner",
          readTime: "2 min"
        },
        
        // Account & Support
        {
          id: "account-management",
          title: "Account Settings & Management",
          content: "Manage your account preferences, billing, and subscription settings.",
          category: "account",
          tags: ["account", "settings", "billing", "subscription"],
          lastUpdated: "2025-06-14",
          views: 1100,
          helpful: 94,
          status: "published",
          difficulty: "Beginner",
          readTime: "2 min"
        },
        {
          id: "troubleshooting",
          title: "Common Issues & Troubleshooting",
          content: "Solutions to frequently encountered problems and technical issues.",
          category: "support",
          tags: ["troubleshooting", "issues", "problems", "solutions"],
          lastUpdated: "2025-06-14",
          views: 1650,
          helpful: 142,
          status: "published",
          difficulty: "Beginner",
          readTime: "4 min"
        },
        {
          id: "faq",
          title: "Frequently Asked Questions",
          content: "Answers to the most common questions about ResumeFormatter.io features and usage.",
          category: "support",
          tags: ["faq", "questions", "answers", "common"],
          lastUpdated: "2025-06-14",
          views: 2100,
          helpful: 189,
          status: "published",
          difficulty: "Beginner",
          readTime: "5 min"
        }
      ];

      let filteredArticles = articles;

      if (category) {
        filteredArticles = filteredArticles.filter(article => 
          article.category.toLowerCase() === category.toString().toLowerCase()
        );
      }

      if (search) {
        const searchTerm = search.toString().toLowerCase();
        filteredArticles = filteredArticles.filter(article =>
          article.title.toLowerCase().includes(searchTerm) ||
          article.content.toLowerCase().includes(searchTerm) ||
          article.tags.some(tag => tag.toLowerCase().includes(searchTerm))
        );
      }

      filteredArticles = filteredArticles.slice(0, parseInt(limit.toString()));

      res.json({
        success: true,
        data: filteredArticles,
        total: filteredArticles.length,
        categories: ["basics", "formatting", "optimization", "templates", "export", "ai", "organization", "mobile", "support", "account"]
      });
    } catch (error) {
      console.error("Error fetching knowledge base articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  // Get specific article
  app.get('/api/support/articles/:id', async (req, res) => {
    try {
      const articleId = req.params.id;
      
      const articleContent = {
        "getting-started": `# Getting Started with ResumeFormatter.io

Welcome to ResumeFormatter.io! This guide will help you create your first professional resume in minutes.

## Quick Start

1. **Choose Your Starting Point**: 
   - Use our sample resume template
   - Upload your existing resume
   - Start from scratch

2. **Edit with Markdown**:
   - Use simple Markdown syntax for formatting
   - See live preview as you type
   - Professional styling applied automatically

3. **Optimize and Export**:
   - Use AI optimization for ATS compatibility
   - Export to PDF, DOCX, or HTML
   - Share or download instantly

## Markdown Basics

- Use \`#\` for headings
- Use \`**text**\` for bold
- Use \`-\` for bullet points
- Use \`---\` for section dividers

## Need Help?

Visit our knowledge base or contact support for assistance.`,

        "markdown-editor": `# Markdown Resume Editor

Master the art of resume writing with our Markdown-powered editor designed for professionals.

## Why Markdown for Resumes?

Markdown offers several advantages:
- **Consistent Formatting**: Professional appearance across all exports
- **Version Control**: Track changes easily with plain text
- **Speed**: Focus on content, not formatting
- **Flexibility**: Easy to modify and update

## Basic Markdown Syntax

### Headers
\`\`\`markdown
# Your Name (Main Header)
## Experience (Section Header)
### Job Title (Subsection)
\`\`\`

### Text Formatting
- **Bold text**: \`**Important information**\`
- *Italic text*: \`*Emphasis*\`
- ~~Strikethrough~~: \`~~Deprecated skill~~\`

### Lists
\`\`\`markdown
- Bullet point
- Another point
  - Sub-point
  - Another sub-point

1. Numbered list
2. Second item
3. Third item
\`\`\`

### Links and Contact Info
\`\`\`markdown
[Email](mailto:you@email.com)
[LinkedIn](https://linkedin.com/in/yourprofile)
[Portfolio](https://yourwebsite.com)
\`\`\`

## Resume Structure Tips

1. **Header Section**: Name, contact information, professional summary
2. **Experience**: Use reverse chronological order
3. **Skills**: Group by category (Technical, Soft Skills, etc.)
4. **Education**: Include relevant degrees and certifications

## Live Preview

Use the split-screen editor to see your changes in real-time as you type.`,

        "markdown-guide": `# Complete Markdown Formatting Guide

Comprehensive reference for all Markdown features available in ResumeFormatter.io.

## Advanced Formatting

### Tables
\`\`\`markdown
| Skill | Level | Years |
|-------|-------|-------|
| JavaScript | Expert | 5+ |
| Python | Advanced | 3+ |
| React | Expert | 4+ |
\`\`\`

### Code Blocks
\`\`\`markdown
\`Inline code\` for technical terms

\`\`\`javascript
// Code blocks for larger snippets
function example() {
  return "Hello World";
}
\`\`\`
\`\`\`

### Blockquotes
\`\`\`markdown
> "Outstanding team player with excellent communication skills."
> - Former Manager
\`\`\`

### Horizontal Rules
\`\`\`markdown
---
Use three dashes to create section separators
---
\`\`\`

## Professional Resume Sections

### Contact Header
\`\`\`markdown
# John Doe
**Software Engineer** | [john@email.com](mailto:john@email.com) | +1 (555) 123-4567
[LinkedIn](https://linkedin.com/in/johndoe) | [GitHub](https://github.com/johndoe)
\`\`\`

### Professional Summary
\`\`\`markdown
## Professional Summary
Experienced software engineer with 5+ years developing scalable web applications.
Proven track record of leading cross-functional teams and delivering high-quality solutions.
\`\`\`

### Experience Section
\`\`\`markdown
## Experience

### Senior Software Engineer | TechCorp Inc.
*January 2022 - Present*

- Led development of microservices architecture serving 1M+ users
- Reduced application load time by 40% through optimization initiatives
- Mentored junior developers and conducted code reviews

### Software Engineer | StartupXYZ
*June 2019 - December 2021*

- Built responsive web applications using React and Node.js
- Collaborated with design team to implement pixel-perfect UI components
- Implemented automated testing reducing bug reports by 30%
\`\`\`

## Formatting Best Practices

1. **Consistency**: Use the same formatting style throughout
2. **Hierarchy**: Proper heading levels for easy scanning
3. **White Space**: Use blank lines to separate sections
4. **Action Words**: Start bullet points with strong action verbs
5. **Quantify**: Include numbers and metrics when possible`,

        "template-gallery": `# Professional Templates

Explore our collection of ATS-friendly resume templates designed for various industries and career levels.

## Available Templates

### Modern Professional
- **Best for**: Tech, consulting, finance
- **Features**: Clean lines, subtle colors, modern typography
- **ATS Score**: 95/100

### Classic Executive
- **Best for**: Management, executive roles, traditional industries
- **Features**: Traditional layout, elegant typography, professional appearance
- **ATS Score**: 98/100

### Creative Designer
- **Best for**: Design, marketing, creative industries
- **Features**: Visual elements, portfolio section, creative layout
- **ATS Score**: 85/100

### Academic Research
- **Best for**: Academia, research, scientific positions
- **Features**: Publication section, research focus, detailed education
- **ATS Score**: 92/100

## Template Selection Guide

### Consider Your Industry
- **Technology**: Modern Professional or Creative Designer
- **Finance/Consulting**: Modern Professional or Classic Executive
- **Healthcare**: Classic Executive
- **Academia**: Academic Research
- **Creative Fields**: Creative Designer

### Career Level Considerations
- **Entry Level**: Modern Professional (emphasis on education and projects)
- **Mid-Level**: Any template based on industry
- **Senior/Executive**: Classic Executive (emphasis on leadership)

## Customization Options

All templates support:
- Custom color schemes
- Font selection
- Section reordering
- Layout modifications
- Export in multiple formats

## ATS Compatibility

All templates are optimized for Applicant Tracking Systems:
- Standard fonts
- Clear section headers
- Proper formatting hierarchy
- No complex graphics that confuse parsers`,

        "template-selection": `# Choosing the Right Template

Strategic guide to selecting the perfect resume template for your career goals.

## Industry-Specific Recommendations

### Technology & Software
**Recommended**: Modern Professional
- Clean, minimal design
- Emphasis on technical skills section
- GitHub/portfolio integration
- ATS-optimized for tech recruiters

### Finance & Consulting
**Recommended**: Classic Executive
- Conservative, professional appearance
- Emphasis on achievements and metrics
- Traditional layout preferred by hiring managers
- High ATS compatibility

### Creative & Design
**Recommended**: Creative Designer
- Visual appeal without sacrificing readability
- Portfolio section integration
- Balanced creativity and professionalism
- Designed for creative industry expectations

### Healthcare & Medicine
**Recommended**: Classic Executive
- Professional, trustworthy appearance
- Clear certification and license sections
- Traditional format preferred in healthcare
- Excellent ATS performance

## Template Features Comparison

### Color Schemes
- **Conservative**: Black, navy, dark gray
- **Modern**: Blue accents, subtle colors
- **Creative**: Wider color palette options

### Layout Options
- **Single Column**: Traditional, ATS-friendly
- **Two Column**: Modern, space-efficient
- **Hybrid**: Flexible, customizable

### Section Emphasis
- **Skills-focused**: Prominent technical skills
- **Experience-focused**: Detailed work history
- **Achievement-focused**: Metrics and results
- **Education-focused**: Academic credentials

## Making Your Decision

### Step 1: Analyze Job Postings
Review 5-10 job postings in your target role to understand:
- Required skills emphasis
- Industry language and tone
- Preferred qualifications format

### Step 2: Consider Company Culture
- **Startups**: Modern, creative approaches
- **Corporations**: Traditional, conservative formats
- **Creative Agencies**: Visual appeal important
- **Government**: Strict formatting requirements

### Step 3: Match Your Experience Level
- **Entry Level**: Education and projects emphasis
- **Experienced**: Achievement and leadership focus
- **Career Change**: Skills transferability highlight

## Template Switching

You can change templates at any time:
1. Go to Template Gallery
2. Preview your content in new template
3. Apply with one click
4. Customize as needed

Your content automatically adapts to the new template structure.`,

        "resume-optimization": `# AI Resume Optimization

Leverage artificial intelligence to maximize your resume's impact and ATS compatibility.

## AI Optimization Features

### ATS Score Analysis
Our AI analyzes your resume against ATS requirements:
- **Keyword Optimization**: Matches job-specific terms
- **Format Compliance**: Ensures ATS readability
- **Section Structure**: Optimizes information hierarchy
- **Score Tracking**: Real-time improvement metrics

### Content Enhancement
AI-powered suggestions for:
- **Action Verb Improvement**: Stronger, more impactful language
- **Quantification**: Adding metrics and numbers
- **Skill Matching**: Aligning with job requirements
- **Grammar and Clarity**: Professional writing standards

## How AI Optimization Works

### 1. Upload Job Description
- Paste the target job posting
- AI extracts key requirements
- Identifies important keywords and skills

### 2. Content Analysis
- Scans your current resume
- Identifies gaps and opportunities
- Suggests specific improvements

### 3. Optimization Recommendations
- **High Priority**: Critical missing keywords
- **Medium Priority**: Content improvements
- **Low Priority**: Minor enhancements

### 4. Implementation
- One-click application of suggestions
- Manual review and editing options
- A/B testing different versions

## ATS Optimization Checklist

### Format Requirements
- [ ] Standard fonts (Arial, Calibri, Times New Roman)
- [ ] Clear section headers
- [ ] Consistent formatting
- [ ] No images or graphics in text areas
- [ ] Proper file format (PDF or DOCX)

### Content Requirements
- [ ] Relevant keywords from job posting
- [ ] Quantified achievements
- [ ] Industry-specific terminology
- [ ] Complete contact information
- [ ] Standard section names

### Structure Requirements
- [ ] Reverse chronological order
- [ ] Clear job titles and company names
- [ ] Consistent date formats
- [ ] Logical information flow
- [ ] Appropriate length (1-2 pages)

## AI Suggestions Examples

### Before AI Optimization
"Worked on marketing campaigns"

### After AI Optimization  
"Developed and executed 12 integrated marketing campaigns, resulting in 35% increase in lead generation and $2.3M in new revenue"

### Before AI Optimization
"Good communication skills"

### After AI Optimization
"Excellent written and verbal communication skills, including experience presenting to C-level executives and cross-functional teams of 20+ members"

## Continuous Improvement

The AI learns from:
- Successful job applications
- Industry trends
- ATS algorithm updates
- User feedback and results

This ensures your optimization stays current with evolving hiring practices.`,

        "ats-optimization": `# ATS-Friendly Resume Tips

Master the art of creating resumes that pass Applicant Tracking Systems and reach human recruiters.

## Understanding ATS Systems

### What is an ATS?
Applicant Tracking Systems are software tools used by employers to:
- Parse and store resume data
- Search for specific keywords
- Rank candidates automatically
- Filter applications before human review

### Common ATS Platforms
- **Workday**: Used by large corporations
- **Greenhouse**: Popular with tech companies  
- **Lever**: Startup and mid-size companies
- **iCIMS**: Enterprise-level organizations
- **BambooHR**: Small to medium businesses

## ATS-Friendly Formatting Rules

### File Format
- **Best**: PDF or DOCX
- **Avoid**: Images, JPEGs, complex layouts
- **Filename**: "FirstName_LastName_Resume.pdf"

### Font and Typography
- **Safe Fonts**: Arial, Calibri, Times New Roman, Helvetica
- **Size**: 10-12pt for body text, 14-16pt for headers
- **Avoid**: Fancy fonts, multiple font families, decorative elements

### Layout Structure
- **Single Column**: Easier for ATS to parse
- **Standard Sections**: Use common headers like "Experience," "Education," "Skills"
- **Consistent Formatting**: Same style for all similar elements
- **White Space**: Adequate spacing between sections

## Keyword Optimization Strategy

### 1. Job Posting Analysis
Extract keywords from:
- Required qualifications
- Preferred skills
- Job responsibilities
- Company values and culture

### 2. Strategic Placement
Include keywords in:
- **Professional Summary**: 3-5 key terms
- **Skills Section**: Exact keyword matches
- **Experience Bullets**: Natural integration
- **Education**: Relevant coursework and certifications

### 3. Keyword Density
- **Natural Integration**: Avoid keyword stuffing
- **Synonyms and Variations**: Use different forms of the same skill
- **Context Matters**: Show how you used each skill

## Common ATS Mistakes to Avoid

### Formatting Errors
- ❌ Headers and footers with important information
- ❌ Tables and text boxes
- ❌ Multiple columns
- ❌ Special characters and symbols
- ❌ Graphics and logos

### Content Errors
- ❌ Missing standard section headers
- ❌ Inconsistent date formats
- ❌ Abbreviations without full terms
- ❌ Industry jargon without keywords
- ❌ Contact info in images

### Technical Errors
- ❌ Password-protected files
- ❌ Corrupted or unreadable formats
- ❌ Files too large to upload
- ❌ Incorrect file extensions

## ATS Testing Checklist

### Before Submitting
1. **Copy-Paste Test**: Copy your resume text into plain text editor
2. **Keyword Check**: Ensure target keywords appear naturally
3. **Format Review**: Verify all information is readable
4. **Contact Verification**: Confirm phone and email are accessible
5. **File Size**: Keep under 1MB for easy upload

### Regular Maintenance
- Update keywords for each application
- Review ATS score using our AI tool
- Test with different job descriptions
- Monitor application success rates

## Industry-Specific Tips

### Technology
- Include programming languages and frameworks
- Mention specific tools and platforms
- Use both acronyms and full terms (e.g., "AI" and "Artificial Intelligence")

### Healthcare
- Include licenses and certifications
- Use medical terminology appropriately
- Mention specific procedures and equipment

### Finance
- Include relevant software (Excel, SQL, Bloomberg)
- Mention regulations and compliance knowledge
- Quantify financial impact and results

### Marketing
- Include digital marketing channels
- Mention analytics and measurement tools
- Showcase campaign results and metrics`,

        "cover-letter-generator": `# AI Cover Letter Generator

Create compelling, tailored cover letters that complement your resume and target specific job opportunities.

## How the AI Generator Works

### 1. Resume Integration
- Automatically pulls relevant experience from your resume
- Identifies key skills and achievements
- Maintains consistency between documents

### 2. Job Description Analysis
- Extracts key requirements and qualifications
- Identifies company values and culture indicators
- Matches your experience to job needs

### 3. Personalized Content
- Creates unique introduction for each application
- Tailors achievements to job requirements
- Generates compelling closing statements

## Cover Letter Structure

### Opening Paragraph
**AI generates based on:**
- Specific job title and company name
- Your most relevant qualification
- Hook to grab reader's attention

**Example Output:**
"I am excited to apply for the Senior Software Engineer position at TechCorp. With 5+ years of experience building scalable web applications and a proven track record of leading successful product launches, I am confident I can contribute to your team's continued innovation."

### Body Paragraphs
**Experience Highlighting:**
- 2-3 most relevant achievements from your resume
- Quantified results when possible
- Connection to job requirements

**Skills Demonstration:**
- Technical skills that match job posting
- Soft skills with specific examples
- Industry knowledge and expertise

### Closing Paragraph
**Call to Action:**
- Express enthusiasm for the role
- Request for interview
- Professional sign-off

## Customization Options

### Tone Settings
- **Professional**: Formal, traditional industries
- **Conversational**: Startups, creative companies  
- **Enthusiastic**: Sales, marketing, customer-facing roles
- **Technical**: Engineering, scientific positions

### Length Options
- **Concise**: 3 paragraphs, 200-250 words
- **Standard**: 4 paragraphs, 300-350 words
- **Detailed**: 5 paragraphs, 400-450 words

### Industry Templates
Pre-configured for:
- Technology and Software
- Finance and Banking
- Healthcare and Medicine
- Education and Academia
- Creative and Design
- Sales and Marketing

## Best Practices

### Research Integration
AI incorporates:
- Company mission and values
- Recent news and achievements
- Industry trends and challenges
- Team structure and culture

### Keyword Optimization
- Includes job posting keywords naturally
- Maintains readability and flow
- Avoids keyword stuffing
- Uses industry terminology appropriately

### Personal Branding
- Consistent voice with your resume
- Highlights unique value proposition
- Showcases personality appropriately
- Maintains professional standards

## Quality Assurance

### AI Review Process
1. **Grammar and Spelling**: Automated proofreading
2. **Readability Score**: Ensures appropriate complexity
3. **Keyword Density**: Optimizes for ATS systems
4. **Length Check**: Maintains ideal word count

### Human Review Options
- Edit suggestions inline
- Alternative phrase options
- Tone adjustment tools
- Custom addition capabilities

## Export and Usage

### File Formats
- PDF (recommended for applications)
- DOCX (for further editing)
- HTML (for email integration)

### Version Management
- Save multiple versions for different roles
- Track which version sent to which company
- A/B testing for response rates

### Integration Features
- Direct email sending
- Application portal upload
- LinkedIn message integration
- Follow-up reminder system

## Success Metrics

### Performance Tracking
- Response rate improvement
- Interview invitation rates
- Application to interview conversion
- User satisfaction scores

### Continuous Improvement
AI learns from:
- Successful applications
- User feedback
- Industry hiring trends
- Recruiter preferences`,

        "exporting-resumes": `# Export & Download Options

Master the various export formats and settings to ensure your resume looks perfect across all platforms.

## Available Export Formats

### PDF Export
**Best for**: Job applications, email attachments, printing
- **Advantages**: Preserves formatting, universally readable, professional appearance
- **ATS Compatibility**: Excellent (95%+ systems support)
- **File Size**: Optimized for quick downloads
- **Security**: Can include password protection

### DOCX Export  
**Best for**: Further editing, ATS systems, collaborative review
- **Advantages**: Editable, high ATS compatibility, familiar format
- **Use Cases**: When employers specifically request Word format
- **Editing**: Maintains formatting in Microsoft Word
- **Compatibility**: Works with Google Docs, LibreOffice

### HTML Export
**Best for**: Online portfolios, website integration, quick sharing
- **Advantages**: Web-ready, responsive design, SEO-friendly
- **Features**: Clickable links, mobile optimization, fast loading
- **Integration**: Easy to embed in personal websites
- **Accessibility**: Screen reader compatible

## Export Settings and Customization

### Page Layout Options
- **Margins**: Standard, narrow, or custom spacing
- **Page Size**: Letter (US), A4 (International), Legal
- **Orientation**: Portrait (recommended) or Landscape
- **Scaling**: Fit content to one or two pages

### Typography Settings
- **Font Selection**: ATS-safe options or custom fonts
- **Size Adjustments**: Optimize for readability vs. space
- **Line Spacing**: Single, 1.15, or 1.5 for clarity
- **Character Spacing**: Fine-tune for perfect fit

### Color and Design
- **Print-Friendly**: Black and white or color options
- **Accent Colors**: Professional color schemes
- **Background**: White or subtle backgrounds
- **Watermarks**: Optional branding elements

## Quality Optimization

### PDF Optimization
- **Resolution**: 300 DPI for printing, 72 DPI for screen
- **Compression**: Balanced quality and file size
- **Fonts**: Embedded for consistent display
- **Links**: Clickable email and website links

### ATS Optimization
- **Text Recognition**: Ensures all text is selectable
- **Format Compliance**: Maintains ATS-friendly structure
- **Keyword Preservation**: Protects important keywords
- **Section Headers**: Clear and parseable

### Mobile Optimization
- **Responsive Design**: Adapts to different screen sizes
- **Touch-Friendly**: Appropriate link sizes and spacing
- **Fast Loading**: Optimized file sizes
- **Readable Text**: Maintains clarity on small screens

## Export Workflow

### Pre-Export Checklist
1. **Content Review**: Verify all information is current
2. **Spell Check**: Run automated and manual review
3. **Format Check**: Ensure consistent styling
4. **Contact Info**: Confirm all links work correctly
5. **Length**: Optimize for 1-2 pages as appropriate

### Export Process
1. **Select Format**: Choose based on intended use
2. **Configure Settings**: Adjust layout and quality options
3. **Preview**: Review before finalizing
4. **Download**: Save to appropriate location
5. **Test**: Verify file opens correctly

### Quality Assurance
- **Cross-Platform Testing**: Check on different devices
- **Print Preview**: Ensure proper printing appearance
- **Link Testing**: Verify all hyperlinks function
- **ATS Testing**: Use online ATS checkers

## File Management Best Practices

### Naming Conventions
- **Format**: FirstName_LastName_Resume_Date
- **Examples**: "John_Smith_Resume_2025", "J_Smith_SoftwareEngineer_Resume"
- **Versions**: Include version numbers for different roles
- **Backup**: Maintain multiple copies

### Organization System
- **Folder Structure**: Organize by job type or company
- **Version Control**: Track changes and applications
- **Backup Strategy**: Cloud storage and local copies
- **Access**: Ensure files are available when needed

### Security Considerations
- **Password Protection**: For sensitive versions
- **Watermarking**: Optional personal branding
- **Privacy**: Remove metadata if needed
- **Distribution**: Track who has which version

## Troubleshooting Common Issues

### PDF Problems
- **Font Issues**: Embed fonts properly
- **Layout Breaks**: Check margin settings
- **Large File Size**: Optimize images and compression
- **Unselectable Text**: Re-export with proper settings

### DOCX Issues
- **Format Changes**: Use styles consistently
- **Compatibility**: Test across different programs
- **Table Problems**: Convert to simple formatting
- **Font Substitution**: Stick to standard fonts

### HTML Issues
- **Display Problems**: Test in multiple browsers
- **Mobile Issues**: Check responsive design
- **Link Problems**: Verify all URLs
- **Loading Speed**: Optimize images and code`,

        "export-options": `# Advanced Export Features

Explore sophisticated export options and settings for professional resume distribution.

## Advanced PDF Features

### Security Options
- **Password Protection**: Secure sensitive information
- **Copy Protection**: Prevent unauthorized copying
- **Print Restrictions**: Control printing permissions
- **Annotation Controls**: Allow or restrict comments

### Digital Signatures
- **Author Verification**: Prove document authenticity
- **Timestamp**: Record creation date and time
- **Certificate Integration**: Use digital certificates
- **Compliance**: Meet legal and corporate requirements

### Accessibility Features
- **Screen Reader Compatibility**: Proper text structure
- **High Contrast**: Adjustable for visual impairments
- **Large Print**: Scalable text options
- **Navigation**: Bookmarks and table of contents

## Batch Export Options

### Multiple Formats Simultaneously
- Export to PDF, DOCX, and HTML in one click
- Maintain consistent settings across formats
- Automated quality checking
- Synchronized version control

### Version Management
- **Role-Specific Versions**: Different emphasis for different jobs
- **Company Customization**: Tailored for specific employers
- **Language Variants**: Multiple language versions
- **Date Tracking**: Automatic version timestamping

### Bulk Operations
- **Template Application**: Apply different templates quickly
- **Batch Optimization**: ATS optimize multiple versions
- **Mass Distribution**: Prepare for multiple applications
- **Archive Management**: Organize historical versions

## Custom Branding Options

### Professional Watermarks
- **Subtle Branding**: Personal logo or initials
- **Contact Information**: Embedded contact details
- **Portfolio Links**: QR codes to online portfolios
- **Social Media**: Professional profile links

### Color Schemes
- **Brand Colors**: Match personal or company branding
- **Industry Standards**: Colors appropriate for your field
- **Print Considerations**: Optimize for black and white printing
- **Accessibility**: Ensure sufficient contrast ratios

### Layout Customization
- **Header Styles**: Multiple header layout options
- **Footer Information**: Custom footer content
- **Margin Control**: Precise spacing adjustments
- **Typography**: Advanced font and spacing controls

## Integration Features

### Cloud Storage Integration
- **Google Drive**: Direct save to Drive folders
- **Dropbox**: Automatic sync and backup
- **OneDrive**: Microsoft ecosystem integration
- **iCloud**: Apple device synchronization

### Email Integration
- **Direct Sending**: Send resumes directly from platform
- **Template Messages**: Pre-written cover emails
- **Tracking**: Know when emails are opened
- **Follow-up**: Automated reminder systems

### Portfolio Integration
- **Website Embedding**: HTML export for personal sites
- **LinkedIn Sync**: Update LinkedIn profile automatically
- **Portfolio Platforms**: Integration with Behance, Dribbble
- **Social Media**: Share-ready formats for professional networks

## Quality Assurance Tools

### Automated Checking
- **Spell Check**: Advanced grammar and spelling
- **Format Validation**: Ensure proper structure
- **Link Verification**: Check all hyperlinks
- **ATS Scoring**: Real-time optimization scoring

### Preview Options
- **Multiple Device Preview**: See how it looks on different screens
- **Print Preview**: Accurate printing representation
- **ATS Preview**: How systems will parse your resume
- **Mobile Preview**: Smartphone and tablet display

### Comparison Tools
- **Before/After**: Compare different versions
- **Format Comparison**: See differences between export types
- **Template Comparison**: Quick template switching
- **Optimization Analysis**: Track improvements over time

## Analytics and Tracking

### Performance Metrics
- **Download Tracking**: Monitor file access
- **Application Success**: Track which versions perform best
- **Response Rates**: Measure recruiter engagement
- **A/B Testing**: Compare different resume versions

### Usage Analytics
- **Export Frequency**: Track most-used formats
- **Template Popularity**: See which templates work best
- **Feature Usage**: Understand which features add value
- **Success Correlation**: Link features to job success

### Reporting Features
- **Monthly Reports**: Resume performance summaries
- **Success Analytics**: Track application outcomes
- **Trend Analysis**: Identify patterns in successful applications
- **Benchmarking**: Compare against industry standards

## Professional Services

### Expert Review
- **Professional Critique**: Human expert review
- **Industry Expertise**: Specialists for different fields
- **ATS Optimization**: Guaranteed ATS compatibility
- **Interview Preparation**: Resume-based interview prep

### Premium Features
- **Priority Support**: Faster response times
- **Advanced Templates**: Exclusive design options
- **Custom Branding**: Full branding customization
- **Unlimited Exports**: No restrictions on downloads

### Enterprise Solutions
- **Team Management**: Coordinate multiple team members
- **Brand Compliance**: Ensure company brand standards
- **Bulk Licensing**: Volume pricing for organizations
- **Custom Integration**: API access for HR systems`,

        "versioning-snapshots": `# Resume Versioning & Snapshots

Master version control for your resume to track changes, maintain multiple versions, and never lose important content.

## Understanding Resume Versioning

### Why Version Control Matters
- **Multiple Opportunities**: Different roles require different emphasis
- **Iterative Improvement**: Track what changes improve results
- **Backup Protection**: Never lose work due to accidental changes
- **Collaboration**: Share specific versions with mentors or colleagues
- **A/B Testing**: Compare performance of different versions

### Version Types
- **Master Version**: Your comprehensive, complete resume
- **Role-Specific**: Tailored for specific job types
- **Company-Specific**: Customized for particular employers
- **Length Variants**: 1-page vs 2-page versions
- **Format Variants**: Creative vs conservative styling

## Snapshot System

### Automatic Snapshots
- **Time-Based**: Hourly, daily, or weekly automatic saves
- **Change-Based**: Triggered by significant modifications
- **Manual Triggers**: Save snapshots before major changes
- **Smart Detection**: AI identifies important milestones

### Snapshot Management
- **Naming Convention**: Clear, descriptive snapshot names
- **Categorization**: Organize by purpose, date, or job type
- **Tagging System**: Add keywords for easy searching
- **Notes**: Document reasons for changes

### Restoration Features
- **One-Click Restore**: Return to any previous version
- **Selective Restore**: Restore specific sections only
- **Merge Options**: Combine elements from different versions
- **Compare Mode**: Side-by-side version comparison

## Version Management Strategies

### Master-Branch Strategy
1. **Maintain Master**: Keep one comprehensive version
2. **Create Branches**: Develop specialized versions from master
3. **Merge Improvements**: Incorporate successful changes back to master
4. **Regular Updates**: Keep master current with latest experience

### Role-Based Strategy
- **Technical Roles**: Emphasize programming and technical skills
- **Management Roles**: Highlight leadership and strategic achievements
- **Creative Roles**: Showcase portfolio and design work
- **Sales Roles**: Focus on revenue and relationship building

### Company-Specific Strategy
- **Startup Versions**: Emphasize adaptability and growth mindset
- **Corporate Versions**: Highlight scale and process improvement
- **Consulting Versions**: Focus on problem-solving and client impact
- **Non-Profit Versions**: Emphasize mission alignment and values

## Change Tracking

### Modification History
- **Detailed Logs**: Every change recorded with timestamp
- **User Attribution**: Track who made what changes
- **Change Categories**: Content, formatting, structure modifications
- **Impact Assessment**: Measure effect of changes on performance

### Visual Diff Tool
- **Highlighted Changes**: See exactly what changed between versions
- **Side-by-Side View**: Compare versions simultaneously
- **Change Summary**: Quick overview of modifications
- **Granular Detail**: Word-level change tracking

### Performance Tracking
- **Application Outcomes**: Track which versions get responses
- **Interview Rates**: Measure version effectiveness
- **Feedback Integration**: Record recruiter and employer feedback
- **Success Metrics**: Identify patterns in successful versions

## Collaboration Features

### Sharing and Feedback
- **Secure Links**: Share specific versions with advisors
- **Comment System**: Receive feedback directly on document
- **Suggestion Mode**: Collaborators can suggest changes
- **Permission Control**: Manage who can view or edit

### Review Workflow
- **Review Requests**: Send versions for professional feedback
- **Approval Process**: Get sign-off before applying to important roles
- **Feedback Integration**: Easily incorporate suggestions
- **Version Approval**: Mark versions as "approved for use"

### Team Coordination
- **Career Services**: Share with university career centers
- **Mentorship**: Collaborate with professional mentors
- **Peer Review**: Exchange feedback with other job seekers
- **Professional Services**: Work with resume writers and coaches

## Advanced Version Control

### Branching Strategies
- **Feature Branches**: Test new sections or formats
- **Experiment Branches**: Try radical changes safely
- **Archive Branches**: Store outdated but potentially useful content
- **Merge Strategies**: Intelligent merging of successful elements

### Tagging System
- **Release Tags**: Mark versions used for applications
- **Performance Tags**: Label high-performing versions
- **Industry Tags**: Organize by target industry
- **Status Tags**: Draft, review, approved, archived

### Backup and Sync
- **Cloud Backup**: Automatic backup to cloud storage
- **Device Sync**: Access versions across all devices
- **Export Archives**: Download complete version history
- **Import Options**: Restore from external backups

## Best Practices

### Organization Guidelines
1. **Clear Naming**: Use descriptive, consistent names
2. **Regular Cleanup**: Archive old, unused versions
3. **Documentation**: Note the purpose of each version
4. **Performance Tracking**: Monitor which versions work best

### Maintenance Schedule
- **Weekly Review**: Check for needed updates
- **Monthly Archive**: Clean up old versions
- **Quarterly Assessment**: Evaluate version performance
- **Annual Overhaul**: Major updates and improvements

### Security Considerations
- **Access Control**: Limit who can view sensitive versions
- **Encryption**: Protect stored versions
- **Audit Trail**: Track all access and modifications
- **Compliance**: Meet any industry security requirements

## Troubleshooting

### Common Issues
- **Version Conflicts**: Resolve competing changes
- **Storage Limits**: Manage space usage efficiently
- **Sync Problems**: Troubleshoot cross-device issues
- **Performance**: Optimize for large version histories

### Recovery Procedures
- **Accidental Deletion**: Restore from automatic backups
- **Corruption**: Recover from previous stable versions
- **Lost Changes**: Restore work from auto-saves
- **System Failure**: Emergency backup procedures`,

        "mobile-editing": `# Mobile Resume Editing

Optimize your resume editing experience on smartphones and tablets with touch-friendly controls and mobile-specific features.

## Mobile Editor Features

### Touch-Optimized Interface
- **Large Touch Targets**: Buttons and controls sized for fingers
- **Gesture Support**: Swipe, pinch, and tap interactions
- **Responsive Layout**: Adapts to any screen size
- **Orientation Support**: Works in portrait and landscape modes

### Smart Keyboard Integration
- **Context-Aware Keyboards**: Appropriate keyboards for different fields
- **Autocomplete**: Intelligent text suggestions
- **Spell Check**: Real-time error detection and correction
- **Voice Input**: Dictate content using speech recognition

### Mobile-Specific Tools
- **Quick Actions**: Common tasks accessible with one tap
- **Toolbar Customization**: Arrange tools for your workflow
- **Shortcut Gestures**: Efficient navigation and editing
- **Offline Editing**: Work without internet connection

## Editing Strategies for Mobile

### Efficient Text Input
- **Voice Dictation**: Speak your resume content naturally
- **Template Starting Points**: Begin with structured content
- **Copy-Paste Integration**: Easy content transfer from other apps
- **Text Expansion**: Custom shortcuts for common phrases

### Section-by-Section Approach
1. **Focus Mode**: Edit one section at a time
2. **Progressive Building**: Start with key sections first
3. **Mobile Breaks**: Work in short, focused sessions
4. **Auto-Save**: Never lose progress between sessions

### Content Optimization
- **Bullet Point Lists**: Easier to manage on mobile
- **Short Paragraphs**: Better readability on small screens
- **Clear Structure**: Simple, organized content hierarchy
- **Mobile Preview**: See how it looks on mobile devices

## Mobile Productivity Tips

### Workflow Optimization
- **Morning Edits**: Fresh perspective for content creation
- **Commute Time**: Productive editing during travel
- **Break Sessions**: Quick updates during short breaks
- **Evening Review**: Final checks and polishing

### Distraction Management
- **Focus Mode**: Hide notifications during editing
- **Dedicated Time**: Set aside specific editing periods
- **Progress Tracking**: Visual indicators of completion
- **Session Goals**: Complete specific sections per session

### Collaboration on Mobile
- **Real-time Sync**: Changes sync across all devices
- **Comment Reviews**: Address feedback on the go
- **Share Links**: Easy sharing via mobile messaging
- **Version Access**: View and restore any version

## Mobile-Specific Features

### Camera Integration
- **Photo Import**: Add professional headshots
- **Document Scanning**: Import existing resumes via camera
- **QR Code Generation**: Create QR codes for easy sharing
- **Business Card Scanning**: Extract contact information

### Location Services
- **Company Lookup**: Automatically find company information
- **Address Completion**: Complete location details
- **Timezone Awareness**: Proper date and time handling
- **Local Templates**: Region-appropriate formatting

### Native App Integration
- **Email Export**: Direct integration with email apps
- **Cloud Storage**: Save to Google Drive, iCloud, Dropbox
- **Calendar Integration**: Schedule follow-ups and interviews
- **Contact Sync**: Update contact information across devices

## Cross-Device Continuity

### Seamless Transitions
- **Real-time Sync**: Start on mobile, finish on desktop
- **Bookmark Sections**: Resume editing where you left off
- **Draft Management**: Save and access drafts anywhere
- **Version History**: Complete history across all devices

### Device-Specific Optimization
- **Mobile Shortcuts**: Quick access to common functions
- **Desktop Power**: Advanced features for detailed work
- **Tablet Balance**: Hybrid experience with larger screen
- **Watch Integration**: Quick notifications and reminders

### Backup and Recovery
- **Automatic Backups**: Regular cloud saves
- **Device Switching**: Easy migration between devices
- **Offline Availability**: Access cached content without internet
- **Emergency Access**: Recovery options for critical deadlines

## Performance Optimization

### Speed Enhancements
- **Lazy Loading**: Fast initial load times
- **Smart Caching**: Efficient data storage
- **Compression**: Optimized file sizes
- **Background Sync**: Updates happen automatically

### Battery Conservation
- **Efficient Rendering**: Optimized for battery life
- **Background Limits**: Minimal background activity
- **Sleep Mode**: Automatic power saving
- **Connection Management**: Smart network usage

### Storage Management
- **Local Cache**: Essential data stored locally
- **Smart Cleanup**: Automatic removal of old data
- **Compression**: Efficient storage usage
- **Cloud Optimization**: Balance between local and cloud storage

## Troubleshooting Mobile Issues

### Common Problems
- **Keyboard Issues**: Troubleshoot input problems
- **Sync Delays**: Resolve syncing problems
- **Performance Lag**: Optimize app performance
- **Display Problems**: Fix formatting and layout issues

### Connection Issues
- **Offline Mode**: Work without internet
- **Sync Recovery**: Resolve conflicts when reconnecting
- **Bandwidth Optimization**: Work efficiently on slow connections
- **Connection Switching**: Handle WiFi to cellular transitions

### App Management
- **Update Management**: Keep app current for best performance
- **Storage Cleanup**: Manage local storage efficiently
- **Permission Settings**: Optimize app permissions
- **Notification Control**: Manage alerts and updates

## Best Practices for Mobile Editing

### Ergonomics
- **Screen Distance**: Maintain proper viewing distance
- **Break Frequency**: Take regular breaks from small screens
- **Lighting**: Ensure adequate lighting for screen viewing
- **Posture**: Maintain good posture during extended sessions

### Security
- **Screen Locks**: Protect devices with passwords/biometrics
- **App Security**: Use secure authentication methods
- **Public WiFi**: Avoid sensitive editing on public networks
- **Regular Backups**: Maintain multiple backup copies

### Efficiency
- **Learn Shortcuts**: Master mobile-specific shortcuts
- **Customize Interface**: Arrange tools for your preferences
- **Use Templates**: Start with structured content
- **Practice Regularly**: Build muscle memory for efficient editing`,

        "account-management": `# Account Settings & Management

Comprehensive guide to managing your ResumeFormatter.io account, preferences, and subscription settings.

## Account Dashboard

### Profile Information
- **Personal Details**: Name, email, phone number management
- **Professional Info**: Current role, industry, experience level
- **Profile Picture**: Upload and manage professional headshot
- **Contact Preferences**: Communication and notification settings

### Account Security
- **Password Management**: Strong password requirements and updates
- **Two-Factor Authentication**: Enhanced security with 2FA setup
- **Login History**: Monitor account access and suspicious activity
- **Session Management**: Active device monitoring and logout options

### Privacy Settings
- **Data Visibility**: Control what information is shared
- **Analytics Opt-out**: Manage data collection preferences
- **Marketing Communications**: Email and notification preferences
- **Account Deletion**: Complete data removal procedures

## Subscription Management

### Plan Overview
- **Current Plan**: Free vs Pro features comparison
- **Usage Metrics**: Track credits, exports, and feature usage
- **Billing History**: Complete payment and invoice history
- **Renewal Dates**: Automatic renewal and cancellation options

### Free Plan Features
- **Resume Creation**: Up to 3 resumes
- **Basic Templates**: Access to standard templates
- **PDF Export**: Standard quality exports
- **Basic AI Features**: Limited optimization suggestions

### Pro Plan Benefits
- **Unlimited Resumes**: Create as many resumes as needed
- **Premium Templates**: Exclusive design options
- **Advanced AI**: Full optimization and suggestions
- **Priority Support**: Faster response times
- **Advanced Analytics**: Detailed performance metrics

### Billing and Payments

#### Payment Methods
- **Credit Cards**: Visa, MasterCard, American Express, Discover
- **PayPal**: Secure PayPal integration
- **Bank Transfers**: Direct bank payment options (select regions)
- **Digital Wallets**: Apple Pay, Google Pay support

#### Billing Cycles
- **Monthly Subscription**: $9.99/month with monthly billing
- **Annual Subscription**: $99/year (2 months free)
- **Student Discount**: 50% off with valid student email
- **Team Plans**: Volume discounts for multiple users

#### Invoice Management
- **Download Invoices**: PDF receipts for all payments
- **Expense Reports**: Business-friendly invoice formatting
- **Tax Information**: VAT and tax details where applicable
- **Payment Confirmations**: Email confirmations for all transactions

## Data Management

### Resume Storage
- **Cloud Sync**: Automatic backup to secure cloud storage
- **Version History**: Complete edit history with timestamps
- **Export Options**: Download all resumes in various formats
- **Sharing Controls**: Manage who can view your resumes

### Data Export
- **Complete Backup**: Download all account data
- **Selective Export**: Choose specific resumes or data
- **Format Options**: JSON, PDF, DOCX export formats
- **Migration Tools**: Export for use with other platforms

### Data Privacy
- **GDPR Compliance**: Full compliance with European data protection
- **CCPA Compliance**: California privacy rights protection
- **Data Encryption**: End-to-end encryption for all data
- **Secure Deletion**: Complete data removal upon request

## Notification Preferences

### Email Notifications
- **Account Updates**: Security and billing notifications
- **Feature Announcements**: New features and improvements
- **Tips and Tutorials**: Educational content and best practices
- **Resume Performance**: Application success and analytics

### In-App Notifications
- **Real-time Updates**: Live notifications during editing
- **Collaboration**: Comments and sharing notifications
- **System Status**: Maintenance and service updates
- **Achievement Alerts**: Progress and milestone notifications

### Mobile Push Notifications
- **Important Updates**: Critical account information
- **Reminder Alerts**: Application deadlines and follow-ups
- **Success Notifications**: Interview invitations and responses
- **Custom Alerts**: Personalized notification preferences

## Integration Settings

### Third-Party Connections
- **LinkedIn Sync**: Import and sync LinkedIn profile data
- **Google Drive**: Direct save and backup to Google Drive
- **Dropbox Integration**: Automatic file synchronization
- **Email Providers**: Integration with Gmail, Outlook, etc.

### API Access
- **Developer Keys**: API access for custom integrations
- **Webhook Configuration**: Real-time data updates
- **Rate Limits**: API usage monitoring and limits
- **Documentation**: Complete API reference and examples

### Import/Export Tools
- **Resume Import**: Upload existing resumes from other platforms
- **Bulk Operations**: Manage multiple resumes simultaneously
- **Template Import**: Custom template upload and management
- **Data Migration**: Transfer from competitors' platforms

## Support and Help

### Customer Support
- **Help Center**: Comprehensive knowledge base and FAQs
- **Live Chat**: Real-time support during business hours
- **Email Support**: Detailed support via support@resumeformatter.io
- **Video Tutorials**: Step-by-step video guides

### Community Features
- **User Forums**: Connect with other users and share tips
- **Feature Requests**: Suggest and vote on new features
- **Beta Testing**: Early access to new features and templates
- **Success Stories**: Share and read job search success stories

### Resources
- **Resume Templates**: Downloadable template library
- **Writing Guides**: Professional resume writing advice
- **Industry Insights**: Hiring trends and best practices
- **Career Coaching**: Connection to professional career services

## Account Troubleshooting

### Common Issues
- **Login Problems**: Password reset and account recovery
- **Sync Issues**: Resolve data synchronization problems
- **Payment Failures**: Troubleshoot billing and payment issues
- **Feature Access**: Resolve subscription and feature problems

### Performance Optimization
- **Browser Compatibility**: Supported browsers and settings
- **Cache Management**: Clear cache for optimal performance
- **Connection Issues**: Network troubleshooting guide
- **Mobile App**: Download and setup mobile applications

### Recovery Procedures
- **Account Recovery**: Restore access to locked accounts
- **Data Recovery**: Restore accidentally deleted content
- **Subscription Recovery**: Restore suspended accounts
- **Backup Restoration**: Recover from backup files

## Advanced Features

### Team Management
- **Multi-User Accounts**: Manage team members and permissions
- **Shared Templates**: Organization-wide template management
- **Bulk Licensing**: Volume pricing and management
- **Administrative Controls**: User management and oversight

### Custom Branding
- **Logo Integration**: Add company or personal logos
- **Color Schemes**: Custom color palettes and branding
- **Template Customization**: Create unique template variations
- **Watermarks**: Professional watermarking options

### Analytics and Reporting
- **Usage Analytics**: Detailed account usage statistics
- **Performance Reports**: Resume and application success metrics
- **Trend Analysis**: Historical data and trend identification
- **Export Reports**: Download usage and performance data`,

        "troubleshooting": `# Common Issues & Troubleshooting

Comprehensive guide to resolving frequently encountered problems and technical issues with ResumeFormatter.io.

## Login and Access Issues

### Password Problems
**Forgot Password**
1. Click "Forgot Password" on login page
2. Enter your registered email address
3. Check email for reset link (including spam folder)
4. Follow link and create new password
5. Password must be 8+ characters with mix of letters, numbers, symbols

**Password Not Working**
- Verify Caps Lock is off
- Check for extra spaces
- Try typing password in a text editor first
- Clear browser cache and cookies
- Try incognito/private browsing mode

**Account Locked**
- Wait 15 minutes for automatic unlock
- Contact support if issue persists
- Verify email address is correct
- Check for account suspension emails

### Browser Compatibility
**Supported Browsers**
- Chrome 90+ (recommended)
- Firefox 88+
- Safari 14+
- Edge 90+

**Browser Issues**
- Clear cache and cookies
- Disable browser extensions temporarily
- Update browser to latest version
- Try incognito/private mode

### Two-Factor Authentication
**Lost Authenticator App**
1. Use backup codes provided during setup
2. Contact support with account verification
3. Temporarily disable 2FA to regain access
4. Set up new authenticator app

**2FA Code Not Working**
- Check device time synchronization
- Try previous or next code
- Verify correct app (Google Authenticator, Authy, etc.)
- Use backup codes if available

## Editor and Formatting Issues

### Text Editing Problems
**Text Not Saving**
- Check internet connection
- Disable browser extensions
- Clear browser cache
- Try manual save (Ctrl+S)
- Check account storage limits

**Formatting Not Applied**
- Refresh page and try again
- Check Markdown syntax is correct
- Verify template supports desired formatting
- Try different browser or incognito mode

**Copy-Paste Issues**
- Use "Paste as Plain Text" (Ctrl+Shift+V)
- Remove hidden characters from source
- Check source formatting compatibility
- Try pasting in smaller sections

### Template Problems
**Template Not Loading**
- Check internet connection
- Clear browser cache
- Try different template first
- Contact support if specific template fails

**Formatting Breaks**
- Verify content fits template structure
- Check for unsupported formatting
- Try simpler formatting approach
- Consider different template

**Custom Styles Not Working**
- Check CSS syntax if using custom styles
- Verify template allows customization
- Clear cache and refresh
- Contact support for advanced customization

## Export and Download Issues

### PDF Export Problems
**PDF Not Generating**
- Check internet connection
- Try smaller content sections
- Disable browser pop-up blockers
- Clear browser cache and retry

**PDF Formatting Issues**
- Verify content fits page margins
- Check for unsupported characters
- Try different template
- Adjust export settings

**PDF File Size Too Large**
- Optimize images and graphics
- Reduce content length
- Check export quality settings
- Contact support for compression options

### Download Failures
**Download Not Starting**
- Check browser download settings
- Disable download managers temporarily
- Try different browser
- Check available storage space

**Corrupted Downloads**
- Try downloading again
- Check file size matches expected
- Scan file for corruption
- Contact support if problem persists

**File Format Issues**
- Verify correct format selected
- Check software compatibility
- Try alternative format (PDF vs DOCX)
- Update software opening files

## Performance and Speed Issues

### Slow Loading
**Page Load Delays**
- Check internet connection speed
- Clear browser cache and cookies
- Disable unnecessary browser extensions
- Try different browser or device

**Editor Lag**
- Reduce content length for editing
- Close other browser tabs
- Check device memory and CPU usage
- Try editing in smaller sections

**Sync Delays**
- Check internet connection stability
- Force sync by refreshing page
- Verify account sync settings
- Contact support if delays persist

### Mobile App Issues
**App Crashes**
- Update app to latest version
- Restart device
- Clear app cache and data
- Reinstall app if necessary

**Sync Problems**
- Check mobile internet connection
- Force close and restart app
- Log out and back in
- Verify account sync is enabled

## Account and Billing Issues

### Subscription Problems
**Payment Declined**
- Verify card details and expiration
- Check available balance/credit limit
- Contact bank about international transactions
- Try alternative payment method

**Subscription Not Active**
- Check payment processing status
- Verify email for payment confirmations
- Contact billing support
- Check account status page

**Features Not Available**
- Verify subscription status
- Log out and back in
- Clear browser cache
- Contact support if features missing

### Data Loss Issues
**Resume Disappeared**
- Check "All Resumes" view
- Verify not accidentally deleted
- Check version history
- Contact support for data recovery

**Changes Not Saved**
- Check auto-save settings
- Verify internet connection during editing
- Check browser cache settings
- Use manual save frequently

## Technical Error Messages

### Common Error Codes
**Error 404 - Page Not Found**
- Check URL spelling
- Try accessing from main site
- Clear browser cache
- Contact support if persistent

**Error 500 - Server Error**
- Refresh page after a few minutes
- Check service status page
- Try different browser
- Contact support if continuing

**Error 403 - Access Denied**
- Verify account permissions
- Check subscription status
- Log out and back in
- Contact support for access issues

### Connection Errors
**Network Timeout**
- Check internet connection
- Try different network if available
- Disable VPN temporarily
- Contact support if persistent

**SSL Certificate Errors**
- Check device date and time
- Update browser to latest version
- Try incognito/private mode
- Contact support if continuing

## Getting Additional Help

### Before Contacting Support
1. **Try Basic Troubleshooting**
   - Clear cache and cookies
   - Try different browser
   - Check internet connection
   - Update browser/app

2. **Gather Information**
   - Browser and version
   - Operating system
   - Error messages (screenshots helpful)
   - Steps to reproduce issue

3. **Check Resources**
   - Search knowledge base
   - Review FAQ section
   - Check community forums
   - Watch tutorial videos

### Contact Options
**Live Chat**
- Available during business hours
- Fastest response for urgent issues
- Screen sharing available for complex problems

**Email Support**
- support@resumeformatter.io
- Include account email and detailed description
- Attach screenshots if relevant
- Response within 24 hours

**Community Forums**
- Ask questions to other users
- Share solutions and tips
- Get help from power users
- Vote on feature requests

### Emergency Support
**Critical Issues**
- Account compromise or security concerns
- Payment/billing emergencies
- Data loss requiring immediate attention
- System-wide outages

**Priority Support (Pro Users)**
- Faster response times
- Direct phone support available
- Screen sharing and remote assistance
- Escalation to technical team`,

        "faq": `# Frequently Asked Questions

Comprehensive answers to the most common questions about ResumeFormatter.io features, usage, and troubleshooting.

## Getting Started

### What is ResumeFormatter.io?
ResumeFormatter.io is a modern resume builder that uses Markdown for editing, making it simple to create professional resumes with consistent formatting. Unlike traditional drag-and-drop builders, our platform focuses on content over complex formatting, ensuring your resume is both ATS-friendly and visually appealing.

### How is this different from other resume builders?
- **Markdown-based editing**: Focus on content, not formatting
- **ATS optimization**: All templates are ATS-friendly by design
- **Version control**: Track changes and maintain multiple versions
- **AI optimization**: Intelligent suggestions for content improvement
- **Developer-friendly**: Appeals to technical professionals

### Do I need to know Markdown to use this?
No! While Markdown knowledge helps, our editor provides:
- Live preview as you type
- Formatting toolbar for common elements
- Template starting points with sample content
- Automatic formatting suggestions
- Comprehensive help guides

### Is there a free version?
Yes! Our free plan includes:
- Up to 3 resumes
- Basic templates
- PDF export
- Basic AI suggestions
- Community support

## Account and Billing

### How much does the Pro version cost?
- **Monthly**: $9.99/month
- **Annual**: $99/year (17% savings)
- **Student**: 50% discount with valid .edu email
- **Team plans**: Volume discounts available

### What's included in the Pro plan?
- Unlimited resumes
- Premium templates
- Advanced AI optimization
- Priority customer support
- Advanced analytics
- Custom branding options
- Export in multiple formats

### Can I cancel anytime?
Yes, you can cancel your subscription at any time from your account settings. You'll retain Pro features until the end of your billing period, then automatically switch to the free plan.

### Do you offer refunds?
We offer a 30-day money-back guarantee for annual subscriptions. Monthly subscriptions are not refundable, but you can cancel to avoid future charges.

## Resume Creation and Editing

### How many resumes can I create?
- **Free plan**: Up to 3 resumes
- **Pro plan**: Unlimited resumes

### Can I import my existing resume?
Yes! You can:
- Upload PDF, DOCX, or plain text files
- Copy and paste from existing resumes
- Import from LinkedIn profile
- Convert from other resume builder exports

### What file formats can I export to?
- **PDF**: Best for applications and printing
- **DOCX**: For further editing in Microsoft Word
- **HTML**: For online portfolios and websites
- **Plain text**: For ATS systems that prefer text

### Are the templates ATS-friendly?
Yes, all our templates are designed with ATS compatibility in mind:
- Standard fonts and formatting
- Clear section headers
- Proper information hierarchy
- No complex graphics or layouts
- Tested with major ATS systems

## AI Features and Optimization

### How does the AI optimization work?
Our AI analyzes your resume content and job descriptions to:
- Suggest relevant keywords
- Improve action verbs and descriptions
- Identify missing sections or information
- Provide ATS compatibility scoring
- Recommend content improvements

### Is my data used to train AI models?
No, your personal resume data is never used to train AI models or shared with third parties. Our AI features process your content in real-time without storing personal information.

### How accurate is the ATS scoring?
Our ATS scoring is based on analysis of major ATS systems and hiring best practices. While we cannot guarantee specific outcomes, our optimization typically improves ATS compatibility by 15-30%.

### Can I customize the AI suggestions?
Yes, you can:
- Accept or reject individual suggestions
- Customize optimization preferences
- Set industry-specific parameters
- Save preferred writing styles

## Technical Questions

### What browsers do you support?
We support all modern browsers:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Is there a mobile app?
Yes! We have mobile apps for:
- iOS (iPhone and iPad)
- Android phones and tablets
- Responsive web app works on all devices

### Can I work offline?
The mobile apps support limited offline editing:
- Create and edit content offline
- Sync changes when connection returns
- Access cached templates and content
- Export requires internet connection

### Is my data secure?
Yes, we take security seriously:
- End-to-end encryption for all data
- SOC 2 Type II certified
- GDPR and CCPA compliant
- Regular security audits
- No data sharing with third parties

## Collaboration and Sharing

### Can I share my resume for feedback?
Yes! You can:
- Generate secure sharing links
- Set view-only or comment permissions
- Collect feedback directly on the document
- Track who viewed your resume

### Can multiple people edit the same resume?
Currently, we support:
- Feedback and comments from multiple users
- Version control for tracking changes
- Collaborative review workflows
- Team account management (Pro feature)

### How do I share my resume with employers?
You can:
- Export as PDF for email attachments
- Generate public links for online viewing
- Send directly through our email integration
- Download in employer's preferred format

## Templates and Customization

### How many templates are available?
We offer:
- **Free plan**: 5 basic templates
- **Pro plan**: 20+ premium templates
- Regular addition of new templates
- Industry-specific options
- Custom template creation (enterprise)

### Can I customize the templates?
Yes, customization options include:
- Color schemes and fonts
- Section ordering and content
- Spacing and layout adjustments
- Personal branding elements
- Custom CSS (advanced users)

### Can I create my own template?
Pro users can:
- Modify existing templates extensively
- Save custom template variations
- Share templates with team members
- Request custom templates from our design team

## Integration and Import/Export

### Do you integrate with LinkedIn?
Yes! You can:
- Import basic profile information
- Sync work experience and education
- Import skills and endorsements
- Keep profiles synchronized

### Can I integrate with job boards?
We're working on integrations with:
- Indeed
- LinkedIn Jobs
- AngelList
- Company career pages

### How do I backup my resumes?
Your resumes are automatically:
- Backed up to secure cloud storage
- Synchronized across all devices
- Available for bulk download
- Recoverable with version history

## Support and Help

### How do I get help?
Support options include:
- **Knowledge base**: Comprehensive articles and guides
- **Live chat**: Real-time support during business hours
- **Email support**: Detailed help via email
- **Community forums**: User-to-user assistance
- **Video tutorials**: Step-by-step guides

### What are your support hours?
- **Live chat**: Monday-Friday, 9 AM - 6 PM EST
- **Email support**: 24/7 (response within 24 hours)
- **Emergency support**: Available for critical issues
- **Pro users**: Priority support with faster response times

### Do you offer career coaching?
While we don't provide direct career coaching, we offer:
- Comprehensive resume writing guides
- Industry-specific templates and advice
- Job search strategy resources
- Partner integrations with career coaches

## Privacy and Data

### What data do you collect?
We collect only what's necessary:
- Account information (email, name)
- Resume content you create
- Usage analytics (anonymized)
- Payment information (securely processed)

### Can I delete my account and data?
Yes, you can:
- Delete your account at any time
- Request complete data deletion
- Export your data before deletion
- Receive confirmation of data removal

### Do you sell my data?
Never. We do not sell, rent, or share your personal data with third parties for marketing purposes. Your resume content remains private and confidential.

### Where is my data stored?
Your data is stored:
- In secure, encrypted cloud storage
- With multiple geographic backups
- In compliance with data protection laws
- With industry-standard security measures

## Troubleshooting

### My resume isn't saving
Try these steps:
1. Check your internet connection
2. Refresh the page and try again
3. Clear your browser cache
4. Try a different browser
5. Contact support if the issue persists

### The formatting looks wrong
This might be due to:
- Browser compatibility issues
- Cached content causing conflicts
- Template-specific formatting requirements
- Content that doesn't fit the template structure

### I can't access my account
Check these common issues:
- Verify you're using the correct email address
- Check if Caps Lock is on
- Try the "Forgot Password" feature
- Clear browser cache and cookies
- Contact support for account recovery

### Export isn't working
Common solutions:
- Check your internet connection
- Disable browser pop-up blockers
- Try a different export format
- Clear browser cache
- Contact support if the problem continues

## Feature Requests and Feedback

### How do I suggest new features?
You can:
- Submit ideas through our feedback form
- Vote on existing feature requests
- Participate in user surveys
- Join our beta testing program

### Do you accept template submissions?
Yes! We welcome:
- Template design submissions
- Industry-specific template ideas
- Accessibility improvement suggestions
- User experience enhancements

### How do I report bugs?
To report bugs:
1. Check if it's a known issue in our status page
2. Try reproducing the issue in incognito mode
3. Include browser, OS, and steps to reproduce
4. Submit through our bug report form
5. Include screenshots if helpful`
      };

      const content = articleContent[articleId as keyof typeof articleContent];
      if (!content) {
        return res.status(404).json({ message: "Article not found" });
      }

      const article = {
        id: articleId,
        content,
        lastUpdated: new Date().toISOString().split('T')[0]
      };

      res.json({
        success: true,
        data: article
      });
    } catch (error) {
      console.error("Error fetching article:", error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  // Register admin routes
  registerAdminRoutes(app);

  const httpServer = createServer(app);
  return httpServer;
}
