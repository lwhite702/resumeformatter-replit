-- Sample query to SELECT the 5 most recent cached posts
SELECT 
  id,
  wp_id,
  title,
  slug,
  excerpt,
  published_at,
  updated_at
FROM cached_posts 
ORDER BY published_at DESC 
LIMIT 5;

-- Query to get posts by specific date range
SELECT 
  title,
  slug,
  excerpt,
  published_at
FROM cached_posts 
WHERE published_at >= NOW() - INTERVAL '30 days'
ORDER BY published_at DESC;

-- Query to search posts by title or content
SELECT 
  title,
  slug,
  excerpt,
  published_at
FROM cached_posts 
WHERE title ILIKE '%search_term%' 
   OR content ILIKE '%search_term%'
ORDER BY published_at DESC;

-- Query to get cache statistics
SELECT 
  COUNT(*) as total_posts,
  MAX(published_at) as latest_post,
  MIN(published_at) as oldest_post,
  MAX(updated_at) as last_cache_update
FROM cached_posts;