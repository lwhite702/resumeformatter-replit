import { cacheWordPressPosts } from './cacheWpPosts';

// CRON job function for caching WordPress posts
// Schedule: Every 6 hours (0 */6 * * *)
export async function runWordPressCacheJob(): Promise<void> {
  console.log('🕐 Starting scheduled WordPress post cache job...');
  
  try {
    await cacheWordPressPosts();
    console.log('✅ Scheduled WordPress cache job completed successfully');
  } catch (error) {
    console.error('❌ Scheduled WordPress cache job failed:', error);
  }
}

// Example usage for manual execution or API endpoint
export async function triggerWordPressCache(): Promise<{ success: boolean; message: string }> {
  try {
    await cacheWordPressPosts();
    return {
      success: true,
      message: 'WordPress posts cached successfully'
    };
  } catch (error) {
    console.error('Cache trigger failed:', error);
    return {
      success: false,
      message: `Cache failed: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}