import {
  users,
  resumes,
  resumeVersions,
  coverLetters,
  optimizationHistory,
  apiIntegrations,
  exportHistory,
  newsletterSubscribers,
  prepPairTransfers,
  cachedPosts,
  featureFlags,
  adminLogs,
  knowledgeFiles,
  billingPlans,
  systemMetrics,
  type User,
  type UpsertUser,
  type InsertResume,
  type Resume,
  type InsertResumeVersion,
  type ResumeVersion,
  type InsertCoverLetter,
  type CoverLetter,
  type InsertOptimizationHistory,
  type OptimizationHistory,
  type ApiIntegration,
  type InsertApiIntegration,
  type ExportHistory,
  type InsertExportHistory,
  type NewsletterSubscriber,
  type InsertNewsletterSubscriber,
  type PrepPairTransfer,
  type InsertPrepPairTransfer,
  type CachedPost,
  type InsertCachedPost,
  type FeatureFlag,
  type InsertFeatureFlag,
  type AdminLog,
  type InsertAdminLog,
  type KnowledgeFile,
  type InsertKnowledgeFile,
  type BillingPlan,
  type InsertBillingPlan,
  type SystemMetric,
  type InsertSystemMetric,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserCredits(userId: string, credits: number): Promise<User>;
  updateUserPlan(userId: string, plan: string): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;

  // Resume operations
  getUserResumes(userId: string): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResume(id: number, updates: Partial<InsertResume>): Promise<Resume>;
  deleteResume(id: number): Promise<void>;

  // Resume version operations
  getResumeVersions(resumeId: number): Promise<ResumeVersion[]>;
  createResumeVersion(version: InsertResumeVersion): Promise<ResumeVersion>;
  getResumeVersion(id: number): Promise<ResumeVersion | undefined>;

  // Cover letter operations
  getUserCoverLetters(userId: string): Promise<CoverLetter[]>;
  createCoverLetter(coverLetter: InsertCoverLetter): Promise<CoverLetter>;
  updateCoverLetter(id: number, updates: Partial<InsertCoverLetter>): Promise<CoverLetter>;
  deleteCoverLetter(id: number): Promise<void>;

  // Optimization history operations
  createOptimizationHistory(optimization: InsertOptimizationHistory): Promise<OptimizationHistory>;
  getOptimizationHistory(resumeId: number): Promise<OptimizationHistory[]>;

  // Admin analytics operations
  getAnalytics(timeRange: string): Promise<any>;
  getUserStats(): Promise<any>;
  getRevenueStats(timeRange: string): Promise<any>;
  getActivityMetrics(): Promise<any>;

  // API integration operations
  getUserApiIntegrations(userId: string): Promise<ApiIntegration[]>;
  createApiIntegration(integration: InsertApiIntegration): Promise<ApiIntegration>;
  updateApiIntegration(id: number, updates: Partial<InsertApiIntegration>): Promise<ApiIntegration>;
  deleteApiIntegration(id: number): Promise<void>;
  getApiIntegrationByPlatform(userId: string, platform: string): Promise<ApiIntegration | undefined>;

  // Export history operations
  createExportHistory(exportData: InsertExportHistory): Promise<ExportHistory>;
  getUserExportHistory(userId: string): Promise<ExportHistory[]>;
  getResumeExportHistory(resumeId: number): Promise<ExportHistory[]>;
  updateExportStatus(id: number, status: string, externalId?: string, errorMessage?: string): Promise<ExportHistory>;

  // Newsletter operations
  createNewsletterSubscriber(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  getNewsletterSubscriber(email: string): Promise<NewsletterSubscriber | undefined>;
  updateNewsletterSubscriber(email: string, updates: Partial<InsertNewsletterSubscriber>): Promise<NewsletterSubscriber>;
  deleteNewsletterSubscriber(email: string): Promise<void>;
  getNewsletterStats(): Promise<any>;

  // PrepPair transfer operations
  createPrepPairTransfer(transfer: InsertPrepPairTransfer): Promise<PrepPairTransfer>;
  getPrepPairTransfers(userId: string): Promise<PrepPairTransfer[]>;
  updatePrepPairTransferStatus(id: number, status: string, prepPairUrl?: string, errorMessage?: string): Promise<PrepPairTransfer>;

  // Cached posts operations
  getCachedPosts(page?: number, perPage?: number): Promise<CachedPost[]>;
  getCachedPostBySlug(slug: string): Promise<CachedPost | undefined>;
  upsertCachedPost(post: InsertCachedPost): Promise<CachedPost>;

  // Admin feature flags operations
  getFeatureFlags(): Promise<FeatureFlag[]>;
  getFeatureFlagsByApp(app: string): Promise<FeatureFlag[]>;
  createFeatureFlag(flag: InsertFeatureFlag): Promise<FeatureFlag>;
  updateFeatureFlag(id: number, updates: Partial<InsertFeatureFlag>): Promise<FeatureFlag>;
  deleteFeatureFlag(id: number): Promise<void>;
  isFeatureEnabled(app: string, flagName: string, userPlan?: string): Promise<boolean>;

  // Admin logging operations
  createAdminLog(log: InsertAdminLog): Promise<AdminLog>;
  getAdminLogs(limit?: number): Promise<AdminLog[]>;

  // Knowledge file operations
  getKnowledgeFiles(app: string): Promise<KnowledgeFile[]>;
  getKnowledgeFile(id: number): Promise<KnowledgeFile | undefined>;
  createKnowledgeFile(file: InsertKnowledgeFile): Promise<KnowledgeFile>;
  updateKnowledgeFile(id: number, updates: Partial<InsertKnowledgeFile>): Promise<KnowledgeFile>;
  deleteKnowledgeFile(id: number): Promise<void>;

  // Billing plan operations
  getBillingPlans(): Promise<BillingPlan[]>;
  getBillingPlansByApp(app: string): Promise<BillingPlan[]>;
  createBillingPlan(plan: InsertBillingPlan): Promise<BillingPlan>;
  updateBillingPlan(id: number, updates: Partial<InsertBillingPlan>): Promise<BillingPlan>;
  deleteBillingPlan(id: number): Promise<void>;

  // System metrics operations
  createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric>;
  getSystemMetrics(app: string, metricName?: string, limit?: number): Promise<SystemMetric[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserCredits(userId: string, credits: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ credits, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserPlan(userId: string, plan: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ plan, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const updateData: any = { stripeCustomerId, updatedAt: new Date() };
    if (stripeSubscriptionId) {
      updateData.stripeSubscriptionId = stripeSubscriptionId;
    }
    
    const [user] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Resume operations
  async getUserResumes(userId: string): Promise<Resume[]> {
    return await db
      .select()
      .from(resumes)
      .where(and(eq(resumes.userId, userId), eq(resumes.isActive, true)))
      .orderBy(desc(resumes.updatedAt));
  }

  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const [created] = await db.insert(resumes).values(resume).returning();
    return created;
  }

  async updateResume(id: number, updates: Partial<InsertResume>): Promise<Resume> {
    const [updated] = await db
      .update(resumes)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(resumes.id, id))
      .returning();
    return updated;
  }

  async deleteResume(id: number): Promise<void> {
    await db.update(resumes).set({ isActive: false }).where(eq(resumes.id, id));
  }

  // Resume version operations
  async getResumeVersions(resumeId: number): Promise<ResumeVersion[]> {
    return await db
      .select()
      .from(resumeVersions)
      .where(eq(resumeVersions.resumeId, resumeId))
      .orderBy(desc(resumeVersions.createdAt));
  }

  async createResumeVersion(version: InsertResumeVersion): Promise<ResumeVersion> {
    const [created] = await db.insert(resumeVersions).values(version).returning();
    return created;
  }

  async getResumeVersion(id: number): Promise<ResumeVersion | undefined> {
    const [version] = await db.select().from(resumeVersions).where(eq(resumeVersions.id, id));
    return version;
  }

  // Cover letter operations
  async getUserCoverLetters(userId: string): Promise<CoverLetter[]> {
    return await db
      .select()
      .from(coverLetters)
      .where(eq(coverLetters.userId, userId))
      .orderBy(desc(coverLetters.updatedAt));
  }

  async createCoverLetter(coverLetter: InsertCoverLetter): Promise<CoverLetter> {
    const [created] = await db.insert(coverLetters).values(coverLetter).returning();
    return created;
  }

  async updateCoverLetter(id: number, updates: Partial<InsertCoverLetter>): Promise<CoverLetter> {
    const [updated] = await db
      .update(coverLetters)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(coverLetters.id, id))
      .returning();
    return updated;
  }

  async deleteCoverLetter(id: number): Promise<void> {
    await db.delete(coverLetters).where(eq(coverLetters.id, id));
  }

  // Optimization history operations
  async createOptimizationHistory(optimization: InsertOptimizationHistory): Promise<OptimizationHistory> {
    const [created] = await db.insert(optimizationHistory).values(optimization).returning();
    return created;
  }

  async getOptimizationHistory(resumeId: number): Promise<OptimizationHistory[]> {
    return await db
      .select()
      .from(optimizationHistory)
      .where(eq(optimizationHistory.resumeId, resumeId))
      .orderBy(desc(optimizationHistory.createdAt));
  }

  // Admin analytics operations
  async getAnalytics(timeRange: string): Promise<any> {
    const now = new Date();
    let startDate = new Date();
    
    switch (timeRange) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    // Get user growth data
    const userGrowth = await db
      .select({
        date: sql<string>`DATE(${users.createdAt})`,
        count: count()
      })
      .from(users)
      .where(sql`${users.createdAt} >= ${startDate}`)
      .groupBy(sql`DATE(${users.createdAt})`)
      .orderBy(sql`DATE(${users.createdAt})`);

    // Get resume creation data
    const resumeCreation = await db
      .select({
        date: sql<string>`DATE(${resumes.createdAt})`,
        count: count()
      })
      .from(resumes)
      .where(sql`${resumes.createdAt} >= ${startDate}`)
      .groupBy(sql`DATE(${resumes.createdAt})`)
      .orderBy(sql`DATE(${resumes.createdAt})`);

    // Get optimization usage
    const optimizations = await db
      .select({
        date: sql<string>`DATE(${optimizationHistory.createdAt})`,
        count: count()
      })
      .from(optimizationHistory)
      .where(sql`${optimizationHistory.createdAt} >= ${startDate}`)
      .groupBy(sql`DATE(${optimizationHistory.createdAt})`)
      .orderBy(sql`DATE(${optimizationHistory.createdAt})`);

    return {
      userGrowth,
      resumeCreation,
      optimizations,
      timeRange
    };
  }

  async getUserStats(): Promise<any> {
    // Total users
    const [totalUsersResult] = await db
      .select({ count: count() })
      .from(users);

    // Pro users
    const [proUsersResult] = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.plan, 'pro'));

    // Free users
    const [freeUsersResult] = await db
      .select({ count: count() })
      .from(users)
      .where(sql`${users.plan} IS NULL OR ${users.plan} = 'free'`);

    // Active users (users who created resumes in last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const [activeUsersResult] = await db
      .selectDistinct({ count: count(resumes.userId) })
      .from(resumes)
      .where(sql`${resumes.createdAt} >= ${thirtyDaysAgo}`);

    return {
      totalUsers: totalUsersResult.count,
      proUsers: proUsersResult.count,
      freeUsers: freeUsersResult.count,
      activeUsers: activeUsersResult.count
    };
  }

  async getRevenueStats(timeRange: string): Promise<any> {
    const now = new Date();
    let startDate = new Date();
    
    switch (timeRange) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    // Get pro subscriptions by date
    const subscriptions = await db
      .select({
        date: sql<string>`DATE(${users.updatedAt})`,
        count: count()
      })
      .from(users)
      .where(sql`${users.plan} = 'pro' AND ${users.updatedAt} >= ${startDate}`)
      .groupBy(sql`DATE(${users.updatedAt})`)
      .orderBy(sql`DATE(${users.updatedAt})`);

    // Calculate estimated revenue (assuming $3.99 per pro user)
    const revenue = subscriptions.map(sub => ({
      ...sub,
      revenue: sub.count * 3.99
    }));

    return {
      subscriptions,
      revenue,
      timeRange
    };
  }

  async getActivityMetrics(): Promise<any> {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    // Active users in last 24 hours
    const [activeUsers24h] = await db
      .selectDistinct({ count: count(resumes.userId) })
      .from(resumes)
      .where(sql`${resumes.updatedAt} >= ${oneDayAgo}`);

    // New signups in last 7 days
    const [newSignups7d] = await db
      .select({ count: count() })
      .from(users)
      .where(sql`${users.createdAt} >= ${sevenDaysAgo}`);

    // Resumes created in last 7 days
    const [resumesCreated7d] = await db
      .select({ count: count() })
      .from(resumes)
      .where(sql`${resumes.createdAt} >= ${sevenDaysAgo}`);

    // AI optimizations in last 7 days
    const [optimizations7d] = await db
      .select({ count: count() })
      .from(optimizationHistory)
      .where(sql`${optimizationHistory.createdAt} >= ${sevenDaysAgo}`);

    // Total resumes
    const [totalResumes] = await db
      .select({ count: count() })
      .from(resumes);

    // Total credits used (sum of all optimizations)
    const [totalCreditsUsed] = await db
      .select({ count: count() })
      .from(optimizationHistory);

    return {
      activeUsers24h: activeUsers24h.count,
      newSignups7d: newSignups7d.count,
      resumesCreated7d: resumesCreated7d.count,
      optimizations7d: optimizations7d.count,
      totalResumes: totalResumes.count,
      totalCreditsUsed: totalCreditsUsed.count
    };
  }

  // API integration operations
  async getUserApiIntegrations(userId: string): Promise<ApiIntegration[]> {
    return await db
      .select()
      .from(apiIntegrations)
      .where(eq(apiIntegrations.userId, userId))
      .orderBy(desc(apiIntegrations.createdAt));
  }

  async createApiIntegration(integration: InsertApiIntegration): Promise<ApiIntegration> {
    const [created] = await db
      .insert(apiIntegrations)
      .values(integration)
      .returning();
    return created;
  }

  async updateApiIntegration(id: number, updates: Partial<InsertApiIntegration>): Promise<ApiIntegration> {
    const [updated] = await db
      .update(apiIntegrations)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(apiIntegrations.id, id))
      .returning();
    return updated;
  }

  async deleteApiIntegration(id: number): Promise<void> {
    await db.delete(apiIntegrations).where(eq(apiIntegrations.id, id));
  }

  async getApiIntegrationByPlatform(userId: string, platform: string): Promise<ApiIntegration | undefined> {
    const [integration] = await db
      .select()
      .from(apiIntegrations)
      .where(and(
        eq(apiIntegrations.userId, userId),
        eq(apiIntegrations.platform, platform),
        eq(apiIntegrations.isActive, true)
      ));
    return integration;
  }

  // Export history operations
  async createExportHistory(exportData: InsertExportHistory): Promise<ExportHistory> {
    const [created] = await db
      .insert(exportHistory)
      .values(exportData)
      .returning();
    return created;
  }

  async getUserExportHistory(userId: string): Promise<ExportHistory[]> {
    return await db
      .select()
      .from(exportHistory)
      .where(eq(exportHistory.userId, userId))
      .orderBy(desc(exportHistory.createdAt));
  }

  async getResumeExportHistory(resumeId: number): Promise<ExportHistory[]> {
    return await db
      .select()
      .from(exportHistory)
      .where(eq(exportHistory.resumeId, resumeId))
      .orderBy(desc(exportHistory.createdAt));
  }

  async updateExportStatus(id: number, status: string, externalId?: string, errorMessage?: string): Promise<ExportHistory> {
    const [updated] = await db
      .update(exportHistory)
      .set({ 
        status, 
        externalId, 
        errorMessage 
      })
      .where(eq(exportHistory.id, id))
      .returning();
    return updated;
  }

  // Newsletter operations
  async createNewsletterSubscriber(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber> {
    const unsubscribeToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const [created] = await db
      .insert(newsletterSubscribers)
      .values({
        ...subscriber,
        unsubscribeToken
      })
      .returning();
    return created;
  }

  async getNewsletterSubscriber(email: string): Promise<NewsletterSubscriber | undefined> {
    const [subscriber] = await db
      .select()
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.email, email));
    return subscriber;
  }

  async updateNewsletterSubscriber(email: string, updates: Partial<InsertNewsletterSubscriber>): Promise<NewsletterSubscriber> {
    const [updated] = await db
      .update(newsletterSubscribers)
      .set(updates)
      .where(eq(newsletterSubscribers.email, email))
      .returning();
    return updated;
  }

  async deleteNewsletterSubscriber(email: string): Promise<void> {
    await db.delete(newsletterSubscribers).where(eq(newsletterSubscribers.email, email));
  }

  async getNewsletterStats(): Promise<any> {
    const [totalSubscribers] = await db
      .select({ count: count() })
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.status, "active"));

    const [newSubscribers7d] = await db
      .select({ count: count() })
      .from(newsletterSubscribers)
      .where(
        and(
          eq(newsletterSubscribers.status, "active"),
          sql`${newsletterSubscribers.subscriptionDate} > NOW() - INTERVAL '7 days'`
        )
      );

    return {
      totalSubscribers: totalSubscribers.count,
      newSubscribers7d: newSubscribers7d.count
    };
  }

  // PrepPair transfer operations
  async createPrepPairTransfer(transfer: InsertPrepPairTransfer): Promise<PrepPairTransfer> {
    const [newTransfer] = await db
      .insert(prepPairTransfers)
      .values(transfer)
      .returning();
    return newTransfer;
  }

  async getPrepPairTransfers(userId: string): Promise<PrepPairTransfer[]> {
    return await db.select()
      .from(prepPairTransfers)
      .where(eq(prepPairTransfers.userId, userId))
      .orderBy(desc(prepPairTransfers.transferredAt));
  }

  async updatePrepPairTransferStatus(id: number, status: string, prepPairUrl?: string, errorMessage?: string): Promise<PrepPairTransfer> {
    const [updatedTransfer] = await db
      .update(prepPairTransfers)
      .set({
        transferStatus: status,
        prepPairUrl,
        errorMessage,
      })
      .where(eq(prepPairTransfers.id, id))
      .returning();
    return updatedTransfer;
  }

  // Cached posts operations
  async getCachedPosts(page: number = 1, perPage: number = 10): Promise<CachedPost[]> {
    const offset = (page - 1) * perPage;
    const posts = await db
      .select()
      .from(cachedPosts)
      .orderBy(desc(cachedPosts.publishedAt))
      .limit(perPage)
      .offset(offset);
    return posts;
  }

  async getCachedPostBySlug(slug: string): Promise<CachedPost | undefined> {
    const [post] = await db
      .select()
      .from(cachedPosts)
      .where(eq(cachedPosts.slug, slug));
    return post;
  }

  async upsertCachedPost(post: InsertCachedPost): Promise<CachedPost> {
    const [upsertedPost] = await db
      .insert(cachedPosts)
      .values(post)
      .onConflictDoUpdate({
        target: cachedPosts.wpId,
        set: {
          title: post.title,
          slug: post.slug,
          excerpt: post.excerpt,
          content: post.content,
          publishedAt: post.publishedAt,
          updatedAt: new Date(),
        },
      })
      .returning();
    return upsertedPost;
  }

  // Admin feature flags operations
  async getFeatureFlags(): Promise<FeatureFlag[]> {
    return await db.select()
      .from(featureFlags)
      .orderBy(featureFlags.app, featureFlags.name);
  }

  async getFeatureFlagsByApp(app: string): Promise<FeatureFlag[]> {
    return await db.select()
      .from(featureFlags)
      .where(eq(featureFlags.app, app))
      .orderBy(featureFlags.name);
  }

  async createFeatureFlag(flag: InsertFeatureFlag): Promise<FeatureFlag> {
    const [newFlag] = await db
      .insert(featureFlags)
      .values(flag)
      .returning();
    return newFlag;
  }

  async updateFeatureFlag(id: number, updates: Partial<InsertFeatureFlag>): Promise<FeatureFlag> {
    const [updatedFlag] = await db
      .update(featureFlags)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(featureFlags.id, id))
      .returning();
    return updatedFlag;
  }

  async deleteFeatureFlag(id: number): Promise<void> {
    await db.delete(featureFlags).where(eq(featureFlags.id, id));
  }

  async isFeatureEnabled(app: string, flagName: string, userPlan?: string): Promise<boolean> {
    const [flag] = await db.select()
      .from(featureFlags)
      .where(and(
        eq(featureFlags.app, app),
        eq(featureFlags.name, flagName)
      ));

    if (!flag || !flag.enabled) {
      return false;
    }

    // Check plan requirement
    if (flag.planRequired && userPlan) {
      return userPlan === flag.planRequired || userPlan.startsWith('pro');
    }

    return true;
  }

  // Admin logging operations
  async createAdminLog(log: InsertAdminLog): Promise<AdminLog> {
    const [newLog] = await db
      .insert(adminLogs)
      .values(log)
      .returning();
    return newLog;
  }

  async getAdminLogs(limit: number = 100): Promise<AdminLog[]> {
    return await db.select()
      .from(adminLogs)
      .orderBy(desc(adminLogs.createdAt))
      .limit(limit);
  }

  // Knowledge file operations
  async getKnowledgeFiles(app: string): Promise<KnowledgeFile[]> {
    return await db.select()
      .from(knowledgeFiles)
      .where(eq(knowledgeFiles.app, app))
      .orderBy(desc(knowledgeFiles.updatedAt));
  }

  async getKnowledgeFile(id: number): Promise<KnowledgeFile | undefined> {
    const [file] = await db.select()
      .from(knowledgeFiles)
      .where(eq(knowledgeFiles.id, id));
    return file;
  }

  async createKnowledgeFile(file: InsertKnowledgeFile): Promise<KnowledgeFile> {
    const [newFile] = await db
      .insert(knowledgeFiles)
      .values(file)
      .returning();
    return newFile;
  }

  async updateKnowledgeFile(id: number, updates: Partial<InsertKnowledgeFile>): Promise<KnowledgeFile> {
    const [updatedFile] = await db
      .update(knowledgeFiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(knowledgeFiles.id, id))
      .returning();
    return updatedFile;
  }

  async deleteKnowledgeFile(id: number): Promise<void> {
    await db.delete(knowledgeFiles).where(eq(knowledgeFiles.id, id));
  }

  // Billing plan operations
  async getBillingPlans(): Promise<BillingPlan[]> {
    return await db.select()
      .from(billingPlans)
      .orderBy(billingPlans.app, billingPlans.sortOrder);
  }

  async getBillingPlansByApp(app: string): Promise<BillingPlan[]> {
    return await db.select()
      .from(billingPlans)
      .where(eq(billingPlans.app, app))
      .orderBy(billingPlans.sortOrder);
  }

  async createBillingPlan(plan: InsertBillingPlan): Promise<BillingPlan> {
    const [newPlan] = await db
      .insert(billingPlans)
      .values(plan)
      .returning();
    return newPlan;
  }

  async updateBillingPlan(id: number, updates: Partial<InsertBillingPlan>): Promise<BillingPlan> {
    const [updatedPlan] = await db
      .update(billingPlans)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(billingPlans.id, id))
      .returning();
    return updatedPlan;
  }

  async deleteBillingPlan(id: number): Promise<void> {
    await db.delete(billingPlans).where(eq(billingPlans.id, id));
  }

  // System metrics operations
  async createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric> {
    const [newMetric] = await db
      .insert(systemMetrics)
      .values(metric)
      .returning();
    return newMetric;
  }

  async getSystemMetrics(app: string, metricName?: string, limit: number = 100): Promise<SystemMetric[]> {
    if (metricName) {
      return await db.select()
        .from(systemMetrics)
        .where(and(
          eq(systemMetrics.app, app),
          eq(systemMetrics.metricName, metricName)
        ))
        .orderBy(desc(systemMetrics.recordedAt))
        .limit(limit);
    }

    return await db.select()
      .from(systemMetrics)
      .where(eq(systemMetrics.app, app))
      .orderBy(desc(systemMetrics.recordedAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
