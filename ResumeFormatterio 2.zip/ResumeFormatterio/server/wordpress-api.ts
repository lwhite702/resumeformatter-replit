export interface WordPressPost {
  id: number;
  date: string;
  slug: string;
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  author: number;
  featured_media: number;
  categories: number[];
  tags: number[];
  _links: {
    self: Array<{ href: string }>;
    collection: Array<{ href: string }>;
    about: Array<{ href: string }>;
    author: Array<{ embeddable: boolean; href: string }>;
    replies: Array<{ embeddable: boolean; href: string }>;
    "version-history": Array<{ count: number; href: string }>;
    "predecessor-version": Array<{ id: number; href: string }>;
    "wp:attachment": Array<{ href: string }>;
    "wp:term": Array<{ taxonomy: string; embeddable: boolean; href: string }>;
    curies: Array<{ name: string; href: string; templated: boolean }>;
  };
}

export interface WordPressCategory {
  id: number;
  count: number;
  description: string;
  link: string;
  name: string;
  slug: string;
}

export interface WordPressMedia {
  id: number;
  date: string;
  slug: string;
  type: string;
  link: string;
  title: {
    rendered: string;
  };
  author: number;
  media_details: {
    width: number;
    height: number;
    file: string;
    sizes: {
      [key: string]: {
        file: string;
        width: number;
        height: number;
        mime_type: string;
        source_url: string;
      };
    };
  };
  source_url: string;
}

export class WordPressAPI {
  private baseURL = 'https://wrelikbrands.com/wp-json/wp/v2';

  private async makeRequest(url: string): Promise<Response> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
      
      const fetchOptions: RequestInit = {
        headers: {
          'User-Agent': 'ResumeFormatter.io/1.0',
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        },
        signal: controller.signal
      };

      // Handle SSL issues in development
      if (process.env.NODE_ENV === 'development') {
        // @ts-ignore - Node.js specific option
        fetchOptions.agent = false;
      }
      
      const response = await fetch(url, fetchOptions);
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return response;
    } catch (error) {
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error(`Request timeout for ${url}`);
        }
        console.error(`WordPress API request failed for ${url}:`, error.message);
      }
      throw error;
    }
  }

  async getPosts(page = 1, perPage = 10): Promise<WordPressPost[]> {
    try {
      const url = `${this.baseURL}/posts?page=${page}&per_page=${perPage}&_fields=id,title,slug,excerpt,content,date`;
      const response = await this.makeRequest(url);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
      }
      
      const posts = await response.json();
      return Array.isArray(posts) ? posts : [];
    } catch (error) {
      console.error('Error fetching WordPress posts:', error);
      throw error;
    }
  }

  async getPost(slug: string): Promise<WordPressPost | null> {
    try {
      const url = `${this.baseURL}/posts?slug=${slug}&_fields=id,title,slug,excerpt,content,date`;
      const response = await this.makeRequest(url);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
      }
      
      const posts = await response.json();
      return Array.isArray(posts) && posts.length > 0 ? posts[0] : null;
    } catch (error) {
      console.error('Error fetching WordPress post:', error);
      throw error;
    }
  }

  async getCategories(): Promise<WordPressCategory[]> {
    try {
      const url = `${this.baseURL}/categories?_fields=id,count,description,link,name,slug`;
      const response = await this.makeRequest(url);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
      }
      
      const categories = await response.json();
      return Array.isArray(categories) ? categories : [];
    } catch (error) {
      console.error('Error fetching WordPress categories:', error);
      throw error;
    }
  }

  async getFeaturedImage(mediaId: number): Promise<string | null> {
    try {
      const url = `${this.baseURL}/media/${mediaId}?_fields=source_url`;
      const response = await this.makeRequest(url);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status} ${response.statusText}`);
      }
      
      const media: WordPressMedia = await response.json();
      return media.source_url || null;
    } catch (error) {
      console.error('Error fetching WordPress media:', error);
      throw error;
    }
  }

  // Extract table of contents from post content
  extractTableOfContents(content: string): Array<{ id: string; text: string; level: number }> {
    const headingRegex = /<h([1-6])[^>]*>(.*?)<\/h[1-6]>/gi;
    const toc: Array<{ id: string; text: string; level: number }> = [];
    let match;

    while ((match = headingRegex.exec(content)) !== null) {
      const level = parseInt(match[1]);
      const text = match[2].replace(/<[^>]*>/g, '').trim();
      const id = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-');
      
      toc.push({ id, text, level });
    }

    return toc;
  }

  // Add IDs to headings in content for anchor links
  addHeadingIds(content: string): string {
    return content.replace(/<h([1-6])([^>]*)>(.*?)<\/h[1-6]>/gi, (match, level, attrs, text) => {
      const cleanText = text.replace(/<[^>]*>/g, '').trim();
      const id = cleanText.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-');
      return `<h${level}${attrs} id="${id}">${text}</h${level}>`;
    });
  }

  // Get related posts based on categories
  async getRelatedPosts(postId: number, categories: number[], limit = 3): Promise<WordPressPost[]> {
    try {
      const categoryParams = categories.join(',');
      const response = await fetch(`${this.baseURL}/posts?categories=${categoryParams}&exclude=${postId}&per_page=${limit}&_embed`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching related posts:', error);
      return [];
    }
  }
}

export const wordpressAPI = new WordPressAPI();