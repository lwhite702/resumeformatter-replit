import {
  pgTable,
  serial,
  integer,
  text,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

export const cachedPosts = pgTable(
  "cached_posts",
  {
    id: serial("id").primaryKey(),
    wpId: integer("wp_id").unique().notNull(),
    title: text("title").notNull(),
    slug: text("slug").notNull(),
    excerpt: text("excerpt"),
    content: text("content"),
    publishedAt: timestamp("published_at").notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_cached_posts_wp_id").on(table.wpId),
    index("idx_cached_posts_published_at").on(table.publishedAt),
    index("idx_cached_posts_slug").on(table.slug),
  ]
);

export type CachedPost = typeof cachedPosts.$inferSelect;
export type InsertCachedPost = typeof cachedPosts.$inferInsert;