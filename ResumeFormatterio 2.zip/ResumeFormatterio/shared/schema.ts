import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  plan: varchar("plan").default("free").notNull(), // free, pro
  credits: integer("credits").default(2).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resume table
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(), // Markdown content
  templateId: varchar("template_id").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Resume versions/snapshots
export const resumeVersions = pgTable("resume_versions", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  name: text("name").notNull(),
  description: text("description"),
  content: text("content").notNull(),
  templateId: varchar("template_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cover letters
export const coverLetters = pgTable("cover_letters", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  resumeId: integer("resume_id").references(() => resumes.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  jobTitle: text("job_title"),
  company: text("company"),
  tone: varchar("tone").default("formal").notNull(), // formal, friendly, executive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// AI optimization history
export const optimizationHistory = pgTable("optimization_history", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  jobDescription: text("job_description"),
  atsScore: integer("ats_score"),
  suggestions: jsonb("suggestions").notNull(), // Array of improvement suggestions
  appliedSuggestions: jsonb("applied_suggestions"), // Which suggestions were applied
  creditsUsed: integer("credits_used").default(3),
  createdAt: timestamp("created_at").defaultNow(),
});

// API integrations table for tracking external platform connections
export const apiIntegrations = pgTable("api_integrations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  platform: varchar("platform").notNull(), // preppair, linkedin, etc.
  apiKey: text("api_key"), // encrypted API key
  apiEndpoint: varchar("api_endpoint"), // custom endpoint URL
  isActive: boolean("is_active").default(true),
  lastSync: timestamp("last_sync"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Export history table for tracking resume exports to external platforms
export const exportHistory = pgTable("export_history", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  platform: varchar("platform").notNull(), // preppair, linkedin, etc.
  exportFormat: varchar("export_format").notNull(), // json, pdf, markdown
  status: varchar("status").default("pending").notNull(), // pending, success, failed
  externalId: varchar("external_id"), // ID from external platform
  exportUrl: text("export_url"), // URL to view exported resume
  errorMessage: text("error_message"),
  metadata: jsonb("metadata"), // Additional export data
  createdAt: timestamp("created_at").defaultNow(),
});

// Newsletter subscribers table
export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  source: varchar("source", { length: 50 }).default("website"),
  subscriptionDate: timestamp("subscription_date").defaultNow().notNull(),
  unsubscribeToken: varchar("unsubscribe_token", { length: 255 }).unique(),
  tags: text("tags").array(),
  metadata: jsonb("metadata"),
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  resumes: many(resumes),
  coverLetters: many(coverLetters),
  optimizationHistory: many(optimizationHistory),
  apiIntegrations: many(apiIntegrations),
  exportHistory: many(exportHistory),
}));

export const resumeRelations = relations(resumes, ({ one, many }) => ({
  user: one(users, {
    fields: [resumes.userId],
    references: [users.id],
  }),
  versions: many(resumeVersions),
  optimizationHistory: many(optimizationHistory),
  coverLetters: many(coverLetters),
  exportHistory: many(exportHistory),
}));

export const resumeVersionRelations = relations(resumeVersions, ({ one }) => ({
  resume: one(resumes, {
    fields: [resumeVersions.resumeId],
    references: [resumes.id],
  }),
}));

export const coverLetterRelations = relations(coverLetters, ({ one }) => ({
  user: one(users, {
    fields: [coverLetters.userId],
    references: [users.id],
  }),
  resume: one(resumes, {
    fields: [coverLetters.resumeId],
    references: [resumes.id],
  }),
}));

export const optimizationHistoryRelations = relations(optimizationHistory, ({ one }) => ({
  user: one(users, {
    fields: [optimizationHistory.userId],
    references: [users.id],
  }),
  resume: one(resumes, {
    fields: [optimizationHistory.resumeId],
    references: [resumes.id],
  }),
}));

export const apiIntegrationRelations = relations(apiIntegrations, ({ one }) => ({
  user: one(users, {
    fields: [apiIntegrations.userId],
    references: [users.id],
  }),
}));

export const exportHistoryRelations = relations(exportHistory, ({ one }) => ({
  user: one(users, {
    fields: [exportHistory.userId],
    references: [users.id],
  }),
  resume: one(resumes, {
    fields: [exportHistory.resumeId],
    references: [resumes.id],
  }),
}));

// Feature flags table for admin settings
export const featureFlags = pgTable("feature_flags", {
  id: serial("id").primaryKey(),
  app: varchar("app").notNull(), // ResumeFormatter.io, PrepPair.me, etc.
  name: varchar("name").notNull(),
  description: text("description"),
  enabled: boolean("enabled").default(false),
  planRequired: varchar("plan_required"), // free, pro_monthly, pro_quarterly
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Admin activity logs
export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminId: varchar("admin_id").notNull(),
  action: varchar("action").notNull(), // feature_flag_updated, plan_modified, etc.
  entityType: varchar("entity_type").notNull(), // feature_flag, billing_plan, user
  entityId: varchar("entity_id"),
  oldValue: jsonb("old_value"),
  newValue: jsonb("new_value"),
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Knowledge file versions for admin docs
export const knowledgeFiles = pgTable("knowledge_files", {
  id: serial("id").primaryKey(),
  app: varchar("app").notNull(),
  title: varchar("title").notNull(),
  content: text("content").notNull(), // Markdown content
  version: integer("version").default(1),
  authorId: varchar("author_id").notNull(),
  isPublished: boolean("is_published").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Billing plan configurations
export const billingPlans = pgTable("billing_plans", {
  id: serial("id").primaryKey(),
  app: varchar("app").notNull(),
  planKey: varchar("plan_key").notNull(), // free, pro_monthly, pro_quarterly
  stripePriceId: varchar("stripe_price_id"),
  displayName: varchar("display_name").notNull(),
  description: text("description"),
  price: integer("price"), // in cents
  currency: varchar("currency").default("usd"),
  interval: varchar("interval"), // month, year
  featuresIncluded: jsonb("features_included"), // array of feature names
  isVisible: boolean("is_visible").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// System health metrics
export const systemMetrics = pgTable("system_metrics", {
  id: serial("id").primaryKey(),
  app: varchar("app").notNull(),
  metricName: varchar("metric_name").notNull(),
  metricValue: jsonb("metric_value").notNull(),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertResumeSchema = createInsertSchema(resumes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertResumeVersionSchema = createInsertSchema(resumeVersions).omit({
  id: true,
  createdAt: true,
});

export const insertCoverLetterSchema = createInsertSchema(coverLetters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOptimizationHistorySchema = createInsertSchema(optimizationHistory).omit({
  id: true,
  createdAt: true,
});

export const insertApiIntegrationSchema = createInsertSchema(apiIntegrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertExportHistorySchema = createInsertSchema(exportHistory).omit({
  id: true,
  createdAt: true,
});

export const insertNewsletterSubscriberSchema = createInsertSchema(newsletterSubscribers).omit({
  id: true,
  subscriptionDate: true,
  unsubscribeToken: true,
});

export const insertFeatureFlagSchema = createInsertSchema(featureFlags).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({
  id: true,
  createdAt: true,
});

export const insertKnowledgeFileSchema = createInsertSchema(knowledgeFiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBillingPlanSchema = createInsertSchema(billingPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  recordedAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type Resume = typeof resumes.$inferSelect;
export type InsertResumeVersion = z.infer<typeof insertResumeVersionSchema>;
export type ResumeVersion = typeof resumeVersions.$inferSelect;
export type InsertCoverLetter = z.infer<typeof insertCoverLetterSchema>;
export type CoverLetter = typeof coverLetters.$inferSelect;
export type InsertOptimizationHistory = z.infer<typeof insertOptimizationHistorySchema>;
export type OptimizationHistory = typeof optimizationHistory.$inferSelect;
export type InsertApiIntegration = z.infer<typeof insertApiIntegrationSchema>;
export type ApiIntegration = typeof apiIntegrations.$inferSelect;
export type InsertExportHistory = z.infer<typeof insertExportHistorySchema>;
export type ExportHistory = typeof exportHistory.$inferSelect;
export type InsertNewsletterSubscriber = z.infer<typeof insertNewsletterSubscriberSchema>;
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertFeatureFlag = z.infer<typeof insertFeatureFlagSchema>;
export type FeatureFlag = typeof featureFlags.$inferSelect;
export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;
export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertKnowledgeFile = z.infer<typeof insertKnowledgeFileSchema>;
export type KnowledgeFile = typeof knowledgeFiles.$inferSelect;
export type InsertBillingPlan = z.infer<typeof insertBillingPlanSchema>;
export type BillingPlan = typeof billingPlans.$inferSelect;
export type InsertSystemMetric = z.infer<typeof insertSystemMetricSchema>;
export type SystemMetric = typeof systemMetrics.$inferSelect;

// PrepPair transfer history table
export const prepPairTransfers = pgTable("preppair_transfers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  resumeId: integer("resume_id").notNull().references(() => resumes.id),
  transferStatus: varchar("transfer_status").notNull(), // pending, success, failed
  transferToken: varchar("transfer_token"), // JWT token used for transfer
  prepPairUrl: varchar("preppair_url"), // Interview prep URL from PrepPair
  errorMessage: varchar("error_message"),
  transferredAt: timestamp("transferred_at").defaultNow(),
});

export const insertPrepPairTransferSchema = createInsertSchema(prepPairTransfers).omit({
  id: true,
  transferredAt: true,
});

export type InsertPrepPairTransfer = z.infer<typeof insertPrepPairTransferSchema>;
export type PrepPairTransfer = typeof prepPairTransfers.$inferSelect;

// Blog posts cache table
export const cachedPosts = pgTable(
  "cached_posts",
  {
    id: serial("id").primaryKey(),
    wpId: integer("wp_id").unique().notNull(),
    title: text("title").notNull(),
    slug: text("slug").notNull(),
    excerpt: text("excerpt"),
    content: text("content"),
    publishedAt: timestamp("published_at").notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("idx_cached_posts_wp_id").on(table.wpId),
    index("idx_cached_posts_published_at").on(table.publishedAt),
    index("idx_cached_posts_slug").on(table.slug),
  ]
);

export const insertCachedPostSchema = createInsertSchema(cachedPosts).omit({
  id: true,
  updatedAt: true,
});

export type CachedPost = typeof cachedPosts.$inferSelect;
export type InsertCachedPost = z.infer<typeof insertCachedPostSchema>;
